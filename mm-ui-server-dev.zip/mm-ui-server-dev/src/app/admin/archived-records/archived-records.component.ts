import { Component, OnInit, ViewChild } from '@angular/core';
import { ArchiveService } from '../services/archive.service';
import { MatPaginator, MatSort, MatDialog, MatDialogConfig, MatTableDataSource, PageEvent,Sort } from '@angular/material';
import { ArchiveModel } from 'app/models/archive.model';
import { ViewInfoComponent } from 'app/shared/view-info/view-info.component';
import{ActivatedRoute,Router}from'@angular/router';
import { DataService } from 'app/services/data.service';
import { CommonApiService } from 'app/services/common-api.service';
import { HelperService } from 'app/services/helper.service';

export interface status {
  value: string;
  viewValue: string;
  status: string;
}

@Component({
  selector: 'app-archived-records',
  templateUrl: './archived-records.component.html',
  styleUrls: ['./archived-records.component.scss']
})
export class ArchivedRecordsComponent implements OnInit {

  public selectedRow: ArchiveModel;
  public  displayedColumns:string[]=['id','origin', 'vendorName', 'containerType', 'itemType','quantityType', 'qaNotified', 'recipientNotified', 'createdBy', 'createdAt','receivableDate', 'status','action']
  public dataSource = new MatTableDataSource();
  public receiptStatus: any = [];
  public paginate:any = {};
  public pageEvent: PageEvent;
  public pageSizeOptions: number[] = [5, 10, 15];
  public totalRecords:number;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(private archiveService: ArchiveService, private dialog: MatDialog,private route:ActivatedRoute,
    private router:Router,public dataSrv : DataService,private commonSrv:CommonApiService,private helperSrv:HelperService ){
      this.receiptStatus= this.dataSrv.STATUS.RECEIPT;
    }
  ngOnInit() {
    this.defaultPaginateArchive();
  }

  /**OPEN view info **/
  openViewMode(selectedRow: ArchiveModel) {
    this.selectedRow = selectedRow
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.data = {
      'selectedValue': this.selectedRow,
      'tableColumns': this.displayedColumns,
      'columnName': ['Receipt No', 'Origin', 'Vendor', 'Container Type', 'Item Type','Quantity Type', 'Qa Notified', 'Recipient Notified', 'Created By', 'Created At', 'Receivable Date',"Status"],
      "component": "Archived Record",
      "mode": true
    };
    let dialogRef = this.dialog.open(ViewInfoComponent, dialogConfig);
  };
   /** Set Default Params */
   defaultPaginateArchive() {
    let reqParams = this.commonSrv.createParam(this.paginate);
    this.router.navigate([], { queryParams: reqParams });
    this.dataSource= new MatTableDataSource(this.route.snapshot.data['archive'].body);
    this.totalRecords = this.route.snapshot.data['archive'].headers.get('X-Total-Count');  
    this.paginateArchive(false,this.dataSrv.STATUS.SHIPPED);
   }
   paginateArchive(setPage = true,status){
     if (setPage) this.paginate.page = 0;
     let reqParams = this.commonSrv.createParam(this.paginate);
     this.router.navigate([],{ queryParams : reqParams });
     this.archiveService.getAllReceivablesByStatus(status,reqParams).subscribe(res=>{
       this.dataSource= new MatTableDataSource(res.body);
       this.totalRecords = res.headers.get('X-Total-Count');
     })
    }
     /** On change Page */
  onChangePage(event?: PageEvent) {
   this.paginate.size = event.pageSize;
   this.paginate.page = event.pageIndex;
   this.paginateArchive(false,this.dataSrv.STATUS.SHIPPED);
   return event;
  }
  /*Sorting*/
  sortData(event: Sort) {
    this.paginate.sort = event.active + ',' + event.direction;
    this.paginateArchive(false,this.dataSrv.STATUS.SHIPPED);    
  }
    /** SEARCH Receivable */
    search(filter) {
      this.archiveService.searchReceivable(this.dataSrv.STATUS.SHIPPED,filter).subscribe(res => {
         this.dataSource = new MatTableDataSource(res.body);
          })
    }
       /** Filter Value */  
  applyFilter(filter?:any){
    if(filter.length>2){
     this.search(filter);    
    }
    if(filter.length==0){
      this.paginateArchive(false,this.dataSrv.STATUS.SHIPPED);
    }
   }
}
