import { Routes } from '@angular/router';
import { UserManagementComponent } from './user-management/user-management.component';
import { AuditLogComponent } from '../audit-log/audit-log/audit-log.component';
import { ArchivedRecordsComponent } from './archived-records/archived-records.component';
import { RoomsComponent } from './configuration/rooms/rooms.component';
import { RoomTempShelvingComponent } from './configuration/storage-types/room-temp-shelving/room-temp-shelving.component';
import { FreezersComponent } from './configuration/storage-types/freezers/freezers.component';
import { IncubatorComponent } from './configuration/storage-types/incubator/incubator.component';
import { RefrigeratorComponent } from './configuration/storage-types/refrigerator/refrigerator.component';
import { LabelsComponent } from './labels/labels.component';
import { AdvSearchComponent } from '../adv-search/adv-search.component';
import { ArchiveResolver } from './services/archive.resolver';
import { UserResolver } from './services/user.resolver';
import { RoomResolver } from './services/room.resolver';
import { IncubatorResolver } from './services/incubators.resolver';
import { OpenShelvingResolver } from './services/open-shel.resolver';
import { RefrigeratorResolver } from './services/refrigerator.resolver';
import { FreezerResolver } from './services/freezer.resolver';
import { ReviewerManagementComponent } from 'app/reviewer/reviewer-management/reviewer-management.component';
import { ReviewerResolver } from 'app/reviewer/reviewer.resolver';
import { RowsComponent } from './configuration/storage-types/rows/rows.component';
import{RoomRowResolver} from './services/room-rows.resolver';

export const AdminRoutes: Routes = [
  {
    path: '',
    redirectTo: 'admin',
    pathMatch: 'full',
  }, {
    path: '',
    children: [{
      path: 'user-management',
      component: UserManagementComponent,
      resolve:{user:UserResolver},
        data:{
          params:{
            page:0,
            size:10,
            sort:'creationAt,DESC',
          }
        }
    },  {
      path:'reviewer-management',
      component:ReviewerManagementComponent,
      resolve: {reviewers: ReviewerResolver},
      data:{
        params:{
          page:0,
          size:10,
          sort:'creationAt,DESC',
        }
      }
    }, 
    {
      path: 'archive',
      component: ArchivedRecordsComponent,
      resolve:{archive:ArchiveResolver},
      data:{
        params:{
          page:0,
          size:10,
          sort:'createdAt,DESC',
        }
      }
    }, {
      path: 'configuration',
      children: [{
        path: 'room',
        component: RoomsComponent,
        resolve:{rooms:RoomResolver},
        data:{
          params:{
            page:0,
            size:10,
            sort:'createdAt,DESC',
          }
        }
      }, {
        path: 'storage-types',
        children: [
          {
            path: 'room-temp-shelving',
            component: RoomTempShelvingComponent,
            resolve:{ 'open-shelving': OpenShelvingResolver },
            data:{
              params:{
                page:0,
                size:10,        
                sort:'createdAt,DESC',

              }
            }
          },
          {
            path: 'freezers',
            component: FreezersComponent,
            resolve:{ freezers: FreezerResolver },
            data:{
              params:{
                page:0,
                size:10,
                sort:'createdAt,DESC',
              }
            }
          },
          {
            path: 'incubators',
            component: IncubatorComponent,
            resolve:{ incubators:IncubatorResolver },
            data:{
              params:{
                page:0,
                size:10,
                sort:'createdAt,DESC',
              }
            }
          },
          {
            path: 'refrigerator',
            component: RefrigeratorComponent,
            resolve:{ refrigerator:RefrigeratorResolver },
            data:{
              params:{
                page:0,
                size:10,
                sort:'CreatedAt,DESC',
              }
            }
          },{
            path: 'rows',
            component:RowsComponent,
            resolve:{ roomRows:RoomRowResolver },
            data:{
              params:{
                page:0,
                size:10,
                sort: 'seqId,DESC',
              }
            }
          }
        ]
      }
      ]
    },
    {
      path: 'labels',
      component: LabelsComponent
    },
    ]
  }];
