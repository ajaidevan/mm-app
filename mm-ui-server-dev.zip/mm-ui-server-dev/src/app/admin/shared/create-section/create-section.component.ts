import { Component, OnInit, Inject, Input, Output } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { FormGroup, FormControl, Validators, FormGroupDirective, NgForm, FormBuilder, FormArray } from '@angular/forms';
import { ErrorStateMatcher } from '@angular/material/core';
import { HelperService } from '../../../services/helper.service';
import { StorageService } from '../../services/storage.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { StorageModel } from 'app/models/storage.model';
import { ValidatorService } from 'app/services/validator.service';

export class MyErrorStateMatcher implements ErrorStateMatcher {

  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = form && form.submitted;
    return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
  }

}

@Component({
  selector: 'app-create-section',
  templateUrl: './create-section.component.html',
  styleUrls: ['./create-section.component.scss']
})

export class CreateSectionComponent implements OnInit {

  public statusTypes: any[] = ['N/A', 'Quarantine', 'Release', 'Reject'];
  public sections: FormArray;
  public sectionsArray: any[] = [];
  public matcher = new MyErrorStateMatcher();
  public editMode: boolean = false;
  public availablesections: any;
  public viewShelf: Array<StorageModel>;
  public availableSeqId:number[]=[];
  public addedItem:boolean = false;
  public clicked=false;

  // @Input() shelfData: Array<StorageModel>;


  constructor(private dialogRef: MatDialogRef<CreateSectionComponent>, @Inject(MAT_DIALOG_DATA) public dialogData: any,
    private helper: HelperService, private formBuilder: FormBuilder,
    private storageSrv: StorageService,private validatorService:ValidatorService,
    private spinnerService: Ng4LoadingSpinnerService) {
    this.sections = this.sectionDiagForm.get('sections') as FormArray;
  }

  ngOnInit() {
    this.storageSrv.sharedSection.distinctUntilChanged().subscribe(data => {
      if (data) {
        this.sectionDiagForm.patchValue(data);
        this.sections.at(0).get('statusType').clearValidators();
        this.sections.at(0).get('statusType').updateValueAndValidity();
        this.editMode = true;
      }
    });
    this.sectionsArray = this.sectionDiagForm.get('sections').value;
    this.getAvailableSeqIds();
  }

  // Section Form
  public sectionDiagForm = this.formBuilder.group({
    id: this.formBuilder.control(''),    
    name: this.formBuilder.control(''),
    statusType: this.formBuilder.control(''),
    seqId: this.formBuilder.control(''),
    sections: this.formBuilder.array([this.createItem()],Validators.required),

  });

  // Get Available Sequence IDS
  public getAvailableSeqIds(){
    if (this.dialogData.type === 'incubator' && ('shelve' in this.dialogData))
      this.storageSrv.getSeqIdsForIncSection(this.dialogData.shelve.id).subscribe(res=>{ this.availableSeqId = res.body});
    if (this.dialogData.type === 'open-shelf')
      this.storageSrv.getSeqIdsForOsSection(this.dialogData.shelve.id).subscribe(res=>{ this.availableSeqId = res.body});
    if (this.dialogData.refType == '+5 WalkIn')
      this.storageSrv.getSeqIdsForRefSection(this.dialogData.shelve.id).subscribe(res=>{ this.availableSeqId = res.body});
    if (this.dialogData.freezerType == 'Walk In')
      this.storageSrv.getSeqIdsForFreezerSection(this.dialogData.shelve.id).subscribe(res=>{ this.availableSeqId = res.body});
  }

  /** form array **/
  createItem(): FormGroup {
    return this.formBuilder.group({
      name: this.formBuilder.control(''),
      seqId: this.formBuilder.control(''),
      isReUsed:this.formBuilder.control(false),
      statusType: this.formBuilder.control('', [ Validators.required])
    });
  }

  /** ADD Field **/
  addItem(): void {
    this.addedItem = true;    
    this.sections = this.sectionDiagForm.get('sections') as FormArray;
    this.sections.push(this.createItem());
    this.sectionsArray = this.sections.value;
  }


  /** REMOVE chips **/
  removeItem(index): void {
    if (index != 0) {
      this.sections = this.sectionDiagForm.get('sections') as FormArray;
      this.sections.removeAt(index);
      this.sectionsArray.splice(index, 1);
    }
  }

  // Re Use
  reUse(mainIndex) {
    var arrayControl = this.sectionDiagForm.get('sections') as FormArray;
    this.sectionsArray[mainIndex].isReUsed = !this.sectionsArray[mainIndex].isReUsed;
    this.sectionDiagForm.get('sections').patchValue(this.sectionsArray);
    arrayControl.at(mainIndex).get('seqId').clearValidators();
    arrayControl.at(mainIndex).get('seqId').updateValueAndValidity();
    arrayControl.at(mainIndex).get('seqId').patchValue('');
  }

  /** DESTROY editmode **/
  ngOnDestroy() {
    this.editMode = false;
  }

  /** CREATE a Section **/
  create() {
    this.validatorService.userValidator(this.editMode?'update':'create').then(res => {
      if(res.val) {
      let sectionObj = this.sectionDiagForm.value;
      this.clicked=false;
      sectionObj['locationId']=this.helper.getLocation();
      delete res.val;
      if (this.sectionDiagForm.valid) {      
        if (this.editMode) {
          delete sectionObj.sections;
          if (this.dialogData.type === 'incubator' && ('shelve' in this.dialogData)) this.updateSectionForIncubator(sectionObj,res);
          if (this.dialogData.type === 'open-shelf' && ('shelve' in this.dialogData)) this.updateSectionForOs(sectionObj,res);
          if (this.dialogData.refType == '+5 WalkIn') this.updateSectionForRefregerator(sectionObj,res);
          if (this.dialogData.freezerType == 'Walk In') this.updateSectionForFreezer(sectionObj,res);
        } else {
          delete sectionObj["id"];
          let generatedSections = this.generateSections(sectionObj);
          if (this.dialogData.type === 'incubator' && ('shelve' in this.dialogData) ) this.addSectionForIncubator(generatedSections,res);
          if (this.dialogData.type === 'open-shelf'  && ('shelve' in this.dialogData)) this.addSectionForOs(generatedSections,res);
          if (this.dialogData.refType == '+5 WalkIn') this.addSectionForRefregerator(generatedSections,res);
          if (this.dialogData.freezerType == 'Walk In') this.addSectionForFreezer(generatedSections,res);
        }
      }
    }
   })
  }

  // Generate  sections
  generateSections(sectionObj) {
    for (let i = 0; i < sectionObj.sections.length; i++) {
      sectionObj.sections[i].name = 'Section'; 
      if (this.dialogData.type === 'incubator' && ('shelve' in this.dialogData)) { 
        sectionObj.sections[i].incubatorId = this.dialogData.id;
        sectionObj.sections[i].incRowId = this.dialogData.row.id;
        sectionObj.sections[i].incRackId = this.dialogData.rack.id;
        sectionObj.sections[i].incShelfId = this.dialogData.shelve.id;
      }
      if (this.dialogData.type === 'open-shelf') { 
        sectionObj.sections[i].openStorageId = this.dialogData.id;
        sectionObj.sections[i].osRackId = this.dialogData.rack.id;
        sectionObj.sections[i].osShelfId = this.dialogData.shelve.id;
      }
      if (this.dialogData.freezerType == 'Walk In') {
        sectionObj.sections[i].freezerId = this.dialogData.id;
        sectionObj.sections[i].freezerRowId = this.dialogData.row.id;
        sectionObj.sections[i].freezerRackId = this.dialogData.rack.id;
        sectionObj.sections[i].freezerShelfId = this.dialogData.shelve.id;
      }
      if (this.dialogData.refType == '+5 WalkIn') { 
        sectionObj.sections[i].refId = this.dialogData.id;
        sectionObj.sections[i].refRowId = this.dialogData.row.id;
        sectionObj.sections[i].refRackId = this.dialogData.rack.id;
        sectionObj.sections[i].refShelfId = this.dialogData.shelve.id;
      }
    }
    return sectionObj.sections;
  }

  // Add Section For Incubator
  addSectionForIncubator(sections,res) {
    this.storageSrv._addRequest(this.dialogData,this.dialogData.shelve.id, sections,res).subscribe(data => {
      this.helper.showSnackbar('Successfully Created Section!');
      this.dialogRef.close(this.sectionDiagForm.value);
      this.storageSrv.setSharedSection(data);
      this.spinnerService.hide();
    }, err => {
       this.helper.showSnackbar(err.error.message,false,true);
    })
  }

  // Update Section For Incubator
  updateSectionForIncubator(sectionObj,res) {
    sectionObj.incubatorId = this.dialogData.id;
    sectionObj.incRowId = this.dialogData.row.id;
    sectionObj.incRackId = this.dialogData.rack.id;
    sectionObj.incShelfId = this.dialogData.shelve.id;
    this.storageSrv._updateRequest(this.dialogData,sectionObj,res).subscribe(data => {
      this.helper.showSnackbar('Successfully Updated Section !');
      this.dialogRef.close(this.sectionDiagForm.value);
      this.storageSrv.setSharedSection(data);
      this.spinnerService.hide();
    },err => {
      this.helper.showSnackbar(err.error.message,false,true);
   })
  }

 // Add Section For Open Shelving
  addSectionForOs(section,res) {
    this.storageSrv._addRequest(this.dialogData,this.dialogData.shelve.id, section,res).subscribe(data => {
      this.helper.showSnackbar('Successfully Created Section!');
      this.dialogRef.close(this.sectionDiagForm.value);
      this.storageSrv.setSharedSection(data);
      this.spinnerService.hide();
    }, err => {
       this.helper.showSnackbar(err.error.message,false,true);
    })
  }

  // Update Section For Open Shelving
  updateSectionForOs(sectionObj,res) {
    sectionObj.openStorageId = this.dialogData.id;
    sectionObj.osRackId = this.dialogData.rack.id;
    sectionObj.osShelfId = this.dialogData.shelve.id;
    this.storageSrv._updateRequest(this.dialogData,sectionObj,res).subscribe(data => {
      this.helper.showSnackbar('Successfully Updated Section !');
      this.dialogRef.close(this.sectionDiagForm.value);
      this.storageSrv.setSharedSection(data);
      this.spinnerService.hide();
    },err => {
      this.helper.showSnackbar(err.error.message,false,true);
   })
  }

  // Add Section For Freezer
  addSectionForFreezer(sections,res) {
    this.storageSrv._addRequest(this.dialogData,this.dialogData.shelve.id, sections,res).subscribe(data => {
      this.helper.showSnackbar('Successfully Created Section!');
      this.dialogRef.close(this.sectionDiagForm.value);
      this.storageSrv.setSharedSection(data);
      this.spinnerService.hide();
    }, err => {
       this.helper.showSnackbar(err.error.message,false,true);
    })
  }

  // Update Section For Freezer
  updateSectionForFreezer(sectionObj,res) {
    sectionObj.freezerId = this.dialogData.id;
    sectionObj.freezerRowId = this.dialogData.row.id;
    sectionObj.freezerRackId = this.dialogData.rack.id;
    sectionObj.freezerShelfId = this.dialogData.shelve.id;
    this.storageSrv._updateRequest(this.dialogData,sectionObj,res).subscribe(data => {
      this.helper.showSnackbar('Successfully Updated Section !');
      this.dialogRef.close(this.sectionDiagForm.value);
      this.storageSrv.setSharedSection(data);
      this.spinnerService.hide();
    },err => {
      this.helper.showSnackbar(err.error.message,false,true);
   })
  }

  // Add Section For Refrigerator
  addSectionForRefregerator(section,res) {
    this.storageSrv._addRequest(this.dialogData,this.dialogData.shelve.id, section,res).subscribe(data => {
      this.helper.showSnackbar('Successfully Created Section!');
      this.dialogRef.close(this.sectionDiagForm.value);
      this.storageSrv.setSharedSection(data);
      this.spinnerService.hide();
    }, err => {
       this.helper.showSnackbar(err.error.message,false,true);
    })
  }

  // Update Section For Refrigerator
  updateSectionForRefregerator(sectionObj,res) {
    sectionObj.refId = this.dialogData.id;
    sectionObj.refRowId = this.dialogData.row.id;
    sectionObj.refRackId = this.dialogData.rack.id;
    sectionObj.refShelfId = this.dialogData.shelve.id;
    this.storageSrv._updateRequest(this.dialogData,sectionObj,res).subscribe(data => {
      this.helper.showSnackbar('Successfully Updated Section !');
      this.dialogRef.close(this.sectionDiagForm.value);
      this.storageSrv.setSharedSection(data);
      this.spinnerService.hide();
    },err => {
      this.helper.showSnackbar(err.error.message,false,true);
   })
  }

  /** CLOSE mat dialog **/
  close() {
    this.dialogRef.close(null);
  }

}
