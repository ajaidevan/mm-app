import { Component, OnInit, Input, Output, EventEmitter, ViewChild } from '@angular/core';
import { MatPaginator, MatSort, MatDialog, MatDialogConfig, MatTableDataSource, PageEvent, Sort } from '@angular/material';
import { StorageService } from '../../services/storage.service';
import { StorageModel } from '../../../models/storage.model';
import { CreateRackComponent } from '../create-rack/create-rack.component';
import { CommonApiService } from 'app/services/common-api.service';
import { Router } from '@angular/router';
import { ValidatorService } from 'app/services/validator.service';
import { CreateShelveComponent } from '../create-shelve/create-shelve.component';
import { CreateSlotComponent } from '../create-slot/create-slot.component';
import { EventService } from 'app/admin/services/event.service';
import { HelperService } from 'app/services/helper.service';

@Component({
  selector: 'app-view-rack',
  templateUrl: './view-rack.component.html',
  styleUrls: ['./view-rack.component.scss']
})
export class ViewRackComponent implements OnInit {

  public displayedColumns: string[] = ['name', 'status_type', 'action'];
  public displayedColumnsRef: string[] = ['name', 'status_type', 'grid_type', 'action'];
  public gridTypes: any[] = [{ value: 'SEVEN', name: '7x7' }, { value: 'NINE', name: '9x9' }, { value: 'TEN', name: '10x10' }, { value: 'ARROW_HEAD', name: 'ARROW HEAD' }];
  public viewMode: boolean = true;
  public dataSource = new MatTableDataSource();
  public dataInfo: any;
  public data: any;
  public selectedInfo: Array<StorageModel> = [];
  public paginate: any = {};
  public totalShelves: number;
  public editMode: boolean;
  public pageEvent: PageEvent;

  @Input() viewInfo: Array<StorageModel>;
  @Output() viewEvent = new EventEmitter();
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(private storageSrv: StorageService, private dialog: MatDialog, private eventSrv: EventService,
    private commonSrv: CommonApiService, private router: Router, private validatorSrv: ValidatorService,private helper:HelperService) { }

  ngOnInit() {
    this.dataInfo = this.viewInfo;
    this.eventSrv.rackEventListner().subscribe(viewMode => { this.viewMode = viewMode; });
    this.setDefaultParams();
    this.refreshShelves();
    this.refreshSlots();
  }

  //refresh shelves for racks.
  refreshShelves() {
    this.storageSrv.sharedShelve.distinctUntilChanged().subscribe(data => {
      if (data) {
        this.setDefaultParams();
        this.editMode = true;
      } else {
        this.setDefaultParams();
      }
    });
  }

  //refresh slots for racks.
  refreshSlots() {
    this.storageSrv.sharedSlot.distinctUntilChanged().subscribe(data => {
      if (data) {
        this.setDefaultParams();
        this.editMode = true;
      } else {
        this.setDefaultParams();
      }
    });
  }

  //View Mode
  receivedViewMode($event) {
    this.viewMode = $event;
  }

  //Go Back
  goBack() {
    this.viewEvent.emit(this.viewMode);
  }

  // Go to main storage
  gotoMainStorage() {
    if (this.viewInfo[0].type == 'incubator') this.eventSrv.emitIncEvent(true);
    if (this.viewInfo[0].type === 'open-shelf') this.eventSrv.emitOpenShelfEvent(true);
    if (this.viewInfo[0].type == 'refrigerator') this.eventSrv.emitRefEvent(true);
    if (this.viewInfo[0].type == 'freezer') this.eventSrv.emitRefEvent(true);
  }

  /** go To RACK **/
  gotoRack(data) {
    this.viewMode = false;
    this.selectedInfo = this.viewInfo;
  }

  /** go To Section **/
  gotoSection(data) {
    this.viewMode = false;
    this.viewInfo[0].shelve = data;
    this.selectedInfo = this.viewInfo;
  }

  // Get Max Grid Type
  getMaxGridType(row) {
    let resp = this.gridTypes.filter(elem => elem.value === row.gridType)
    return resp[0];
  }

  // Set Default Param
  setDefaultParams() {
    this.paginate = {
      page: 0,
      size: 10,
      sort: 'seqId,ASC',
    }
    this.paginateShelve(false);
    this.paginateSlots(false);
  }

  /** Paginate Shelfs */
  paginateShelve(setPage = true) {
    if (setPage) this.paginate.page = 0;
    let reqParams = this.commonSrv.createParam(this.paginate);
    this.router.navigate([], { queryParams: reqParams });
    if (this.viewInfo[0].incType == 'Walk In') this.getShelvesForIncByRackId(reqParams);
    if (this.viewInfo[0].type === 'open-shelf') this.getShelvesForOsByRackId(reqParams);
    if (this.viewInfo[0].refType == '+5 WalkIn') this.getShelvesForRefByRackId(reqParams);
    if (this.viewInfo[0].freezerType == 'Walk In') this.getShelvesForFreezerByRackId(reqParams);
  }

  /** Paginate Slots */
  paginateSlots(setPage = true) {
    if (setPage) this.paginate.page = 0;
    let reqParams = this.commonSrv.createParam(this.paginate);
    this.router.navigate([], { queryParams: reqParams });
    if (this.viewInfo[0].refType === '+5 Chest' || this.viewInfo[0].refType == '+5 Upright') this.getSlotsForRefByRackId(reqParams);
    if (this.viewInfo[0].freezerType === 'LN2' || this.viewInfo[0].freezerType === 'Ultra-Low Chest' || this.viewInfo[0].freezerType === 'Freezer Chest') this.getSlotsForFreezerByRackId(reqParams);
    if (this.viewInfo[0].freezerType === 'Ultra-Low Upright' || this.viewInfo[0].freezerType === 'Freezer Upright') this.getSlotForFreezerShelveByRackId(reqParams)
  }

  /** Onchange Page **/
  onChangePage(event?: PageEvent) {
    this.paginate.size = event.pageSize;
    this.paginate.page = event.pageIndex;
    this.paginateSlots(false);
    this.paginateShelve(false);
    return event;
  }

  // Get Shelve For Incubator By Rack ID
  getShelvesForIncByRackId(reqParams) {
    this.viewInfo[0].storageType='Inc-Rack-Shelf'
    this.storageSrv._getRequest(this.viewInfo[0],this.viewInfo[0].rack.id, reqParams).subscribe(res => {
      this.dataSource.data = res.body;
      this.totalShelves = res.headers.get('X-Total-Count');
    })
  }

  // Get Shelve For OS By Rack ID
  getShelvesForOsByRackId(reqParams) {
    this.viewInfo[0].storageType='Os-Rack-Shelf'
    this.storageSrv._getRequest(this.viewInfo[0],this.viewInfo[0].rack.id, reqParams).subscribe(res => {
      this.dataSource.data = res.body;
      this.totalShelves = res.headers.get('X-Total-Count');
    })
  }

  // Get Shelve For Refrigerator By Rack ID
  getShelvesForRefByRackId(reqParams) {
    this.viewInfo[0].storageType='Ref-Rack-Shelf';
    this.storageSrv._getRequest(this.viewInfo[0],this.viewInfo[0].rack.id, reqParams).subscribe(res => {
      this.dataSource.data = res.body;
      this.totalShelves = res.headers.get('X-Total-Count');
    })
  }

  // Get Shelve For Freezer By Rack ID
  getShelvesForFreezerByRackId(reqParams) {
    this.viewInfo[0].storageType='Freezer-Rack-Shelve';
    this.storageSrv._getRequest(this.viewInfo[0],this.viewInfo[0].rack.id, reqParams).subscribe(res => {
      this.dataSource.data = res.body;
      this.totalShelves = res.headers.get('X-Total-Count');
    })
  }

  // Get Slot For Refrigerator By Rack ID
  getSlotsForRefByRackId(reqParams) {
    this.viewInfo[0].storageType='Ref-Rack-Slot'
    this.storageSrv._getRequest(this.viewInfo[0],this.viewInfo[0].rack.id, reqParams).subscribe(res => {
      this.dataSource.data = res.body;
      this.totalShelves = res.headers.get('X-Total-Count');
    })
  }

  // Get Slot For Freezer By Rack ID
  getSlotsForFreezerByRackId(reqParams) {
    this.viewInfo[0].storageType='Freezer-Rack-Slot'
    this.storageSrv._getRequest(this.viewInfo[0],this.viewInfo[0].rack.id, reqParams).subscribe(res => {
      this.dataSource.data = res.body;
      this.totalShelves = res.headers.get('X-Total-Count');
    })
  }

  // Get Slot For Freezer Shelve By Rack ID
  getSlotForFreezerShelveByRackId(reqParams) {
    this.viewInfo[0].storageType='Freezer-Rack-Slot'
    this.storageSrv._getRequest(this.viewInfo[0],this.viewInfo[0].rack.id, reqParams).subscribe(res => {
      this.dataSource.data = res.body;
      this.totalShelves = res.headers.get('X-Total-Count');
    })
  }


  /** open CREATE Shelf **/
  openCreateShelve(newData?): void {
    if (newData) {
      this.storageSrv.setSharedShelve(newData);
    } else {
      this.storageSrv.setSharedShelve("");
    }
    let dialogRef = this.dialog.open(CreateShelveComponent, {
      width: '700px',
      data: this.viewInfo[0]
    });
  }

  /** open CREATE Slot **/
  openCreateSlot(newData?): void {
    if (newData) {
      this.storageSrv.setSharedSlot(newData);
    } else {
      this.storageSrv.setSharedSlot("");
    }
    let dialogRef = this.dialog.open(CreateSlotComponent, {
      width: '700px',
      data: this.viewInfo[0]
    });
  }

  /** DELETE rack **/
  onDelete(row, index) {
    this.validatorSrv.userValidator('delete').then(res => {
      if (res.val) {
        delete res.val;
        if (this.viewInfo[0].type === 'incubator' && this.viewInfo[0].incType == 'Walk In') this.deleteShelveForIncubatorRows(row, index,res);
        if (this.viewInfo[0].type === 'open-shelf') this.deleteRackForOsRows(row, index,res);
        if (this.viewInfo[0].refType == '+5 WalkIn') this.deleteShelfForRefRows(row, index,res);
        if (this.viewInfo[0].refType === '+5 Chest' || this.viewInfo[0].refType == '+5 Upright') this.deleteSlotForRef(row, index,res);
        if (this.viewInfo[0].freezerType === 'Walk In') this.deleteShelfForFreezer(row, index,res);
        if (this.viewInfo[0].freezerType === 'LN2' || this.viewInfo[0].freezerType === 'Ultra-Low Chest' || this.viewInfo[0].freezerType === 'Freezer Chest') this.deleteSlotForFreezer(row, index,res);
        if (this.viewInfo[0].freezerType === 'Ultra-Low Upright' || this.viewInfo[0].freezerType === 'Freezer Upright') this.deleteSlotForFreezerByRack(row, index,res);
      }
    },err=>{
        this
    }).catch(err => {
      console.error("Delete Openshelving Failed", err);
    });
  }

  //Delete Shelve For Incubator Row
  deleteShelveForIncubatorRows(shelve, index, res) {
    this.storageSrv._deleteRequest(this.viewInfo[0],shelve, res).subscribe(data => {
      let shelveData = this.dataSource.data;
      shelveData.splice(Number(index), 1);
      this.dataSource.data = shelveData;
      this.totalShelves = shelveData.length;
    },err=>{
       this.helper.showSnackbar(err.error.message,false,true);
      });
  }

  //Delete Rack For OS Row
  deleteRackForOsRows(Shelf, index,res) {
    this.storageSrv._deleteRequest(this.viewInfo[0],Shelf,res).subscribe(data => {
      let shelveData = this.dataSource.data;
      shelveData.splice(Number(index), 1);
      this.dataSource.data = shelveData;
      this.totalShelves = shelveData.length;
    },err=>{
       this.helper.showSnackbar(err.error.message,false,true);
      });
  }

  //Delete Shelve For Refrigerator Row
  deleteShelfForRefRows(Shelf, index,res) {
    this.storageSrv._deleteRequest(this.viewInfo[0],Shelf,res).subscribe(data => {
      let shelveData = this.dataSource.data;
      shelveData.splice(Number(index), 1);
      this.dataSource.data = shelveData;
      this.totalShelves = shelveData.length;
    },err=>{
        this.helper.showSnackbar(err.error.message,false,true);
      });
  }

  //Delete Shelve For Freezer
  deleteShelfForFreezer(Shelf, index, res) {
    this.storageSrv._deleteRequest(this.viewInfo[0],Shelf, res).subscribe(data => {
      let shelveData = this.dataSource.data;
      shelveData.splice(Number(index), 1);
      this.dataSource.data = shelveData;
      this.totalShelves = shelveData.length;
    },err=>{
       this.helper.showSnackbar(err.error.message,false,true);
      });
  }

  //Delete Slot For Refrigerator
  deleteSlotForRef(rack, index, res) {
    this.storageSrv._deleteRequest(this.viewInfo[0],rack, res).subscribe(data => {
      let shelveData = this.dataSource.data;
      shelveData.splice(Number(index), 1);
      this.dataSource.data = shelveData;
      this.totalShelves = shelveData.length;
    },err=>{
       this.helper.showSnackbar(err.error.message,false,true);
      });
  }

  //Delete Slot For Freeer
  deleteSlotForFreezer(rack, index, res) {
    this.storageSrv._deleteRequest(this.viewInfo[0],rack, res).subscribe(data => {
      let shelveData = this.dataSource.data;
      shelveData.splice(Number(index), 1);
      this.dataSource.data = shelveData;
      this.totalShelves = shelveData.length;
    },err=>{
       this.helper.showSnackbar(err.error.message,false,true);
      });
  }

  //Delete Slot For Freezer By Rack ID
  deleteSlotForFreezerByRack(rack, index, res) {
    this.storageSrv._deleteRequest(this.viewInfo[0],rack, res).subscribe(data => {
      let shelveData = this.dataSource.data;
      shelveData.splice(Number(index), 1);
      this.dataSource.data = shelveData;
      this.totalShelves = shelveData.length;
    },err=>{
       this.helper.showSnackbar(err.error.message,false,true);
      });
  }

  //Search Shelves For Incubator Rack Id
  searchShelvesForIncByRackId(filterValue?: any) {
    this.storageSrv.searchShelvesForIncByRackId(this.viewInfo[0].rack.id, filterValue).subscribe(res => {
      this.dataSource.data = res.body;
    })
  }

  //Search Shelves For OS Rack Id
  searchShelvesForOsByRackId(filterValue?: any) {
    this.storageSrv.searchShelvesForOsByRackId(this.viewInfo[0].rack.id, filterValue).subscribe(res => {
      this.dataSource.data = res.body;
    })
  }

  //Search Slot For Refrigerator Rack Id
  searchSlotsForRefByRackId(filterValue?: any) {
    this.storageSrv.searchSlotsForRefByRackId(this.viewInfo[0].rack.id, filterValue).subscribe(res => {
      this.dataSource.data = res.body;
    })
  }

  //Search Shelves For Refrigerator Rack Id
  searchShelvesForRefByRackId(filterValue?: any) {
    this.storageSrv.searchShelvesForRefByRackId(this.viewInfo[0].rack.id, filterValue).subscribe(res => {
      this.dataSource.data = res.body;
    })
  }

  //Search Slot For Shelve Freezer Rack Id
  searchSlotForShelveFreezerByRackId(filterValue?: any) {
    this.storageSrv.searchSlotForShelveFreezerByRackId(this.viewInfo[0].rack.id, filterValue).subscribe(res => {
      this.dataSource.data = res.body;
    })
  }

  //Search Slot For Freezer Rack Id
  searchSlotForFreezerByRackId(filterValue?: any) {
    this.storageSrv.searchSlotForFreezerByRackId(this.viewInfo[0].rack.id, filterValue).subscribe(res => {
      this.dataSource.data = res.body;
    })
  }

  //Search Shelve For Freezer Row By Rack Id
  searchShelveForFreezerRowByRackId(filterValue?: any) {
    this.storageSrv.searchShelveForFreezerRowByRackId(this.viewInfo[0].rack.id, filterValue).subscribe(res => {
      this.dataSource.data = res.body;
    })
  }

  //Filter Slot For Shelve Freezer Rack Id
  filterSlotForShelveFreezerByRackId(filter?: any) {
    if (filter.length > 0) this.searchSlotForShelveFreezerByRackId(filter);
    if (filter.length == 0) this.getSlotForFreezerShelveByRackId(false)
  }

  //Filter Slot For Freezer Rack Id
  filterSlotForFreezerByRackId(filter?: any) {
    if (filter.length > 0) this.searchSlotForFreezerByRackId(filter);
    if (filter.length == 0) this.paginateSlots(false)
  }

  //Filter Shelve For Freezer Row Rack Id
  filterShelveForFreezerRowByRackId(filter?: any) {
    if (filter.length > 0) this.searchShelveForFreezerRowByRackId(filter);
    if (filter.length == 0) this.paginateShelve(false)
  }

  //Filter Shelve For Incubator Rack Id
  filterShelvesForIncByRackId(filter?: any) {
    if (filter.length > 0) this.searchShelvesForIncByRackId(filter);
    if (filter.length == 0) this.paginateShelve();
  }

  //Filter Shelve For OS Rack Id
  filterShelvesForOsByRackId(filter?: any) {
    if (filter.length > 0) this.searchShelvesForOsByRackId(filter);
    if (filter.length == 0) this.paginateShelve();
  }

  //Filter Slot For Refrigerator Rack Id
  filterSlotsForRefByRackId(filter?: any) {
    if (filter.length > 0) this.searchSlotsForRefByRackId(filter);
    if (filter.length == 0) this.paginateSlots();
  }

  //Filter Shelve For Refrigerator Rack Id
  filterShelvesForRefByRackId(filter?: any) {
    if (filter.length > 0) this.searchShelvesForRefByRackId(filter);
    if (filter.length == 0) this.paginateShelve();
  }

  // Apply Filter
  applyFilter(filter?: string) {
    if((filter.includes('shelf-') || filter.includes('Shelf-')) || filter.includes('slot-') || filter.includes('Slot-')) filter = filter.split("-").pop();
    if (this.viewInfo[0].type === 'incubator')
      this.filterShelvesForIncByRackId(filter);
    if (this.viewInfo[0].type === 'open-shelf')
      this.filterShelvesForOsByRackId(filter);
    if (this.viewInfo[0].refType === '+5 Chest' || this.viewInfo[0].refType == '+5 Upright')
      this.filterSlotsForRefByRackId(filter);
    if (this.viewInfo[0].refType == '+5 WalkIn')
      this.filterShelvesForRefByRackId(filter);
    if (this.viewInfo[0].freezerType === 'Ultra-Low Upright' || this.viewInfo[0].freezerType === 'Freezer Upright')
      this.filterSlotForShelveFreezerByRackId(filter);
    if (this.viewInfo[0].freezerType === 'LN2' || this.viewInfo[0].freezerType === 'Ultra-Low Chest' || this.viewInfo[0].freezerType === 'Freezer Chest')
      this.filterSlotForFreezerByRackId(filter);
    if (this.viewInfo[0].freezerType == 'Walk In')
      this.filterShelveForFreezerRowByRackId(filter);
  }

  /**Sorting**/
  sortData(event: Sort) {
    this.paginate.sort = event.active + ',' + event.direction;
    if (this.viewInfo[0].incType == 'Walk In' || this.viewInfo[0].type === 'open-shelf' || this.viewInfo[0].refType == '+5 WalkIn' || this.viewInfo[0].freezerType == 'Walk In')
      this.paginateShelve();
    if (this.viewInfo[0].refType === '+5 Chest' || this.viewInfo[0].refType == '+5 Upright' || this.viewInfo[0].freezerType === 'LN2' || this.viewInfo[0].freezerType === 'Ultra-Low Chest' || this.viewInfo[0].freezerType === 'Freezer Chest'
      || this.viewInfo[0].freezerType === 'Ultra-Low Upright' || this.viewInfo[0].freezerType === 'Freezer Upright')
      this.paginateSlots();
  }
}