import { Component, OnInit, Inject, Input, Output } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { FormGroup, FormControl, Validators, FormGroupDirective, NgForm, FormBuilder, FormArray } from '@angular/forms';
import { ErrorStateMatcher } from '@angular/material/core';
import { HelperService } from '../../../services/helper.service';
import { StorageService } from '../../services/storage.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { StorageModel } from 'app/models/storage.model';
import { ValidatorService } from 'app/services/validator.service';

export class MyErrorStateMatcher implements ErrorStateMatcher {

  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = form && form.submitted;
    return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
  }

}

@Component({
  selector: 'app-create-slot',
  templateUrl: './create-slot.component.html',
  styleUrls: ['./create-slot.component.scss']
})

export class CreateSlotComponent implements OnInit {

  public statusTypes: any[] = ['N/A', 'Quarantine', 'Release', 'Reject'];
  public gridTypes: any[] = [{ value: 'SEVEN', name: '7x7', size: 49 }, { value: 'NINE', name: '9x9', size: 81 }, { value: 'TEN', name: '10x10', size: 100 },
  { value: 'ARROW_HEAD', name: 'ARROW HEAD', size: 62 }];
  public slots: FormArray;
  public slotsArray: any[] = [];
  public matcher = new MyErrorStateMatcher();
  public editMode: boolean = false;
  public availableslots: any;
  public viewShelf: Array<StorageModel>;
  public availableSeqId:number[]=[];
  public addedItem:boolean = false;
  public clicked=false;


  // @Input() shelfData: Array<StorageModel>;


  constructor(private dialogRef: MatDialogRef<CreateSlotComponent>, @Inject(MAT_DIALOG_DATA) public dialogData: any,
    private helper: HelperService, private formBuilder: FormBuilder,
    private storageSrv: StorageService,private validatorService:ValidatorService,
    private spinnerService: Ng4LoadingSpinnerService) {
    this.slots = this.slotDiagForm.get('slots') as FormArray;
  }

  ngOnInit() {
    this.storageSrv.sharedSlot.distinctUntilChanged().subscribe(data => {
      if (data) {
        this.slotDiagForm.patchValue(data);
        this.slots.at(0).get('statusType').clearValidators();
        this.slots.at(0).get('statusType').updateValueAndValidity();
        this.editMode = true;
      }
    });
    this.slotsArray = this.slotDiagForm.get('slots').value;
    this.getAvailableSeqIds();
  }

  // Slot Form
  public slotDiagForm = this.formBuilder.group({
    id: this.formBuilder.control(''),
    name: this.formBuilder.control(''),
    gridType: this.formBuilder.control(''),
    statusType: this.formBuilder.control(''),
    seqId: this.formBuilder.control(''),
    slots: this.formBuilder.array([this.createItem()], Validators.required),

  });

  // Get AVailable Sequence Ids
  public getAvailableSeqIds() {
    if (this.dialogData.refType === '+5 Chest' || this.dialogData.refType == '+5 Upright')
      this.storageSrv.getSeqIdsForRefSlotsByRack(this.dialogData.rack.id).subscribe(res => { this.availableSeqId = res.body });
    if (this.dialogData.type === 'freezer' && this.dialogData.freezerType !== 'Walk In')
      this.storageSrv.getSeqIdsForFreezerSlotByRackId(this.dialogData.rack.id).subscribe(res => { this.availableSeqId = res.body });
  }

  /** form array **/
  createItem(): FormGroup {
    return this.formBuilder.group({
      name: this.formBuilder.control(''),
      seqId: this.formBuilder.control(''),
      isReUsed: this.formBuilder.control(false),
      statusType: this.formBuilder.control('', [ Validators.required]),
      gridType: this.formBuilder.control('')
    });
  }

  /** ADD Field **/
  addItem(): void {
    this.addedItem = true;
    this.slots = this.slotDiagForm.get('slots') as FormArray;
    this.slots.push(this.createItem());
    this.slotsArray = this.slots.value;
  }

  /** choose grid type  */
  selectGridType() {
    let rack = this.dialogData.rack;
    let parentGridType = this.gridTypes.filter(function (e) { return e.value === rack.gridType; });
    let filteredGridType = (rack.gridType !== 'ARROW_HEAD') ?
      this.gridTypes.filter(function (e) { return e.size <= parentGridType[0].size && e.value !== 'ARROW_HEAD' }) : parentGridType;
    return filteredGridType;
  }

  /** REMOVE chips **/
  removeItem(index): void {
    if (index != 0) {
      this.slots = this.slotDiagForm.get('slots') as FormArray;
      this.slots.removeAt(index);
      this.slotsArray.splice(index, 1);
    }
  }

  // Re Use
  reUse(mainIndex) {
    var arrayControl = this.slotDiagForm.get('slots') as FormArray;
    this.slotsArray[mainIndex].isReUsed = !this.slotsArray[mainIndex].isReUsed;
    this.slotDiagForm.get('slots').patchValue(this.slotsArray);
    arrayControl.at(mainIndex).get('seqId').clearValidators();
    arrayControl.at(mainIndex).get('seqId').updateValueAndValidity();
    arrayControl.at(mainIndex).get('seqId').patchValue('');
  }

  /** DESTROY editmode **/
  ngOnDestroy() {
    this.editMode = false;
  }

  /** CREATE a Slot **/
  create() {
    this.validatorService.userValidator(this.editMode?'update':'create').then(res => {
      if(res.val) {
        let slotObj = this.slotDiagForm.value;
        this.clicked=false;
        delete res.val;
        slotObj['locationId']=this.helper.getLocation();
        if (this.slotDiagForm.valid) {
          if (this.editMode) {
            delete slotObj.slots;
            if (this.dialogData.refType === '+5 Chest' || this.dialogData.refType == '+5 Upright') this.updateSlotForRef(slotObj,res);
            if (this.dialogData.freezerType === 'LN2' || this.dialogData.freezerType === 'Ultra-Low Chest' || this.dialogData.freezerType === 'Freezer Chest') this.updateSlotForFreezer(slotObj,res);
            if (this.dialogData.freezerType === 'Ultra-Low Upright' || this.dialogData.freezerType === 'Freezer Upright') this.updateSlotForFreezerShelveRack(slotObj,res)
          } else {
            delete slotObj["id"];
            let generatedSlots = this.generateSlots(slotObj);
            if (this.dialogData.refType === '+5 Chest' || this.dialogData.refType == '+5 Upright') this.addSlotForRefByRackId(generatedSlots,res);
            if (this.dialogData.freezerType === 'LN2' || this.dialogData.freezerType === 'Ultra-Low Chest' || this.dialogData.freezerType === 'Freezer Chest') this.addSlotForFreezerByRackId(generatedSlots,res);
            if (this.dialogData.freezerType === 'Ultra-Low Upright' || this.dialogData.freezerType === 'Freezer Upright') this.addSlotForFreezerShelveByRackId(generatedSlots,res)
          }
        }
      }
    })

  }

  // create  slots
  generateSlots(slotObj) {
    for (let i = 0; i < slotObj.slots.length; i++) {
      slotObj.slots[i].name = 'Slot';
      if (this.dialogData.refType == '+5 Upright') {
        slotObj.slots[i].refId = this.dialogData.id;
        slotObj.slots[i].refRackId = this.dialogData.rack.id;
        slotObj.slots[i].refShelfId = this.dialogData.shelve.id;
      }
      if (this.dialogData.refType == '+5 Chest') {
        slotObj.slots[i].refId = this.dialogData.id;
        slotObj.slots[i].refRackId = this.dialogData.rack.id;
      }
      if (this.dialogData.freezerType === 'LN2' || this.dialogData.freezerType === 'Ultra-Low Chest' || this.dialogData.freezerType === 'Freezer Chest') {
        slotObj.slots[i].freezerId = this.dialogData.id;
        slotObj.slots[i].freezerRackId = this.dialogData.rack.id;
      }
      if (this.dialogData.freezerType === 'Ultra-Low Upright' || this.dialogData.freezerType === 'Freezer Upright') {
        slotObj.slots[i].freezerId = this.dialogData.id;
        slotObj.slots[i].freezerRackId = this.dialogData.rack.id;
        slotObj.slots[i].freezerShelfId = this.dialogData.shelve.id;
      }
    }
    return slotObj.slots;
  }

  // Add Slot For Ref By Rack Id
  addSlotForRefByRackId(slot,res) {
    this.storageSrv._addRequest(this.dialogData,this.dialogData.rack.id, slot,res).subscribe(data => {
      this.helper.showSnackbar('Successfully Created Slot!');
      this.dialogRef.close(this.slotDiagForm.value);
      this.storageSrv.setSharedSlot(data);
      this.spinnerService.hide();
    }, err => {
       this.helper.showSnackbar(err.error.message,false,true);
    })
  }

  // Update Slot For Ref
  updateSlotForRef(slotObj,res) {
    slotObj.refId = this.dialogData.id;
    slotObj.refRackId = this.dialogData.rack.id;
    if (this.dialogData.refType === '+5 Upright') slotObj.refShelfId = this.dialogData.shelve.id;
    this.storageSrv._updateRequest(this.dialogData,slotObj,res).subscribe(data => {
      this.helper.showSnackbar('Successfully Updated Slot !');
      this.dialogRef.close(this.slotDiagForm.value);
      this.storageSrv.setSharedSlot(data);
      this.spinnerService.hide();
    },err => {
      this.helper.showSnackbar(err.error.message,false,true);
   })
  }

  // Add Slot For Freezer By Rack Id
  addSlotForFreezerByRackId(slot,res) {
    this.storageSrv._addRequest(this.dialogData,this.dialogData.rack.id, slot,res).subscribe(data => {
      this.helper.showSnackbar('Successfully Created Slot!');
      this.dialogRef.close(this.slotDiagForm.value);
      this.storageSrv.setSharedSlot(data);
      this.spinnerService.hide();
    }, err => {
       this.helper.showSnackbar(err.error.message,false,true);
    })
  }

  // Update Slot For Freezer
  updateSlotForFreezer(slotObj,res) {
    slotObj.freezerId = this.dialogData.id;
    slotObj.freezerRackId = this.dialogData.rack.id;
    if (this.dialogData.freezerType === 'LN2' || this.dialogData.freezerType === 'Ultra-Low Chest' || this.dialogData.freezerType === 'Ultra-Low Chest') slotObj.freezerRackId = this.dialogData.rack.id;
    this.storageSrv._updateRequest(this.dialogData,slotObj,res).subscribe(data => {
      this.helper.showSnackbar('Successfully Updated Slot !');
      this.dialogRef.close(this.slotDiagForm.value);
      this.storageSrv.setSharedSlot(data);
      this.spinnerService.hide();
    },err => {
      this.helper.showSnackbar(err.error.message,false,true);
   })
  }

  // Add Slot For Freezer Shelve By Rack Id
  addSlotForFreezerShelveByRackId(slot,res) {
    this.storageSrv._addRequest(this.dialogData,this.dialogData.rack.id, slot,res).subscribe(data => {
      this.helper.showSnackbar('Successfully Created Slot!');
      this.dialogRef.close(this.slotDiagForm.value);
      this.storageSrv.setSharedSlot(data);
      this.spinnerService.hide();
    }, err => {
       this.helper.showSnackbar(err.error.message,false,true);
    })
  }

  // Update Slot For Freezer Shelve By Rack Id
  updateSlotForFreezerShelveRack(slotObj,res) {
    slotObj.freezerId = this.dialogData.id;
    slotObj.freezerRackId = this.dialogData.rack.id;
    slotObj.freezerShelfId = this.dialogData.shelve.id
    if (this.dialogData.freezerType === 'LN2' || this.dialogData.freezerType === 'Ultra-Low Chest' || this.dialogData.freezerType === 'Ultra-Low Chest') slotObj.freezerRackId = this.dialogData.rack.id;
    this.storageSrv._updateRequest(this.dialogData,slotObj,res).subscribe(data => {
      this.helper.showSnackbar('Successfully Updated Slot !');
      this.dialogRef.close(this.slotDiagForm.value);
      this.storageSrv.setSharedSlot(data);
      this.spinnerService.hide();
    },err => {
      this.helper.showSnackbar(err.error.message,false,true);
   })
  }

  /** CLOSE mat dialog **/
  close() {
    this.dialogRef.close(null);
  }

}
