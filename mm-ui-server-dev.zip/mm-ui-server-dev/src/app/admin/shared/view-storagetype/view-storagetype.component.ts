import { Component, OnInit, Input, Output, EventEmitter, ViewChild } from '@angular/core';
import { MatPaginator, MatSort, MatDialog, MatDialogConfig, MatTableDataSource, PageEvent,Sort } from '@angular/material';
import { StorageService } from '../../services/storage.service';
import { StorageModel } from '../../../models/storage.model';
import { CreateShelveComponent } from '../create-shelve/create-shelve.component';
import { ValidatorService } from 'app/services/validator.service';
import { CommonApiService } from 'app/services/common-api.service';
import { ActivatedRoute, Router } from '@angular/router';
import { CreateRowComponent } from '../create-row/create-row.component';
import { CreateRackComponent } from '../create-rack/create-rack.component';
import { EventService } from 'app/admin/services/event.service';
import { HelperService } from 'app/services/helper.service';

@Component({
  selector: 'app-view-storagetype',
  templateUrl: './view-storagetype.component.html',
  styleUrls: ['./view-storagetype.component.scss']
})
export class ViewStorageTypeComponent implements OnInit {

  public displayedColumns: string[] = ['name','status', 'action'];
  public displayedColumnsRef: string[] = ['name', 'status','grid_type','action'];
  public gridTypes: any[] = [ { value:'SEVEN',name:'7x7'},{ value:'NINE',name:'9x9'}, { value:'TEN',name:'10x10'}, { value:'ARROW_HEAD',name:'ARROW HEAD'}];
  public viewMode: boolean = true;
  public dataSource = new MatTableDataSource();
  public data: any;
  public dataInfo: any;
  public selectedInfo: Array<StorageModel> = [];
  public dataSourceRack: any;
  public paginate:any = {};
  public totalData:any;
  public shelf: Array<StorageModel> = [];
  public editMode: boolean = false;
  public pageEvent: PageEvent;

  @Input() viewStorageInfo: Array<StorageModel>;
  @Output() viewEvent = new EventEmitter();
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(private storageSrv: StorageService, private dialog: MatDialog, private validatorSrv: ValidatorService,
    private commonSrv: CommonApiService, private router: Router, private eventSrv:EventService,private helper:HelperService) { }

  ngOnInit() {
    this.eventSrv.incEventListner().subscribe(viewMode =>{ this.viewMode = viewMode; } );
    this.eventSrv.refEventListner().subscribe(viewMode =>{ this.viewMode = viewMode; } );
    this.eventSrv.openShelfEventListner().subscribe(viewMode =>{ this.viewMode = viewMode; } );

    //Freezer Info from Parent Component.
    this.dataInfo = this.viewStorageInfo;
    this.refreshForShelves();
    this.refreshForRows(); 
    this.setDefaultParams();
    this.refreshForRacks();
  }

  //refresh  shelves
  refreshForShelves() {
    this.storageSrv.sharedShelve.distinctUntilChanged().subscribe(data => {
      if (data) {
          this.setDefaultParams();
          this.editMode = true;
      } else {
          this.setDefaultParams();
      }
    });
  }

  //refresh Rows
  refreshForRows(){
    this.storageSrv.sharedRow.distinctUntilChanged().subscribe(data => {
      if (data) {
          this.setDefaultParams();
          this.editMode = true;
      }else{
          this.setDefaultParams();
      }
    });
  } 

  //refresh Racks
  refreshForRacks(){
    this.storageSrv.sharedRack.distinctUntilChanged().subscribe(data => {
      if (data) {
          this.setDefaultParams();
          this.editMode = true;
      }else{
          this.setDefaultParams();
      }
    });
  }

  //Receive View Mode
  receivedViewMode($event) {
    this.viewMode = $event;
  }

  // Navigate
  navigate() {
    this.router.navigate(['./admin/configuration/storage-types/incubators'])
  }

  // Go Back
  goBack() {
    this.viewEvent.emit(this.viewMode);   
  }

  /** go To SHELVE **/
  gotoShelve(data) {
    this.viewMode = false;
    this.viewStorageInfo[0].shelve = data;
    this.selectedInfo = this.viewStorageInfo;
  }

  /** go To RACK **/
  gotoRack(data) {
    this.viewMode = false;
    this.viewStorageInfo[0].rack = data;
    this.selectedInfo = this.viewStorageInfo;
  }

  /** go To Row **/
  gotoRow(data) {
    this.viewMode = false;
    this.viewStorageInfo[0].row = data;
    this.selectedInfo = this.viewStorageInfo;
  }

  /** go To SLOT **/
  gotoSlot(data) {
    this.viewMode = false;
    this.selectedInfo = this.viewStorageInfo;
  }

  // Get Max Grid Type
  getMaxGridType(row){
    let resp = this.gridTypes.filter( elem => elem.value === row.gridType )
    return resp[0];
  }

  /** open CREAT SHELVE **/
  openCreateShelve(newData?): void {
    if (newData) {
      this.storageSrv.setSharedShelve(newData);
    } else {
      this.storageSrv.setSharedShelve("");
    }
    let dialogRef = this.dialog.open(CreateShelveComponent, {
      width: '700px',
      data: this.viewStorageInfo[0]
    });
  }
  
  /** open CREAT Row **/
  openCreateRow(newData?): void {
    if (newData) {
      this.storageSrv.setSharedRow(newData);
    } else {
      this.storageSrv.setSharedRow("");
    }
    let dialogRef = this.dialog.open(CreateRowComponent, {
      width: '700px',
      data: this.viewStorageInfo[0]
    });
  }

   /** open CREATE RACK **/
   openCreateRack(newData?): void {
    if (newData) {
      this.storageSrv.setSharedRack(newData);
    } else {
      this.storageSrv.setSharedRack("");
    }
    let dialogRef = this.dialog.open(CreateRackComponent, {
      width: '700px',
      data: this.viewStorageInfo[0]
    });
  }
   
  //all rows for incubators
  getRowsByIncubatorId(reqParams){
    this.viewStorageInfo[0].storageType="Inc-StorageType"
    this.storageSrv._getRequest(this.viewStorageInfo[0],this.viewStorageInfo[0].id,reqParams).subscribe(res=>{
      this.dataSource.data = res.body;
      this.totalData = res.headers.get('X-Total-Count');
    })
  }

  // Get Racks For OS By Row Id  
  getRacksForOsById(reqParams) {
    this.viewStorageInfo[0].storageType='Os-Rack'
    this.storageSrv._getRequest(this.viewStorageInfo[0],this.viewStorageInfo[0].id, reqParams).subscribe(res => {
      this.dataSource.data = res.body;
      this.totalData = res.headers.get('X-Total-Count');
    })
  }


  //all rows for Refrigerator
  getRowsByRefId(reqParams){
    this.viewStorageInfo[0].storageType="Ref-StorageType"
    this.storageSrv._getRequest(this.viewStorageInfo[0],this.viewStorageInfo[0].id,reqParams).subscribe(res=>{
      this.dataSource.data = res.body;
      this.totalData = res.headers.get('X-Total-Count');
    })
  }

  //all rows for Freezer
  getRowsByFreezerId(reqParams){
    this.viewStorageInfo[0].storageType='Freezer-StorageType'
    this.storageSrv._getRequest(this.viewStorageInfo[0],this.viewStorageInfo[0].id,reqParams).subscribe(res=>{
      this.dataSource.data = res.body;
      this.totalData = res.headers.get('X-Total-Count');
    })
  }

//all Shelve for Incubator
  getShelvesByIncubatorId(reqParams){
    this.viewStorageInfo[0].storageType='Inc-StorageType'
    this.storageSrv._getRequest(this.viewStorageInfo[0],this.viewStorageInfo[0].id, reqParams).subscribe(res => {
      this.dataSource.data = res.body;
      this.totalData = res.headers.get('X-Total-Count');
    })
  }
  
  //all Shelve for Refrigerator
  getShelvesByRefId(reqParams){
    this.viewStorageInfo[0].storageType="Ref-StorageType"
    this.storageSrv._getRequest(this.viewStorageInfo[0],this.viewStorageInfo[0].id, reqParams).subscribe(res => {
      this.dataSource.data = res.body;
      this.totalData = res.headers.get('X-Total-Count');
    })
  }

  // all Shelve for Freezer
  getShelvesByFreezerId(reqParams){
    this.viewStorageInfo[0].storageType='Freezer-StorageType'
    this.storageSrv._getRequest(this.viewStorageInfo[0],this.viewStorageInfo[0].id, reqParams).subscribe(res => {
      this.dataSource.data = res.body;
      this.totalData = res.headers.get('X-Total-Count');
    })
  }

// all Rack for Refrigerator
  getRacksByRefId(reqParams){
    this.viewStorageInfo[0].storageType="Ref-StorageType"
    this.storageSrv._getRequest(this.viewStorageInfo[0],this.viewStorageInfo[0].id, reqParams).subscribe(res => {
      this.dataSource.data = res.body;
      this.totalData = res.headers.get('X-Total-Count');
    })
  }

  // all Rack for Freezer
  getRackByFreezerId(reqParams){
    this.viewStorageInfo[0].storageType='Freezer-StorageType'
    this.storageSrv._getRequest(this.viewStorageInfo[0],this.viewStorageInfo[0].id, reqParams).subscribe(res => {
      this.dataSource.data = res.body;
      this.totalData = res.headers.get('X-Total-Count');
    })
  }

  // Set Default Params
  setDefaultParams() {
    this.paginate = {
      page: 0,
      size: 10,
      sort: 'seqId,ASC'
    }
    if (this.viewStorageInfo[0].incType !=='Walk In' || this.viewStorageInfo[0].refType =='+5 Upright' ||  this.viewStorageInfo[0].freezerType === 'Ultra-Low Upright' ||
     this.viewStorageInfo[0].freezerType === 'Freezer Upright')
      this.paginateShelfs(false);
    if(this.viewStorageInfo[0].refType =='+5 WalkIn' || this.viewStorageInfo[0].incType === 'Walk In' || this.viewStorageInfo[0].freezerType === 'Walk In')
      this.paginateRows(false); 
    if(this.viewStorageInfo[0].refType =='+5 Chest' || this.viewStorageInfo[0].freezerType === 'LN2'|| this.viewStorageInfo[0].freezerType === 'Ultra-Low Chest' || this.viewStorageInfo[0].freezerType === 'Freezer Chest' || this.viewStorageInfo[0].type ==='open-shelf' )
      this.paginateRacks(false);
  }

  /** Paginate Rows */
  paginateRows(setPage = true) {
    if (setPage) this.paginate.page = 0;
    let reqParams = this.commonSrv.createParam(this.paginate);
    this.router.navigate([],{queryParams:reqParams});
    if(this.viewStorageInfo[0].type === 'incubator' && this.viewStorageInfo[0].incType =='Walk In') this.getRowsByIncubatorId(reqParams);
    if(this.viewStorageInfo[0].type ==='refrigerator') this.getRowsByRefId(reqParams);
    if(this.viewStorageInfo[0].freezerType === 'Walk In' ) this.getRowsByFreezerId(reqParams);
   }
   
  /** Paginate Shelfs */
  paginateShelfs(setPage = true) {
    if (setPage) this.paginate.page = 0;
    let reqParams = this.commonSrv.createParam(this.paginate);
    this.router.navigate([], { queryParams: reqParams });
    if(this.viewStorageInfo[0].type === 'incubator' && this.viewStorageInfo[0].incType !=='Walk In') this.getShelvesByIncubatorId(reqParams);
    if( this.viewStorageInfo[0].refType =='+5 Upright') this.getShelvesByRefId(reqParams);
    if(this.viewStorageInfo[0].freezerType === 'Ultra-Low Upright' || this.viewStorageInfo[0].freezerType === 'Freezer Upright') this.getShelvesByFreezerId(reqParams);
  }

  /** Paginate Racks */
  paginateRacks(setPage = true) {
    if (setPage) this.paginate.page = 0;
    let reqParams = this.commonSrv.createParam(this.paginate);
    this.router.navigate([], { queryParams: reqParams });
    if(this.viewStorageInfo[0].refType =='+5 Chest') this.getRacksByRefId(reqParams);
    if(this.viewStorageInfo[0].freezerType === 'LN2'|| this.viewStorageInfo[0].freezerType === 'Ultra-Low Chest' || this.viewStorageInfo[0].freezerType === 'Freezer Chest') this.getRackByFreezerId(reqParams);
    if(this.viewStorageInfo[0].type ==='open-shelf') this.getRacksForOsById(reqParams);
  }

  /** Onchange Page **/
  onChangePage(event?: PageEvent) {
    this.paginate.size = event.pageSize;
    this.paginate.page = event.pageIndex;

    if ((this.viewStorageInfo[0].type === 'incubator' && this.viewStorageInfo[0].incType !== 'Walk In') || this.viewStorageInfo[0].refType =='+5 Upright' || this.viewStorageInfo[0].freezerType === 'Ultra-Low Upright' || this.viewStorageInfo[0].freezerType === 'Freezer Upright')
      this.paginateShelfs(false);
    if(this.viewStorageInfo[0].refType =='+5 WalkIn' || (this.viewStorageInfo[0].type === 'incubator' && this.viewStorageInfo[0].incType === 'Walk In') || this.viewStorageInfo[0].freezerType === 'Walk In')
      this.paginateRows(false); 
      if(this.viewStorageInfo[0].refType =='+5 Chest' || this.viewStorageInfo[0].freezerType === 'LN2'|| this.viewStorageInfo[0].freezerType === 'Ultra-Low Chest' || this.viewStorageInfo[0].freezerType === 'Freezer Chest' || this.viewStorageInfo[0].type ==='open-shelf')
      this.paginateRacks(false);
    return event;
  }

  /** DELETE shelve **/
  onDeleteShelve(row, index) {
    this.validatorSrv.userValidator('delete').then(res => {
      if (res.val) {
        delete res.val;
        if(this.viewStorageInfo[0].type ==='incubator' && this.viewStorageInfo[0].incType !== 'Walk In')  this.deleteIncShelf(row, index,res);
        if(this.viewStorageInfo[0].refType =='+5 Upright')  this.deleteRefShelf(row, index,res);
        if(this.viewStorageInfo[0].freezerType === 'Ultra-Low Upright' || this.viewStorageInfo[0].freezerType === 'Freezer Upright') this.deleteFreezerShelf(row, index,res);
      }
    }).catch(err => {
      console.error("Delete Shelf is Failed", err);
    });
  }

  /** DELETE row **/
  onDeleteRow(row, index){
    this.validatorSrv.userValidator('delete').then(res => {
      if (res.val) {
        delete res.val;
        if(this.viewStorageInfo[0].type ==='incubator' && this.viewStorageInfo[0].incType === 'Walk In')  this.deleteRowForIncubator(row, index, res);
        if(this.viewStorageInfo[0].type ==='open-shelf')  this.deleteRowForOs(row, index,res);
        if(this.viewStorageInfo[0].refType ==='+5 WalkIn') this.deleteRowForRefrigerator(row, index,res);
        if(this.viewStorageInfo[0].freezerType ==='Walk In') this.deleteRowForFreezer(row, index,res);
      }
    }).catch(err => {
      console.error("Delete Row is Failed", err);
    });
  }

   /** DELETE Rack **/
   onDeleteRack(row, index){
    this.validatorSrv.userValidator('delete').then(res => {
      if (res.val) {
        if(this.viewStorageInfo[0].refType ==='+5 Chest')
          this.deleteRackForRefrigerator(row, index,res);
        if(this.viewStorageInfo[0].freezerType === 'LN2'|| this.viewStorageInfo[0].freezerType === 'Ultra-Low Chest' || this.viewStorageInfo[0].freezerType === 'Freezer Chest')
          this.deleteRackForFreezer(row, index,res);
        if(this.viewStorageInfo[0].type === 'open-shelf')
          this.deleteRackForOs(row,index,res);
      }
    }).catch(err => {
      console.error("Delete Rack is Failed", err);
    });
  }

  // Delete Freezer Rack
  onDeleteFreezerRack(row, index){
    this.validatorSrv.userValidator('delete').then(res => {
      if (res.val) {
        if(this.viewStorageInfo[0].refType ==='+5 Chest')
          this.deleteRackForFreezer(row, index,res);
      }
    }).catch(err => {
      console.error("Delete Rack is Failed", err);
    });
  }

   // Delete Incubator Shelf
  deleteIncShelf(row,index,res){
    this.storageSrv._deleteRequest(this.viewStorageInfo[0],row,res).subscribe(data => {
      let shelveData = this.dataSource.data;
      shelveData.splice(Number(index), 1);
      this.totalData = shelveData.length;
      this.dataSource.data = shelveData;
    },err=>{
       this.helper.showSnackbar(err.error.message,false,true);
     });
  }

   // Delete Refrigerator Shelf
  deleteRefShelf(row,index,res){
    this.storageSrv._deleteRequest(this.viewStorageInfo[0],row,res).subscribe(data => {
      let shelveData = this.dataSource.data;
      shelveData.splice(Number(index), 1);
      this.dataSource.data = shelveData;
    },err=>{
      this.helper.showSnackbar(err.error.message,false,true);
     });
  }

   // Delete Row For Incubator
  deleteRowForIncubator(row,index,res){
    this.storageSrv._deleteRequest(this.viewStorageInfo[0],row,res).subscribe(data => {
      let rowData = this.dataSource.data;
      rowData.splice(Number(index), 1);
      this.totalData = rowData.length;
      this.dataSource.data = rowData;
    },err=>{
      this.helper.showSnackbar(err.error.message,false,true);
     });
  }

  // Delete Row For OS
  deleteRowForOs(row,index,res){
    this.storageSrv._deleteRequest(this.viewStorageInfo[0],row,res).subscribe(data => {
      let rowData = this.dataSource.data;
      rowData.splice(Number(index), 1);
      this.totalData = rowData.length;
      this.dataSource.data = rowData;
    },err=>{
      this.helper.showSnackbar(err.error.message,false,true);
     });
  }

  // Delete Rack For Refrigerator
  deleteRackForRefrigerator(row,index,res){
    this.storageSrv._deleteRequest(this.viewStorageInfo[0],row,res).subscribe(data => {
      let rowData = this.dataSource.data;
      rowData.splice(Number(index), 1);
      this.totalData = rowData.length;
      this.dataSource.data = rowData;
    },err=>{
      this.helper.showSnackbar(err.error.message,false,true);
     });
  }

  // Delete Rack For Freezer
  deleteRackForFreezer(row,index,res){
    this.storageSrv._deleteRequest(this.viewStorageInfo[0],row,res).subscribe(data => {
      let rowData = this.dataSource.data;
      rowData.splice(Number(index), 1);
      this.totalData = rowData.length;
      this.dataSource.data = rowData;
    },err=>{
      this.helper.showSnackbar(err.error.message,false,true);
     });
  }

  // Delete Row For Freezer
  deleteRowForFreezer(row,index,res){
    this.storageSrv._deleteRequest(this.viewStorageInfo[0],row,res).subscribe(data => {
      let rowData = this.dataSource.data;
      rowData.splice(Number(index), 1);
      this.totalData = rowData.length;
      this.dataSource.data = rowData;
    },err=>{
      this.helper.showSnackbar(err.error.message,false,true);
     });
  }

  // Delete Row For Refrigerator
  deleteRowForRefrigerator(row,index,res){
    this.storageSrv._deleteRequest(this.viewStorageInfo[0],row,res).subscribe(data => {
      let rowData = this.dataSource.data;
      rowData.splice(Number(index), 1);
      this.totalData = rowData.length;
      this.dataSource.data = rowData;
    },err=>{
      this.helper.showSnackbar(err.error.message,false,true);
     });
  }

  // Delete Shelf For Freezer
  deleteFreezerShelf(row,index,res){
    this.storageSrv._deleteRequest(this.viewStorageInfo[0],row,res).subscribe(data => {
      let shelveData = this.dataSource.data;
      shelveData.splice(Number(index), 1);
      this.dataSource.data = shelveData;
    },err=>{
      this.helper.showSnackbar(err.error.message,false,true);
     });
  }
  // Delete Racks For OS
  deleteRackForOs(rack, index,res) {
        this.storageSrv._deleteRequest(this.viewStorageInfo[0],rack,res).subscribe(data => {
          let rackData = this.dataSource.data;
          rackData.splice(Number(index), 1);
          this.dataSource.data = rackData;
        },err=>{
          this.helper.showSnackbar(err.error.message,false,true);
        });
  }


  // Search Row By Incubator
  searchRowByIncubator(filterValue?:any){
    this.storageSrv.searchRowByIncubator(this.viewStorageInfo[0].id,filterValue).subscribe(res=>{
      this.dataSource.data = res.body;
    })
  }

  // Search Row By OS
  searchRacksByOsId(filterValue?:any){
    this.storageSrv.searchRacksByOsId(this.viewStorageInfo[0].id,filterValue).subscribe(res=>{
      this.dataSource.data = res.body;
    })
  }

  // Search Shelve By Freezer Id
  searchShelveByFreezerId(filterValue?:any){
    this.storageSrv.searchShelveByFreezerId(this.viewStorageInfo[0].id,filterValue).subscribe(res=>{
      this.dataSource.data = res.body;
    })
  }

  // Search Shelve By Refrigerator Id
  searchShelvesByRefId(filterValue?:any){
    this.storageSrv.searchShelvesByRefId(this.viewStorageInfo[0].id,filterValue).subscribe(res=>{
      this.dataSource.data = res.body;
    })
  }

  // Search Row By Regrigerator Id
  searchRowsByRefId(filterValue?:any){
    this.storageSrv.searchRowsByRefId(this.viewStorageInfo[0].id,filterValue).subscribe(res=>{
      this.dataSource.data = res.body;
    })
  }

  // Search Rack By Refrigerator Id
  searchRacksByRefId(filterValue?:any){
    this.storageSrv.searchRacksByRefId(this.viewStorageInfo[0].id,filterValue).subscribe(res=>{
      this.dataSource.data = res.body;
    })
  }

  // Search Rack By Freezer Id
  searchRacksByFreezerId(filterValue?:any){
    this.storageSrv.searchRacksByFreezerId(this.viewStorageInfo[0].id,filterValue).subscribe(res=>{
      this.dataSource.data = res.body;
    })
  }

  // Search Row By Freezer Id
  searchRowByFreezerId(filterValue?:any){
    this.storageSrv.searchRowByFreezerId(this.viewStorageInfo[0].id,filterValue).subscribe(res=>{
      this.dataSource.data = res.body;
    })
  }
  // Search Shelves By Incubator Id
  searchShelvesByIncubatorId(filterValue ?:any){
    this.storageSrv.searchShelvesByIncId(this.viewStorageInfo[0].id,filterValue).subscribe(res=>{
      this.dataSource.data = res.body;
    })
  }
  // Filter Rack By Freezer Id
  filterRacksByFreezerId(filter?:any){
    if(filter.length>0) this.searchRacksByFreezerId(filter);
    if(filter.length==0) this.paginateRacks(false);
  }

  // Filter Row By Freezer Id
  filterRowByFreezerId(filter?:any){
    if(filter.length>0) this.searchRowByFreezerId(filter);
    if(filter.length==0) this.paginateRows(false);
  }

  // Search Row By Incubator Id
  filterRowByIncubator(filter?:any){
    if(filter.length > 0) this.searchRowByIncubator(filter);
    if(filter.length == 0) this.paginateRows();
  }

  // Search Rack By OS Id
  filterRacksByOsId(filter?:any){
    if(filter.length>0) this.searchRacksByOsId(filter);
    if(filter.length==0) this.paginateRacks();
  }

  // Search Shelve By Freezer Id
  filterShelveByFreezerId(filter?:any){
    if(filter.length>0) this.searchShelveByFreezerId(filter);
    if(filter.length==0) this.paginateShelfs();
  }

  // Search Shelve By Refrigerator Id
  filterShelvesByRefId(filter?:any){
    if(filter.length>0) this.searchShelvesByRefId(filter);
    if(filter.length==0) this.paginateShelfs();
  }

  // Search Row By Refrigerator Id
  filterRowsByRefId(filter?:any){
    if(filter.length>0) this.searchRowsByRefId(filter);
    if(filter.length==0) this.paginateRows();
  }

  // Search Rack By Refrigerator Id
  filterRacksByRefId(filter?:any){
    if(filter.length>0) this.searchRacksByRefId(filter);
    if(filter.length==0) this.paginateRacks();
  }
   //Search Shelves By Incubator Id
  filterShelvesByIncId(filter?:any){
    if(filter.length>0) this.searchShelvesByIncubatorId(filter);
    if(filter.length==0) this.paginateShelfs();
  } 
  
  // Apply Filter
  applyFilter(filter?:string){
    if((filter.includes('row-') || filter.includes('Row-')) ||
     (filter.includes('rack-') || filter.includes('Rack-')) || 
     (filter.includes('shelf-') || filter.includes('Shelf-')))
       filter = filter.split("-").pop();
    if(this.viewStorageInfo[0].type === 'incubator' && this.viewStorageInfo[0].incType ==='Walk In')
        this.filterRowByIncubator(filter);
    if(this.viewStorageInfo[0].type ==='open-shelf')
        this.filterRacksByOsId(filter);     
    if(this.viewStorageInfo[0].freezerType === 'Ultra-Low Upright' || this.viewStorageInfo[0].freezerType === 'Freezer Upright')
        this.filterShelveByFreezerId(filter);
    if(this.viewStorageInfo[0].refType =='+5 Upright')
        this.filterShelvesByRefId(filter);    
    if(this.viewStorageInfo[0].refType =='+5 WalkIn')
        this.filterRowsByRefId(filter);
    if(this.viewStorageInfo[0].refType =='+5 Chest')
        this.filterRacksByRefId(filter);
    if(this.viewStorageInfo[0].freezerType === 'LN2'|| this.viewStorageInfo[0].freezerType === 'Ultra-Low Chest' || this.viewStorageInfo[0].freezerType === 'Freezer Chest')
      this.filterRacksByFreezerId(filter);
    if(this.viewStorageInfo[0].freezerType =='Walk In')
      this.filterRowByFreezerId(filter);
    if(this.viewStorageInfo[0].type === 'incubator' && this.viewStorageInfo[0].incType !='Walk In')
      this.filterShelvesByIncId(filter);
  }
  
  /** sort table */
  sortData(event:Sort){
    this.paginate.sort = event.active + ',' + event.direction;
    if ((this.viewStorageInfo[0].type === 'incubator' && this.viewStorageInfo[0].incType !== 'Walk In') || this.viewStorageInfo[0].freezerType === 'Ultra-Low Upright' || this.viewStorageInfo[0].freezerType === 'Freezer Upright' || this.viewStorageInfo[0].refType =='+5 Upright')
      this.paginateShelfs(false);
    if (this.viewStorageInfo[0].freezerType === 'Walk In' ||  this.viewStorageInfo[0].incType === 'Walk In' ||
    this.viewStorageInfo[0].refType =='+5 WalkIn')
      this.paginateRows(false); 
    if(this.viewStorageInfo[0].refType =='+5 Chest' || this.viewStorageInfo[0].freezerType === 'LN2'|| this.viewStorageInfo[0].freezerType === 'Ultra-Low Chest' || this.viewStorageInfo[0].freezerType === 'Freezer Chest' || this.viewStorageInfo[0].type ==='open-shelf')
      this.paginateRacks();
  }
}
