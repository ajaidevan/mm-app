import { Component, OnInit, Input, Output, EventEmitter, ViewChild } from '@angular/core';
import { MatPaginator, MatSort, MatDialog, MatTableDataSource, PageEvent, Sort } from '@angular/material';
import { StorageService } from '../../services/storage.service';
import { StorageModel } from '../../../models/storage.model';
import { CommonApiService } from 'app/services/common-api.service';
import { Router } from '@angular/router';
import { ValidatorService } from 'app/services/validator.service';
import { CreateSectionComponent } from '../create-section/create-section.component';
import { CreateRackComponent } from '../create-rack/create-rack.component';
import { EventService } from 'app/admin/services/event.service';
import { HelperService } from 'app/services/helper.service';

@Component({
  selector: 'app-view-shelve',
  templateUrl: './view-shelve.component.html',
  styleUrls: ['./view-shelve.component.scss']
})
export class ViewShelveComponent implements OnInit {

  public displayedColumns: string[] = ['name', 'status_type', 'action'];
  public displayedColumnsRef: string[] = ['name', 'status_type', 'grid_type', 'action',];
  public gridTypes: any[] = [{ value: 'SEVEN', name: '7x7' }, { value: 'NINE', name: '9x9' }, { value: 'TEN', name: '10x10' }, { value: 'ARROW_HEAD', name: 'ARROW HEAD' }];

  public viewMode: boolean = true;

  public dataInfo: Array<StorageModel> = [];
  public data: any;
  public dataSource = new MatTableDataSource();
  public paginate: any = {};
  public totalData: number;
  public editMode: boolean;
  public pageEvent: PageEvent;

  @Input() viewInfo: Array<StorageModel>;
  @Output() viewEvent = new EventEmitter();
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(private storageSrv: StorageService, private router: Router, private validatorSrv: ValidatorService,
    private commonSrv: CommonApiService, private dialog: MatDialog, private eventSrv: EventService,private helper:HelperService) { }

  ngOnInit() {
    this.dataInfo = this.viewInfo;
    this.setDefaultParams();
    this.racksRefreshForSections();
    this.racksRefreshForShelf();
  }

  //Receive View Mode
  receivedViewMode($event) {
    this.viewMode = $event;
  }

  //Go back
  goBack() {
    this.viewEvent.emit(this.viewMode);
  }

  /** go To SHELVE **/
  gotoRack(data) {
    this.viewMode = false;
    this.viewInfo[0].rack = data;
    this.dataInfo = this.viewInfo;
  }

  // Go TO Main Storage
  gotoMainStorage() {
    if (this.viewInfo[0].type == 'incubator') this.eventSrv.emitIncEvent(true);
    if (this.viewInfo[0].type === 'open-shelf') this.eventSrv.emitOpenShelfEvent(true);
    if (this.viewInfo[0].type == 'refrigerator') this.eventSrv.emitRefEvent(true);
    if (this.viewInfo[0].type == 'freezer') this.eventSrv.emitRefEvent(true);
  }

  // Go Back To Row
  goBackToRow() {
    if (this.viewInfo[0].incType === 'Walk In' || this.viewInfo[0].refType === '+5 WalkIn' ||
      this.viewInfo[0].freezerType == 'Walk In' || this.viewInfo[0].type === 'open-shelf') {
      this.eventSrv.emitRowEvent(true);
    }
  }

  // Get Max Grid Type
  getMaxGridType(row) {
    let resp = this.gridTypes.filter(elem => elem.value === row.gridType)
    return resp[0];
  }

  //refresh racks for sections.
  racksRefreshForSections() {
    this.storageSrv.sharedSection.distinctUntilChanged().subscribe(data => {
      if (data) {
        this.setDefaultParams();
        this.editMode = true;
      } else {
        this.setDefaultParams();
      }
    });
  }

  //refresh racks for shelf.
  racksRefreshForShelf() {
    this.storageSrv.sharedRack.distinctUntilChanged().subscribe(data => {
      if (data) {
        this.setDefaultParams();
        this.editMode = true;
      } else {
        this.setDefaultParams();
      }
    });
  }

  // Set Default Params
  setDefaultParams() {
    this.paginate = {
      page: 0,
      size: 10,
      sort: 'seqId,ASC'
    }
    if (this.viewInfo[0].type === 'open-shelf' || this.viewInfo[0].incType == 'Walk In' || this.viewInfo[0].refType === '+5 WalkIn' ||
      this.viewInfo[0].refType == '+5 WalkIn' || this.viewInfo[0].freezerType == 'Walk In')
      this.paginateSections(false);
    if (this.viewInfo[0].refType == '+5 Upright' || this.viewInfo[0].freezerType === 'Ultra-Low Upright' || this.viewInfo[0].freezerType === 'Freezer Upright') this.paginateRacks(false);
  }

  /** Paginate Shelfs */
  paginateSections(setPage = true) {
    if (setPage) this.paginate.page = 0;
    let reqParams = this.commonSrv.createParam(this.paginate);
    this.router.navigate([], { queryParams: reqParams });
    if (this.viewInfo[0].incType == 'Walk In') this.getSectionForIncByShelveId(reqParams);
    if (this.viewInfo[0].type === 'open-shelf') this.getSectionForOsByShelveId(reqParams);
    if (this.viewInfo[0].refType == '+5 WalkIn') this.getSectionForRefByShelveId(reqParams);
    if (this.viewInfo[0].freezerType == 'Walk In') this.getSectionForFreezerByShelveId(reqParams);
  }

  /** Paginate Racks */
  paginateRacks(setPage = true) {
    if (setPage) this.paginate.page = 0;
    let reqParams = this.commonSrv.createParam(this.paginate);
    this.router.navigate([], { queryParams: reqParams });
    if (this.viewInfo[0].refType == '+5 Upright') this.getRacksForRefByShelfId(reqParams);
    if (this.viewInfo[0].freezerType === 'Ultra-Low Upright' || this.viewInfo[0].freezerType === 'Freezer Upright') this.getRacksForFreezerByShefId(reqParams);
  }

  /** Onchange Page **/
  onChangePage(event?: PageEvent) {
    this.paginate.size = event.pageSize;
    this.paginate.page = event.pageIndex;
    if (this.viewInfo[0].type === 'open-shelf' || this.viewInfo[0].refType === '+5 WalkIn' || this.viewInfo[0].freezerType == 'Walk In' || this.viewInfo[0].refType == '+5 WalkIn')
      this.paginateSections(false);
    if (this.viewInfo[0].refType == '+5 Upright' || this.viewInfo[0].freezerType === 'Ultra-Low Upright' || this.viewInfo[0].freezerType === 'Freezer Upright') this.paginateRacks(false);
    return event;
  }

  // Get Section For Incubator By Shelve Id
  getSectionForIncByShelveId(reqParams) {
    this.viewInfo[0].storageType='Inc-Shelf-Section'
    this.storageSrv._getRequest(this.viewInfo[0],this.viewInfo[0].shelve.id, reqParams).subscribe(res => {
      this.dataSource.data = res.body;
      this.totalData = res.headers.get('X-Total-Count');
    })
  }

  // Get Section For OS By Shelve Id
  getSectionForOsByShelveId(reqParams) {
    this.viewInfo[0].storageType='Os-Shelf-Section'
    this.storageSrv._getRequest(this.viewInfo[0],this.viewInfo[0].shelve.id, reqParams).subscribe(res => {
      this.dataSource.data = res.body;
      this.totalData = res.headers.get('X-Total-Count');
    })
  }

  // Get Section For Refrigerator By Shelve Id
  getSectionForRefByShelveId(reqParams) {
    this.viewInfo[0].storageType='Ref-Shelf-Section';
    this.storageSrv._getRequest(this.viewInfo[0],this.viewInfo[0].shelve.id, reqParams).subscribe(res => {
      this.dataSource.data = res.body;
      this.totalData = res.headers.get('X-Total-Count');
    })
  }

  // Get Racks For Refrigerator By Shelve Id
  getRacksForRefByShelfId(reqParams) {
    this.viewInfo[0].storageType='Ref-Shelf-Rack';
    this.storageSrv._getRequest(this.viewInfo[0],this.viewInfo[0].shelve.id, reqParams).subscribe(res => {
      this.dataSource.data = res.body;
      this.totalData = res.headers.get('X-Total-Count');
    });
  }

  // Get Section For Freezer By Shelve Id
  getSectionForFreezerByShelveId(reqParams) {
    this.viewInfo[0].storageType='Freezer-Shelve-Section'
    this.storageSrv._getRequest(this.viewInfo[0],this.viewInfo[0].shelve.id, reqParams).subscribe(res => {
      this.dataSource.data = res.body;
      this.totalData = res.headers.get('X-Total-Count');
    })
  }

  // Get Racks For Freezer By Shelve Id
  getRacksForFreezerByShefId(reqParams) {
    this.viewInfo[0].storageType='Freezer-Shelve-Rack'
    this.storageSrv._getRequest(this.viewInfo[0],this.viewInfo[0].shelve.id, reqParams).subscribe(res => {
      this.dataSource.data = res.body;
      this.totalData = res.headers.get('X-Total-Count');
    });
  }

  /** open CREATE Section **/
  openCreateSection(newData?): void {
    if (newData) {
      this.storageSrv.setSharedSection(newData);
    } else {
      this.storageSrv.setSharedSection("");
    }
    let dialogRef = this.dialog.open(CreateSectionComponent, {
      width: '700px',
      data: this.viewInfo[0]
    });
  }

  /** open CREATE RACK **/
  openCreateRack(newData?): void {
    if (newData) {
      this.storageSrv.setSharedRack(newData);
    } else {
      this.storageSrv.setSharedRack("");
    }
    let dialogRef = this.dialog.open(CreateRackComponent, {
      width: '700px',
      data: this.viewInfo[0]
    });
  }

  /** DELETE Section **/
  onDelete(row, index) {
    this.validatorSrv.userValidator('delete').then(res => {
      if (res.val) {
        delete res.val;
        if (this.viewInfo[0].type === 'incubator' && this.viewInfo[0].incType == 'Walk In') this.deleteIncSectionForShelve(row, index,res);
        if (this.viewInfo[0].refType == '+5 WalkIn') this.deleteRefSectionForShelve(row, index, res);
        if (this.viewInfo[0].type === 'open-shelf') this.deleteOsSectionForShelve(row, index,res);
        if (this.viewInfo[0].refType == '+5 Upright') this.deleteRefRacksForShelve(row, index,res);
        if (this.viewInfo[0].freezerType == 'Walk In') this.deleteFreezerSectionForShelve(row, index,res);
        if (this.viewInfo[0].freezerType === 'Ultra-Low Upright' || this.viewInfo[0].freezerType === 'Freezer Upright') this.deleteFreezerRacksForShelve(row, index,res);
      }
    }).catch(err => {
      console.error("Delete Shelf Failed", err);
    });
  }

  // Delete Incubator Section For Shelve
  deleteIncSectionForShelve(section, index,res) {
    this.storageSrv._deleteRequest(this.viewInfo[0],section,res).subscribe(data => {
      let sectionData = this.dataSource.data;
      sectionData.splice(Number(index), 1);
      this.dataSource.data = sectionData;
      this.totalData = sectionData.length;
    },err=>{
       this.helper.showSnackbar(err.error.message,false,true);
     });
  }

  // Delete OS Section For Shelve
  deleteOsSectionForShelve(section, index,res) {
    this.storageSrv._deleteRequest(this.viewInfo[0],section,res).subscribe(data => {
      let sectionData = this.dataSource.data;
      sectionData.splice(Number(index), 1);
      this.dataSource.data = sectionData;
      this.totalData = sectionData.length;
    },err=>{
      this.helper.showSnackbar(err.error.message,false,true);
    });
  }

  // Delete Refrigerator Section For Shelve
  deleteRefSectionForShelve(section, index, res) {
    this.storageSrv._deleteRequest(this.viewInfo[0],section, res).subscribe(data => {
      let sectionData = this.dataSource.data;
      sectionData.splice(Number(index), 1);
      this.dataSource.data = sectionData;
      this.totalData = sectionData.length;
    },err=>{
       this.helper.showSnackbar(err.error.message,false,true);
      });
  }

  // Delete Refrigerator Racks For Shelve
  deleteRefRacksForShelve(rack, index, res) {
    this.storageSrv._deleteRequest(this.viewInfo[0],rack, res).subscribe(data => {
      let sectionData = this.dataSource.data;
      sectionData.splice(Number(index), 1);
      this.dataSource.data = sectionData;
      this.totalData = sectionData.length;
    },err=>{
       this.helper.showSnackbar(err.error.message,false,true);
      });
  }

  // Delete Freezer Section For Shelve
  deleteFreezerSectionForShelve(section, index, res) {
    this.storageSrv._deleteRequest(this.viewInfo[0],section, res).subscribe(data => {
      let sectionData = this.dataSource.data;
      sectionData.splice(Number(index), 1);
      this.dataSource.data = sectionData;
      this.totalData = sectionData.length;
    },err=>{
       this.helper.showSnackbar(err.error.message,false,true);
      })
  }

  // Delete Freezer Racks For Shelve
  deleteFreezerRacksForShelve(rack, index, res) {
    this.storageSrv._deleteRequest(this.viewInfo[0],rack, res).subscribe(data => {
      let sectionData = this.dataSource.data;
      sectionData.splice(Number(index), 1);
      this.dataSource.data = sectionData;
      this.totalData = sectionData.length;
    },err=>{
      this.helper.showSnackbar(err.error.message,false,true);
     });
  }

  // Search Incubator Section By Shelve Id
  searchIncSectionByShelveId(filterValue?: any) {
    this.storageSrv.searchIncSectionByShelveId(this.viewInfo[0].shelve.id, filterValue).subscribe(res => {
      this.dataSource.data = res.body;
    })
  }

  // Search OS Section By Shelve Id
  searchOsSectionByShelveId(filterValue?: any) {
    this.storageSrv.searchOsSectionByShelveId(this.viewInfo[0].shelve.id, filterValue).subscribe(res => {
      this.dataSource.data = res.body;
    })
  }

  // Search Freezer Rack By Shelve Id
  searchFreezerRackByShelveId(filterValue?: any) {
    this.storageSrv.searchFreezerRackByShelveId(this.viewInfo[0].shelve.id, filterValue).subscribe(res => {
      this.dataSource.data = res.body;
    })
  }

  // Search Rack For Refrigerator By Shelve Id
  searchRacksForRefByShefId(filterValue?: any) {
    this.storageSrv.searchRacksForRefByShefId(this.viewInfo[0].shelve.id, filterValue).subscribe(res => {
      this.dataSource.data = res.body;
    })
  }

  // Search Refrigerator Section By Shelve Id
  searchRefSectionByShelveId(filterValue?: any) {
    this.storageSrv.searchRefSectionByShelveId(this.viewInfo[0].shelve.id, filterValue).subscribe(res => {
      this.dataSource.data = res.body;
    })
  }

  // Search Freezer Section By Shelve Id
  searchFreezerSectionByShelveId(filterValue?: any) {
    this.storageSrv.searchFreezerSectionByShelveId(this.viewInfo[0].shelve.id, filterValue).subscribe(res => {
      this.dataSource.data = res.body;
    })
  }

  // Filter Freezer Section By Shelve Id
  filterFreezerSectionByShelveId(filter?: any) {
    if (filter.length > 0) this.searchFreezerSectionByShelveId(filter);
    if (filter.length == 0) this.paginateSections(false);
  }

  // Filter Incubator Section By Shelve Id
  filterIncSectionByShelveId(filter?: any) {
    if (filter.length > 0) this.searchIncSectionByShelveId(filter);
    if (filter.length == 0) this.paginateSections();
  }

  // Filter OS Section By Shelve Id
  filterOsSectionByShelveId(filter?: any) {
    if (filter.length > 0) this.searchOsSectionByShelveId(filter);
    if (filter.length == 0) this.paginateSections();
  }

  // Filter Freezer Rack By Shelve Id
  filterFreezerRackByShelveId(filter?: any) {
    if (filter.length > 0) this.searchFreezerRackByShelveId(filter);
    if (filter.length == 0) this.paginateRacks();
  }

  // Filter Refirgerator For Rack By Shelve Id
  filterRacksForRefByShefId(filter?: any) {
    if (filter.length > 0) this.searchRacksForRefByShefId(filter);
    if (filter.length == 0) this.paginateRacks();
  }

  // Filter Refirgerator Section By Shelve Id
  filterRefSectionByShelveId(filter?: any) {
    if (filter.length > 0) this.searchRefSectionByShelveId(filter);
    if (filter.length == 0) this.paginateSections();
  }

  // Apply Filter
  applyFilter(filter?: string) {
    if((filter.includes('section-') || filter.includes('Section-')) || filter.includes('rack-') || filter.includes('Rack-')) filter = filter.split("-").pop();

    if (this.viewInfo[0].type === 'incubator' && this.viewInfo[0].incType == 'Walk In')
      this.filterIncSectionByShelveId(filter);
    if (this.viewInfo[0].type === 'open-shelf')
      this.filterOsSectionByShelveId(filter);
    if (this.viewInfo[0].freezerType === 'Ultra-Low Upright' || this.viewInfo[0].freezerType === 'Freezer Upright')
      this.filterFreezerRackByShelveId(filter);
    if (this.viewInfo[0].refType == '+5 Upright')
      this.filterRacksForRefByShefId(filter);
    if (this.viewInfo[0].refType == '+5 WalkIn')
      this.filterRefSectionByShelveId(filter);
    if (this.viewInfo[0].freezerType == 'Walk In')
      this.filterFreezerSectionByShelveId(filter);
  }
  /*Sorting*/
  sortData(event: Sort) {
    this.paginate.sort = event.active + ',' + event.direction;
    if (this.viewInfo[0].incType == 'Walk In' || this.viewInfo[0].type === 'open-shelf' || this.viewInfo[0].refType == '+5 WalkIn' || this.viewInfo[0].freezerType == 'Walk In')
      this.paginateSections();
    if (this.viewInfo[0].refType == '+5 Upright' || this.viewInfo[0].freezerType === 'Ultra-Low Upright' || this.viewInfo[0].freezerType === 'Freezer Upright')
      this.paginateRacks(false);
  }

}