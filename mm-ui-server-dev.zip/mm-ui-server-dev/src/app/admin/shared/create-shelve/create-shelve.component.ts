import { Component, OnInit, Inject, Input, Output } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { FormGroup, FormControl, Validators, FormGroupDirective, NgForm, FormBuilder, FormArray } from '@angular/forms';
import { ErrorStateMatcher } from '@angular/material/core';
import { HelperService } from '../../../services/helper.service';
import { StorageService } from '../../services/storage.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { StorageModel } from 'app/models/storage.model';
import { ValidatorService } from 'app/services/validator.service';

export class MyErrorStateMatcher implements ErrorStateMatcher {

  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = form && form.submitted;
    return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
  }

}

@Component({
  selector: 'app-create-shelve',
  templateUrl: './create-shelve.component.html',
  styleUrls: ['./create-shelve.component.scss']
})

export class CreateShelveComponent implements OnInit {

  public statusTypes: any[] = ['N/A', 'Quarantine', 'Release', 'Reject'];
  public shelves: FormArray;
  public shelvesArray: any[] = [];
  public matcher = new MyErrorStateMatcher();
  public editMode: boolean = false;
  public availableshelves: any;
  public viewShelf: Array<StorageModel>;
  public availableSeqId:number[] =[];
  public addedItem:boolean = false;
  public clicked=false;
  // @Input() shelfData: Array<StorageModel>;


  constructor(private dialogRef: MatDialogRef<CreateShelveComponent>, @Inject(MAT_DIALOG_DATA) public dialogData: any,
    private helper: HelperService, private formBuilder: FormBuilder,
    private storageSrv: StorageService,private validatorService:ValidatorService,
    private spinnerService: Ng4LoadingSpinnerService) {
    this.shelves = this.shelveDiagForm.get('shelves') as FormArray;
  }

  ngOnInit() {
    this.storageSrv.sharedShelve.distinctUntilChanged().subscribe(data => {
      if (data) {
        this.shelveDiagForm.patchValue(data);
        this.shelves.at(0).get('statusType').clearValidators();
        this.shelves.at(0).get('statusType').updateValueAndValidity();
        this.editMode = true;
      }
    });
    this.shelvesArray = this.shelveDiagForm.get('shelves').value;
    this.getAvailableSeqIds();
  }

  // Get Available Sequence Ids
  public getAvailableSeqIds() {
    if (this.dialogData.type === 'incubator' && !('rack' in this.dialogData))
      this.storageSrv.getSeqIdsForIncShelves(this.dialogData.id).subscribe(res => { this.availableSeqId = res.body })
    if (this.dialogData.type === 'incubator' && ('rack' in this.dialogData))
      this.storageSrv.getSeqIdsForIncRackShelf(this.dialogData.rack.id).subscribe(res => { this.availableSeqId = res.body });
    if (this.dialogData.type === 'open-shelf')
      this.storageSrv.getSeqIdsForOsShelf(this.dialogData.rack.id).subscribe(res => { this.availableSeqId = res.body });
    if (this.dialogData.refType === '+5 Upright')
      this.storageSrv.getSeqIdsForRefShelf(this.dialogData.id).subscribe(res => { this.availableSeqId = res.body });
    if (this.dialogData.type === 'refrigerator' && this.dialogData.refType === '+5 WalkIn')
      this.storageSrv.getSeqIdsForRefShelfByRackId(this.dialogData.rack.id).subscribe(res => { this.availableSeqId = res.body });
    if (this.dialogData.freezerType === 'Walk In')
      this.storageSrv.getSeqIdsForFreezerShelfByRackId(this.dialogData.rack.id).subscribe(res => { this.availableSeqId = res.body });
    if (this.dialogData.freezerType === 'Ultra-Low Upright' || this.dialogData.freezerType === 'Freezer Upright')
      this.storageSrv.getSeqIdsForFreezerShelf(this.dialogData.id).subscribe(res => { this.availableSeqId = res.body });
  }

  // Shelve Form
  public shelveDiagForm = this.formBuilder.group({
    id: this.formBuilder.control(''),
    name: this.formBuilder.control(''),
    statusType: this.formBuilder.control(''),
    seqId: this.formBuilder.control(''),
    shelves: this.formBuilder.array([this.createItem()], Validators.required)
  });


  /** form array **/
  createItem(): FormGroup {
    return this.formBuilder.group({
      name: this.formBuilder.control(''),
      seqId: this.formBuilder.control(''),
      isReUsed: this.formBuilder.control(false),
      statusType: this.formBuilder.control('', [ Validators.required])
    });
  }

  /** ADD Field **/
  addItem(): void {
    this.addedItem = true;
    this.shelves = this.shelveDiagForm.get('shelves') as FormArray;
    this.shelves.push(this.createItem());
    this.shelvesArray = this.shelves.value;
  }


  /** REMOVE chips **/
  removeItem(index): void {
    if (index != 0) {
      this.shelves = this.shelveDiagForm.get('shelves') as FormArray;
      this.shelves.removeAt(index);
      this.shelvesArray.splice(index, 1);
    }
  }

  // Re Use
  reUse(mainIndex) {
    var arrayControl = this.shelveDiagForm.get('shelves') as FormArray;
    this.shelvesArray[mainIndex].isReUsed = !this.shelvesArray[mainIndex].isReUsed;
    this.shelveDiagForm.get('shelves').patchValue(this.shelvesArray);
    arrayControl.at(mainIndex).get('seqId').clearValidators();
    arrayControl.at(mainIndex).get('seqId').updateValueAndValidity();
    arrayControl.at(mainIndex).get('seqId').patchValue('');
  }

  /** DESTROY editmode **/
  ngOnDestroy() {
    this.editMode = false;
  }

  /** CREATE a shelve **/
  create() {
    this.validatorService.userValidator(this.editMode?'update':'create').then(res => {
      if(res.val) {
        let shelveObj = this.shelveDiagForm.value;
        this.clicked=false;
        shelveObj['locationId']=this.helper.getLocation();
        delete res.val;
        if (this.shelveDiagForm.valid) {
          if (this.editMode) {
            delete shelveObj.shelves;
            if (this.dialogData.type === 'incubator' && !('rack' in this.dialogData)) this.updateShelveForIncubator(shelveObj,res);
            if (this.dialogData.type === 'incubator' && ('rack' in this.dialogData)) this.updateShelveForRack(shelveObj,res);
            if (this.dialogData.type === 'open-shelf') this.updateShelvesForOs(shelveObj,res);
            if (this.dialogData.refType === '+5 Upright') this.updateShelveForRefregerator(shelveObj,res);
            if (this.dialogData.refType === '+5 WalkIn') this.updateShelveForRefByRackId(shelveObj,res);
            if (this.dialogData.freezerType === 'Walk In') this.updateShelveForFreezerByRackId(shelveObj,res);

            if (this.dialogData.freezerType === 'Ultra-Low Upright' || this.dialogData.freezerType === 'Freezer Upright') this.updateShelveForFreezer(shelveObj,res);
          } else {
            delete shelveObj["id"];
            let generatedSelves = this.generateShelves(shelveObj);
            if (this.dialogData.type === 'incubator' && !('rack' in this.dialogData)) this.addShelveForIncubator(generatedSelves,res);
            if (this.dialogData.type === 'incubator' && 'rack' in this.dialogData) this.addShelveForRacks(generatedSelves,res);
            if (this.dialogData.type === 'open-shelf') this.addShelvesForOs(generatedSelves,res);
            // if (this.dialogData.type === 'freezer') this.addShelveForFreezer(generatedSelves);
            if (this.dialogData.refType === '+5 Upright') this.addShelveForRefregerator(generatedSelves,res);
            if (this.dialogData.refType === '+5 WalkIn') this.addShelveForRefByRackId(generatedSelves,res);
            if (this.dialogData.freezerType === 'Walk In') this.addShelveForFreezerByRackId(generatedSelves,res);
            if (this.dialogData.freezerType === 'Ultra-Low Upright' || this.dialogData.freezerType === 'Freezer Upright') this.addShelveForFreezer(generatedSelves,res)
          }
        }
      }
    })
  }

  // create  shelves
  generateShelves(shelveObj) {
    for (let i = 0; i < shelveObj.shelves.length; i++) {
      shelveObj.shelves[i].name = 'Shelf';
      if (this.dialogData.type === 'incubator' && !('rack' in this.dialogData)) {
        shelveObj.shelves[i].incubatorId = this.dialogData.id;
      }
      if (this.dialogData.type === 'incubator' && ('rack' in this.dialogData)) {
        shelveObj.shelves[i].incubatorId = this.dialogData.id;
        shelveObj.shelves[i].incRowId = this.dialogData.row.id;
        shelveObj.shelves[i].incRackId = this.dialogData.rack.id;
      }
      if (this.dialogData.type === 'open-shelf') {
        shelveObj.shelves[i].openStorageId = this.dialogData.id;
        shelveObj.shelves[i].osRackId = this.dialogData.rack.id;
      }
      if (this.dialogData.type === 'refrigerator' && this.dialogData.refType === '+5 Upright') {
        shelveObj.shelves[i].refId = this.dialogData.id
      }
      if (this.dialogData.type === 'refrigerator' && this.dialogData.refType === '+5 WalkIn') {
        shelveObj.shelves[i].refId = this.dialogData.id;
        shelveObj.shelves[i].refRackId = this.dialogData.rack.id;
        shelveObj.shelves[i].refRowId = this.dialogData.row.id;
      }
      if (this.dialogData.type === 'freezer' && this.dialogData.freezerType === 'Walk In') {
        shelveObj.shelves[i].freezerId = this.dialogData.id;
        shelveObj.shelves[i].freezerRowId = this.dialogData.row.id;
        shelveObj.shelves[i].freezerRackId = this.dialogData.rack.id;
      }
      if (this.dialogData.type === 'freezer' && (this.dialogData.freezerType === 'Ultra-Low Upright' || this.dialogData.freezerType === 'Freezer Upright')) shelveObj.shelves[i].freezerId = this.dialogData.id;
    }
    return shelveObj.shelves;
  }

  // Racks
  addShelveForRacks(shelves,res) {
    this.storageSrv._addRequest(this.dialogData,this.dialogData.rack.id, shelves,res).subscribe(data => {
      this.helper.showSnackbar('Successfully Created Shelves!');
      this.dialogRef.close(this.shelveDiagForm.value);
      this.storageSrv.setSharedShelve(data);
      this.spinnerService.hide();
    }, err => {
         this.helper.showSnackbar(err.error.message,false, true);       
    })
  }

  // Incubator
  addShelveForIncubator(shelves,res) {
    this.storageSrv._addRequest(this.dialogData,this.dialogData.id, shelves,res).subscribe(data => {
      this.helper.showSnackbar('Successfully Created Shelves!');
      this.dialogRef.close(this.shelveDiagForm.value);
      this.storageSrv.setSharedShelve(data);
      this.spinnerService.hide();
    }, err => {
        this.helper.showSnackbar(err.error.message,false, true);       
    })
  }

  // Update Shelve For Incubator
  updateShelveForIncubator(shelveObj,res) {
    shelveObj.incubatorId = this.dialogData.id;
    this.storageSrv._updateRequest(this.dialogData,shelveObj,res).subscribe(data => {
      this.helper.showSnackbar('Successfully Updated Shelve !');
      this.dialogRef.close(this.shelveDiagForm.value);
      this.storageSrv.setSharedShelve(data);
      this.spinnerService.hide();
    },err => {
      this.helper.showSnackbar(err.error.message,false,true);
   })
  }

  // Open Shelving
  addShelvesForOs(shelves,res) {
    this.storageSrv._addRequest(this.dialogData,this.dialogData.rack.id, shelves,res).subscribe(data => {
      this.helper.showSnackbar('Successfully Created Shelve!');
      this.dialogRef.close(this.shelveDiagForm.value);
      this.storageSrv.setSharedShelve(data);
      this.spinnerService.hide();
    }, err => {
       this.helper.showSnackbar(err.error.message,false, true);       
    })
  }

  // Update Shelve For OS
  updateShelvesForOs(shelfObj,res) {
    shelfObj.openStorageId = this.dialogData.id;
    shelfObj.osRackId = this.dialogData.rack.id;
    this.storageSrv._updateRequest(this.dialogData,shelfObj,res).subscribe(data => {
      this.helper.showSnackbar('Successfully Updated Shelve !');
      this.dialogRef.close(this.shelveDiagForm.value);
      this.storageSrv.setSharedShelve(data);
      this.spinnerService.hide();
    },err => {
      this.helper.showSnackbar(err.error.message,false,true);
   })
  }

  //refrigerator 
  addShelveForRefregerator(shelves,res) {
    this.storageSrv._addRequest(this.dialogData,this.dialogData.id, shelves,res).subscribe(data => {
      this.helper.showSnackbar('Successfully Created Shelve!');
      this.dialogRef.close(this.shelveDiagForm.value);
      this.storageSrv.setSharedShelve(data);
      this.spinnerService.hide();
    }, err => {
       this.helper.showSnackbar(err.error.message,false, true);       
    })
  }

  // Update Shelve For Refrigerator
  updateShelveForRefregerator(shelfObj,res) {
    shelfObj.refId = this.dialogData.id;
    this.storageSrv._updateRequest(this.dialogData,shelfObj,res).subscribe(data => {
      this.helper.showSnackbar('Successfully Updated Shelve !');
      this.dialogRef.close(this.shelveDiagForm.value);
      this.storageSrv.setSharedShelve(data);
      this.spinnerService.hide();
    },err => {
      this.helper.showSnackbar(err.error.message,false,true);
   })
  }

  // Update Shelve For Incubator By RackId
  updateShelveForRack(shelveObj,res) {
    shelveObj.incubatorId = this.dialogData.id;
    shelveObj.incRowId = this.dialogData.row.id;
    shelveObj.incRackId = this.dialogData.rack.id;
    this.storageSrv._updateRequest(this.dialogData, shelveObj,res).subscribe(data => {
      this.helper.showSnackbar('Successfully Updated Shelve !');
      this.dialogRef.close(this.shelveDiagForm.value);
      this.storageSrv.setSharedShelve(data);
      this.spinnerService.hide();
    },err => {
      this.helper.showSnackbar(err.error.message,false,true);
   })
  }

  // Add Shelve For Refrigerator By Rack ID
  addShelveForRefByRackId(shelves,res) {
    this.storageSrv._addRequest(this.dialogData,this.dialogData.rack.id, shelves,res).subscribe(data => {
      this.helper.showSnackbar('Successfully Created Shelves!');
      this.dialogRef.close(this.shelveDiagForm.value);
      this.storageSrv.setSharedShelve(data);
      this.spinnerService.hide();
    }, err => {
       this.helper.showSnackbar(err.error.message,false, true);       
    })
  }

  // Update Shelve For Refrigerator By Rack Id
  updateShelveForRefByRackId(shelveObj,res) {
    shelveObj.refId = this.dialogData.id;
    shelveObj.refRowId = this.dialogData.row.id;
    shelveObj.refRackId = this.dialogData.rack.id;
    this.storageSrv._updateRequest(this.dialogData,shelveObj,res).subscribe(data => {
      this.helper.showSnackbar('Successfully Updated Shelve !');
      this.dialogRef.close(this.shelveDiagForm.value);
      this.storageSrv.setSharedShelve(data);
      this.spinnerService.hide();
    },err => {
      this.helper.showSnackbar(err.error.message,false,true);
   })
  }

  // Add Shelve For Freezer By Rack Id
  addShelveForFreezerByRackId(shelves,res) {
    this.storageSrv._addRequest(this.dialogData,this.dialogData.rack.id, shelves,res).subscribe(data => {
      this.helper.showSnackbar('Successfully Created Shelves!');
      this.dialogRef.close(this.shelveDiagForm.value);
      this.storageSrv.setSharedShelve(data);
      this.spinnerService.hide();
    }, err => {
       this.helper.showSnackbar(err.error.message,false, true);       
    })
  }

  // Add Shelve For Freezer
  addShelveForFreezer(shelves,res) {
    this.storageSrv._addRequest(this.dialogData,this.dialogData.id, shelves,res).subscribe(data => {
      this.helper.showSnackbar('Successfully Created Shelve!');
      this.dialogRef.close(this.shelveDiagForm.value);
      this.storageSrv.setSharedShelve(data);
      this.spinnerService.hide();
    }, err => {
       this.helper.showSnackbar(err.error.message,false, true);       
    })
  }

  // Update Shelve For Freezer By Rack Id
  updateShelveForFreezerByRackId(shelveObj,res) {
    shelveObj.freezerId = this.dialogData.id;
    shelveObj.freezerRowId = this.dialogData.row.id;
    shelveObj.freezerRackId = this.dialogData.rack.id;
    this.storageSrv._updateRequest(this.dialogData,shelveObj,res).subscribe(data => {
      this.helper.showSnackbar('Successfully Updated Shelve !');
      this.dialogRef.close(this.shelveDiagForm.value);
      this.storageSrv.setSharedShelve(data);
      this.spinnerService.hide();
    },err => {
      this.helper.showSnackbar(err.error.message,false,true);
   })
  }

  // Update Shelve For Freezer
  updateShelveForFreezer(shelfObj,res) {
    shelfObj.freezerId = this.dialogData.id;
    this.storageSrv._updateRequest(this.dialogData,shelfObj,res).subscribe(data => {
      this.helper.showSnackbar('Successfully Updated Shelve !');
      this.dialogRef.close(this.shelveDiagForm.value);
      this.storageSrv.setSharedShelve(data);
      this.spinnerService.hide();
    },err => {
      this.helper.showSnackbar(err.error.message,false,true);
   })
  }

  /** CLOSE mat dialog **/
  close() {
    this.dialogRef.close(null);
  }

}
