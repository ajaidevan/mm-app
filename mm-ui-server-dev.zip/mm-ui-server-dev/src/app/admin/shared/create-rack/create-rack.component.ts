import { Component, OnInit, Inject, Input, Output } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { FormGroup, FormControl, Validators, FormGroupDirective, NgForm, FormBuilder, FormArray } from '@angular/forms';
import { ErrorStateMatcher } from '@angular/material/core';
import { HelperService } from '../../../services/helper.service';
import { StorageService } from '../../services/storage.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { StorageModel } from 'app/models/storage.model';
import { ValidatorService } from 'app/services/validator.service';

export class MyErrorStateMatcher implements ErrorStateMatcher {

  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = form && form.submitted;
    return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
  }

}

@Component({
  selector: 'app-create-rack',
  templateUrl: './create-rack.component.html',
  styleUrls: ['./create-rack.component.scss']
})

export class CreateRackComponent implements OnInit {

  public statusTypes: any[] = ['N/A', 'Quarantine', 'Release', 'Reject'];
  public gridTypes: any[] = [{ value: 'SEVEN', name: '7x7' }, { value: 'NINE', name: '9x9' }, { value: 'TEN', name: '10x10' }, { value: 'ARROW_HEAD', name: 'ARROW HEAD' }];
  public racks: FormArray;
  public racksArray: any[] = [];
  public matcher = new MyErrorStateMatcher();
  public editMode: boolean = false;
  public availableracks: any;
  public viewShelf: Array<StorageModel>;
  public availableSeqId :number[] =[];
  public addedItem:boolean = false;
  public clicked=false;

  // @Input() shelfData: Array<StorageModel>;


  constructor(private dialogRef: MatDialogRef<CreateRackComponent>, @Inject(MAT_DIALOG_DATA) public dialogData: any,
    private helper: HelperService, private formBuilder: FormBuilder,
    private storageSrv: StorageService,private validatorService:ValidatorService,
    private spinnerService: Ng4LoadingSpinnerService) {
    this.racks = this.rackDiagForm.get('racks') as FormArray;
  }

  ngOnInit() {
    this.storageSrv.sharedRack.distinctUntilChanged().subscribe(data => {
      if (data) {
        this.rackDiagForm.patchValue(data);
        this.racks.at(0).get('statusType').clearValidators();
        this.racks.at(0).get('statusType').updateValueAndValidity();
        this.editMode = true;
      }
    });
    this.racksArray = this.rackDiagForm.get('racks').value;
    this.getAvailableSeqIds();
  }

  // Rack Form
  public rackDiagForm = this.formBuilder.group({
    id: this.formBuilder.control(''),
    name: this.formBuilder.control(''),
    statusType: this.formBuilder.control(''),
    gridType: this.formBuilder.control(''),
    seqId: this.formBuilder.control(''),
    racks: this.formBuilder.array([this.createItem()], Validators.required),
  });

  // Get Available Sequence Ids
  public getAvailableSeqIds() {
    if (this.dialogData.type === 'incubator' && ('row' in this.dialogData))
      this.storageSrv.getSeqIdsForIncRack(this.dialogData.row.id).subscribe(res => { this.availableSeqId = res.body })
    if (this.dialogData.type === 'open-shelf')
      this.storageSrv.getSeqIdsForOsRack(this.dialogData.id).subscribe(res => { this.availableSeqId = res.body });
    if (this.dialogData.refType === '+5 WalkIn')
      this.storageSrv.getSeqIdsForRefRackByRowId(this.dialogData.row.id).subscribe(res => { this.availableSeqId = res.body });
    if (this.dialogData.refType === '+5 Upright')
      this.storageSrv.getSeqIdsForRefRackByShelfId(this.dialogData.shelve.id).subscribe(res => { this.availableSeqId = res.body });
    if (this.dialogData.refType === '+5 Chest')
      this.storageSrv.getSeqIdsForRefRackByRefId(this.dialogData.id).subscribe(res => { this.availableSeqId = res.body });
    if (this.dialogData.freezerType === 'Walk In')
      this.storageSrv.getSeqIdsForFreezerRackByRowId(this.dialogData.row.id).subscribe(res => { this.availableSeqId = res.body });
    if (this.dialogData.freezerType === 'LN2' || this.dialogData.freezerType === 'Ultra-Low Chest' || this.dialogData.freezerType === 'Freezer Chest')
      this.storageSrv.getSeqIdsForFreezerRackById(this.dialogData.id).subscribe(res => { this.availableSeqId = res.body });
    if (this.dialogData.freezerType === 'Ultra-Low Upright' || this.dialogData.freezerType === 'Freezer Upright')
      this.storageSrv.getSeqIdsForFreezerRacksByShelfId(this.dialogData.shelve.id).subscribe(res => { this.availableSeqId = res.body });
  }

  /** form array **/
  createItem(): FormGroup {
    return this.formBuilder.group({
      name: this.formBuilder.control(''),
      seqId: this.formBuilder.control(''),
      isReUsed: this.formBuilder.control(false),
      statusType: this.formBuilder.control('', [ Validators.required]),
      gridType: this.formBuilder.control(''),
    });
  }

  /** ADD Field **/
  addItem(): void {
    this.addedItem = true;
    this.racks = this.rackDiagForm.get('racks') as FormArray;
    this.racks.push(this.createItem());
    this.racksArray = this.racks.value;
  }


  /** REMOVE chips **/
  removeItem(index): void {
    if (index != 0) {
      this.racks = this.rackDiagForm.get('racks') as FormArray;
      this.racks.removeAt(index);
      this.racksArray.splice(index, 1);
    }
  }

  // Re Use
  reUse(mainIndex) {
    var arrayControl = this.rackDiagForm.get('racks') as FormArray;
    this.racksArray[mainIndex].isReUsed = !this.racksArray[mainIndex].isReUsed;
    this.rackDiagForm.get('racks').patchValue(this.racksArray);
    arrayControl.at(mainIndex).get('seqId').clearValidators();
    arrayControl.at(mainIndex).get('seqId').updateValueAndValidity();
    arrayControl.at(mainIndex).get('seqId').patchValue('');
  }

  /** DESTROY editmode **/
  ngOnDestroy() {
    this.editMode = false;
  }

  /** CREATE a Rack **/
  create() {
    this.validatorService.userValidator(this.editMode?'update':'create').then(res => {
      if(res.val) {
        let rackObj = this.rackDiagForm.value;
        this.clicked=false;
        delete res.val;
        rackObj['locationId']=this.helper.getLocation();
          if (this.rackDiagForm.valid) {
            if (this.editMode) {
              delete rackObj.racks;
              if (this.dialogData.type === 'incubator') this.updateRackForIncubator(rackObj,res);
              if (this.dialogData.type === 'open-shelf') this.updateRackForOs(rackObj,res);
              if (this.dialogData.refType === '+5 WalkIn') this.updateRackForRefByRow(rackObj,res);
              if (this.dialogData.refType === '+5 Upright') this.updateRackForRefByShelf(rackObj,res);
              if (this.dialogData.refType === '+5 Chest') this.updateRackForRefrigerator(rackObj,res);
              if (this.dialogData.freezerType === 'Walk In') this.updateRackForFreezerByRowId(rackObj,res);
              if (this.dialogData.freezerType === 'LN2' || this.dialogData.freezerType === 'Ultra-Low Chest' || this.dialogData.freezerType === 'Freezer Chest') this.updateRackForFreezer(rackObj,res);
              if (this.dialogData.freezerType === 'Ultra-Low Upright' || this.dialogData.freezerType === 'Freezer Upright') this.updateRackForFreezerByShelf(rackObj,res);
            } else {
              delete rackObj["id"];
              let generatedRacks = this.generateRacks(rackObj);

              if (this.dialogData.type === 'incubator') this.addRackForIncubatorRows(this.dialogData.row.id, generatedRacks,res);
              if (this.dialogData.type === 'open-shelf') this.addRackForOs(generatedRacks,res);
              if (this.dialogData.refType === '+5 WalkIn') this.addRackForRefByRow(this.dialogData.row.id, generatedRacks,res);
              if (this.dialogData.refType === '+5 Upright') this.addRackForRefByShelf(this.dialogData.shelve.id, generatedRacks,res);
              if (this.dialogData.refType === '+5 Chest') this.addRackForRefrigerator(this.dialogData.id, generatedRacks,res);
              if (this.dialogData.freezerType === 'Walk In') this.addRackForFreezerByRow(this.dialogData.row.id, generatedRacks,res);
              if (this.dialogData.freezerType === 'Ultra-Low Upright' || this.dialogData.freezerType === 'Freezer Upright') this.addRackForFreezerByShelf(this.dialogData.shelve.id, generatedRacks,res);
              if (this.dialogData.freezerType === 'LN2' || this.dialogData.freezerType === 'Ultra-Low Chest' || this.dialogData.freezerType === 'Freezer Chest') this.addRackForFreezer(this.dialogData.id, generatedRacks,res);
            }
          }
      }
    })
  }

  // Generate  racks
  generateRacks(rackObj) {
    for (let i = 0; i < rackObj.racks.length; i++) {
      rackObj.racks[i].name = 'Rack';
      if (this.dialogData.type === 'incubator') {
        rackObj.racks[i].incubatorId = this.dialogData.id;
        rackObj.racks[i].incRowId = this.dialogData.row.id;
      }
      if (this.dialogData.type === 'open-shelf') {
        rackObj.racks[i].openStorageId = this.dialogData.id;
      }
      if (this.dialogData.freezerType === 'Walk In') {
        rackObj.racks[i].gridType = 'ZERO';
        rackObj.racks[i].freezerId = this.dialogData.id;
        rackObj.racks[i].freezerRowId = this.dialogData.row.id;
      }
      if (this.dialogData.refType === '+5 WalkIn') {
        rackObj.racks[i].gridType = 'ZERO';
        rackObj.racks[i].refId = this.dialogData.id;
        rackObj.racks[i].refRowId = this.dialogData.row.id;
      }
      if (this.dialogData.refType === '+5 Upright') {
        rackObj.racks[i].refId = this.dialogData.id;
        rackObj.racks[i].refShelfId = this.dialogData.shelve.id;
      }
      if (this.dialogData.refType === '+5 Chest') {
        rackObj.racks[i].refId = this.dialogData.id;
      }
      if (this.dialogData.freezerType === 'Ultra-Low Upright' || this.dialogData.freezerType === 'Freezer Upright') {
        rackObj.racks[i].freezerId = this.dialogData.id;
        rackObj.racks[i].freezerShelfId = this.dialogData.shelve.id;
      }
      if (this.dialogData.freezerType === 'LN2' || this.dialogData.freezerType === 'Ultra-Low Chest' || this.dialogData.freezerType === 'Freezer Chest') {
        rackObj.racks[i].freezerId = this.dialogData.id;
      }
    }
    return rackObj.racks;
  }

  //Add Rack For Incubator By Rows
  addRackForIncubatorRows(rowId, racks,res) {
    this.storageSrv._addRequest(this.dialogData,rowId, racks,res).subscribe(data => {
      this.helper.showSnackbar('Successfully Created Rack!');
      this.dialogRef.close(this.rackDiagForm.value);
      this.storageSrv.setSharedRack(data);
      this.spinnerService.hide();
    }, err => {
       this.helper.showSnackbar(err.error.message,false,true);
    })
  }

  // Update Rack For Incubator By Row
  updateRackForIncubator(rackObj,res) {
    rackObj.incubatorId = this.dialogData.id;
    rackObj.incRowId = this.dialogData.row.id;
    this.storageSrv._updateRequest(this.dialogData,rackObj,res).subscribe(data => {
      this.helper.showSnackbar('Successfully Updated Rack !');
      this.dialogRef.close(this.rackDiagForm.value);
      this.storageSrv.setSharedRack(data);
      this.spinnerService.hide();
    },err=>{
      this.helper.showSnackbar(err.error.message,false,true);
    })
  }

  // Add Rack For Open Shelving
  addRackForOs(racks,res) {
    this.storageSrv._addRequest(this.dialogData,this.dialogData.id, racks,res).subscribe(data => {
      this.helper.showSnackbar('Successfully Created Rack!');
      this.dialogRef.close(this.rackDiagForm.value);
      this.storageSrv.setSharedRack(data);
      this.spinnerService.hide();
    }, err => {
       this.helper.showSnackbar(err.error.message,false,true);
    })
  }

  // Update Rack For Open Shelving
  updateRackForOs(rackObj,res) {
    rackObj.openStorageId = this.dialogData.id;
    this.storageSrv._updateRequest(this.dialogData,rackObj,res).subscribe(data => {
      this.helper.showSnackbar('Successfully Updated Rack!');
      this.dialogRef.close(this.rackDiagForm.value);
      this.storageSrv.setSharedRack(data);
      this.spinnerService.hide();
    },err=>{
       this.helper.showSnackbar(err.error.message,false,true);
    })
  }

  // Add Rack For Freezer By Row Id
  addRackForFreezerByRow(rowId, racks,res) {
    this.storageSrv._addRequest(this.dialogData,rowId, racks,res).subscribe(data => {
      this.helper.showSnackbar('Successfully Created Rack!');
      this.dialogRef.close(this.rackDiagForm.value);
      this.storageSrv.setSharedRack(data);
      this.spinnerService.hide();
    },err => {
       this.helper.showSnackbar(err.error.message,false,true);
    })
  }

  // Update Rack For Freezer By Row Id
  updateRackForFreezerByRowId(rackObj,res) {
    rackObj.freezerId = this.dialogData.id;
    rackObj.freezerRowId = this.dialogData.row.id;
    rackObj.gridType = 'ZERO';
    this.storageSrv._updateRequest(this.dialogData,rackObj,res).subscribe(data => {
      this.helper.showSnackbar('Successfully Updated Rack !');
      this.dialogRef.close(this.rackDiagForm.value);
      this.storageSrv.setSharedRack(data);
      this.spinnerService.hide();
    },err=>{
      this.helper.showSnackbar(err.error.message,false,true);
    })
  }

  // Add Rack For Refrigerator By Row Id
  addRackForRefByRow(rowId, racks, res) {
    this.storageSrv._addRequest(this.dialogData,rowId, racks, res).subscribe(data => {
      this.helper.showSnackbar('Successfully Created Rack!');
      this.dialogRef.close(this.rackDiagForm.value);
      this.storageSrv.setSharedRack(data);
      this.spinnerService.hide();
    }, err => {
       this.helper.showSnackbar(err.error.message,false,true);
    })
  }

  // Update Rack For Refrigerator By Row
  updateRackForRefByRow(rackObj,res) {
    rackObj.refId = this.dialogData.id;
    rackObj.refRowId = this.dialogData.row.id;
    rackObj.gridType = 'ZERO';
    this.storageSrv._updateRequest(this.dialogData,rackObj, res).subscribe(data => {
      this.helper.showSnackbar('Successfully Updated Rack !');
      this.dialogRef.close(this.rackDiagForm.value);
      this.storageSrv.setSharedRack(data);
      this.spinnerService.hide();
    },err=>{
      this.helper.showSnackbar(err.error.message,false,true);
    })
  }

  // Update Rack For Refrigerator Shelf
  addRackForRefByShelf(shelfId, racks,res) {
    this.storageSrv._addRequest(this.dialogData,shelfId, racks,res).subscribe(data => {
      this.helper.showSnackbar('Successfully Created Rack!');
      this.dialogRef.close(this.rackDiagForm.value);
      this.storageSrv.setSharedRack(data);
      this.spinnerService.hide();
    }, err => {
       this.helper.showSnackbar(err.error.message,false,true);
    })
  }

  // Update Rack For Refrigerator By Shelf
  updateRackForRefByShelf(rackObj,res) {
    rackObj.refId = this.dialogData.id;
    rackObj.refShelfId = this.dialogData.shelve.id;
    this.storageSrv._updateRequest(this.dialogData,rackObj,res).subscribe(data => {
      this.helper.showSnackbar('Successfully Updated Rack !');
      this.dialogRef.close(this.rackDiagForm.value);
      this.storageSrv.setSharedRack(data);
      this.spinnerService.hide();
    },err =>{
      this.helper.showSnackbar(err.error.message,false,true);
    })
  }

  // Add Rack For Refrigerator 
  addRackForRefrigerator(refId, racks,res) {
    this.storageSrv._addRequest(this.dialogData,refId, racks,res).subscribe(data => {
      this.helper.showSnackbar('Successfully Created Rack!');
      this.dialogRef.close(this.rackDiagForm.value);
      this.storageSrv.setSharedRack(data);
      this.spinnerService.hide();
    }, err => {
       this.helper.showSnackbar(err.error.message,false,true);
    })
  }

  // Update Rack For Refrigerator
  updateRackForRefrigerator(rackObj,res) {
    rackObj.refId = this.dialogData.id;
    this.storageSrv._updateRequest(this.dialogData,rackObj,res).subscribe(data => {
      this.helper.showSnackbar('Successfully Updated Rack !');
      this.dialogRef.close(this.rackDiagForm.value);
      this.storageSrv.setSharedRack(data);
      this.spinnerService.hide();
    },err =>{
      this.helper.showSnackbar(err.error.message,false,true);
    })
  }

  // Add Rack For Freezer
  addRackForFreezer(freezerId, racks,res) {
    this.storageSrv._addRequest(this.dialogData,freezerId, racks,res).subscribe(data => {
      this.helper.showSnackbar('Successfully Created Rack!');
      this.dialogRef.close(this.rackDiagForm.value);
      this.storageSrv.setSharedRack(data);
      this.spinnerService.hide();
    }, err => {
       this.helper.showSnackbar(err.error.message,false,true);
    })
  }

  // Update Rack For Freezer
  updateRackForFreezer(rackObj,res) {
    rackObj.freezerId = this.dialogData.id;
    this.storageSrv._updateRequest(this.dialogData,rackObj,res).subscribe(data => {
      this.helper.showSnackbar('Successfully Updated Rack !');
      this.dialogRef.close(this.rackDiagForm.value);
      this.storageSrv.setSharedRack(data);
      this.spinnerService.hide();
    },err =>{
      this.helper.showSnackbar(err.error.message,false,true);
    })
  }

  // Update Rack For Freeezr By SHelf
  addRackForFreezerByShelf(shelfId, racks,res) {
    this.storageSrv._addRequest(this.dialogData,shelfId, racks,res).subscribe(data => {
      this.helper.showSnackbar('Successfully Created Rack!');
      this.dialogRef.close(this.rackDiagForm.value);
      this.storageSrv.setSharedRack(data);
      this.spinnerService.hide();
    }, err => {
        this.helper.showSnackbar(err.error.message,false,true);
    })
  }

  // Update Rack For Freezer By Shelf
  updateRackForFreezerByShelf(rackObj,res) {
    rackObj.freezerId = this.dialogData.id;
    rackObj.freezerShelfId = this.dialogData.shelve.id;
    this.storageSrv._updateRequest(this.dialogData,rackObj,res).subscribe(data => {
      this.helper.showSnackbar('Successfully Updated Rack !');
      this.dialogRef.close(this.rackDiagForm.value);
      this.storageSrv.setSharedRack(data);
      this.spinnerService.hide();
    },err =>{
      this.helper.showSnackbar(err.error.message,false,true);
    })
  }
  /** CLOSE mat dialog **/
  close() {
    this.dialogRef.close(null);
  }

}
