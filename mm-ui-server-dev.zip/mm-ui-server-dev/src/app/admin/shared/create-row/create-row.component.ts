import { Component, OnInit, Inject, Input, Output } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { FormGroup, FormControl, Validators, FormGroupDirective, NgForm, FormBuilder, FormArray } from '@angular/forms';
import { ErrorStateMatcher } from '@angular/material/core';
import { HelperService } from '../../../services/helper.service';
import { StorageService } from '../../services/storage.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { StorageModel } from 'app/models/storage.model';
import { ValidatorService } from 'app/services/validator.service';

export class MyErrorStateMatcher implements ErrorStateMatcher {

  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = form && form.submitted;
    return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
  }

}

@Component({
  selector: 'app-create-row',
  templateUrl: './create-row.component.html',
  styleUrls: ['./create-row.component.scss']
})

export class CreateRowComponent implements OnInit {

  public statusTypes: any[] = ['N/A', 'Quarantine', 'Release', 'Reject'];
  public rows: FormArray;
  public rowsArray: any[] = [];
  public matcher = new MyErrorStateMatcher();
  public editMode: boolean = false;
  public availablerows: any;
  public viewShelf: Array<StorageModel>;
  public availableSeqId:number[] =[];
  public addedItem:boolean = false;
  public clicked=false;

  // @Input() shelfData: Array<StorageModel>;


  constructor(private dialogRef: MatDialogRef<CreateRowComponent>, @Inject(MAT_DIALOG_DATA) public dialogData: any,
    private helper: HelperService, private formBuilder: FormBuilder,
    private storageSrv: StorageService,private validatorService:ValidatorService,
    private spinnerService: Ng4LoadingSpinnerService) {
    this.rows = this.rowDiagForm.get('rows') as FormArray;
  }

  ngOnInit() {
    this.storageSrv.sharedRow.distinctUntilChanged().subscribe(data => {
      if (data) {
        this.rowDiagForm.patchValue(data);
        this.rows.at(0).get('statusType').clearValidators();
        this.rows.at(0).get('statusType').updateValueAndValidity();
        this.editMode = true;
      }
    });
    this.rowsArray = this.rowDiagForm.get('rows').value;
    this.getAvailableSeqIds();
  }

  // Row Form
  public rowDiagForm = this.formBuilder.group({
    id: this.formBuilder.control(''),
    name: this.formBuilder.control(''),
    statusType: this.formBuilder.control(''),
    seqId: this.formBuilder.control(''),
    rows: this.formBuilder.array([this.createItem()], Validators.required),
  });

  // Get Available Sequence Ids
  public getAvailableSeqIds() {
    if (this.dialogData.type === 'incubator')
      this.storageSrv.getSeqIdsForIncRow(this.dialogData.id).subscribe(res => { this.availableSeqId = res.body });
    if (this.dialogData.type === 'open-shelf')
      this.storageSrv.getSeqIdsForOsRow(this.dialogData.id).subscribe(res => { this.availableSeqId = res.body });
    if (this.dialogData.type === 'refrigerator')
      this.storageSrv.getSeqIdsForRefRow(this.dialogData.id).subscribe(res => { this.availableSeqId = res.body });
    if (this.dialogData.type === 'freezer')
      this.storageSrv.getSeqIdsForFreezerRow(this.dialogData.id).subscribe(res => { this.availableSeqId = res.body });
  }

  /** form array **/
  createItem(): FormGroup {
    return this.formBuilder.group({
      name: this.formBuilder.control(''),
      seqId: this.formBuilder.control(''),
      isReUsed: this.formBuilder.control(false),
      statusType: this.formBuilder.control('', [Validators.required])
    });
  }

  /** ADD Field **/
  addItem(): void {
    this.addedItem = true;
    this.rows = this.rowDiagForm.get('rows') as FormArray;
    this.rows.push(this.createItem());
    this.rowsArray = this.rows.value;
  }


  /** REMOVE chips **/
  removeItem(index): void {
    if (index != 0) {
      this.rows = this.rowDiagForm.get('rows') as FormArray;
      this.rows.removeAt(index);
      this.rowsArray.splice(index, 1);
    }
  }

  // Re Use
  reUse(mainIndex) {
    var arrayControl = this.rowDiagForm.get('rows') as FormArray;
    this.rowsArray[mainIndex].isReUsed = !this.rowsArray[mainIndex].isReUsed;
    this.rowDiagForm.get('rows').patchValue(this.rowsArray);
    arrayControl.at(mainIndex).get('seqId').clearValidators();
    arrayControl.at(mainIndex).get('seqId').updateValueAndValidity();
    arrayControl.at(mainIndex).get('seqId').patchValue('');
  }

  /** DESTROY editmode **/
  ngOnDestroy() {
    this.editMode = false;
  }

  /** CREATE a shelve **/
  create() {
    this.validatorService.userValidator(this.editMode?'update':'create').then(res => {
      if(res.val) {
        let rowObj = this.rowDiagForm.value;
        this.clicked=false;
        delete res.val;
        rowObj['locationId']=this.helper.getLocation();
        if (this.rowDiagForm.valid) {
          if (this.editMode) {
            delete rowObj.rows;
            if (this.dialogData.type === 'incubator') this.updateRowForIncubator(rowObj,res);
            if (this.dialogData.type === 'open-shelf') this.updateRowForOs(rowObj,res);
            if (this.dialogData.type === 'refrigerator') this.updateRowForRef(rowObj,res);
            if (this.dialogData.type === 'freezer') this.updateRowForFreezer(rowObj,res);
          } else {
            delete rowObj["id"];
            let generatedRow = this.generateRows(rowObj);
            if (this.dialogData.type === 'incubator') this.addRowForIncubator(generatedRow,res);
            if (this.dialogData.type === 'open-shelf') this.addRowForOs(generatedRow,res);
            if (this.dialogData.type === 'freezer') this.addRowForFreezer(generatedRow,res);
            if (this.dialogData.type === 'refrigerator') this.addRowForRefregerator(generatedRow,res);
          }
        }
      }
    })
  }

  // Generate  rows
  generateRows(rowObj) {
    for (let i = 0; i < rowObj.rows.length; i++) {
      if (this.dialogData.type === 'incubator') { rowObj.rows[i].name = 'Row'; rowObj.rows[i].incubatorId = this.dialogData.id; }
      if (this.dialogData.type === 'open-shelf') { rowObj.rows[i].name = 'Row'; rowObj.rows[i].openStorageId = this.dialogData.id; }
      if (this.dialogData.type === 'freezer') { rowObj.rows[i].name = 'Row'; rowObj.rows[i].freezerId = this.dialogData.id; }
      if (this.dialogData.type === 'refrigerator') { rowObj.rows[i].name = 'Row'; rowObj.rows[i].refId = this.dialogData.id; }
    }
    return rowObj.rows;
  }

  // Add Row For Incubator
  addRowForIncubator(rows,res) {
    this.storageSrv._addRequest(this.dialogData,this.dialogData.id, rows,res).subscribe(data => {
      this.helper.showSnackbar('Successfully Created Row!');
      this.dialogRef.close(this.rowDiagForm.value);
      this.storageSrv.setSharedRow(data);
      this.spinnerService.hide();
    }, err => {
       this.helper.showSnackbar(err.error.message,false, true);
    })
  }

  // Update Row For Incubator
  updateRowForIncubator(rowObj,res) {
    rowObj.incubatorId = this.dialogData.id;
    this.storageSrv._updateRequest(this.dialogData,rowObj,res).subscribe(data => {
      this.helper.showSnackbar('Successfully Updated Row !');
      this.dialogRef.close(this.rowDiagForm.value);
      this.storageSrv.setSharedRow(data);
      this.spinnerService.hide();
    },err =>{
      this.helper.showSnackbar(err.error.message,false, true);
    })
  }

  // Add Row For Freezer
  addRowForFreezer(rows,res) {
    this.storageSrv._addRequest(this.dialogData,this.dialogData.id, rows,res).subscribe(data => {
      this.helper.showSnackbar('Successfully Created Row!');
      this.dialogRef.close(this.rowDiagForm.value);
      this.storageSrv.setSharedRow(data);
      this.spinnerService.hide();
    }, err => {
       this.helper.showSnackbar(err.error.message,false, true);
    })

  }
  updateRowForFreezer(rowObj,res) {
    rowObj.freezerId = this.dialogData.id;
    this.storageSrv._updateRequest(this.dialogData,rowObj,res).subscribe(data => {
      this.helper.showSnackbar('Successfully Updated Row !');
      this.dialogRef.close(this.rowDiagForm.value);
      this.storageSrv.setSharedRow(data);
      this.spinnerService.hide();
    },err =>{
      this.helper.showSnackbar(err.error.message,false, true);
    })
  }

  // Add Row For Refrigerator
  addRowForRefregerator(rows,res) {
    this.storageSrv._addRequest(this.dialogData,this.dialogData.id, rows,res).subscribe(data => {
      this.helper.showSnackbar('Successfully Created Row!');
      this.dialogRef.close(this.rowDiagForm.value);
      this.storageSrv.setSharedRow(data);
      this.spinnerService.hide();
    }, err => {
       this.helper.showSnackbar(err.error.message,false, true);
    })
  }

  // Update Row For Refrigerator
  updateRowForRef(row,res) {
    row.refId = this.dialogData.id;
    this.storageSrv._updateRequest(this.dialogData,row,res).subscribe(data => {
      this.helper.showSnackbar('Successfully Updated Row !');
      this.dialogRef.close(this.rowDiagForm.value);
      this.storageSrv.setSharedRow(data);
      this.spinnerService.hide();
    },err =>{
      this.helper.showSnackbar(err.error.message,false, true);
    })
  }

  // Add Row For Open Shelving
  addRowForOs(rows,res) {
    this.storageSrv._addRequest(this.dialogData,this.dialogData.id, rows,res).subscribe(data => {
      this.helper.showSnackbar('Successfully Created Row!');
      this.dialogRef.close(this.rowDiagForm.value);
      this.storageSrv.setSharedRow(data);
      this.spinnerService.hide();
    }, err => {
       this.helper.showSnackbar(err.error.message,false, true);
    })
  }

  // Update Row For Open SHelving
  updateRowForOs(rowObj,res) {
    rowObj.openStorageId = this.dialogData.id;
    this.storageSrv._updateRequest(this.dialogData,rowObj,res).subscribe(data => {
      this.helper.showSnackbar('Successfully Updated Row !');
      this.dialogRef.close(this.rowDiagForm.value);
      this.storageSrv.setSharedRow(data);
      this.spinnerService.hide();
    },err =>{
      this.helper.showSnackbar(err.error.message,false, true);
    })
  }

  /** CLOSE mat dialog **/
  close() {
    this.dialogRef.close(null);
  }

}
