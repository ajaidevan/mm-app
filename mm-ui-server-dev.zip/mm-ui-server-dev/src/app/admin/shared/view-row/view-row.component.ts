import { Component, OnInit, Input, Output, EventEmitter, ViewChild } from '@angular/core';
import { MatPaginator, MatSort, MatDialog, MatTableDataSource, PageEvent, Sort } from '@angular/material';
import { StorageService } from '../../services/storage.service';
import { StorageModel } from '../../../models/storage.model';
import { CommonApiService } from 'app/services/common-api.service';
import { Router, ActivatedRoute } from '@angular/router';
import { CreateRackComponent } from '../create-rack/create-rack.component';
import { ValidatorService } from 'app/services/validator.service';
import { EventService } from 'app/admin/services/event.service';
import { HelperService } from 'app/services/helper.service';

@Component({
  selector: 'app-view-row',
  templateUrl: './view-row.component.html',
  styleUrls: ['./view-row.component.scss']
})
export class ViewRowComponent implements OnInit {

  public displayedColumns: string[] = ['name', 'staus_type', 'action'];
  public viewMode: boolean = true;
  public dataInfo: Array<StorageModel> = [];
  public dataInfo2: Array<StorageModel> = [];
  public data: any;
  public dataSource = new MatTableDataSource();
  public paginate: any = {};
  public totalRacks: number;
  public editMode: boolean;
  public pageEvent: PageEvent;

  @Input() viewInfo: Array<StorageModel>;
  @Output() viewEvent = new EventEmitter();
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(private storageSrv: StorageService, private router: Router, private validatorSrv: ValidatorService,
    private commonSrv: CommonApiService, private dialog: MatDialog, private route: ActivatedRoute, private eventSrv: EventService,private helper:HelperService) { }

  ngOnInit() {
    this.dataInfo = this.viewInfo;
    //got to inc
    this.eventSrv.rowEventListner().subscribe(viewMode => { this.viewMode = viewMode; });
    this.racksRefreshForRows();
    this.setDefaultParams();
  }

  // Receive View Mode
  receivedViewMode($event) {
    this.viewMode = $event;
  }

  // Go Back
  goBack() {
    this.viewEvent.emit(this.viewMode);
  }

  /** go To rack **/
  gotoRack(data) {
    this.viewMode = false;
    this.viewInfo[0].rack = data;
    this.dataInfo = this.viewInfo;
  }

  //refresh racks for rows.
  racksRefreshForRows() {
    this.storageSrv.sharedRack.distinctUntilChanged().subscribe(data => {
      if (data) {
        this.setDefaultParams();
        this.editMode = true;
      } else {
        this.setDefaultParams();
      }
    });
  }


  // Get Racks For Incubator By Row Id 
  getRacksForIncByRowId(reqParams) {
    this.viewInfo[0].storageType='Inc-Row-Rack'
    this.storageSrv._getRequest(this.viewInfo[0],this.viewInfo[0].row.id, reqParams).subscribe(res => {
      this.dataSource.data = res.body;
      this.totalRacks = res.headers.get('X-Total-Count');
    })
  }

  // Get Racks For Refrigerator By Row Id 
  getRacksForRefByRowId(reqParams) {
    this.viewInfo[0].storageType='Ref-Row-Rack'
    this.storageSrv._getRequest(this.viewInfo[0],this.viewInfo[0].row.id, reqParams).subscribe(res => {
      this.dataSource.data = res.body;
      this.totalRacks = res.headers.get('X-Total-Count');
    })
  }

  // Get Racks For Freezer By Row Id 
  getRacksForFreezersByRowId(reqParams) {
    this.viewInfo[0].storageType='Freezer-Row-Rack'
    this.storageSrv._getRequest(this.viewInfo[0],this.viewInfo[0].row.id, reqParams).subscribe(res => {
      this.dataSource.data = res.body;
      this.totalRacks = res.headers.get('X-Total-Count');
    })
  }

  /** open CREATE RACK **/
  openCreateRack(newData?): void {
    if (newData) {
      this.storageSrv.setSharedRack(newData);
    } else {
      this.storageSrv.setSharedRack("");
    }
    let dialogRef = this.dialog.open(CreateRackComponent, {
      width: '700px',
      data: this.viewInfo[0]
    });
  }

  /** DELETE rack **/
  onDeleteRack(rack, index) {
    this.validatorSrv.userValidator('delete').then(res => {
      if (res.val) {
        delete res.val;
        if (this.viewInfo[0].type === 'incubator' && this.viewInfo[0].incType == 'Walk In') this.deleteRackForIncubatorRows(rack, index,res);
        if (this.viewInfo[0].type === 'open-shelf') this.deleteRackForOsRows(rack, index,res);
        if (this.viewInfo[0].refType === "+5 WalkIn") this.deleteRackForRefRows(rack, index,res);
        if (this.viewInfo[0].freezerType === "Walk In") this.deleteRackForFreezerRows(rack, index,res);
      }
    }).catch(err => {
      console.error("Delete Openshelving Failed", err);
    });
  }

  // Delete Racks For OS By Rows
  deleteRackForOsRows(rack, index,res) {
        this.storageSrv._deleteRequest(this.viewInfo[0],rack,res).subscribe(data => {
          let rackData = this.dataSource.data;
          rackData.splice(Number(index), 1);
          this.dataSource.data = rackData;
          this.totalRacks = rackData.length;
        },err=>{
          this.helper.showSnackbar(err.error.message,false,true);
        });
  }

  // Delete Racks For Incubators By Rows
  deleteRackForIncubatorRows(rack, index,res) {
    this.storageSrv._deleteRequest(this.viewInfo[0],rack,res).subscribe(data => {
      let rackData = this.dataSource.data;
      rackData.splice(Number(index), 1);
      this.dataSource.data = rackData;
      this.totalRacks = rackData.length;
    },err=>{
       this.helper.showSnackbar(err.error.message,false,true);
      });
  }

  // Delete Racks For Refrigerator By Rows
  deleteRackForRefRows(rack, index,res) {
    this.storageSrv._deleteRequest(this.viewInfo[0],rack,res).subscribe(data => {
      let rackData = this.dataSource.data;
      rackData.splice(Number(index), 1);
      this.dataSource.data = rackData;
      this.totalRacks = rackData.length;
    },err=>{
       this.helper.showSnackbar(err.error.message,false,true);
      });
  }

  // Delete Racks For Freezer By Rows
  deleteRackForFreezerRows(rack, index,res) {
    this.storageSrv._deleteRequest(this.viewInfo[0],rack,res).subscribe(data => {
      let rackData = this.dataSource.data;
      rackData.splice(Number(index), 1);
      this.dataSource.data = rackData;
      this.totalRacks = rackData.length;
    },err=>{
       this.helper.showSnackbar(err.error.message,false,true);
      });
  }

  // Set Default Param
  setDefaultParams() {
    this.paginate = {
      page: 0,
      size: 10,
      sort: 'seqId,ASC'
    }
    this.paginateRacks(false);
  }

  /** Paginate Shelfs */
  paginateRacks(setPage = true) {
    if (setPage) this.paginate.page = 0;
    let reqParams = this.commonSrv.createParam(this.paginate);
    this.router.navigate([], { queryParams: reqParams });
    if (this.viewInfo[0].incType == 'Walk In') this.getRacksForIncByRowId(reqParams);
    if (this.viewInfo[0].refType === "+5 WalkIn") this.getRacksForRefByRowId(reqParams);
    if (this.viewInfo[0].freezerType === "Walk In") this.getRacksForFreezersByRowId(reqParams);
  }

  /** Onchange Page **/
  onChangePage(event?: PageEvent) {
    this.paginate.size = event.pageSize;
    this.paginate.page = event.pageIndex;
    this.paginateRacks(false);
    return event;
  }
  //search racks For Incubator Row
  searchRackForIncByRowId(filterValue?: any) {
    this.storageSrv.searchRackForIncByRowId(this.viewInfo[0].row.id, filterValue).subscribe(res => {
      this.dataSource.data = res.body;
    })
  }

  // Search Racks For OS By Rows
  searchRacksForOsByRowId(filterValue?: any) {
    this.storageSrv.searchRacksForOsByRowId(this.viewInfo[0].row.id, filterValue).subscribe(res => {
      this.dataSource.data = res.body;
    })
  }

  // Search Racks For Refrigerator By Rows
  searchRacksForRefByRowId(filterValue?: any) {
    this.storageSrv.searchRacksForRefByRowId(this.viewInfo[0].row.id, filterValue).subscribe(res => {
      this.dataSource.data = res.body;
    })
  }

  // Search Racks For Freezer By Rows
  searchRacksForFreezerByRowId(filterValue?: any) {
    this.storageSrv.searchRacksForFreezerByRowId(this.viewInfo[0].row.id, filterValue).subscribe(res => {
      this.dataSource.data = res.body;
    })
  }

  // Filter Racks For Freezer By Rows
  filterRacksForFreezerByRowId(filter?: any) {
    if (filter.length > 0) this.searchRacksForFreezerByRowId(filter);
    if (filter.length == 0) this.paginateRacks(false)
  }

  // Filter Racks For Incubator By Rows
  fiterRackForIncByRowId(filter?: any) {
    if (filter.length > 0) this.searchRackForIncByRowId(filter);
    if (filter.length == 0) this.paginateRacks();
  }

  // Filter Racks For OS By Rows
  filterRacksForOsByRowId(filter?: any) {
    if (filter.length > 0) this.searchRacksForOsByRowId(filter);
    if (filter.length == 0) this.paginateRacks();
  }

  // Filter Racks For Refrigerator By Rows
  filterRacksForRefByRowId(filter?: any) {
    if (filter.length > 0) this.searchRacksForRefByRowId(filter);
    if (filter.length == 0) this.paginateRacks();
  }

  //Apply Filter
  applyFilter(filter?: string) {
    if(filter.includes('rack-') || filter.includes('Rack-')) filter = filter.split("-").pop();
    if (this.viewInfo[0].type === 'incubator')
      this.fiterRackForIncByRowId(filter);
    if (this.viewInfo[0].type === 'open-shelf')
      this.filterRacksForOsByRowId(filter);
    if (this.viewInfo[0].refType === "+5 WalkIn")
      this.filterRacksForRefByRowId(filter);
    if (this.viewInfo[0].freezerType === "Walk In")
      this.filterRacksForFreezerByRowId(filter);
  }

  /*Sorting*/
  sortData(event: Sort) {
    this.paginate.sort = event.active + ',' + event.direction;
    this.paginateRacks();
  }

}
