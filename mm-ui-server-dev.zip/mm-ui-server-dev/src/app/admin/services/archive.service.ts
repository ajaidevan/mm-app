import { Injectable } from '@angular/core';
import { HttpClient }   from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';
import { Observable,throwError }   from 'rxjs';
import { ArchiveModel } from 'app/models/archive.model';
import{Ng4LoadingSpinnerService}from'ng4-loading-spinner';
import { catchError, map } from 'rxjs/operators';
import { CommonApiService } from 'app/services/common-api.service';
import { environment } from 'environments/environment';
import { HelperService } from 'app/services/helper.service';



@Injectable()

export class ArchiveService {

  private httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  };
  
  private archiveUrl = '../assets/json-files/non-gmp.json';

  constructor( private http: HttpClient,private spinnerService:Ng4LoadingSpinnerService,private httpRequest: CommonApiService,private helper: HelperService ) { }

  getArchive(): Observable<ArchiveModel[]> {
    this.spinnerService.show();
    return this.http.get<ArchiveModel[]>(this.archiveUrl, this.httpOptions).pipe(map(response => {
      return response;
    }), catchError((error: Error) => throwError(error)));
  }
  getAllReceivablesByStatus(status,paramObj?:any){
    return this.httpRequest.getRequestWithToken(environment.BASEURL + `/mm/receivables/summary?status=${status}&locationId=${this.helper.getLocation()}`,paramObj);
  }
  searchReceivable(status,filterValue?: string){
    return this.httpRequest.getRequestWithToken(environment.BASEURL + '/mm/receivables/summary?status='+status+'&locationId='+this.helper.getLocation()+'&query=' + filterValue, {});
  }
}
