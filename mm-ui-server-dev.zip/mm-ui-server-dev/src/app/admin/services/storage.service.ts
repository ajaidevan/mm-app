import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';
import { Observable, BehaviorSubject,throwError} from 'rxjs';
import { CommonApiService } from 'app/services/common-api.service';
import { environment } from '../../../environments/environment';
import { StorageModel } from 'app/models/storage.model';

@Injectable()
export class StorageService {

  public freezerDetails: any;
  public refrigeratorDetails: any;
  public incubatorDetails: any;
  public roomtempincubatorDetails: any;
  public openshelvingDetails: any;

  private httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  };

  //Freezers
  private createdFreezer = new BehaviorSubject("");
  public currentFreezer = this.createdFreezer.asObservable();
  private sharableFreezer = new BehaviorSubject<any>("");
  public sharedFreezer = this.sharableFreezer.asObservable();
  //Freezer-Slots
  private createdFreezerSlot = new BehaviorSubject("");
  public currentFreezerSlot = this.createdFreezerSlot.asObservable();
  private sharableFreezerSlot = new BehaviorSubject<any>("");
  public sharedFreezerSlot = this.sharableFreezerSlot.asObservable();
  //Shelve
  private createdShelve = new BehaviorSubject("");
  public currentShelve = this.createdShelve.asObservable();
  private sharableShelve = new BehaviorSubject<any>("");
  public sharedShelve = this.sharableShelve.asObservable();
  //Rows
  private createdRow = new BehaviorSubject("");
  public currentRow = this.createdRow.asObservable();
  private sharableRow = new BehaviorSubject<any>("");
  public sharedRow = this.sharableRow.asObservable();
  //Slots
  private createdSlot = new BehaviorSubject("");
  public currentSlot = this.createdSlot.asObservable();
  private sharableSlot = new BehaviorSubject<any>("");
  public sharedSlot = this.sharableSlot.asObservable();
  //Section
  private createdSection = new BehaviorSubject("");
  public currentSection = this.createdSection.asObservable();
  private sharableSection = new BehaviorSubject<any>("");
  public sharedSection = this.sharableSection.asObservable();
  //Racks
  private sharableRack = new BehaviorSubject<any>("");
  public sharedRack = this.sharableRack.asObservable();
  private createdRack = new BehaviorSubject("");
  public currentRack = this.createdRack.asObservable();
  //Refrigerators
  private createdRefrigerator = new BehaviorSubject("");
  public currentRefrigerator = this.createdRefrigerator.asObservable();
  private sharableRefrigerator = new BehaviorSubject<any>("");
  public sharedRefrigerator = this.sharableRefrigerator.asObservable();
  //Incubators
  private createdIncubator = new BehaviorSubject("");
  public currentIncubator = this.createdIncubator.asObservable();
  private sharableIncubator = new BehaviorSubject<any>("");
  public sharedIncubator = this.sharableIncubator.asObservable();
  //Room Temp Incubators
  private createdRoomTempIncubator = new BehaviorSubject("");
  public currentRoomTempIncubator = this.createdRoomTempIncubator.asObservable();
  private sharableRoomTempIncubator = new BehaviorSubject<any>("");
  public sharedRoomTempIncubator = this.sharableRoomTempIncubator.asObservable();
  //Open Shelving Incubators
  private createdOpenShelving = new BehaviorSubject("");
  public currentOpenShelving = this.createdOpenShelving.asObservable();
  private sharableOpenShelving = new BehaviorSubject<any>("");
  public sharedOpenShelving = this.sharableOpenShelving.asObservable();
   //Rows
   private createdRoomRows = new BehaviorSubject("");
   public currentRoomRow = this.createdRoomRows.asObservable();
   private sharableRoomRow = new BehaviorSubject<any>("");
   public sharedRoomRow = this.sharableRoomRow.asObservable();
 
  //Freezer
  sendCurrentFreezer(freezerObj) {
    this.createdFreezer.next(freezerObj);
  }

  setSharedFreezer(freezerObj) {
    this.sharableFreezer.next(freezerObj);
  }

  //Shelves
  sendCurrentShelve(shelveObj) {
    this.createdShelve.next(shelveObj);
  }
  setSharedShelve(shelveObj) {
    this.sharableShelve.next(shelveObj);
  }

  //row
  sendCurrentRow(rowObj) {
    this.createdRow.next(rowObj);
  }
  setSharedRow(rowObj) {
    this.sharableRow.next(rowObj);
  }
  //roomRow
  sendCurrentRoomRow(rowObj){
    this.createdRoomRows.next(rowObj);
  }
  setSharedRoomRow(rowObj){
    this.sharableRoomRow.next(rowObj);
  }
  

  //Slot
  sendCurrentSlot(slotObj) {
    this.createdSlot.next(slotObj);
  }
  setSharedSlot(slotObj) {
    this.sharableSlot.next(slotObj);
  }

  //Section  
  sendCurrentSection(sectionObj) {
    this.createdSection.next(sectionObj);
  }
  setSharedSection(sectionObj) {
    this.sharableSection.next(sectionObj);
  }

  // Rack
  sendCurrentRack(freezerRackObj) {
    this.createdRack.next(freezerRackObj);
  }

  setSharedRack(freezerRackObj) {
    this.sharableRack.next(freezerRackObj);
  }

  // Freezer Slot
  sendCurrentFreezerSlot(freezerSlotObj) {
    this.createdFreezerSlot.next(freezerSlotObj);
  }

  setSharedFreezerSlot(freezerSlotObj) {
    this.sharableFreezerSlot.next(freezerSlotObj);
  }

  // Refrigerator
  sendCurrentRefrigerator(refrigeratorObj) {
    this.createdRefrigerator.next(refrigeratorObj);
  }

  setSharedRefrigerator(refrigeratorObj) {
    this.sharableRefrigerator.next(refrigeratorObj);
  }

  // Incubator
  sendCurrentIncubator(incubatorObj) {
    this.createdIncubator.next(incubatorObj);
  }

  setSharedIncubator(incubatorObj) {
    this.sharableIncubator.next(incubatorObj);
  }

  // Room-Temp Incubator
  sendCurrentRoomTempIncubator(roomTempIncubatorObj) {
    this.createdRoomTempIncubator.next(roomTempIncubatorObj);
  }

  setSharedRoomTempIncubator(roomTempIncubatorObj) {
    this.sharableRoomTempIncubator.next(roomTempIncubatorObj);
  }

  // Open-Shelving
  sendCurrentOpenShelving(openShelvingObj) {
    this.createdOpenShelving.next(openShelvingObj);
  }

  setSharedOpenShelving(openShelvingObj) {
    this.sharableOpenShelving.next(openShelvingObj);
  }

  private userUrl = '../assets/json-files/storage.json';

  constructor(private http: HttpClient, private httpHelper: CommonApiService) {
  }

  /******* Freezer ********/
  getAllFreezersByLocId(locationId, reqParams): any {
    return this._generateRequest('/st/freezers?locationId=' + locationId, reqParams);
  }

  deleteFreezer(freezer: StorageModel,header) {
    return this._generateDeleteRequest('/st/freezers/' + freezer.id, freezer,header);
  }

  addFreezer(freezer: StorageModel,header) {
    return this._generateAddRequest('/st/freezers', freezer,header);
  }

  updateFreezer(freezer: StorageModel,header) {
    return this._generatePutRequest('/st/freezers/', freezer,header);
  }

  /******* Freezer-Shelve ********/
  searchShelveForFreezerRowByRackId(rackId, filterValue?: any) {
    return this._generateRequest('/st/freezer-racks/' + rackId + '/freezer-shelves?query=' + filterValue, {});
  }

  getSeqIdsForFreezerShelf(freezerId) {
    return this._generateRequest('/st/freezers/' + freezerId + '/freezer-shelves/sequences?query=AVAILABLE', {});
  }

  getSeqIdsForFreezerShelfByRackId(rackId) {
    return this._generateRequest('/st/freezer-racks/' + rackId + '/freezer-shelves/sequences?query=AVAILABLE', {});
  }

  searchShelveByFreezerId(freezerId, filterValue?: string) {
    return this._generateRequest('/st/freezers/' + freezerId + '/freezer-shelves?query=' + filterValue, {})
  }

  searchFreezer(locationId, filterValue?: string) {
    return this._generateRequest('/st/freezers?locationId=' + locationId + '&query=' + filterValue, {});
  }

  searchRacksForFreezerByRowId(rowId, filterValue?: any) {
    return this._generateRequest('/st/freezer-rows/' + rowId + '/freezer-racks?query=' + filterValue, {})
  }
  searchRacksByFreezerId(freezerId, filterValue?: any) {
    return this._generateRequest('/st/freezers/' + freezerId + '/freezer-racks?query=' + filterValue, {})
  }

  getAllRacksByFreezerId(freezerId): any {
    return this._generateRequest( '/freezers/location/' + freezerId,{});
  }

  getSeqIdsForFreezerRackByRowId(rowId) {
    return this._generateRequest('/st/freezer-rows/' + rowId + '/freezer-racks/sequences?query=AVAILABLE', {});
  }
  getSeqIdsForFreezerRackById(freezerId) {
    return this._generateRequest('/st/freezers/' + freezerId + '/freezer-racks/sequences?query=AVAILABLE', {});
  }
  getSeqIdsForFreezerRacksByShelfId(shelfId) {
    return this._generateRequest('/st/freezer-shelves/' + shelfId + '/freezer-racks/sequences?query=AVAILABLE', {});
  }

  searchFreezerRackByShelveId(shelfId, filterValue) {
    return this._generateRequest('/st/freezer-shelves/' + shelfId + '/freezer-racks?query=' + filterValue, {})
  }

  deleteRack(rack: StorageModel) {
    return this._generateDeleteRequest('/freezers/' + rack.id, rack,{});
  }

  addRack(rack: StorageModel) {
    return this._generateAddRequest('/freezers/add', rack,{});
  }

  updateRack(rack: StorageModel) {
    return this._generatePutRequest('/freezer/' + rack.id, rack,{});
  }

  /******* Freezer-Slot ********/
  searchSlotForShelveFreezerByRackId(rackId, filterValue?: any) {
    return this._generateRequest('/st/freezer-racks/' + rackId + '/freezer-slots?query=' + filterValue, {});
  }

  getFreezerSlot() {
    return this.http.get<StorageModel[]>(this.userUrl, this.httpOptions);
  }

  searchSlotForFreezerByRackId(rackId, filterValue?: any) {
    return this._generateRequest('/st/freezer-racks/' + rackId + '/freezer-slots?query=' + filterValue, {});
  }

  getSeqIdsForFreezerSlotByRackId(rackId) {
    return this._generateRequest('/st/freezer-racks/' + rackId + '/freezer-slots/sequences?query=AVAILABLE', {});
  }

  deleteSlot(slot: StorageModel) {
    return this._generateDeleteRequest('/freezers/' + slot.id, slot,{});
  }

  addSlot(slot: StorageModel) {
    return this._generateAddRequest('/freezers/add', slot,{});
  }

  updateSlot(slot: StorageModel) {
    return this._generatePutRequest('/freezer/' + slot.id, slot,{});
  }

  // /******* Freezer-Row *********/
  deleteRowForFreezer(row, header) {
    return this._generateDeleteRequest('/st/freezer-rows/' + row.id, {}, header);
  }

  searchRowByFreezerId(refId, filterValue?: any) {
    return this._generateRequest('/st/freezers/' + refId + '/freezer-rows?query=' + filterValue, {});
  }

  getSeqIdsForFreezerRow(freezerId) {
    return this._generateRequest('/st/freezers/' + freezerId + '/freezer-rows/sequences?query=AVAILABLE', {});
  }

  /******* Freezer-Section *********/
  searchFreezerSectionByShelveId(shelveId, filterValue?: any) {
    return this._generateRequest('/st/freezer-shelves/' + shelveId + '/freezer-sections?query=' + filterValue, {})
  }

  getSeqIdsForFreezerSection(shelfId) {
    return this._generateRequest('/st/freezer-shelves/' + shelfId + '/freezer-sections/sequences?query=AVAILABLE', {});
  }

  /******* Refrigerator ********/
  getAllRefByLocId(locationId, reqParams): any {
    return this._generateRequest('/st/refrigerators?locationId=' + locationId, reqParams);
  }

  searchRefrigerator(locationId, filterValue?: any) {
    return this._generateRequest('/st/refrigerators?locationId=' + locationId + '&query=' + filterValue, {})
  }

  deleteRefrigerator(refrigerator: StorageModel,header) {
    return this._generateDeleteRequest('/st/refrigerators/' + refrigerator.id, refrigerator,header);
  }

  addRefrigerator(refrigerator: StorageModel,header) {
    return this._generateAddRequest('/st/refrigerators', refrigerator,header);
  }

  updateRefrigerator(refrigerator: StorageModel,header) {
    return this._generatePutRequest('/st/refrigerators/', refrigerator,header);
  }

  /******* Refrigerator-Shelve ********/
  searchShelvesForRefByRackId(rackId, filterValue?: any) {
    return this._generateRequest('/st/ref-racks/' + rackId + '/ref-shelves?query=' + filterValue, {});
  }

  searchShelvesByRefId(refId, filterValue?: any) {
    return this._generateRequest('/st/refrigerators/' + refId + '/ref-shelves?query=' + filterValue, {})
  }
 
  getSeqIdsForRefShelf(refId) {
    return this._generateRequest('/st/refrigerators/' + refId + '/ref-shelves/sequences?query=AVAILABLE', {});
  }

  getSeqIdsForRefShelfByRackId(rackId) {
    return this._generateRequest('/st/ref-racks/' + rackId + '/ref-shelves/sequences?query=AVAILABLE', {});
  }

  /******* Refrigerator-Rack ********/
 
  searchRacksForRefByShefId(shelfId, filterValue?: any) {
    return this._generateRequest('/st/ref-shelves/' + shelfId + '/ref-racks?query=' + filterValue, {});
  }

  searchRacksForRefByRowId(rowId, filterValue?: any) {
    return this._generateRequest('/st/ref-rows/' + rowId + '/ref-racks?query=' + filterValue, {})
  }

  searchRacksByRefId(refId, filterValue?: any) {
    return this._generateRequest('/st/refrigerators/' + refId + '/ref-racks?query=' + filterValue, {})
  }

  getSeqIdsForRefRackByRowId(rowId) {
    return this._generateRequest('/st/ref-rows/' + rowId + '/ref-racks/sequences?query=AVAILABLE', {});
  }

  getSeqIdsForRefRackByShelfId(shelfId) {
    return this._generateRequest('/st/ref-shelves/' + shelfId + '/ref-racks/sequences?query=AVAILABLE', {});
  }

  getSeqIdsForRefRackByRefId(refId) {
    return this._generateRequest('/st/refrigerators/' + refId + '/ref-racks/sequences?query=AVAILABLE', {});
  }

  /******* Refrigerator-Row ********/
  
  getSeqIdsForRefRow(refId) {
    return this._generateRequest('/st/refrigerators/' + refId + '/ref-rows/sequences?query=AVAILABLE', {});
  }
  searchRowsByRefId(refId, filterValue?: any) {
    return this._generateRequest('/st/refrigerators/' + refId + '/ref-rows?query=' + filterValue, {});
  }
 
  searchRefSectionByShelveId(shelveId, filterValue?: any) {
    return this._generateRequest('/st/ref-shelves/' + shelveId + '/ref-sections?query=' + filterValue, {})
  }
 
  getSeqIdsForRefSection(shelfId) {
    return this._generateRequest('/st/ref-shelves/' + shelfId + '/ref-sections/sequences?query=AVAILABLE', {});
  }

  searchSlotsForRefByRackId(rackId, filterValue?: any) {
    return this._generateRequest('/st/ref-racks/' + rackId + '/ref-slots?query=' + filterValue, {});
  }

  getSeqIdsForRefSlotsByRack(rackId) {
    return this._generateRequest('/st/ref-racks/' + rackId + '/ref-slots/sequences?query=AVAILABLE', {});
  }

  /******* Incubator ********/
  getIncubator(locationId, reqParams?: any) {
    return this._generateRequest('/st/incubators?locationId=' + locationId, reqParams);
  }

  searchIncubator(locationId, filterValue?: string) {
    return this._generateRequest('/st/incubators?locationId=' + locationId + '&query=' + filterValue, {});
  }

  deleteIncubator(incubator: StorageModel,header) {
    return this._generateDeleteRequest('/st/incubators/' + incubator.id, incubator,header);
  }

  addIncubator(incubator: StorageModel,header) {
    return this._generateAddRequest('/st/incubators', incubator,header);
  }

  updateIncubator(incubator: StorageModel,header) {
    return this._generatePutRequest('/st/incubators', incubator,header);
  }

  /******* Incubator-Shelve ********/
  searchShelvesForIncByRackId(rackId, filterValue?: any) {
    return this._generateRequest('/st/inc-racks/' + rackId + '/inc-shelves?query=' + filterValue, {})
  }

  getSeqIdsForIncShelves(incubatorId) {
    return this._generateRequest('/st/incubators/' + incubatorId + '/inc-shelves/sequences?query=AVAILABLE', {});
  }
  
  searchShelvesByIncId(incubatorId,filterValue?:any){
    return this._generateRequest('/st/incubators/' + incubatorId + '/inc-shelves?query=' + filterValue, {})
  }

  /******* Incubator-Row ********/
  getSeqIdsForIncRow(incubatorId) {
    return this._generateRequest('/st/incubators/' + incubatorId + '/inc-rows/sequences?query=AVAILABLE', {});
  }

  searchRowByIncubator(incubatorId, filterValue?: any) {
    return this._generateRequest('/st/incubators/' + incubatorId + '/inc-rows?query=' + filterValue, {})
  }

  /******* Incubator-Rack ********/
  getSeqIdsForIncRack(rowId) {
    return this._generateRequest('/st/inc-rows/' + rowId + '/inc-racks/sequences?query=AVAILABLE', {});
  }

  getSeqIdsForIncRackShelf(rackId) {
    return this._generateRequest('/st/inc-racks/' + rackId + '/inc-shelves/sequences?query=AVAILABLE', {});
  }

  searchRackForIncByRowId(rowId, filterValue?: any) {
    return this._generateRequest('/st/inc-rows/' + rowId + '/inc-racks?query=' + filterValue, {})
  }

  /******* Incubator-Section ********/
  getSeqIdsForIncSection(shelfId) {
    return this._generateRequest('/st/inc-shelves/' + shelfId + '/inc-sections/sequences?query=AVAILABLE', {});
  }
  searchIncSectionByShelveId(shelveId, filterValue?: any) {
    return this._generateRequest('/st/inc-shelves/' + shelveId + '/inc-sections?query=' + filterValue, {});
  }

  updateSectionForShelve(section,header?) {
    return this._generatePutRequest( '/st/inc-sections', section,header);
  }

  /******* Open-Shelving ********/
  getAllOpenShelvingsByLocation(locationId, reqParams): any {
    return this._generateRequest('/st/open-storage/?locationId=' + locationId, reqParams);
  }

  searchOpenShelving(locationId, filterValue?: any) {
    return this._generateRequest('/st/open-storage/?locationId=' + locationId + '&query=' + filterValue, {})
  }

  addOpenShelving(openShelving: StorageModel,header) {
    return this._generateAddRequest('/st/open-storage/', openShelving,header);
  }

  updateOpenShelving(openShelving: StorageModel,header) {
    return this._generatePutRequest('/st/open-storage/', openShelving,header);
  }

  deleteOpenShelving(openShelving: StorageModel,header) {
    return this._generateDeleteRequest('/st/open-storage/' + openShelving.id, openShelving,header);
  }

  /******* Open-Shelving-Shelve ********/
  searchShelvesForOsByRackId(rackId, filterValue?: any) {
    return this._generateRequest('/st/os-racks/' + rackId + '/os-shelves?query=' + filterValue, {})
  }

  searchOsSectionByShelveId(shelfId, filterValue) {
    return this._generateRequest('/st/os-shelves/' + shelfId + '/os-sections?query=' + filterValue, {})
  }

  getSeqIdsForOsShelf(rackId) {
    return this._generateRequest('/st/os-racks/' + rackId + '/os-shelves/sequences?query=AVAILABLE', {});
  }

  /******* Open-Shelving-Rack ********/
  getSeqIdsForOsRack(osId) {
    return this._generateRequest('/st/open-storages/' + osId + '/os-racks/sequences?query=AVAILABLE', {});
  }

  searchRacksForOsByRowId(rowId, filterValue?: any) {
    return this._generateRequest('/st/os-rows/' + rowId + '/os-racks?query=' + filterValue, {});
  }

  /******* Open-Shelving-Row ********/
  getSeqIdsForOsRow(osId) {
    return this._generateRequest('/st/open-storage/' + osId + '/os-rows/sequences?query=AVAILABLE', {});
  }
  
  searchRacksByOsId(osId, filterValue?: any) {
    return this._generateRequest('/st/open-storages/' + osId + '/os-racks' + '?query=' + filterValue, {})
  }

  getSeqIdsForOsSection(shelfId) {
    return this._generateRequest('/st/os-shelves/' + shelfId + '/os-sections/sequences?query=AVAILABLE', {});
  }

  /******* Room Temp / Open Shelving Incubators  *******/
  getRoomTempIncubator() {
    return this.http.get<StorageModel[]>(this.userUrl);
  }

  getAllRoomTempIncubatorsByLocation(locationId, reqParams): any {
    return this._generateRequest('/room-temp-incubators?locationId=' + locationId, reqParams);
  }

  deleteRoomTempIncubator(roomtempincubator: StorageModel) {
    return this.httpHelper.deleteReqeust(environment.BASEURL + '/room-temp-incubators/' + roomtempincubator.id, roomtempincubator);
  }

  addRoomTempIncubator(roomtempincubator: StorageModel) {
    return this.httpHelper.postRequest(environment.BASEURL + '/room-temp-incubators/add', roomtempincubator);
  }

  updateRoomTempIncubator(roomtempincubator: StorageModel) {
    return this.httpHelper.putRequest(environment.BASEURL + '/room-temp-incubators/' + roomtempincubator.id, roomtempincubator);
  }

  getShelve() {
    return this.http.get<StorageModel[]>(this.userUrl, this.httpOptions);
  }
  /**rows under room */
  addRowForRoom(roomId, rows, header){
      return this._generateAddRequest('/st/rooms/'+roomId+'/room-rows', rows, header)
  }
  updateRowForRoom(rows, header){
    return this._generatePutRequest('/st/room-rows', rows, header);
  }
  getAllRoomRows(reqParams){
    return this._generateRequest('/st/room-rows/',reqParams);
  }
  getSeqIdsForRoomRow(roomId){
    return this._generateRequest('/st/rooms/' +roomId + '/room-rows/sequence?query=AVAILABLE', {});
  }
  deleteRoomRows(row,header){
     return this._generateDeleteRequest('/st/room-rows/' + row.id, {}, header);
  }
  searchRoomRows(roomId,filterValue?: any){
    return this._generateRequest('/st/rooms/' +roomId + '/room-rows?query=' + filterValue, {})
  }
  //rowsbyRoom
  getAllRoomRowsByRoom(roomId, reqParams?){
    return this._generateRequest('/st/rooms/'+roomId+'/room-rows',reqParams);
  }
  public _getRequest(selectedStorage,storageId, reqParams){
    switch(selectedStorage.storageType){
      case 'Freezer-StorageType':
        if (['Freezer Upright', 'Ultra-Low Upright'].includes(selectedStorage["freezerType"])){
          return this._generateRequest('/st/freezers/'+storageId+`/freezer-shelves`, reqParams);
        }
        else if (['LN2', 'Ultra-Low Chest', 'Freezer Chest'].includes(selectedStorage["freezerType"])){
          return this._generateRequest( '/st/freezers/' + storageId + '/freezer-racks', reqParams)
        }
        else if (selectedStorage["freezerType"] === 'Walk In'){
          return this._generateRequest( '/st/freezers/' + storageId + '/freezer-rows/', reqParams);
        }
        else {
          return throwError('Unrecognized Freezer type!');
        }
      case 'Freezer-Row-Rack':
        return this._generateRequest('/st/freezer-rows/' + storageId + '/freezer-racks', reqParams)
      case 'Freezer-Shelve-Section':
        return this._generateRequest('/st/freezer-shelves/' + storageId + '/freezer-sections', reqParams)
      case 'Freezer-Shelve-Rack':
        return this._generateRequest('/st/freezer-shelves/' + storageId + '/freezer-racks', reqParams);
      case 'Freezer-Rack-Shelve':
        return this._generateRequest('/st/freezer-racks/' + storageId + '/freezer-shelves', reqParams);
      case 'Freezer-Rack-Slot':
        return this._generateRequest('/st/freezer-racks/' + storageId + '/freezer-slots', reqParams);
      
      case "Ref-StorageType":
          if(['+5 Upright'].includes(selectedStorage['refType'])){
            return  this._generateRequest('/st/refrigerators/' + storageId + '/ref-shelves', reqParams);
          }
          else if(selectedStorage['refType']==='+5 Chest'){
            return this._generateRequest( '/st/refrigerators/' + storageId + '/ref-racks', reqParams);
          }
          else if(selectedStorage['refType']==='+5 WalkIn'){
            return this._generateRequest('/st/refrigerators/' + storageId + '/ref-rows/', reqParams);
          } 
          else {
            return throwError('Unrecognized Refrigerator type!');
          }
      case "Ref-Shelf-Rack":
         return this._generateRequest('/st/ref-shelves/' + storageId + '/ref-racks', reqParams);
      case "Ref-Row-Rack":
          return this._generateRequest('/st/ref-rows/' + storageId + '/ref-racks', reqParams)
      case "Ref-Rack-Shelf":
          return this._generateRequest('/st/ref-racks/' + storageId + '/ref-shelves', reqParams);
      case "Ref-Rack-Slot":
          return this._generateRequest( '/st/ref-racks/' + storageId + '/ref-slots', reqParams);
      case "Ref-Shelf-Section":
           return this._generateRequest('/st/ref-shelves/' + storageId + '/ref-sections', reqParams);
      case "Inc-StorageType":
        if(selectedStorage['incType']==='Walk In'){
           return this._generateRequest('/st/incubators/' + storageId + '/inc-rows', reqParams)
         }
        else{
           return this._generateRequest('/st/incubators/' + storageId + '/inc-shelves', reqParams)
        }
      case "Inc-Row-Rack":
        return this._generateRequest('/st/inc-rows/' + storageId + '/inc-racks', reqParams)
      case "Inc-Rack-Shelf":
        return this._generateRequest('/st/inc-racks/' + storageId + '/inc-shelves', reqParams)
      case "Inc-Shelf-Section":
        return this._generateRequest('/st/inc-shelves/' + storageId + '/inc-sections', reqParams)
      case 'Open-Storage':
        return this._generateRequest('/st/open-storage/' + storageId + '/os-rows/', reqParams);
      case 'Os-Rack':
        return this._generateRequest('/st/open-storages/' + storageId + '/os-racks', reqParams);
      case 'Os-Rack-Shelf':
        return this._generateRequest('/st/os-racks/' + storageId + '/os-shelves', reqParams);
      case 'Os-Shelf-Section':
        return this._generateRequest('/st/os-shelves/' + storageId + '/os-sections/', reqParams);
    }
  }
  public _updateRequest(storage,storageObj,header){
    switch(storage.type){
      case 'freezer':
        if(storageObj.name==='Row'){
          return this._generatePutRequest('/st/freezer-rows', storageObj, header);
        }
        if(storageObj.name ==='Rack'){
          return this._generatePutRequest('/st/freezer-racks', storageObj, header)
        }
        if(storageObj.name=='Shelf'){
          return this._generatePutRequest('/st/freezer-shelves', storageObj,header)
        }
        if (storageObj.name=='Section'){
          return this._generatePutRequest('/st/freezer-sections/', storageObj,header);
        }
        if(storageObj.name=='Slot'){
          return this._generatePutRequest('/st/freezer-slots/', storageObj,header);
        }
      case 'refrigerator':
        if(storageObj.name==='Row'){
          return this._generatePutRequest('/st/ref-rows', storageObj, header);
        }
        if(storageObj.name==='Rack'){
          return this._generatePutRequest('/st/ref-racks', storageObj, header)
        }
        if(storageObj.name==='Shelf'){
         return this._generatePutRequest('/st/ref-shelves', storageObj,header);
        }
        if(storageObj.name==='Section'){
         return this._generatePutRequest('/st/ref-sections/', storageObj,header);
        }
        if(storageObj.name==='Slot' ){
         return this._generatePutRequest('/st/ref-slots/', storageObj,header);
        }
      case 'incubator':
        if(storageObj.name=='Row'){
          return this._generatePutRequest('/st/inc-rows', storageObj, header);
        }
        if(storageObj.name =='Rack'){
          return this._generatePutRequest('/st/inc-racks', storageObj, header)
        }
        if(storageObj.name =='Shelf'){
         return this._generatePutRequest('/st/inc-shelves', storageObj,header);
        }
        if(storageObj.name =='Section'){
          return this._generatePutRequest('/st/inc-sections', storageObj,header);
        }
      case 'open-shelf':
        if(storageObj.name=='Row'){
          return this._generatePutRequest('/st/os-rows', storageObj,header);
        }
        if(storageObj.name==='Rack'){
          return this._generatePutRequest('/st/os-racks/', storageObj,header);
        }
        if(storageObj.name ==='Shelf'){
         return this._generatePutRequest('/st/os-shelves/', storageObj,header);
        }
        if(storageObj.name ==='Section'){
         return this._generatePutRequest('/st/os-sections/', storageObj,header);
        }
    }
  }
  public _addRequest(storage,storageId,storageObj,header){
    switch(storage.type){
      case 'freezer':
       if(storage["freezerType"] === 'Walk In' && storageObj[0].name==='Row'){
         return this._generateAddRequest('/st/freezers/' + storageId + '/freezer-rows', storageObj, header)
       }
       if( storage["freezerType"] === 'Walk In' && storageObj[0].name==='Rack'){
         return this._generateAddRequest('/st/freezer-rows/' + storageId + '/freezer-racks',storageObj, header)
       }
       if(['Freezer Upright', 'Ultra-Low Upright'].includes(storage["freezerType"]) && storageObj[0].name==='Rack'){
         return this._generateAddRequest('/st/freezer-shelves/' + storageId + '/freezer-racks',storageObj, header)
        }
       if(['LN2', 'Ultra-Low Chest', 'Freezer Chest'].includes(storage["freezerType"]) && storageObj[0].name==='Rack'){
         return this._generateAddRequest('/st/freezers/' + storageId + '/freezer-racks', storageObj, header)
       }
       if(storage["freezerType"] === 'Walk In' && storageObj[0].name ==='Shelf'){
         return this._generateAddRequest('/st/freezer-racks/' + storageId + '/freezer-shelves', storageObj,header)
       }
       if(['Freezer Upright', 'Ultra-Low Upright'].includes(storage["freezerType"]) && storageObj[0].name==='Shelf'){
         return this._generateAddRequest('/st/freezers/' + storageId + '/freezer-shelves', storageObj,header);
       }
       if(storage["freezerType"] === 'Walk In' && storageObj[0].name==='Section'){
         return this._generateAddRequest('/st/freezer-shelves/' + storageId + '/freezer-sections/', storageObj,header);
       }
       if(storageObj[0].name==='Slot'){
        return this._generateAddRequest('/st/freezer-racks/' + storageId + '/freezer-slots/', storageObj,header);
       }

      case 'refrigerator':
       if(['+5 WalkIn'].includes(storage['refType']) && storageObj[0].name==='Row'){
          return this._generateAddRequest('/st/refrigerators/' + storageId + '/ref-rows', storageObj, header)
        }
       if(['+5 WalkIn'].includes(storage['refType']) && storageObj[0].name==='Rack'){
          return this._generateAddRequest('/st/ref-rows/' + storageId + '/ref-racks', storageObj, header)
        }
       if(['+5 Upright'].includes(storage['refType']) && storageObj[0].name==='Rack'){
          return this._generateAddRequest('/st/ref-shelves/' + storageId + '/ref-racks', storageObj, header)
        }
       if(['+5 Chest'].includes(storage['refType']) && storageObj[0].name==='Rack'){
          return this._generateAddRequest('/st/refrigerators/' + storageId + '/ref-racks', storageObj, header)
        }
       if(['+5 Upright'].includes(storage['refType']) && storageObj[0].name==='Shelf'){
        return this._generateAddRequest('/st/refrigerators/' + storageId + '/ref-shelves', storageObj,header);
       }
       if(['+5 WalkIn'].includes(storage['refType']) && storageObj[0].name==='Shelf'){
         return this._generateAddRequest('/st/ref-racks/' + storageId + '/ref-shelves', storageObj,header)
       }
       if(['+5 WalkIn'].includes(storage['refType']) && storageObj[0].name==='Section'){
        return this._generateAddRequest('/st/ref-shelves/' + storageId + '/ref-sections/', storageObj,header);
       }
       if(['+5 Upright','+5 Chest'].includes(storage['refType']) && storageObj[0].name==='Slot'){
        return this._generateAddRequest('/st/ref-racks/' + storageId + '/ref-slots/', storageObj,header);
       }

      case 'incubator':
       if(['Walk In'].includes(storage['incType']) && storageObj[0].name==='Row'){
         return this._generateAddRequest('/st/incubators/' + storageId + '/inc-rows', storageObj, header)
       }
       if(['Walk In'].includes(storage['incType']) && storageObj[0].name==='Rack'){
         return this._generateAddRequest('/st/inc-rows/' + storageId + '/inc-racks', storageObj, header)
       }
       if(storage['incType']!='Walk In' && storageObj[0].name==='Shelf'){
         return this._generateAddRequest('/st/incubators/' + storageId + '/inc-shelves', storageObj,header)
       }
       if(['Walk In'].includes(storage['incType']) && storageObj[0].name==='Shelf'){
        return this._generateAddRequest('/st/inc-racks/' + storageId + '/inc-shelves', storageObj,header)
       }
       if(['Walk In'].includes(storage['incType']) && storageObj[0].name==='Section'){
         return this._generateAddRequest('/st/inc-shelves/' + storageId + '/inc-sections', storageObj,header);
       }
      case 'open-shelf':
       if(storageObj[0].name==='Row'){
         return this._generateAddRequest('/st/open-storage/' + storageId + '/os-rows', storageObj,header);
       }
       if(storageObj[0].name==='Rack'){
         return this._generateAddRequest('/st/open-storages/' + storageId + '/os-racks', storageObj,header);
       }
       if(storageObj[0].name==='Shelf'){
         return this._generateAddRequest('/st/os-racks/' + storageId + '/os-shelves', storageObj,header);
       }
       if(storageObj[0].name==='Section'){
         return this._generateAddRequest('/st/os-shelves/' + storageId + '/os-sections/', storageObj,header);
       }
    }

  }
  public _deleteRequest(storage, storageObj,header){
    switch(storage.type){
      case 'freezer':
        if(storageObj.name==='Row'){
         return this._generateDeleteRequest('/st/freezer-rows/' + storageObj.id, {}, header);
        }
        if(storageObj.name==='Rack'){
         return this._generateDeleteRequest('/st/freezer-racks/' + storageObj.id, storageObj,header);
        }
        if(storageObj.name ==='Shelf'){
         return this._generateDeleteRequest('/st/freezer-shelves/' + storageObj.id, {},header);
        }
        if(storageObj.name ==='Section'){
         return this._generateDeleteRequest('/st/freezer-sections/' + storageObj.id, {},header)
        }
        if(storageObj.name ==='Slot'){
         return this._generateDeleteRequest( '/st/freezer-slots/' + storageObj.id, storageObj, header);
        }
      case 'refrigerator':
        if(storageObj.name ==='Row'){
          return this._generateDeleteRequest('/st/ref-rows/' + storageObj.id, {}, header);
        }
        if(storageObj.name ==='Rack'){
         return this._generateDeleteRequest('/st/ref-racks/' + storageObj.id, {},header);
        }
        if(storageObj.name ==='Shelf'){
         return this._generateDeleteRequest('/st/ref-shelves/' + storageObj.id, {},header);
        }
        if(storageObj.name ==='Slot'){
         return this._generateDeleteRequest('/st/ref-slots/' + storageObj.id, storageObj, header);
        }
        if(storageObj.name ==='Section'){
          return this._generateDeleteRequest('/st/ref-sections/' + storageObj.id, {},header)
        }
      case "incubator":
        if(storageObj.name ==='Row'){
         return this._generateDeleteRequest('/st/inc-rows/' + storageObj.id, {}, header);
        }
        if(storageObj.name ==='Shelf'){
         return this._generateDeleteRequest('/st/inc-shelves/' + storageObj.id, {},header);
        }
        if(storageObj.name ==='Rack'){
         return this._generateDeleteRequest('/st/inc-racks/' + storageObj.id, {}, header)
        }
        if(storageObj.name ==='Section'){
         return this._generateDeleteRequest('/st/inc-sections/' + storageObj.id, {} ,header)
        }
      case 'open-shelf':
        if(storageObj.name ==='Row'){
         return this._generateDeleteRequest('/st/os-rows/' + storageObj.id, storageObj,header);
        }
        if(storageObj.name ==='Rack'){
         return this._generateDeleteRequest( '/st/os-racks/' + storageObj.id, storageObj,header);
        }
        if(storageObj.name ==='Shelf'){
         return this._generateDeleteRequest('/st/os-shelves/' + storageObj.id, storageObj,header);
        }
        if(storageObj.name ==='Section'){
         return this._generateDeleteRequest('/st/os-sections/' + storageObj.id, storageObj,header);
        }
   }
  }

  public _generateRequest(endpoint,headers){
    return this.httpHelper.getRequestWithToken(environment.BASEURL + endpoint, headers)
  }
 public _generatePutRequest(endpoint,storageObj,headers){
    return this.httpHelper.putRequest(environment.BASEURL + endpoint,storageObj, headers);
 }
 public _generateAddRequest(endpoint,storageObj,headers){
   return this.httpHelper.postRequest(environment.BASEURL + endpoint,storageObj, headers);
 }
 public _generateDeleteRequest(endpoint,storageObj,headers){
   return this.httpHelper.deleteReqeust(environment.BASEURL +endpoint ,storageObj,headers);
 }
 
}
