import { Injectable } from '@angular/core';
import{ArchiveService}from'./archive.service';
import{Observable,of,EMPTY}from"rxjs";
import{catchError,mergeMap}from"rxjs/operators";
import{Resolve,ActivatedRouteSnapshot,RouterStateSnapshot}from"@angular/router";
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { CommonApiService } from 'app/services/common-api.service';
import { DataService } from "app/services/data.service";


 @Injectable()
 
 export class ArchiveResolver implements Resolve<any>{
     
    constructor(private archiveService:ArchiveService,private spinnerService:Ng4LoadingSpinnerService,private commonSrv:CommonApiService,
        private dataSrv:DataService){}
    resolve(route:ActivatedRouteSnapshot,state:RouterStateSnapshot):Observable<any>|Observable<never>{
        let reqParams = this.commonSrv.createParam(route.data['params']);
        return this.archiveService.getAllReceivablesByStatus(this.dataSrv.STATUS.SHIPPED,reqParams).pipe(catchError(error   => {
            return EMPTY;
    }),mergeMap(something=>{
           this.spinnerService.hide();
           if(something){
               return of(something);
           }
           else{
               this.spinnerService.hide();
               return EMPTY;
           }
       })
       )
    }
}
 