import { BehaviorSubject } from "rxjs";

export class EventService{

    private gotoRackEvent = new BehaviorSubject<boolean>(true);
    private gotoShelfEvent = new BehaviorSubject<boolean>(true);
    private gotoRowEvent = new BehaviorSubject<boolean>(true);
    private gotoRefEvent = new BehaviorSubject<boolean>(true);
    private gotoIncEvent = new BehaviorSubject<boolean>(true);
    private gotoOpenShelfEvent = new BehaviorSubject<boolean>(true);
    private gotoFreezerEvent = new BehaviorSubject<boolean>(true);
   
   
    emitRackEvent(viewMode:boolean) { this.gotoRackEvent.next(viewMode);}
    rackEventListner(){  return this.gotoRackEvent.asObservable(); }

    emitShelfEvent(viewMode:boolean) { this.gotoShelfEvent.next(viewMode);}
    shelfEventListner(){  return this.gotoShelfEvent.asObservable(); }

    emitRowEvent(viewMode:boolean) { this.gotoRowEvent.next(viewMode);}
    rowEventListner(){  return this.gotoRowEvent.asObservable(); }

    emitRefEvent(viewMode:boolean) { this.gotoRefEvent.next(viewMode);}
    refEventListner(){  return this.gotoRefEvent.asObservable(); }

    emitIncEvent(viewMode:boolean) { this.gotoIncEvent.next(viewMode);}
    incEventListner(){  return this.gotoIncEvent.asObservable(); }

    emitOpenShelfEvent(viewMode:boolean) { this.gotoOpenShelfEvent.next(viewMode);}
    openShelfEventListner(){  return this.gotoOpenShelfEvent.asObservable(); }

    emitFreezerEvent(viewMode:boolean) { this.gotoFreezerEvent.next(viewMode);}
    freezerEventListner(){  return this.gotoFreezerEvent.asObservable(); }

}