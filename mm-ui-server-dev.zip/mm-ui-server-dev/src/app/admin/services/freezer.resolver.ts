import{Injectable}from"@angular/core";
import{Observable,of,EMPTY}from"rxjs";
import{catchError,mergeMap}from"rxjs/operators";
import{Resolve,ActivatedRouteSnapshot,RouterStateSnapshot}from"@angular/router";
import{Ng4LoadingSpinnerService}from"ng4-loading-spinner";
import { HelperService } from 'app/services/helper.service';
import { CommonApiService } from "app/services/common-api.service";
import { StorageService } from "./storage.service";


@Injectable()

export class FreezerResolver implements Resolve<any>{
    
    constructor(private storageSrv:StorageService,private spinnerService:Ng4LoadingSpinnerService
        ,private helperService:HelperService,private commonSrv:CommonApiService){}
    resolve(route:ActivatedRouteSnapshot,state:RouterStateSnapshot):Observable<any>|Observable<never>{

        let reqParams=this.commonSrv.createParam(route.data['params']);
        return this.storageSrv.getAllFreezersByLocId(this.helperService.getLocation(),reqParams).pipe(catchError(error=>{
            return EMPTY;
        }),mergeMap(response=>{
            this.spinnerService.hide();
            if(response){
                return of(response);
            }
            else{
                this.spinnerService.hide();
                return EMPTY;
            }
        }))
    }
}