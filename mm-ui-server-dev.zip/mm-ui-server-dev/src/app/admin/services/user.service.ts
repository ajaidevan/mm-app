import { Injectable } from '@angular/core';
import { Observable, BehaviorSubject,throwError }   from 'rxjs';
import { CommonApiService } from 'app/services/common-api.service';
import { environment } from '../../../environments/environment';
import { LocationUserModel } from 'app/models/user.model';
import { HelperService } from 'app/services/helper.service';
import{Ng4LoadingSpinnerService}from'ng4-loading-spinner';
import { catchError, map } from 'rxjs/operators';
import { DataService } from 'app/services/data.service';

@Injectable()

export class UserService {

  constructor( private httpRequest: CommonApiService,private helperSrv:HelperService,private spinnerService:Ng4LoadingSpinnerService,private data:DataService ) { }
  private sharableUser = new BehaviorSubject<any>("");
  public sharedUsers = this.sharableUser.asObservable();

  private createdUser = new BehaviorSubject("");
  public createdCurrentUser = this.createdUser.asObservable();

  setSharedUser(userObj) {
    this.sharableUser.next(userObj);
  }

  sendCreatedUser(userObj) {
    this.createdUser.next(userObj);
  }
 
  // Get users by location id
  getAllUsersByLocation(paramObj?:any){
    this.spinnerService.show();
    this.data.changeCurrentRole("user");
    return this.httpRequest.getRequestWithToken(environment.BASEURL+ 
      '/auth/users/tenants/' + this.helperSrv.getTenantId()+'/locations/'+this.helperSrv.getLocation(),paramObj)
      .pipe(map(response => {
      return response;
    }), catchError((error: Error) => throwError(error)));
  }  
  

  /**ACTIVATE user */
  activateUser(token) {
    return this.httpRequest.getRequestWithToken(environment.BASEURL + '/auth/accounts/activate?token=' + token,{})
  }
 

  /** ADD new user */
  addNewUser(userObj,header) {
    return this.httpRequest.postRequest(environment.BASEURL+ '/auth/users', userObj,header);
  }

  /**UPDATE user */
  updateUser(userObj,header) {
    return this.httpRequest.putRequest(environment.BASEURL+'/auth/users/'+userObj.id, userObj,header);
  }

  /** DELETE user */
  deleteUser(user,header) {
    return this.httpRequest.deleteReqeust(environment.BASEURL+ 
      '/auth/users/'+user.id,user,header);
  }

  /** REFRESH user */
  refreshUser() {
    return this.httpRequest.getRequestWithToken(environment.BASEURL + "/auth/users/refresh",{});
  }

  /** Search USER */
  searchUser(filterValue?:any){
    return this.httpRequest.getRequestWithToken(environment.BASEURL + '/auth/users/tenants/' + this.helperSrv.getTenantId()+'/locations/'+this.helperSrv.getLocation() + '/search?search='+filterValue,{})
  }
  
  /**Reactivate user */
  reactivateUser(email){
    return this.httpRequest.getRequestWithToken(environment.BASEURL + "/auth/accounts/resend-activate-link?email=" + email,{})
  }
}
