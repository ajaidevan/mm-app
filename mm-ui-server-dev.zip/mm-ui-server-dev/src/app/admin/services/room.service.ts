import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, BehaviorSubject, throwError } from 'rxjs';
import { CommonApiService } from 'app/services/common-api.service';
import { environment } from '../../../environments/environment';
import { RoomModel } from 'app/models/room.model';
import { catchError,map } from 'rxjs/operators';

@Injectable()

export class RoomService {

    private sharableRoom = new BehaviorSubject<any>("");
    public sharedRoom = this.sharableRoom.asObservable();

    private createdRoom = new BehaviorSubject("");
    public createdCurrentRoom = this.createdRoom.asObservable();
    
    constructor(private http: HttpClient, private httpRequest: CommonApiService) {
    }

    setSharedRoom(locationObj) {
        this.sharableRoom.next(locationObj);
    }
    sendCreatedRoom(roomObj) {
        this.createdRoom.next(roomObj);
      }

    /** GET all rooms */
    getAllRooms(locationId,paramObj?:any): Observable<any> {
        return this.httpRequest.getRequestWithToken(environment.BASEURL + '/st/rooms?locationId='+locationId,paramObj)
        .pipe(map(response => {
            return response;
          }), catchError((error: Error) => throwError(error)));
    }

    /** SEARCH room */
    searchRoom(locationId,filterValue?:any){
        return this.httpRequest.getRequestWithToken(environment.BASEURL+'/st/rooms?locationId='+locationId+'&query='+filterValue,{})
    }

    /** DELETE room */
    deleteRoom(room,header):Observable<RoomModel> {
        return this.httpRequest.deleteReqeust(environment.BASEURL+ '/st/rooms/'+room.id,{},header);
    }

    /** ADD a room */
    addRoom(room: any,header?:any) {
        return this.httpRequest.postRequest(environment.BASEURL + '/st/rooms/',room,header);
    }

    /** UPDATE a room */
    updateRoom(room: any,header?:any) {
        return this.httpRequest.putRequest(environment.BASEURL+ '/st/rooms/', room,header);
    }

}
