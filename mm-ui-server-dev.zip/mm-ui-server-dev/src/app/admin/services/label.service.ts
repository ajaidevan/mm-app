import { Injectable } from '@angular/core';
import { CommonApiService } from 'app/services/common-api.service';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { Label } from 'app/models/label.model';

@Injectable({
  providedIn: 'root'
})
export class LabelService {

  constructor(private httpRequest: CommonApiService) { }

  /** GET all label specification */
  getAlllabel(): Observable<Label[]> {
    return this.httpRequest.getRequestWithToken(environment.BASEURL + '/auth/labels',{})
  }
}