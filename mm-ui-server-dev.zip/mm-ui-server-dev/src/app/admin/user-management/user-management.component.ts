import { Component, OnInit, ViewChild } from '@angular/core';
import { UserService } from '../services/user.service';
import { MatPaginator, MatSort, MatDialog, MatDialogConfig, MatTableDataSource, PageEvent,Sort } from '@angular/material';
import { CreateUserComponent } from './create-user/create-user.component';
import { HelperService } from 'app/services/helper.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { ValidatorService } from 'app/services/validator.service';
import { DataService } from 'app/services/data.service';
import { LocationUserModel } from 'app/models/user.model';
import { ViewInfoComponent } from 'app/shared/view-info/view-info.component';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonApiService } from 'app/services/common-api.service';
import{AuthService} from 'app/services/auth.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-user-management',
  templateUrl: './user-management.component.html',
  styleUrls: ['./user-management.component.scss']
})
export class UserManagementComponent implements OnInit {

  public displayedColumns: string[] = ['id', 'firstName', 'lastName', 'email', 'role', 'status', 'action'];
  public selectedRow: LocationUserModel;
  public selectedRoles: any = null
  public dataSource = new MatTableDataSource();
  public editMode: boolean = false;
  public rowData: LocationUserModel[];
  public activityLog: string;
  public locationIndexes = new Array();
  public roles = [{ name: "QA" }, { name: "Technician" }];
  public paginate:any;
  public totalUsers:number;
  public pageEvent:PageEvent;
  public searchValue:string;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(private dialog: MatDialog, private userService: UserService, private data: DataService,
    private spinnerService: Ng4LoadingSpinnerService, private helperService: HelperService,private authService:AuthService,
    private validatorService: ValidatorService,private route:ActivatedRoute,private router:Router,
    private commonSrv:CommonApiService) { }  

  ngOnInit() {
    this.data.currentLog.subscribe(activityLog => this.activityLog = activityLog);
        // for every update and create reload page data.
    this.userService.createdCurrentUser.subscribe(data => {
   //   let newDataSource = this.dataSource.data;
      if (this.editMode) {        
        //for edit do not change page
        this.refreshUser(false);
        this.editMode = false;
      } else {
        //for create start with page=0
        this.refreshUser(true);
      }
    });

    /**for default paginated user data.*/
    this.defaultPaginatedUser();
   }
   ngAfterViewInit() {
    //this.dataSource.sort=this.sort;
  }
  
  /** open CREATE user **/
  openCreateUser(newData?): void {
    if (newData) {
      this.data.changeCurrentLog("user-mangement/edit");
      this.userService.setSharedUser(newData);
    } else {
      this.data.changeCurrentLog("user-mangement/create");
      this.userService.setSharedUser("");
    }
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true
    let dialogRef = this.dialog.open(CreateUserComponent, dialogConfig);
  }

  /** DELETE a user **/
  onDeleteUser(user) {
    this.validatorService.userValidator('delete').then(res => {
      if (res.val) {
        delete res.val;
        res.locations = this.helperService.getFormatedLocations(user);
        this.userService.deleteUser(user,res).subscribe(data => {
          let userData = this.dataSource.data;
          for (const index in userData) {
            if (user.id == userData[index]["id"]) {
              userData.splice(Number(index), 1)
              break;
            }
          }
          this.dataSource.data = userData;
          this.refreshUser();
          this.spinnerService.hide();
        });
      }
    }).catch(err => {
      console.log("Delete Error Response :", err);
    });
  }
 
  /**Reactivate link to email */
  onReactivateUser(row){
    Swal.fire({
      title: 'Are you sure?',
      text: "You want to send reactivation link to the email !",
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes',
    }).then((result) => {
      if (result.value) {
        this.validatorService.userValidator('reactivate').then(res => {
          if(res.val) {
          delete res.val;
          res.locations = this.helperService.getFormatedLocations(row);
            this.authService.reactivateUser(row.email,res).subscribe(res=>{
              this.helperService.showSnackbar("ReActivation Link has been sent to Email successfully!!!"); 
              })
            }
        })
      }
    })

  }
  /** EDIT a user **/
  onEditUser(userObj) {
    this.editMode = true;
    this.openCreateUser(userObj);
  }

  /** open VIEW INFO **/
  openViewMode(selectedRow: LocationUserModel) {
    this.selectedRow = selectedRow
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = false;
    dialogConfig.autoFocus = true;
    dialogConfig.data = {
      'selectedValue': this.selectedRow,
      'tableColumns': this.displayedColumns,
      'columnName': ['ID', 'First Name', 'Last Name', 'Email', 'Role', 'Status'],
      "component": "User",
      "mode": true
    };
    let dialogRef = this.dialog.open(ViewInfoComponent, dialogConfig);
  };

  /** REFRESH User **/
  refreshUser(changePage?:boolean) {
    this.searchValue='';
    this.userService.refreshUser().subscribe(
    res => {
      this.paginateUser(changePage);
      this.helperService.showSnackbar('Table Refreshed Successfully',true);
    }, err => {
        console.log(err);
      })
  }

  /** Set Default Param **/
  defaultPaginatedUser(){
    this.paginate=this.route.snapshot.data['params'];
    let reqParams = this.commonSrv.createParam(this.paginate);
    this.router.navigate([], { queryParams: reqParams });
    this.dataSource.data=this.route.snapshot.data['user'].body.content;
    this.rowData=this.route.snapshot.data['user'].body.content;
    this.totalUsers =this.route.snapshot.data['user'].body.totalElements;  
   } 
   
   /**
    * 
    * @param setPage
    */
   /** Pagination User **/
   paginateUser(setPage=true){
     if(setPage) this.paginate.page=0;    
     let reqParams = this.commonSrv.createParam(this.paginate);
     this.spinnerService.show();
      this.userService.getAllUsersByLocation(reqParams).subscribe(res=>{
       this.dataSource.data = res.body.content;
       this.rowData = res.body.content;  
       this.totalUsers=res.body['totalElements']; 
       this.router.navigate([],{queryParams:reqParams});
       this.spinnerService.hide();
       })    
   }
 
   /**
    * 
    * @param event
    */
 
    /** On Change Page **/
    onChangePage(event?:PageEvent) {
     this.paginate.size = event.pageSize;
     this.paginate.page = event.pageIndex;
     this.paginateUser(false);
     return event;
   }


  /** Search USER */
    search(filterValue?:any){
      this.userService.searchUser(filterValue).subscribe(res=>{
        this.dataSource.data = res.body;
      })
    }

   /** Filter Value */  
  applyFilter(filter?:any){
   if(filter.length>2){
    this.search(filter);    
   }
   if(filter.length==0){
     this.paginateUser();
   }
  }

  /*Sorting*/
  sortData(event: Sort) {
    this.paginate.sort = event.active + ',' + event.direction;
    this.paginateUser();    
  }
}