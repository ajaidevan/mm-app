import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { MatDialogRef } from '@angular/material';
import { FormGroup, FormControl, Validators, FormGroupDirective, NgForm, FormBuilder, FormArray } from '@angular/forms';
import { ErrorStateMatcher } from '@angular/material/core';
import { HelperService } from '../../../services/helper.service';
import { UserService } from '../../services/user.service'
import { COMMA, ENTER } from '@angular/cdk/keycodes';
import { MatAutocompleteSelectedEvent, MatChipInputEvent, MatAutocomplete } from '@angular/material';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { DataService } from 'app/services/data.service';
import { FrontValidationService } from 'app/services/front-validation/front-validation.service';
import { PatternValidationService } from 'app/services/front-validation/pattern-validation.service';
import { AuthService } from 'app/services/auth.service';
import Swal from 'sweetalert2';
import { ValidatorService } from 'app/services/validator.service';
import { UserRetrievalService } from 'app/services/user.retrieval.service';
import {UserReActivationLinkService} from 'app/services/user-reacivatelink.service';

export class MyErrorStateMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = form && form.submitted;
    return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
  }
}

@Component({
  selector: 'app-create-user',
  templateUrl: './create-user.component.html',
  styleUrls: ['./create-user.component.scss']
})
export class CreateUserComponent implements OnInit {
  public isRole:boolean = false;
  public errorEmail:any;
  public roleList: string[] = ["QA", "Technician"];
  public editMode: boolean = false;
  public visible: boolean = true;
  public selectable: boolean = true;
  public removable: boolean = true;
  public addOnBlur: boolean = false;
  public separatorKeysCodes: number[] = [ENTER, COMMA];
  public selectedRoles: any[] = [];
  public currentSelected: String;
  public matcher = new MyErrorStateMatcher();
  public activityLog: string;
  public locationsRoles: FormArray;
  public userObj: any;
  public userVal:any;
  public currentOperation:any;
  public errorMsg:any;
  public oldEmail:string;
  public userDiagForm = this.formBuilder.group({
    id: this.formBuilder.control(''),
    email: this.formBuilder.control('', [Validators.required, Validators.pattern(this.patternSrv.emailPattern),Validators.maxLength(255)]),
    firstName: this.formBuilder.control('', [Validators.required,Validators.pattern(this.patternSrv.namePattern),Validators.maxLength(15)]),
    lastName: this.formBuilder.control('', [Validators.required,Validators.pattern(this.patternSrv.namePattern),Validators.maxLength(15)]),
    enabled: this.formBuilder.control(''),
    tenant: this.formBuilder.control('NA'),
    password: this.formBuilder.control('password'),
    roles: this.formBuilder.control('', Validators.required),
    locationsRoles: this.formBuilder.array([this.createItem()])
  });

  createItem(): FormGroup {
    return this.formBuilder.group({
      role: [],
      location: ''
    });
  }

  @ViewChild('roleInput') roleInput: ElementRef<HTMLInputElement>;
  @ViewChild('auto') matAutocomplete: MatAutocomplete;

  constructor(private dialogRef: MatDialogRef<CreateUserComponent>,
    private helper: HelperService, private data: DataService,private authSrv:AuthService,
    private userService: UserService,private frontValSrv:FrontValidationService,
    private formBuilder: FormBuilder,private patternSrv:PatternValidationService,
    private spinnerService: Ng4LoadingSpinnerService,private validatorService: ValidatorService,
    private userRetrievalSrv:UserRetrievalService,private userReacivateLinkSrv:UserReActivationLinkService) {
    this.locationsRoles = this.userDiagForm.get('locationsRoles') as FormArray;
  }

  ngOnInit() {
    this.userVal = this.frontValSrv.validationMsg;
   this.data.currentLog.subscribe(activityLog => this.activityLog = activityLog);
    this.data.currentOperation.subscribe(currentOperation => this.currentOperation = currentOperation);
    this.userService.sharedUsers.distinctUntilChanged().subscribe(data => {
      if (data) {
        this.userDiagForm.patchValue(data);
        this.oldEmail = data.email;
        for (const role of data['locationsRoles'][0]['role']) {
          this.selectedRoles.push(role.name);
        }
        this.editMode = true;
      }
    });
  }

  /** add CHIP's **/
  add(event: MatChipInputEvent): void {
    if (!this.matAutocomplete.isOpen) {
      const input = event.input;
      const value = event.value;
      if (input) {
        input.value = '';
      }
    }
  }

  /** remove CHIP's **/
  remove(role): void {
    const index = this.selectedRoles.indexOf(role);
    if (index > 0) {
      this.selectedRoles.splice(index, 1);
    }
    if (index <=0) {
      this.selectedRoles.splice(index, 1);
      this.userDiagForm.get('roles').patchValue(null)
    }
  }

  selected(event: MatAutocompleteSelectedEvent): void {
    this.currentSelected = event.option.viewValue;
    if(!this.selectedRoles.includes(this.currentSelected)){
       this.selectedRoles.push(event.option.viewValue);
    }
    this.roleInput.nativeElement.value = '';
  }

  /** CREATE a user **/
  create() {
    this.validatorService.userValidator(this.editMode ?'update':'create').then(res => {
      if(res.val) {
      delete res.val;
      this.data.changeOperation("user");
      this.spinnerService.show();
      if (this.userDiagForm.valid) {
        let userObj = this.userDiagForm.value;
        userObj.tenant = this.helper.getTenantId();
        userObj["roles"] = [];
        userObj["username"] = userObj["firstName"].toLowerCase() + "_" + userObj["lastName"].toLowerCase();
        let rolesArray = [];
        for (let index in this.selectedRoles) {
          rolesArray.push({ name: this.selectedRoles[index] });
        }
        userObj["locationsRoles"][0]["role"] = rolesArray;
        userObj["locationsRoles"][0]["location"] = {
          name: this.helper.getLocation()
        };
        res.locations = this.helper.getFormatedLocations(userObj)
        if (this.editMode) {
          this.data.changeCurrentLog("user-mangement/edit");
          this.userService.updateUser(userObj,res).subscribe(data => {
            this.userService.sendCreatedUser(userObj);
            this.helper.showSnackbar('Successfully updated A record');
            this.dialogRef.close(this.userDiagForm.value);
            this.spinnerService.hide();
          }, err => {
             if(err.status='500'){
               this.helper.showSnackbar('Something Went Wrong Failed To Update !',false, true);
              }
             else{
               this.helper.showSnackbar(err.error.message,false, true);
              }
            },()=>{
            this.userReacivateLinkSrv.reactivateUserOnEmailchanges(this.oldEmail,this.userDiagForm.get('email').value);
          });
        } else {
          this.data.changeCurrentLog("user-mangement/create");
          userObj["password"] = "password";
          userObj["enabled"] = false;
          delete userObj["id"];
          this.userService.addNewUser(userObj,res).subscribe(data => {
            this.userService.sendCreatedUser(data);
            this.helper.showSnackbar('Successfully sent activation email!!!');
            this.dialogRef.close(this.userDiagForm.value);
            this.spinnerService.hide();
          });
        }
      }
     }
    })
  }

  /** CLOSE mat dialog **/
  close() {
    this.dialogRef.close(null);
  }

  /** DESTROY editmode **/
  ngOnDestroy() {
    this.editMode = false;
  }

  /** EMail Exist */
  isEmailExist(emailId){
    this.authSrv.validateUser(emailId).subscribe(res =>{
      if(res.body.exist && !res.body.deleted){
        this.errorEmail='Email Already Exists'
      }
      if(!res.body.exist && !res.body.deleted){
        this.errorEmail=null;
      }
      if(res.body.exist && res.body.deleted) {
          this.userRetrievalSrv.userRetrievePopup().then(res=>{
          if(res){
            this.retrieveAndSendReactivationLink(emailId);
          }
          else{
            this.userDiagForm.get('email').patchValue('');
          }
        });  
      }
    })
  }
  retrieveAndSendReactivationLink(emailId:string){
    this.authSrv.retrieveUser(emailId).subscribe(res=>{
      this.userService.sendCreatedUser(res);
      this.helper.showSnackbar('User Retrieved Successfully');
      this.dialogRef.close(this.userDiagForm.value);
    })
  }
}