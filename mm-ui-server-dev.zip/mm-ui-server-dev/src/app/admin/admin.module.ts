import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import {
  MatIconModule, MatCardModule, MatButtonModule, MatListModule, MatProgressBarModule, MatMenuModule, MatFormFieldModule,
  MatInputModule, MatRippleModule, MatSelectModule, MatSortModule, MatTableModule, MatPaginatorModule, MatRadioModule, MatCheckboxModule,
  MatDatepickerModule, MatDialogModule, MatToolbarModule, MatAutocompleteModule, MatChipsModule, MatExpansionModule, MAT_DIALOG_DATA, MatTooltipModule, MatProgressSpinnerModule
} from '@angular/material';
import { FlexLayoutModule } from '@angular/flex-layout';

import { ChartsModule } from 'ng2-charts/ng2-charts';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { AdminRoutes } from './admin.routing';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { UserManagementComponent } from './user-management/user-management.component';
import { ArchivedRecordsComponent } from './archived-records/archived-records.component';
import { LabelsComponent } from './labels/labels.component';

import { HelperService } from '../services/helper.service';
import { UserService } from './services/user.service';
import { ArchiveService } from './services/archive.service';
import { RoomService } from './services/room.service';
import { StorageService } from './services/storage.service';
import{AdvSearchService}from '../adv-search/adv-search.service';

import { RoomsComponent } from './configuration/rooms/rooms.component';
import { RoomTempShelvingComponent } from './configuration/storage-types/room-temp-shelving/room-temp-shelving.component';
import { FreezersComponent } from './configuration/storage-types/freezers/freezers.component';
import { IncubatorComponent } from './configuration/storage-types/incubator/incubator.component';
import { RefrigeratorComponent } from './configuration/storage-types/refrigerator/refrigerator.component';

import { CreateUserComponent } from './user-management/create-user/create-user.component';
import { CreateRoomComponent } from './configuration/rooms/create-room/create-room.component';
import { CreateFreezerComponent } from './configuration/storage-types/freezers/create-freezer/create-freezer.component';
import { CreateIncubatorComponent } from './configuration/storage-types/incubator/create-incubator/create-incubator.component';
import { CreateRefrigeratorComponent } from './configuration/storage-types/refrigerator/create-refrigerator/create-refrigerator.component';
import { CreateOpenshelvingComponent } from './configuration/storage-types/room-temp-shelving/create-openshelving/create-openshelving.component';
import { AdvSearchComponent } from '../adv-search/adv-search.component';

import { CreateShelveComponent } from './shared/create-shelve/create-shelve.component';
import { CreateRackComponent } from './shared/create-rack/create-rack.component';
import { CreateSlotComponent } from './shared/create-slot/create-slot.component';
import { ViewStorageTypeComponent } from './shared/view-storagetype/view-storagetype.component';
import { ViewRackComponent } from './shared/view-rack/view-rack.component';
import { AuditLogComponent } from '../audit-log/audit-log/audit-log.component';
import {ArchiveResolver} from'./services/archive.resolver';
import {UserResolver} from'./services/user.resolver';
import { RoomResolver } from './services/room.resolver';
import { IncubatorResolver } from './services/incubators.resolver';
import { CreateRowComponent } from './shared/create-row/create-row.component';
import { ViewRowComponent } from './shared/view-row/view-row.component';
import { CreateSectionComponent } from './shared/create-section/create-section.component';
import { OpenShelvingResolver } from './services/open-shel.resolver';
import { ViewShelveComponent } from './shared/view-shelve/view-shelve.component';
import { RefrigeratorResolver } from './services/refrigerator.resolver';
import { EventService } from './services/event.service';
import { FreezerResolver } from './services/freezer.resolver';
import { ReviewerManagementModule } from 'app/reviewer/reviewer-management.module';
import { RowsComponent } from './configuration/storage-types/rows/rows.component';
import { CreateRowsComponent } from './configuration/storage-types/rows/create-rows/create-rows.component';
import{RoomRowResolver} from'./services/room-rows.resolver';

@NgModule({
  declarations: [UserManagementComponent, ArchivedRecordsComponent, CreateUserComponent,
    RoomsComponent, RoomTempShelvingComponent, FreezersComponent,
    IncubatorComponent, RefrigeratorComponent, LabelsComponent, CreateRoomComponent, 
    CreateFreezerComponent,ViewRowComponent,ViewShelveComponent,
    CreateIncubatorComponent, CreateRefrigeratorComponent, CreateOpenshelvingComponent, 
    ViewStorageTypeComponent, CreateShelveComponent, ViewRackComponent,
    CreateRackComponent, CreateSlotComponent, CreateSectionComponent, CreateRowComponent, RowsComponent, CreateRowsComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(AdminRoutes),
    MatFormFieldModule,
    MatInputModule,
    MatIconModule,
    MatCardModule,
    MatButtonModule,
    MatListModule,
    MatProgressBarModule,
    MatMenuModule,
    ChartsModule,
    NgxChartsModule,
    NgxDatatableModule,
    FlexLayoutModule,
    FormsModule,
    ReactiveFormsModule.withConfig({warnOnNgModelWithFormControl: 'never'}),
    MatSelectModule,
    MatSortModule,
    MatTableModule,
    MatPaginatorModule,
    MatRadioModule,
    MatCheckboxModule,
    MatDatepickerModule,
    MatDialogModule,
    MatRippleModule,
    MatExpansionModule,
    MatToolbarModule,
    MatChipsModule,
    MatAutocompleteModule,
    ReviewerManagementModule,
    MatTooltipModule,
  ],
  providers: [HelperService, UserService,UserResolver, ArchiveService,EventService, FreezerResolver,
    ArchiveResolver, RoomService, StorageService, RoomResolver, IncubatorResolver,OpenShelvingResolver,RefrigeratorResolver,RoomRowResolver,
  
    { provide: MAT_DIALOG_DATA, useValue: [] }],
  entryComponents: [CreateUserComponent, CreateRoomComponent, CreateFreezerComponent,
    CreateIncubatorComponent, CreateOpenshelvingComponent, CreateRefrigeratorComponent, 
    CreateShelveComponent,CreateRowComponent, CreateRackComponent, CreateSlotComponent,CreateSectionComponent,CreateRowsComponent]
})
export class AdminModule { }
