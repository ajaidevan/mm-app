import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import { LabelService } from '../services/label.service';
import { Label } from 'app/models/label.model';

@Component({
  selector: 'app-labels',
  templateUrl: './labels.component.html',
  styleUrls: ['./labels.component.scss']
})
export class LabelsComponent implements OnInit {

  public displayedColumns: string[] = ['labelName', 'description', 'dimensions'];
  public dataSource = new MatTableDataSource<Label>();

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(private labelSrv: LabelService) { }

  ngOnInit() {
    this.getAllLabel();
  }

  /** GET all labels **/
  getAllLabel() {
    this.labelSrv.getAlllabel().subscribe(data => {
      this.dataSource.data = data
    }, err => {
      console.error("label specifiaction failed", err);
    })
  }

  applyFilter(filterValue: string) {
  }
}
