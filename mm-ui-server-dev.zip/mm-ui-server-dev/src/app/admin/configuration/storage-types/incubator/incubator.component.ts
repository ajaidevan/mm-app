import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatSort, MatDialog, MatTableDataSource, MatDialogConfig, PageEvent ,Sort} from '@angular/material';
import { StorageService } from '../../../services/storage.service';
import { StorageModel } from '../../../../models/storage.model';
import { CreateIncubatorComponent } from './create-incubator/create-incubator.component';
import { ValidatorService } from 'app/services/validator.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { HelperService } from 'app/services/helper.service';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonApiService } from 'app/services/common-api.service';
import { EventService } from 'app/admin/services/event.service';

@Component({
  selector: 'app-incubator',
  templateUrl: './incubator.component.html',
  styleUrls: ['./incubator.component.scss']
})
export class IncubatorComponent implements OnInit {

  public displayedColumns: string[] = ['id', 'roomId', 'name', 'serialNo', 'incType', 'opSetPoint', 'statusType', 'action'];
  public dataSource: any = new MatTableDataSource();
  public data: any;
  public editMode: boolean = false;
  public viewMode: boolean = true;
  public selectedInfo: Array<StorageModel> = [];
  public paginate: any = {};
  public totalIncubators: any;
  public pageEvent: PageEvent;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(private dialog: MatDialog, private storageSrv: StorageService, private validatorService: ValidatorService,
    private spinnerService: Ng4LoadingSpinnerService, private route: ActivatedRoute, private router: Router,
    private commonSrv: CommonApiService, private helperService: HelperService) { }

  ngOnInit() {
    //got to inc
    this.setDfaultIncubatorsParam();
    this.storageSrv.currentIncubator.subscribe(data => {
      let newData = this.dataSource.data;
      if (this.editMode) {
        this.paginateIncubators(false);
        this.editMode = false;
      } else {
        this.paginateIncubators(false);
      }
    });
  }

  receivedViewMode($event) {
    this.viewMode = $event;
    this.selectedInfo.splice(0, 1);
  }

  gotoIncubator(data) {
    this.viewMode = false;
    data.type = 'incubator';
    this.selectedInfo.push(data);
  }

  /** CREATE a incubator **/
  openCreateIncubator(newData?): void {
    if (newData) {
      this.storageSrv.setSharedIncubator(newData);
    } else {
      this.storageSrv.setSharedIncubator("");
    }
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    let dialogRef = this.dialog.open(CreateIncubatorComponent, dialogConfig);
  }

  /** DELETE a incubator **/
  onDeleteIncubator(incubator, index) {
    this.validatorService.userValidator('delete').then(res => {
      if (res.val) {
        delete res.val;
        this.storageSrv.deleteIncubator(incubator,res).subscribe(data => {
          let incubatorData = this.dataSource.data;
          for (const index in incubatorData) {
            if (incubator.id == incubatorData[index]["id"]) {
              incubatorData.splice(Number(index), 1)
              break;
            }
          }
          this.dataSource.data = incubatorData;
          this.paginateIncubators(false);
        },err=>{
             this.helperService.showSnackbar(err.error.message,false,true)
          });
      }
    }).catch(err => {
      console.error("Delete Incubator Failed", err);
    });
  }

  /** EDIT a incubator **/
  onEditIncubator(userObj) {
    this.editMode = true;
    this.openCreateIncubator(userObj);
  }

  /** Set Params */
  setDfaultIncubatorsParam() {
    this.paginate = this.route.snapshot.data['params'];
    let reqParams = this.commonSrv.createParam(this.paginate);
    this.router.navigate([], { queryParams: reqParams })
    this.dataSource.data = this.route.snapshot.data['incubators'].body;
    this.totalIncubators = this.route.snapshot.data['incubators'].headers.get('X-Total-Count');
  }

  /** Paginate INCUBATORS */
  paginateIncubators(setPage = true) {
    if (setPage) this.paginate.page = 0; this.paginate.size = 10;
    let reqParams = this.commonSrv.createParam(this.paginate);
    this.router.navigate([], { queryParams: reqParams });
    this.storageSrv.getIncubator(this.helperService.getLocation(), reqParams).subscribe(data => {
      this.dataSource.data = data.body;
      this.totalIncubators = data.headers.get('X-Total-Count');
    })
  }

  /** Onchange Page **/
  onChangePage(event?: PageEvent) {
    this.paginate.size = event.pageSize;
    this.paginate.page = event.pageIndex;
    this.paginateIncubators(false);
    return event;
  }

  /** Search Incubator **/
  search(filterValue: any) {
    this.storageSrv.searchIncubator(this.helperService.getLocation(),filterValue).subscribe(res => {
      this.dataSource.data = res.body;
    })
  }

  /** Apply Filter **/
  applyFilter(filter?: string) {
    if (filter.length >= 3) {
      this.search(filter)
    }
     if(filter.length == 0) this.paginateIncubators();
  }
   /*Sorting*/
   sortData(event: Sort) {
    this.paginate.sort = event.active + ',' + event.direction;
    this.paginateIncubators();    
  }

}
