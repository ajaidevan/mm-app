import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material';
import { FormGroup, FormControl, Validators, FormGroupDirective, NgForm } from '@angular/forms';
import { ErrorStateMatcher } from '@angular/material/core';
import { HelperService } from 'app/services/helper.service';
import { StorageService } from '../../../../services/storage.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { RoomService } from 'app/admin/services/room.service';
import{DataService} from 'app/services/data.service';
import { ValidatorService } from 'app/services/validator.service';

export class MyErrorStateMatcher implements ErrorStateMatcher {

  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = form && form.submitted;
    return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
  }

}
@Component({
  selector: 'app-create-incubator',
  templateUrl: './create-incubator.component.html',
  styleUrls: ['./create-incubator.component.scss']
})

export class CreateIncubatorComponent implements OnInit {

  public incubatorTypes: any[] = ['Walk In','Counter Top','Upright','Stacked'];

  public statusTypes: any[] = ['N/A', 'Quarantine', 'Release', 'Reject'];

  public fetchedRooms :any ;
  public incubatorDiagForm = new FormGroup({
    id:new FormControl(''),
    roomName: new FormControl('',Validators.required),
    name: new FormControl('', Validators.required),
    serialNo: new FormControl('', Validators.required),
    incType: new FormControl([], Validators.required),
    opSetPoint: new FormControl('', Validators.required),
    statusType:new FormControl('',Validators.required),
    locationId:new FormControl(this.helper.getLocation()),
    row:new FormControl('',Validators.required),
  });

  public matcher = new MyErrorStateMatcher();
  public editMode: boolean = false;
  public clicked=false;
  public fetchedRoomRows:any;
  public roomRowData:any = {};
  public paginateRows: any = {};
  public fetchedRowsLength:number;
  public paginateElements:number;
  public roomId:any;
  constructor(private dialogRef: MatDialogRef<CreateIncubatorComponent>,
    private helper: HelperService,private validatorService:ValidatorService,
    private storageSrv: StorageService,private roomSrv: RoomService,private dataService:DataService,
    private spinnerService: Ng4LoadingSpinnerService) { }

  ngOnInit() {
    this.storageSrv.sharedIncubator.distinctUntilChanged().subscribe(data => {
      if (data) {
        this.incubatorDiagForm.patchValue(data);
        this.incubatorDiagForm.get('roomName').patchValue(data.roomName);
        this.editMode = true;
        this.getAllRowsByRoom(data.roomId,data.roomRowId);
      }
    });
    this.roomSrv.getAllRooms(this.helper.getLocation(),{}).subscribe(res=> this.fetchedRooms = res.body);
  }

  /** DESTROY editmode **/
  ngOnDestroy() {
    this.editMode = false;
  }

  /** CREATE a incubator **/
  create() {
    this.validatorService.userValidator(this.editMode?'update':'create').then(res => {
      if(res.val) {
        this.clicked=false;
        delete res.val;
        let incubatorObj = this.incubatorDiagForm.value;
        incubatorObj['locationId']=this.helper.getLocation();
        incubatorObj['roomId'] = this.roomRowData.room.id;
        incubatorObj['roomName'] = this.roomRowData.room.name;
        incubatorObj['roomRowName'] = this.roomRowData.row.seqId;
        incubatorObj['roomRowId'] = this.roomRowData.row.id;
        if (this.editMode) {
          if (this.incubatorDiagForm.valid) {
            this.storageSrv.updateIncubator(incubatorObj,res).subscribe(data => {
              this.helper.showSnackbar('Successfully Updated Incubator !');
              this.dialogRef.close(this.incubatorDiagForm.value);
              this.storageSrv.sendCurrentIncubator(data);
            })
          }
        } else {
          if (this.incubatorDiagForm.valid) {
            delete incubatorObj["id"];
            this.storageSrv.addIncubator(incubatorObj,res).subscribe(data => {
              this.storageSrv.sendCurrentIncubator(data);
              this.helper.showSnackbar('Successfully Created Incubator!');
              this.dialogRef.close(this.incubatorDiagForm.value);          
            },err=>{
              this.helper.showSnackbar('Incubator Already Exists!');
            })
          }
        }
      }
    })
  }
  /**fetched Rows by Room  */
getAllRowsByRoom(roomId,rowId?){
  this.spinnerService.show();
  this.incubatorDiagForm.controls['row'].reset();
  this.paginateAllRows(roomId,rowId);
  this.findRoomById(roomId);
}

  /** CLOSE mat dialog **/
  close() {
    this.dialogRef.close(null);
  }
  findRoomById(id){
    this.roomSrv.getAllRooms(this.helper.getLocation(),{}).subscribe(res=> {
      this.fetchedRooms = res.body;
      if(this.fetchedRooms && this.fetchedRooms.length > 0)
      this.roomRowData.room = this.fetchedRooms.find(room => room.id === id);
    });
  }
  
  findRowById(id){
    this.roomRowData.row = this.fetchedRoomRows.find(row => row.id === id);
    if(this.editMode){
      if(id){
        this.incubatorDiagForm.get('row').patchValue(this.roomRowData.row.seqId);
      }
    } 
  }

   
  paginateAllRows(roomId,rowId?) {
    this.spinnerService.show();
    this.paginateRows.page = 0;
    this.paginateRows.size = 10;
    this.paginateRows.sort = "creationAt,DESC";
    this.roomId = roomId;
    this.storageSrv.getAllRoomRowsByRoom(roomId,this.paginateRows).subscribe(
      data => {
       if(data.body.length > 0) {
        this.fetchedRoomRows = data.body;
        this.fetchedRowsLength= data.headers.get('X-Total-Count');
        this.paginateElements = 10;
        this.spinnerService.hide();
       if(this.editMode)this.findRowById(rowId);
      }
      if(data.body.length === 0) this.fetchedRoomRows = ['There is No Row available in this room'];
      }, err => {
        this.helper.showSnackbar('Failed To Fetch Companies !', false, true);
        this.spinnerService.hide();
      }
    )
  }

  loadMoreCompanies() {
    this.paginateRows.size = this.paginateRows.size + 10;
    this.storageSrv.getAllRoomRowsByRoom(this.roomId,this.paginateRows).subscribe(
      data => {
        this.spinnerService.show();
        this.fetchedRoomRows = data.body;
        this.fetchedRowsLength= data.headers.get('X-Total-Count');
        if(this.fetchedRowsLength > this.paginateElements) this.paginateElements = this.paginateElements + 10;
        this.spinnerService.hide();
      }, err => {
        this.spinnerService.hide();
      }
    )
    return false;
  }
}
