import { Component, OnInit ,ViewChild,Input,Output,EventEmitter,} from '@angular/core';
import { MatPaginator, MatSort, MatDialog, MatTableDataSource, MatDialogConfig, PageEvent,Sort } from '@angular/material';
import { StorageService } from '../../../services/storage.service';
import { CreateRowsComponent } from './create-rows/create-rows.component';
import { ValidatorService } from 'app/services/validator.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { HelperService } from 'app/services/helper.service';
import { CommonApiService } from 'app/services/common-api.service';
import { ActivatedRoute, Router } from '@angular/router';
import { RoomModel } from 'app/models/room.model';
import { EventService } from 'app/admin/services/event.service';


@Component({
  selector: 'app-rows',
  templateUrl: './rows.component.html',
  styleUrls: ['./rows.component.scss']
})
export class RowsComponent implements OnInit {
  public displayedColumns: string[] = ['name','statustype', 'action'];
  public dataSource = new MatTableDataSource();
  public editMode: boolean = false;
  public viewMode: boolean = true;
  public data: any;
  public paginate: any = {};
  public totalRows: number;
  public pageEvent: PageEvent;
  public dataInfo: any;

  @Input()  viewRowInfo:Array<RoomModel>;
  @Output() viewEvent = new EventEmitter();
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(private dialog: MatDialog, private storageSrv: StorageService, private validatorService: ValidatorService, private spinnerService: Ng4LoadingSpinnerService,
    private helperService: HelperService, private commonSrv: CommonApiService, private actRoute: ActivatedRoute, private router: Router,private eventSrv:EventService) { }

  ngOnInit() {
    this.dataInfo=this.viewRowInfo;
    this.setDefaultParams();
    this.storageSrv.currentRoomRow.subscribe(data => {
      if (this.editMode) {
        this.paginateRoomRows(false);
        this.editMode = false;
      } else {
        this.paginateRoomRows(false);
      }
    });
  }
   /** Delete  Room-Rows **/
   onDeleteRoomRows(row, index) {
    this.validatorService.userValidator('delete').then(res => {
      if (res.val) {
        delete res.val;
        this.storageSrv.deleteRoomRows(row,res).subscribe(data => {
          let rowData = this.dataSource.data;
          rowData.splice(Number(index), 1);
          this.dataSource.data = rowData;
          this.paginateRoomRows(false);
        },err=>{
            this.helperService.showSnackbar(err.error.message,false,true)});
      }
    }).catch(err => {
      console.error("Delete RoomRow Failed", err);
    });
  }
 /** EDIT Room-Rows **/
 onEditRoomRows(rowObj) {
  this.editMode = true;
  this.openCreateRow(rowObj);
}
  /** open CREATE Row **/
  openCreateRow(newData?): void {
    if (newData) {
      this.storageSrv.setSharedRoomRow(newData);
    } else {
      this.storageSrv.setSharedRoomRow("");
    }
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    let dialogRef = this.dialog.open(CreateRowsComponent, {
      width: '700px',
      data: this.viewRowInfo[0]
    });
  }
 
   //all rows By Room
   getRowsByroom(reqParams){
    this.storageSrv.getAllRoomRowsByRoom(this.dataInfo[0].id,reqParams).subscribe(res=>{
      this.dataSource.data = res.body;
      this.totalRows = res.headers.get('X-Total-Count');
    })
  }
  // Set Default Params
  setDefaultParams() {
    this.paginate = {
      page: 0,
      size: 10,
      sort: 'seqId,ASC'
    }
    this.paginateRoomRows(false);
    }
  paginateRoomRows(setPage=true){
    if (setPage) this.paginate.page = 0;
    let reqParams = this.commonSrv.createParam(this.paginate);
    this.router.navigate([], { queryParams: reqParams });
    this.getRowsByroom(reqParams);
  }
/** Onchange Page **/
onChangePage(event?: PageEvent) {
  this.paginate.size = event.pageSize;
  this.paginate.page = event.pageIndex;
  this.paginateRoomRows(false);
  return event;
}
 /*Sorting*/
 sortData(event: Sort) {
  this.paginate.sort = event.active + ',' + event.direction;
  this.paginateRoomRows();    
}
 /** Search Freezer **/
 search(filterValue: any) {
  this.storageSrv.searchRoomRows(this.dataInfo[0].id, filterValue).subscribe(res => {
    this.dataSource =  new MatTableDataSource(res.body);
  })
}

/** Apply Filter **/
applyFilter(filter?: string) {
  if(filter.includes('row-') || filter.includes('Row-')) filter = filter.split("-").pop();

  if (filter.length > 0) {
    this.search(filter)
  }
  if (filter.length == 0) this.paginateRoomRows();
}
// Go Back
goBack() {
  this.viewEvent.emit(this.viewMode);   
}
}
