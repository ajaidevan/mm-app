import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateRowsComponent } from './create-rows.component';

describe('CreateRowsComponent', () => {
  let component: CreateRowsComponent;
  let fixture: ComponentFixture<CreateRowsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreateRowsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateRowsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
