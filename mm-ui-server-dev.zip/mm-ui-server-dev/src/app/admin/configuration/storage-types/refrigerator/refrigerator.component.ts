import { Component, OnInit, ViewChild} from '@angular/core';
import { MatPaginator, MatSort, MatDialog, MatTableDataSource, MatDialogConfig, PageEvent,Sort } from '@angular/material';
import { StorageService } from '../../../services/storage.service';
import { CreateRefrigeratorComponent } from './create-refrigerator/create-refrigerator.component';
import { ValidatorService } from 'app/services/validator.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { HelperService } from 'app/services/helper.service';
import { StorageModel } from 'app/models/storage.model';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonApiService } from 'app/services/common-api.service';
import { EventService } from 'app/admin/services/event.service';

@Component({
  selector: 'app-refrigerator',
  templateUrl: './refrigerator.component.html',
  styleUrls: ['./refrigerator.component.scss'],
})
export class RefrigeratorComponent implements OnInit {

  public displayedColumns: string[] = ['id','name', 'roomNo', 'serialNo', 'refType', 'opSetPoint','statusType','action'];
  public dataSource = new MatTableDataSource();
  public editMode: boolean = false;
  public viewMode: boolean = true;
  public data: any;
  public selectedInfo: Array<StorageModel> = [];
  public type: any;
  public paginate: any ={};
  public totalRefrigerator: number;
  public pageEvent : PageEvent;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(private dialog: MatDialog, private storageSrv: StorageService, private validatorService: ValidatorService, private spinnerService: Ng4LoadingSpinnerService,
    private helperService: HelperService,private actRoute: ActivatedRoute, private router: Router,private eventSrv :EventService,
    private commonSrv: CommonApiService) { }

  ngOnInit() {
    this.setDfaultRefrigeratorParam();
    this.storageSrv.currentRefrigerator.subscribe(data => {
      if (this.editMode) {        
            this.paginateRefrigerator(false);
            this.editMode = false;
          } else {
            this.paginateRefrigerator(false);
          }
      });
  }

  receivedViewMode($event) {
    this.viewMode = $event;
    this.selectedInfo.splice(0, 1);
  }

  gotoRefrigerator(data) {
    this.viewMode = false;
    data.type ='refrigerator';
    this.selectedInfo.push(data);
  }

  /** CREATE a refrigerator **/
  openCreateRefrigerator(newData?): void {
    if (newData) {
      this.storageSrv.setSharedRefrigerator(newData);
    } else {
      this.storageSrv.setSharedRefrigerator("");
    }
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    let dialogRef = this.dialog.open(CreateRefrigeratorComponent, dialogConfig);
  }

 

  /** DELETE a refrigerator **/
  onDeleteRefrigerator(refrigerator, index) {
    this.validatorService.userValidator('delete').then(res => {
      if (res.val) {
        delete res.val;
        this.storageSrv.deleteRefrigerator(refrigerator,res).subscribe(data => {
          let refrigeratorData = this.dataSource.data;
          refrigeratorData.splice(Number(index), 1);
          this.dataSource.data = refrigeratorData;
          this.paginateRefrigerator(false);
        },err=>{
           this.helperService.showSnackbar(err.error.message,false,true);
          });
      }
    }).catch(err => {
      console.error("Delete Refrigerator Failed ", err);
    });
  }

  /** EDIT a refrigerator **/
  onEditRefrigerator(userObj) {
    this.editMode = true;
    this.openCreateRefrigerator(userObj);
  }
  
  /** Set Params */
  setDfaultRefrigeratorParam(){
    this.paginate = this.actRoute.snapshot.data['params'];
    let reqParams = this.commonSrv.createParam(this.paginate);
      this.router.navigate([],{queryParams : reqParams})
      this.dataSource.data = this.actRoute.snapshot.data['refrigerator'].body;
      this.totalRefrigerator = this.actRoute.snapshot.data['refrigerator'].headers.get('X-Total-Count');
    }

   /** Paginate Refrigerator */
   paginateRefrigerator(setPage = true){
    if(setPage) this.paginate.page = 0;
    let reqParams = this.commonSrv.createParam(this.paginate);
    this.router.navigate([],{queryParams:reqParams});
    this.storageSrv.getAllRefByLocId(this.helperService.getLocation(),reqParams).subscribe(data=>{
      this.dataSource.data = data.body;
      this.totalRefrigerator = data.headers.get('X-Total-Count');
    })
   }

   /** Onchange Page **/
  onChangePage(event?: PageEvent) {
    this.paginate.size = event.pageSize;
    this.paginate.page = event.pageIndex;
    this.paginateRefrigerator(false);
    return event;
  }
  /**Sorting*/
  sortData(event:Sort){
    this.paginate.sort=event.active +","+event.direction;
    this.paginateRefrigerator();

  }
    /** Search Open-Shelving */
    searchRefrigerator(filterValue?:any){
      this.storageSrv.searchRefrigerator(this.helperService.getLocation(),filterValue).subscribe(res=>{
      this.dataSource.data = res.body;
      })
    }
    
    /** Apply Filter */
    applyFilter(filter?:any) {
      if(filter.length>0) this.searchRefrigerator(filter);
      if(filter.length==0) this.paginateRefrigerator();
    }
}
