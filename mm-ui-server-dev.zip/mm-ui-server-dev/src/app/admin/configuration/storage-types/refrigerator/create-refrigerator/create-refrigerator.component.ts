import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material';
import { FormGroup, FormControl, Validators, FormGroupDirective, NgForm, FormBuilder } from '@angular/forms';
import { ErrorStateMatcher } from '@angular/material/core';
import { HelperService } from 'app/services/helper.service';
import { StorageService } from '../../../../services/storage.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { RoomService } from 'app/admin/services/room.service';
import{DataService} from'app/services/data.service';
import { ValidatorService } from 'app/services/validator.service';

export class MyErrorStateMatcher implements ErrorStateMatcher {

  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = form && form.submitted;
    return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
  }
}
@Component({
  selector: 'app-create-refrigerator',
  templateUrl: './create-refrigerator.component.html',
  styleUrls: ['./create-refrigerator.component.scss']
})

export class CreateRefrigeratorComponent implements OnInit {


  public fetchedRooms :any ;
  public refTypes: any[] = ['+5 Upright','+5 Chest','+5 WalkIn'];
  public statusTypes: any[] = ['N/A', 'Quarantine', 'Release', 'Reject'];

  public refrigeratorDiagForm = new FormGroup({
    id: new FormControl(''),
    name: new FormControl('', Validators.required),
    roomName: new FormControl('', Validators.required),
    serialNo: new FormControl('', Validators.required),
    refType: new FormControl([], Validators.required),
    opSetPoint: new FormControl('', Validators.required),
    statusType:new FormControl('',Validators.required),
    locationId:new FormControl(this.helper.getLocation()),
    row:new FormControl('',Validators.required),
  });

  public matcher = new MyErrorStateMatcher();
  public editMode: boolean = false;
  public clicked=false;
  public fetchedRoomRows:any;
  public roomRowData:any = {};
  public paginateRows: any = {};
  public fetchedRowsLength:number;
  public paginateElements:number;
  public roomId:any;

  constructor(private dialogRef: MatDialogRef<CreateRefrigeratorComponent>,
    private helper: HelperService,private validatorService:ValidatorService,
    private storageSrv: StorageService,private roomSrv :RoomService,private dataService:DataService,
    private spinnerService: Ng4LoadingSpinnerService) { }

  ngOnInit() {
    this.storageSrv.sharedRefrigerator.distinctUntilChanged().subscribe(data => {
      if (data) {
        this.refrigeratorDiagForm.patchValue(data);
        this.refrigeratorDiagForm.get('roomName').patchValue(data.roomName);
        this.editMode = true;
        this.getAllRowsByRoom(data.roomId,data.roomRowId);

      }
    })
    this.roomSrv.getAllRooms(this.helper.getLocation(),{}).subscribe(res=> this.fetchedRooms = res.body);
  }

  /** DESTROY editmode **/
  ngOnDestroy() {
    this.editMode = false;
  }

  /** CREATE a refrigerator **/
  create() {
    this.validatorService.userValidator(this.editMode?'update':'create').then(res => {
      if(res.val) {
        this.spinnerService.show();
        this.clicked=false;
        delete res.val;
        if (this.refrigeratorDiagForm.valid) {
          let refrigeratorObj = this.refrigeratorDiagForm.value;
          refrigeratorObj['locationId']=this.helper.getLocation();
          refrigeratorObj['roomId'] = this.roomRowData.room.id;
          refrigeratorObj['roomName'] = this.roomRowData.room.name;
          refrigeratorObj['roomRowName'] = this.roomRowData.row.seqId;
          refrigeratorObj['roomRowId'] = this.roomRowData.row.id;
        if (this.editMode) {
            this.storageSrv.updateRefrigerator(refrigeratorObj,res).subscribe(data => {
              this.helper.showSnackbar('Successfully Updated Refrigerator !');
              this.dialogRef.close(this.refrigeratorDiagForm.value);
              this.storageSrv.sendCurrentRefrigerator(data);
            })
        } else {
            delete refrigeratorObj["id"];
            this.storageSrv.addRefrigerator(refrigeratorObj,res).subscribe(data => {
              this.helper.showSnackbar('Successfully Created Refrigerator!');
              this.dialogRef.close(this.refrigeratorDiagForm.value);
              this.storageSrv.sendCurrentRefrigerator(data);
            },err=>{
              this.helper.showSnackbar('Refrigerator Already Exists!');
            })
        }
      }
    }
  })
}
/**fetched Rows by Room  */
getAllRowsByRoom(roomId,rowId?){
  this.spinnerService.show();
  this.refrigeratorDiagForm.controls['row'].reset();
  this.paginateAllRows(roomId,rowId);
  this.findRoomById(roomId);
 }
  /** CLOSE mat dialog **/
  close() {
    this.dialogRef.close(null);
  }
  findRoomById(id){
    this.roomSrv.getAllRooms(this.helper.getLocation(),{}).subscribe(res=> {
      this.fetchedRooms = res.body;
      if(this.fetchedRooms && this.fetchedRooms.length > 0)
      this.roomRowData.room = this.fetchedRooms.find(room => room.id === id);
    });
  }
  findRowById(id){
    this.roomRowData.row = this.fetchedRoomRows.find(row => row.id === id);
    if(this.editMode) {
      if(id){
        this.refrigeratorDiagForm.get('row').patchValue(this.roomRowData.row.seqId);
      }
    }
  }
 
  paginateAllRows(roomId,rowId?) {
    this.spinnerService.show();
    this.paginateRows.page = 0;
    this.paginateRows.size = 10;
    this.paginateRows.sort = "creationAt,DESC";
    this.roomId = roomId;
    this.storageSrv.getAllRoomRowsByRoom(roomId,this.paginateRows).subscribe(
      data => {
       if(data.body.length > 0) {
        this.fetchedRoomRows = data.body;
        this.fetchedRowsLength= data.headers.get('X-Total-Count');
        this.paginateElements = 10;
        this.spinnerService.hide();
       if(this.editMode)this.findRowById(rowId);
      }
      if(data.body.length === 0) this.fetchedRoomRows = ['There is No Row available in this room'];
      }, err => {
        this.helper.showSnackbar('Failed To Fetch Companies !', false, true);
        this.spinnerService.hide();
      }
    )
  }

  loadMoreCompanies() {
    this.paginateRows.size = this.paginateRows.size + 10;
    this.storageSrv.getAllRoomRowsByRoom(this.roomId,this.paginateRows).subscribe(
      data => {
        this.spinnerService.show();
        this.fetchedRoomRows = data.body;
        this.fetchedRowsLength= data.headers.get('X-Total-Count');
        if(this.fetchedRowsLength > this.paginateElements) this.paginateElements = this.paginateElements + 10;
        this.spinnerService.hide();
      }, err => {
        this.spinnerService.hide();
      }
    )
    return false;
  }
}
