import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatSort, MatDialog, MatTableDataSource, MatDialogConfig, PageEvent,Sort } from '@angular/material';
import { StorageService } from '../../../services/storage.service';
import { StorageModel } from '../../../../models/storage.model';
import { CreateOpenshelvingComponent } from './create-openshelving/create-openshelving.component';
import { ValidatorService } from 'app/services/validator.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { HelperService } from 'app/services/helper.service';
import { Router, ActivatedRoute } from '@angular/router';
import { CommonApiService } from 'app/services/common-api.service';
import { EventService } from 'app/admin/services/event.service';

@Component({
  selector: 'app-room-temp-shelving',
  templateUrl: './room-temp-shelving.component.html',
  styleUrls: ['./room-temp-shelving.component.scss']
  
})
export class RoomTempShelvingComponent implements OnInit {

  public displayedColumns: string[] = ['id','os_name', 'os_roomNo', 'os_serialNo', 'statusType', 'action'];
  public dataSource = new MatTableDataSource();
  public editMode: boolean = false;
  public viewMode: boolean = true;
  public data: any;
  public selectedInfo: Array<StorageModel> = [];
  public paginate: any ={};
  public totalOs: any;
  public pageEvent : PageEvent;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(private dialog: MatDialog, private storageSrv: StorageService, private validatorService: ValidatorService, 
    private spinnerService: Ng4LoadingSpinnerService,private commonSrv: CommonApiService,private eventSrv:EventService,
    private helperService: HelperService,private router: Router,private actRout: ActivatedRoute,) { }

  ngOnInit() {
   this.setDfaultOpenShelvingParam();
   this.storageSrv.currentOpenShelving.subscribe(data => {
    let newData = this.dataSource.data;
    if (this.editMode) {
        this.paginateOpenShelving();
        this.editMode = false;
    } else {
        this.paginateOpenShelving();
        this.dataSource.data = newData;
      }
  });
  }

  receivedViewMode($event) {
    this.viewMode = $event;
    this.selectedInfo.splice(0, 1);
  }

  gotoOpenShelving(data) {
    this.viewMode = false;
    data.type ='open-shelf';
    this.selectedInfo.push(data);
  }

  /** open CREATE open shelving **/
  openCreateOpenShelving(newData?): void {
    if (newData) {
      this.storageSrv.setSharedOpenShelving(newData);
    } else {
      this.storageSrv.setSharedOpenShelving("");
    }
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    let dialogRef = this.dialog.open(CreateOpenshelvingComponent, dialogConfig);
  }

  /** DELETE a open shelving **/
  onDeleteOpenShelving(openShelving, index) {
    this.validatorService.userValidator('delete').then(res => {
      if (res.val) {
        delete res.val;
        this.storageSrv.deleteOpenShelving(openShelving,res).subscribe(data => {
          let openShelvingData = this.dataSource.data;
          openShelvingData.splice(Number(index), 1);
          this.dataSource.data = openShelvingData;
          this.paginateOpenShelving(false);
        },err=>{
           this.helperService.showSnackbar(err.error.message,false,true);
          });
      }
    }).catch(err => {
      console.error("Delete Openshelving Failed", err);
    });
  }

  /** EDIT a open shelving **/
  onEditOpenShelving(userObj) {
    this.editMode = true;
    this.openCreateOpenShelving(userObj);
  }

  /** Set Params */
  setDfaultOpenShelvingParam(){
    this.paginate = this.actRout.snapshot.data['params'];
    let reqParams = this.commonSrv.createParam(this.paginate);
      this.router.navigate([],{queryParams : reqParams})
      this.dataSource.data = this.actRout.snapshot.data['open-shelving'].body;
      this.totalOs= this.actRout.snapshot.data['open-shelving'].headers.get('X-Total-Count');
  }

   /** Paginate OpenShelving */
   paginateOpenShelving(setPage = true){
    if(setPage) this.paginate.page = 0;
    let reqParams = this.commonSrv.createParam(this.paginate);
    this.router.navigate([],{queryParams:reqParams});
    this.storageSrv.getAllOpenShelvingsByLocation(this.helperService.getLocation(),reqParams).subscribe(data=>{
      this.dataSource.data = data.body;
      this.totalOs = data.headers.get('X-Total-Count');
    })
   }

  /** Onchange Page **/
  onChangePage(event?: PageEvent) {
    this.paginate.size = event.pageSize;
    this.paginate.page = event.pageIndex;
    this.paginateOpenShelving(false);
    return event;
  }

  /** Search Open-Shelving */
  searchOpenShelving(filterValue?:any){
    this.storageSrv.searchOpenShelving(this.helperService.getLocation(),filterValue).subscribe(res=>{
    this.dataSource.data = res.body;
    })
  }
  
  /** Apply Filter */
  applyFilter(filter?:any) {
    if(filter.length>2) this.searchOpenShelving(filter);
    if(filter.length==0) this.paginateOpenShelving();
  }
  /**Sorting */
  sortData(event: Sort) {
    this.paginate.sort = event.active + ',' + event.direction;
    this.paginateOpenShelving();    
  }


}
