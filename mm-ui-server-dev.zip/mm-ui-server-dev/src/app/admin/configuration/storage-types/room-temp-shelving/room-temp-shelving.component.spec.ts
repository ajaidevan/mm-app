import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RoomTempShelvingComponent } from './room-temp-shelving.component';

describe('RoomTempShelvingComponent', () => {
  let component: RoomTempShelvingComponent;
  let fixture: ComponentFixture<RoomTempShelvingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RoomTempShelvingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RoomTempShelvingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
