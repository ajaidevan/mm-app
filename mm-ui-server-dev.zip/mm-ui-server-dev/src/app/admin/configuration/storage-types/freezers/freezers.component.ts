import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatSort, MatDialog, MatTableDataSource, MatDialogConfig, PageEvent,Sort } from '@angular/material';
import { StorageService } from '../../../services/storage.service';
import { CreateFreezerComponent } from './create-freezer/create-freezer.component';
import { ValidatorService } from 'app/services/validator.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { HelperService } from 'app/services/helper.service';
import { StorageModel } from 'app/models/storage.model';
import { CommonApiService } from 'app/services/common-api.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-freezers',
  templateUrl: './freezers.component.html',
  styleUrls: ['./freezers.component.scss']
})
export class FreezersComponent implements OnInit {

  public displayedColumns: string[] = ['name', 'roomName', 'serialNo', 'type', 'statustype', 'opeSetPoint', 'action'];
  public dataSource = new MatTableDataSource();
  public editMode: boolean = false;
  public viewMode: boolean = true;
  public data: any;
  public selectedInfo: Array<StorageModel> = [];
  public type: any;
  public paginate: any = {};
  public totalFreezer: number;
  public pageEvent: PageEvent;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(private dialog: MatDialog, private storageSrv: StorageService, private validatorService: ValidatorService, private spinnerService: Ng4LoadingSpinnerService,
    private helperService: HelperService, private commonSrv: CommonApiService, private actRoute: ActivatedRoute, private router: Router) { }

  ngOnInit() {
    this.setDefaultFrezeerParam();
    this.storageSrv.currentFreezer.subscribe(data => {
      if (this.editMode) {
        this.paginateFreezer(false);
        this.editMode = false;
      } else {
        this.paginateFreezer(false);
      }
    });
  }

  receivedViewMode($event) {
    this.viewMode = $event;
    this.selectedInfo.splice(0, 1);
  }

  gotoFreezer(data) {
    this.viewMode = false;
    data.type = 'freezer';
    this.selectedInfo.push(data);
  }

  /** open CREATE freezer **/
  openCreateFreezer(newData?): void {
    if (newData) {
      this.storageSrv.setSharedFreezer(newData);
    } else {
      this.storageSrv.setSharedFreezer("");
    }
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    let dialogRef = this.dialog.open(CreateFreezerComponent, dialogConfig);
  }


  /** DELETE a freezer **/
  onDeleteFreezer(freezer, index) {
    this.validatorService.userValidator('delete').then(res => {
      if (res.val) {
        delete res.val;
        this.storageSrv.deleteFreezer(freezer,res).subscribe(data => {
          let freezerData = this.dataSource.data;
          freezerData.splice(Number(index), 1);
          this.dataSource.data = freezerData;
          this.paginateFreezer(false);
        },err=>{
            this.helperService.showSnackbar(err.error.message,false,true)});
      }
    }).catch(err => {
      console.error("Delete Freezer Failed", err);
    });
  }

  /** EDIT a freezer **/
  onEditFreezer(userObj) {
    this.editMode = true;
    this.openCreateFreezer(userObj);
  }

  /** Set Params */
  setDefaultFrezeerParam() {
    this.paginate = this.actRoute.snapshot.data['params'];
    let reqParams = this.commonSrv.createParam(this.paginate);
    this.router.navigate([], { queryParams: reqParams })
    this.dataSource.data = this.actRoute.snapshot.data['freezers'].body;
    this.totalFreezer = this.actRoute.snapshot.data['freezers'].headers.get('X-Total-Count');
  }

  /** Paginate Freezer */
  paginateFreezer(setPage = true) {
    if (setPage) this.paginate.page = 0;
    let reqParams = this.commonSrv.createParam(this.paginate);
    this.router.navigate([], { queryParams: reqParams });
    this.storageSrv.getAllFreezersByLocId(this.helperService.getLocation(), reqParams).subscribe(data => {
      this.dataSource.data = data.body;
      this.totalFreezer = data.headers.get('X-Total-Count');
    })
  }

  /** Onchange Page **/
  onChangePage(event?: PageEvent) {
    this.paginate.size = event.pageSize;
    this.paginate.page = event.pageIndex;
    this.paginateFreezer(false);
    return event;
  }

  /** Search Freezer **/
  search(filterValue: any) {
    this.storageSrv.searchFreezer(this.helperService.getLocation(), filterValue).subscribe(res => {
      this.dataSource.data = res.body;
    })
  }

  /** Apply Filter **/
  applyFilter(filter?: string) {
    if (filter.length > 0) {
      this.search(filter)
    }
    if (filter.length == 0) this.paginateFreezer();
  }

  /*Sorting*/
  sortData(event: Sort) {
    this.paginate.sort = event.active + ',' + event.direction;
    this.paginateFreezer();    
  }
}
