import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material';
import { FormGroup, FormControl, Validators, FormGroupDirective, NgForm } from '@angular/forms';
import { ErrorStateMatcher } from '@angular/material/core';
import { HelperService } from 'app/services/helper.service';
import { StorageService } from '../../../../services/storage.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { RoomService } from 'app/admin/services/room.service';
import{DataService} from 'app/services/data.service';
import { ValidatorService } from 'app/services/validator.service';

export class MyErrorStateMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = form && form.submitted;
    return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
  }
}
@Component({
  selector: 'app-create-freezer',
  templateUrl: './create-freezer.component.html',
  styleUrls: ['./create-freezer.component.scss']
})
export class CreateFreezerComponent implements OnInit {

  public freezerTypes: any[] = [ 'Ultra-Low Upright','Ultra-Low Chest', 'LN2','Freezer Upright','Freezer Chest','Walk In'];
  public statusTypes: any[] = ['N/A', 'Quarantine', 'Release', 'Reject'];
  public fetchedRooms :any ;
  public freezerDiagForm = new FormGroup({
    id: new FormControl(''),
    name: new FormControl('', Validators.required),
    roomName: new FormControl('', Validators.required),
    serialNo: new FormControl('', Validators.required),
    freezerType: new FormControl([], Validators.required),
    opSetPoint: new FormControl('', Validators.required),
    statusType:new FormControl('',Validators.required),
    locationId:new FormControl(this.helper.getLocation()),
    row:new FormControl('',Validators.required),
  });

  public matcher = new MyErrorStateMatcher();
  public editMode: boolean = false;
  public clicked=false;
  public fetchedRoomRows:any;
  public roomRowData:any = {};
  public paginateRows: any = {};
  public fetchedRowsLength:number;
  public paginateElements:number;
  public roomId:any;
  constructor(private dialogRef: MatDialogRef<CreateFreezerComponent>,
    private helper: HelperService,private validatorService:ValidatorService,
    private storageSrv: StorageService,private roomSrv :RoomService,private dataService:DataService,
    private spinnerService: Ng4LoadingSpinnerService) { }

  ngOnInit() {
    this.storageSrv.sharedFreezer.distinctUntilChanged().subscribe(data => {
      if (data) {
        this.freezerDiagForm.patchValue(data);
        this.freezerDiagForm.get('roomName').patchValue(data.roomName);
        this.editMode = true;
        this.getAllRowsByRoom(data.roomId,data.roomRowId);
      }
    });
    this.roomSrv.getAllRooms(this.helper.getLocation(),{}).subscribe(res=> this.fetchedRooms = res.body);
  }

  /** DESTROY editmode **/
  ngOnDestroy() {
    this.editMode = false;
  }


  /** CREATE a freezer **/
  create() {
    this.validatorService.userValidator(this.editMode?'update':'create').then(res => {
      if(res.val) {
        this.clicked=false;
        delete res.val;
        let freezerObj = this.freezerDiagForm.value;
        freezerObj['locationId']=this.helper.getLocation();
        freezerObj['roomId'] = this.roomRowData.room.id;
        freezerObj['roomName'] = this.roomRowData.room.name;
        freezerObj['roomRowName'] = this.roomRowData.row.seqId;
        freezerObj['roomRowId'] = this.roomRowData.row.id;
        if (this.editMode) {
          if (this.freezerDiagForm.valid) {
            this.storageSrv.updateFreezer(freezerObj,res).subscribe(data => {
              this.helper.showSnackbar('Successfully Updated Freezer !');
              this.dialogRef.close(this.freezerDiagForm.value);
              this.storageSrv.sendCurrentFreezer(data);
            })
          }
        } else {
          if (this.freezerDiagForm.valid) {
            delete freezerObj["id"];
            this.storageSrv.addFreezer(freezerObj,res).subscribe(data => {
              this.helper.showSnackbar('Successfully Created Freezer!');
              this.dialogRef.close(this.freezerDiagForm.value);
              this.storageSrv.sendCurrentFreezer(data);
            },err=>{
              this.helper.showSnackbar('Freezer Already Exists!');
            })
          }
        }
      }
    })
  }
   getAllRowsByRoom(roomId,rowId?){
    this.spinnerService.show();
    this.freezerDiagForm.controls['row'].reset();
    this.paginateAllRows(roomId,rowId);
    this.storageSrv.getAllRoomRowsByRoom(roomId).subscribe(res=>{
      if(res.body.length > 0) {
      } 
    })
     this.findRoomById(roomId);
   }

  /** CLOSE mat dialog **/
  close() {
    this.dialogRef.close(null);
  }
  findRoomById(id){
    this.roomSrv.getAllRooms(this.helper.getLocation(),{}).subscribe(res=> {
      this.fetchedRooms = res.body;
      if(this.fetchedRooms && this.fetchedRooms.length > 0)
      this.roomRowData.room = this.fetchedRooms.find(room => room.id === id);
    });
  }
  
  findRowById(id){
    this.roomRowData.row = this.fetchedRoomRows.find(row => row.id === id);
    if(this.editMode){
      if(id){
        this.freezerDiagForm.get('row').patchValue(this.roomRowData.row.seqId)
    }}
  }

  paginateAllRows(roomId,rowId?) {
    this.spinnerService.show();
    this.paginateRows.page = 0;
    this.paginateRows.size = 10;
    this.paginateRows.sort = "creationAt,DESC";
    this.roomId = roomId;
    this.storageSrv.getAllRoomRowsByRoom(roomId,this.paginateRows).subscribe(
      data => {
       if(data.body.length > 0) {
        this.fetchedRoomRows = data.body;
        this.fetchedRowsLength= data.headers.get('X-Total-Count');
        this.paginateElements = 10;
        this.spinnerService.hide();
       if(this.editMode)this.findRowById(rowId);
      }
      if(data.body.length === 0) this.fetchedRoomRows = ['There is No Row available in this room'];
      }, err => {
        this.helper.showSnackbar('Failed To Fetch Companies !', false, true);
        this.spinnerService.hide();
      }
    )
  }

  loadMoreCompanies() {
    this.paginateRows.size = this.paginateRows.size + 10;
    this.storageSrv.getAllRoomRowsByRoom(this.roomId,this.paginateRows).subscribe(
      data => {
        this.spinnerService.show();
        this.fetchedRoomRows = data.body;
        this.fetchedRowsLength= data.headers.get('X-Total-Count');
        if(this.fetchedRowsLength > this.paginateElements) this.paginateElements = this.paginateElements + 10;
        this.spinnerService.hide();
      }, err => {
        this.spinnerService.hide();
      }
    )
    return false;
  }
}
