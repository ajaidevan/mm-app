import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material';
import { Validators, FormBuilder } from '@angular/forms';
import { HelperService } from '../../../../services/helper.service'
import { RoomService } from '../../../services/room.service';
import{DataService} from'app/services/data.service';
import { ValidatorService } from '../../../../services/validator.service';

@Component({
  selector: 'app-create-room',
  templateUrl: './create-room.component.html',
  styleUrls: ['./create-room.component.scss']
})
export class CreateRoomComponent implements OnInit {

  public locationValue: string = this.helper.getLocation();
  public location= this.locationValue.split("-").length>1 ? this.locationValue.split("-").splice(1):this.locationValue;
  public roomTypes = ['N/A', 'Quarantine', 'Release', 'Reject'];
  public companies :any;
  public roomDiagForm = this.formBuilder.group({
    id:this.formBuilder.control(''),
    name: this.formBuilder.control('', Validators.required),
    type: this.formBuilder.control('', Validators.required),
    locationId: this.formBuilder.control(this.location, Validators.required),
  });
  public editMode: boolean = false;
  public clicked=false;
  constructor(
    private dialogRef: MatDialogRef<CreateRoomComponent>, private helper: HelperService,private validatorService:ValidatorService,
    private formBuilder: FormBuilder, private roomService: RoomService,private dataservice:DataService,
  ) { }

  ngOnInit() { 
    this.roomService.sharedRoom.distinctUntilChanged().subscribe(data => {
      if (data) {
        this.roomDiagForm.patchValue(data);
        let locationId  = this.roomDiagForm.get('locationId').value;
        locationId = locationId.split("-").length >1 ?  locationId.split("-").splice(1): locationId;
        this.roomDiagForm.get('locationId').patchValue(locationId);
        this.editMode=true;
      }
    });
  }

  ngOnDestroy() {
    this.editMode = false;
  }

  /** CREATE new room **/
  create() {
    this.validatorService.userValidator(this.editMode?'update':'create').then(res => {
    if(res.val) {
    let roomObj = this.roomDiagForm.value; 
    roomObj['locationId']=this.helper.getLocation();
    this.clicked=false;
    if (this.editMode) {
      if (this.roomDiagForm.valid) {      
        this.roomService.updateRoom(roomObj,res).subscribe(data => {
          this.roomService.sendCreatedRoom(data);
          this.helper.showSnackbar('Successfully updated Room !!!');
          this.dialogRef.close(this.roomDiagForm.value);
        })
      }     
    } else {
      if (this.roomDiagForm.valid) {  
        delete roomObj.id;      
        this.roomService.addRoom(roomObj,res).subscribe(data => {
          this.roomService.sendCreatedRoom(data);     
          this.helper.showSnackbar('Successfully created Room!!!');
          this.dialogRef.close(this.roomDiagForm.value);
        })
      }
    }
  }    
  }).catch(err => {
    this.helper.showSnackbar("Error Response :", err);
  });
  }   

  /** CLOSE mat dialog **/
  close() {
    this.dialogRef.close(null);
  }
}