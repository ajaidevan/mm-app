import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatSort, MatDialog, MatTableDataSource, MatDialogConfig, PageEvent,Sort } from '@angular/material';
import { CreateRoomComponent } from './create-room/create-room.component';
import { RoomService } from 'app/admin/services/room.service';
import { HelperService } from 'app/services/helper.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonApiService } from 'app/services/common-api.service';
import { ValidatorService } from 'app/services/validator.service';
import { StorageService } from '../../services/storage.service';
import { StorageModel } from 'app/models/storage.model';
import { RoomModel } from 'app/models/room.model';

 
@Component({
  selector: 'app-rooms',
  templateUrl: './rooms.component.html',
  styleUrls: ['./rooms.component.scss']
})
export class RoomsComponent implements OnInit {

  public displayedColumns: string[] = ['name','type', 'locationId', 'action'];
  public dataSource = new MatTableDataSource();
  public location: string;
  public editMode: boolean = false;
  public paginate: any;
  public totalRooms: number;
  public pageEvent:PageEvent
  public viewMode: boolean = true;
  public data: any;
  public selectedInfo: Array<RoomModel> = [];

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(
    private dialog: MatDialog, private roomService: RoomService, private helper: HelperService,private commonSrv : CommonApiService,
    private spinnerService: Ng4LoadingSpinnerService,private route : ActivatedRoute,private router : Router,private validatorService : ValidatorService,
  ) { }

  ngOnInit() {
    this.setDefaultRoomParams();
    this.roomService.createdCurrentRoom.subscribe(data => {
      let newDataSource = this.dataSource.data;
      if (this.editMode) {
        this.paginateRooms(false)
        this.editMode = false;
      } else {
        newDataSource.push(data);
        this.paginateRooms(false)
        this.dataSource.data = newDataSource;
      }
    });
  }
  

  /** open CREATE New **/
  openCreateRoom(newData?): void {
    if (newData) {
      this.roomService.setSharedRoom(newData);
    }
    else {
      this.roomService.setSharedRoom("");
    }
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    let dialogRef = this.dialog.open(CreateRoomComponent, dialogConfig);
  }

  /** EDIT rooms **/
  onEditRoom(roomObj) {
    this.editMode = true;
    this.openCreateRoom(roomObj);
  }

  /** DELETE rooms **/
  onDeleteRoom(room) {
    this.validatorService.userValidator('delete').then(res=>{
      if(res.val){
        delete res.val;
        this.roomService.deleteRoom(room,res).subscribe(data => {
          let userData = this.dataSource.data;
          for (const index in userData) {
            if (room.id == userData[index]["id"]) {
              userData.splice(Number(index), 1)
              break;
            }
          }
          this.dataSource.data = userData;
          this.paginateRooms(false);
        },err=>{
            this.helper.showSnackbar(err.error.message);
        })
      }      
    })
  }

    /** Set Default Params */
    setDefaultRoomParams() {
      this.paginate = this.route.snapshot.data['params'];
      let reqParams = this.commonSrv.createParam(this.paginate);
      this.router.navigate([], { queryParams : reqParams });
      this.dataSource.data = this.route.snapshot.data['rooms'].body;
      this.totalRooms = this.route.snapshot.data['rooms'].headers.get('X-Total-Count');
    }

  /** Paginate The Rooms **/
  paginateRooms(setPage = true) {
    if (setPage) this.paginate.page = 0;
    let reqParams = this.commonSrv.createParam(this.paginate);
    this.roomService.getAllRooms(this.helper.getLocation(),reqParams).subscribe(data => {
      this.dataSource.data = data.body;
      this.totalRooms = data.headers.get('X-Total-Count');
      this.router.navigate([], { queryParams: reqParams });
    })
  }

  /** Onchange Page **/
  onChangePage(event?: PageEvent) {
    this.paginate.size = event.pageSize;
    this.paginate.page = event.pageIndex;
    this.paginateRooms(false);
    return event;
  }

  searchRoom(filterValue?:any){
    this.roomService.searchRoom(this.helper.getLocation(),filterValue).subscribe(res=>{
      this.dataSource.data = res.body;
    })
  }

  applyFilter(filter?:any){
    if(filter.length > 2){
      this.searchRoom(filter);
    }
    if(filter.length == 0){
      this.paginateRooms();
    }
  }
  /*Sorting*/
  sortData(event: Sort) {
    this.paginate.sort = event.active + ',' + event.direction;
    this.paginateRooms();    
  }
  receivedViewMode($event) {
    this.viewMode = $event;
    this.selectedInfo.splice(0, 1);
  }
  gotoRoomRows(data) {
    this.viewMode = false;
    this.selectedInfo.push(data);
  }

}
