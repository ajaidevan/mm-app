import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'app-view-info',
  templateUrl: './view-info.component.html',
  styleUrls: ['./view-info.component.scss']
})
export class ViewInfoComponent implements OnInit {

  public columnName: String[];
  public selectedData: any;
  public component: any;
  public tableColumns: String[];
  public mode: any;
  public gridSelectedData : any;

  constructor(private dialogRef: MatDialogRef<ViewInfoComponent>, @Inject(MAT_DIALOG_DATA) data) {
    if (data) {
      if(data.selectedValue.cell) this.gridSelectedData = data.selectedValue.cell;
      this.selectedData = data.selectedValue;
      this.mode = data.mode;
      this.component = data.component;
      this.columnName = data.columnName;
      this.tableColumns = data.tableColumns;
    }
  }

  ngOnInit() {
  }

}
