import { Injectable } from '@angular/core';

export interface BadgeItem {
  type: string;
  value: string;
}

export interface ChildrenItems {
  state: string;
  name: string;
  type?: string;
  subchildren?: SuperChildrenItems[];
}
export interface SuperChildrenItems {
  state: string;
  name: string;
  type?: string;
  supersubchildren?: SuperSubChildrenItems[];
}
export interface SuperSubChildrenItems {
  state: string;
  name: string;
  type?: string;
}
export interface Menu {
  state: string;
  name: string;
  type: string;
  icon: string;
  badge?: BadgeItem[];
  children?: ChildrenItems[];
  accessLevel?: string[];
  subLink?:String;
}

const MENUITEMS: Menu[] = [
  {
    state: 'home',
    name: 'Dashboard',
    type: 'link',
    icon: 'explore',
    accessLevel: ["Admin", "role_client_admin", "role_super_admin"]
  },
  {
    state: 'receipt',
    name: 'Receiving',
    type: 'link',
    icon: 'get_app',
    accessLevel: ["Technician", "QA"]
  },
  {
    state: 'receipt',
    name: 'QA Approval',
    type: 'subLink',
    subLink:'qa-receipt',
    icon: 'graphic_eq',
    accessLevel: ["QA"]
  }, {
    state: 'inventory-management',
    name: 'Inventory Management',
    type: 'sub',
    icon: 'storage',
    children: [
      { state: 'add-item', name: 'Add Item' },
      { state: 'move-item', name: 'Move Item' },
      { state: 'inventory-verification', name: 'Inventory Verification' },
      { state: 'material-count', name: 'Material Count' }
    ],
    accessLevel: ["Technician","QA"]
  }, {
    state: 'explore-inventory',
    name: 'Explore Inventory',
    type: 'link',
    icon: 'remove_red_eye',
    accessLevel: ["Technician","Reviewer",'QA']
  },
  // {
  //   state: 'admin',
  //   name: 'Search',
  //   type: 'sub',
  //   icon: 'search',
  //   children: [
  //     { state: 'adv-search', name: 'Advanced Search' }
  //   ],
  //   accessLevel: ["Technician", "Reviewer",]
  // },
  {
    state: 'reports',
    name: 'Reports',
    type: 'sub',
    icon: 'library_books',
    children: [
      { state: 'chain-of-custody', name: 'Chain of Custody' },
    ],
    accessLevel: ["Technician", "Reviewer"]
  },
  {
    state: 'admin',
    name: 'Labels',
    type: 'sub',
    icon: 'video_label',
    children: [
      { state: 'labels', name: 'View Label Specification' }
    ],
    accessLevel: ["QA", "Technician"]
  },
  {
    state: 'admin',
    name: 'Admin',
    type: 'sub',
    icon: 'face',
    children: [
      { state: 'user-management', name: 'User Management' },
      { state: 'reviewer-management',name:'Reviewer Management'},
      {
        state: 'configuration', name: 'Configuration', type: 'sub',
        subchildren: [
          { state: 'room', name: 'Room' },
          {
            state: 'storage-types', name: 'Storage Types', type: 'sub',
            supersubchildren: [
              { state: 'freezers', name: 'Freezers' },
              { state: 'refrigerator', name: 'Refrigerator' },
              { state: 'incubators', name: 'Incubators' },
              { state: 'room-temp-shelving', name: 'Open Shelving / RT' },
            ]
          }
        ],
      },
      {
        state: 'archive', name: 'Archived Records', type: 'link'
      },
    ],
    accessLevel: ["Admin"]
  },
  {
    state: 'super',
    name: 'Super Admin',
    type: 'sub',
    icon: 'security',
    children: [
      { state: 'client', name: 'Client Management' },
      { state: 'location', name: 'Location Management' },
      { state: 'user', name: 'User Management' },
      { state: 'reviewer', name: 'Reviewer Management' },
    ],
    accessLevel: ["role_super_admin"]
  },
  {
    state: 'client',
    name: 'Client Admin',
    type: 'sub',
    icon: 'security',
    children: [
      { state: 'location', name: 'Location Management' },
      { state: 'user', name: 'User Management' },
      { state: 'reviewer', name: 'Reviewer Management' },
    ],
    accessLevel: ["role_client_admin"]
  },  {
    state: 'audit-log',
    name: 'Audit Log',
    type: 'link',
    icon: 'get_app',
    accessLevel: ["Admin","role_client_admin"]
  },
  {
    state: 'adv-search',
    name: 'Advanced Search',
    type: 'link',
    icon: 'search',
    accessLevel: ["Admin","role_super_admin","Reviewer"]
  },
  // {
  //   state: 'error',
  //   name: 'ERROR',
  //   type: 'sub',
  //   icon: 'error_outline',
  //   children: [
  //     {state: '404', name: '404'},
  //     {state: '503', name: '503'}
  //   ]
  // }
];

@Injectable()
export class MenuItems {
  getAll(): Menu[] {
    return MENUITEMS;
  }

  add(menu: Menu) {
    MENUITEMS.push(menu);
  }
}
