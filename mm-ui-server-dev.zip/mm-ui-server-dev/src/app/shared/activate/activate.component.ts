import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from 'app/super-admin/services/user.service';
import { FormBuilder, Validators } from '@angular/forms';
import { AuthService } from 'app/services/auth.service';
import { HelperService } from 'app/services/helper.service';
import { PatternValidationService } from 'app/services/front-validation/pattern-validation.service';
import { FrontValidationService } from 'app/services/front-validation/front-validation.service';

@Component({
  selector: 'app-activate',
  templateUrl: './activate.component.html',
  styleUrls: ['./activate.component.scss']
})
export class ActivateComponent implements OnInit {

  public hide: boolean[] = [true, true, true];
  public activateUserForm: any;
  public email: string;
  public password: string;
  public token: string;
  public pwdValidationMsg:any;

  constructor(private route: ActivatedRoute, private router: Router,
    private activatedRoute: ActivatedRoute,private patternSrv:PatternValidationService,
    private userService: UserService, private fb: FormBuilder,
    private authSrv: AuthService,private frontValSrv:FrontValidationService,
    private helper: HelperService,
  ) {
    /** FORGOT PASSWORD form **/
    this.activateUserForm = this.fb.group({
      newPassword: ['', [Validators.required, Validators.minLength(8), Validators.pattern(this.patternSrv.pwdPattern)]],
      reTypeNewPassword: ['', [Validators.required, Validators.minLength(8)]]
    });
    this.activatedRoute.queryParams.subscribe(params => {
      this.token = params['token'];
    });
  }

  ngOnInit() {
    this.pwdValidationMsg = this.frontValSrv.validationMsg;
  }

  /** reset PASSWORD **/
  resetPassword() {
    let newPassword = this.activateUserForm.controls['newPassword'].value;
    let data = { token: this.token, newPassword: newPassword }
    this.authSrv.forgotPasswordFinish(data).subscribe(
      res => {
        if (res.status) {
          this.helper.showSnackbar('Password has been changed successfully please proceed with login');
          this.router.navigateByUrl('/authentication/login');
        }
      },
      err => {
        if(err.status=='401'){
          this.helper.showSnackbar('User is Already activated please proceed with login')
        }
        else{
          this.helper.showSnackbar("Something Went Wrong Please Try Again Later",false,true);
        }
      }
    );
  }

  /** ACTIVATE  user **/
  activateUser() {
    this.userService.activateUser(this.token).subscribe(data => {
    })
  }

}
