import { Component, OnInit, ViewChild, Inject } from '@angular/core';
import { DamageBoxComponent } from '../damage-box/damage-box.component';
import { MatTableDataSource, MatPaginator, MatSort, MatDialogRef, MAT_DIALOG_DATA, PageEvent } from '@angular/material';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ReceiptService } from 'app/receipt/receipt.service';

@Component({
  selector: 'app-damage-tool-tip',
  templateUrl: './damage-tool-tip.component.html',
  styleUrls: ['./damage-tool-tip.component.scss']
})
export class DamageToolTipComponent implements OnInit {
  public displayedColumns: string[] = ['caseNo', 'field','damageCount'];
  public countSource: string[] = ['data', 'data2'];
  public fieldsArr: any[] = [];
  // public dataSource: MatTableDataSource<FieldData>;
  public totalCase:any;
  public dataSource:any;
  public boxNumber: any;
  public qtyType:any;
  public paginate:any = { page:0,size:10};

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(private activateRoute: ActivatedRoute, private dialogRef: MatDialogRef<DamageBoxComponent>, @Inject(MAT_DIALOG_DATA) data,
    private router: Router, private fb: FormBuilder,private receiptService:ReceiptService) {
    let fields: FieldData[] = [];

    let count = Number(data.receivableData.iCases.length);
    fields = (count) ? Array.apply(null, Array(count)).map(function (_, i) {
      let damageRow = {items:[],count:0};
      damageRow  = data.receivableData.iCases[i];
      let damageCount = 0;
         if (data.receivableData.iCases.length > 0) {
          for(let damageData of damageRow.items){
            if(damageData.damageId !==null){
                  damageCount ++;
               }
            }
          }else{
            damageRow.count = 0;
          }
          return { caseNo:i, field: damageRow.count, damageCount: damageCount };
          
    }) : 0;
    this.fieldsArr = fields;
    this.totalCase = fields.length;
    this.dataSource = new MatTableDataSource(fields);
    if(data.receivableData.quantityType){
      this.qtyType = data.receivableData.quantityType;
    };

    if(data){
      let count = 0;
      this.eachDamageForm.get('itemNo').patchValue(data.receivableData.items.length);
      if(data.receivableData.items){
        for(let damageCount of data.receivableData.items){
          if(damageCount.damageId != null){
            count ++;
          }
        }
        this.eachDamageForm.get('damageCount').patchValue(count);
      }
    }
  }
  
  public eachDamageForm=this.fb.group({
    itemNo:[''],
    damageCount:['']
  })
  ngOnInit() { }

  // Set the paginator and sort after the view init.
  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }
  dismiss(){
    this.dialogRef.close(null);
  }

  save(){
    if(this.qtyType == 'case') this.receiptService.sendTotalDamageCases(this.fieldsArr);
    if(this.qtyType == 'each') this.receiptService.sendTotalDamageCases(this.eachDamageForm.value);
    this.dismiss();
  }

  /** On Change Page **/
  onChangePage(event?:PageEvent) {
    this.paginate.size = event.pageSize;
    this.paginate.page = event.pageIndex;
    return event;
  }
}

export interface FieldData {
  id: string;
  caseNo:string;
  field: string;
  damageCount:string;
}