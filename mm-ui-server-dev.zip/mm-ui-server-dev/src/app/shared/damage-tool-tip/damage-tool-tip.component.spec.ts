import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DamageToolTipComponent } from './damage-tool-tip.component';

describe('DamageToolTipComponent', () => {
  let component: DamageToolTipComponent;
  let fixture: ComponentFixture<DamageToolTipComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DamageToolTipComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DamageToolTipComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
