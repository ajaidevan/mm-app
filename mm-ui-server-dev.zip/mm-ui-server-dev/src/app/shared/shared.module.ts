import { NgModule } from '@angular/core';

import { MenuItems } from './menu-items/menu-items';
import { HorizontalMenuItems } from './menu-items/horizontal-menu-items';
import { AccordionAnchorDirective, AccordionLinkDirective, AccordionDirective } from './accordion';
import { ToggleFullscreenDirective } from './fullscreen/toggle-fullscreen.directive';
import { ActivateComponent } from 'app/shared/activate/activate.component';
import { UserService } from 'app/super-admin/services/user.service';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FlexLayoutModule } from '@angular/flex-layout';
import { HelperService } from 'app/services/helper.service';
import { SupportComponent } from './components/support/support.component';
import { CommonMaterialModule } from './common.module';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { ConfirmDialogComponent } from './confirm-dialog/confirm-dialog.component';
import { EllipsisPipe } from './pipes/ellipsis.pipe';
import { IdListPipe } from './pipes/id-list.pipe';
import { ArrayChangePipe } from './pipes/array-change.pipe';
import { InventoryExplorerComponent } from './explorer/inventory-explorer/inventory-explorer.component';
import { ExplorerSlotComponent } from './explorer/explorer-slot/explorer-slot.component';
import { SlotPaginatorComponent } from './explorer/slot-paginator/slot-paginator.component';
import { MaterialDetailDialog } from './explorer/material-detail-dialog/material-detail-dialog.component';
import { VerifyDialog } from './explorer/verify-dialog/verify-dialog.component';
import { DamageBoxComponent } from './damage-box/damage-box.component';
import { DamageToolTipComponent } from './damage-tool-tip/damage-tool-tip.component';
import { QuickSearchComponent } from './components/quick-search/quick-search.component';
import { ExplorerService } from 'app/inventory-management/services/explorer.service';
import { MatTableModule } from '@angular/material';

@NgModule({
  declarations: [
    EllipsisPipe,
    IdListPipe,
    ArrayChangePipe,
    AccordionAnchorDirective,
    AccordionLinkDirective,
    AccordionDirective,
    ToggleFullscreenDirective,
    ActivateComponent,
    SupportComponent,
    ChangePasswordComponent,
    ConfirmDialogComponent,
    InventoryExplorerComponent,
    ExplorerSlotComponent,
    QuickSearchComponent,
    SlotPaginatorComponent,
    MaterialDetailDialog,
    VerifyDialog,
    DamageBoxComponent,
    DamageToolTipComponent,
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    FlexLayoutModule,
    CommonMaterialModule,
    MatTableModule
  ],
  exports: [
    EllipsisPipe,
    IdListPipe,
    ArrayChangePipe,
    InventoryExplorerComponent,
    ExplorerSlotComponent,
    QuickSearchComponent,
    SlotPaginatorComponent,
    MaterialDetailDialog,
    AccordionAnchorDirective,
    AccordionLinkDirective,
    AccordionDirective,
    ToggleFullscreenDirective,
    DamageToolTipComponent,
    DamageBoxComponent
  ],
  entryComponents: [SupportComponent, ConfirmDialogComponent, MaterialDetailDialog, VerifyDialog, DamageBoxComponent, DamageToolTipComponent],
  providers: [MenuItems, HorizontalMenuItems, UserService, HelperService, ExplorerService]
})
export class SharedModule { }
