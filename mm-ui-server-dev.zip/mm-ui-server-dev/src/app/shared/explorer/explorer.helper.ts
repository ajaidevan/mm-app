import { EXPCONFIG, ExplorerConfig } from "./explorer.config";
import { TransferType, TransferObject } from "../../inventory-management/services/transfer.service";
import { InventoryCase, InventoryItem, InventoryGrid } from "./material.helper";

export type ExplorerItemType = 'HOME' |
  'ROOM' |

  // CATEGORIES
  'OS-STORAGE TYPE' | 'FREEZER-STORAGE TYPE' | 'INCUBATOR-STORAGE TYPE' | 'REFRIGERATOR-STORAGE TYPE' |'ROW-STORAGE TYPE'|
    // ROWS 
    'ROWS'|
  // OPEN-STORAGE
  'OPEN-STORAGE' |
   'OS-RACK' | 'OS-SHELF' | 'OS-SECTION' |

  // FREEZER
  'FREEZER' |
  'FREEZER-ROW' | 'FREEZER-RACK' | 'FREEZER-SHELF' | 'FREEZER-ROW-RACK' |
  'FREEZER-RACK-SHELF' | 'FREEZER-SECTION' | 'FREEZER-SLOT' |

  // INCUBATOR
  'INCUBATOR' |
  'INCUBATOR-ROW' | 'INCUBATOR-SHELF' |
  'INCUBATOR-RACK' | 'INCUBATOR-RACK-SHELF' | 'INCUBATOR-SECTION' |


  // REFRIGERATOR
  'REFRIGERATOR' |
  'REFRIGERATOR-SHELF' | 'REFRIGERATOR-ROW' | 'REFRIGERATOR-RACK' |
  'REFRIGERATOR-SLOT' |
  'REFRIGERATOR-RACK-SHELF' | 'REFRIGERATOR-SECTION';

/**
 * This is a generic class for all storage items displayed in the `InventoryExplorerComponent`.
 * Supported types can be found in the `ExplorerItemType`
 */
export class ExplorerItem {
  type: ExplorerItemType;
  entity: any; //original object received from API

  // Meta data (auto generated on instantiation)
  config: ExplorerConfig;
  emptySlots: { [type in TransferType]: number };
  isLeafNode: boolean;
  displayItems: boolean;
  displayCases: boolean;
  displayGrids: boolean;

  // UI meta data
  name: string;
  displayType: boolean = true;
  tooltipText: string = "";

  constructor(type: ExplorerItemType, entity?) {
    this.type = type;
    this.entity = entity || {};

    try {
      this.generateUIprops();
      this.config = this.getConfig();
      this.isLeafNode = this.setLeafNode();
      this.displayItems = this.entity.hasOwnProperty('items');
      this.displayCases = this.entity.hasOwnProperty('cases');
      this.displayGrids = this.isLeafNode && this.entity.gridType !== undefined;

      this.entity.cases = Array.isArray(this.entity.cases) ? this.entity.cases.map(i => Object.assign(new InventoryCase(), i)) : [];
      this.entity.items = Array.isArray(this.entity.items) ? this.entity.items.map(i => Object.assign(new InventoryItem(), i)) : [];
      this.entity.grids = Array.isArray(this.entity.grids) ? this.entity.grids.map(i => Object.assign(new InventoryGrid(), i)) : [];

      this.calculateEmptySlots();
    } catch (err) {
      throw err;
    }
  }

  // Config
  private getConfig(): any {
    return EXPCONFIG.find(e => e.type === this.type) || {};
  }

  private calculateEmptySlots() {
    const itemsLength = this.displayItems ? this.entity.items.length : 0;
    const casesLength = this.displayCases ? this.entity.cases.length : 0;
    const gridLength = this.displayGrids ? this.entity.grids.filter(g => g.itemId === null).length : 0;

    const emptyCases = this.config.max ? this.config.max.CASE - casesLength : 0;
    const emptyItems = this.config.max ? this.config.max.ITEM - itemsLength : 0 + gridLength;

    if (emptyCases < 0 || emptyItems < 0) {
      throw `Something wrong happened with calculating empty slots in: ${this.type} `;
    }
    // For GRID, ITEM is used
    this.emptySlots = {
      'CASE': emptyCases,
      'ITEM': emptyItems
    };
  }

  // Meta data
  private generateUIprops() {    
    if (this.type.match(/.*SHELF|ROW|RACK|SLOT|SECTION/)) {
      if(this.entity.seqId)
        this.name = `${this.entity.name}  ${this.entity.seqId}`;
      else
        this.name = this.entity.name;
    } else {
      this.name = this.entity.name;
    }

    this.displayType = !this.type.match(/.*CATEGORY/);

    const type = this.entity.type ||
      this.entity.freezerType ||
      this.entity.refType ||
      this.entity.incType;

    if (type) this.tooltipText += `Type: ${type}\n`;
    if (this.entity.name) this.tooltipText += `Name: ${this.entity.name}\n`;
    if (this.entity.serialNo) this.tooltipText += `Serial #: ${this.entity.serialNo}\n`;
    if (this.entity.seqId) this.tooltipText += `Seq ID: ${this.entity.seqId}\n`;
    if (this.entity.gridType) this.tooltipText += `Grid Type: ${this.entity.gridType}\n`;
    if (this.entity.comment) this.tooltipText += `Comment: ${this.entity.comment}\n`;
  }


  /**
   * LeafSections are handled in a different way in `ExplorerService.getChildren()`.
   * Instead of XHR requesting the children we just return empty array.
   */
  private setLeafNode(): boolean {
    const leafNodes: ExplorerItemType[] = [
      'REFRIGERATOR-SECTION',
      'FREEZER-SECTION',
      'INCUBATOR-SECTION',
      'INCUBATOR-SHELF',
      'OS-SECTION',
      'FREEZER-SLOT',
      'REFRIGERATOR-SLOT',
      'ROWS'
    ];
    return leafNodes.includes(this.type);
  }


  /**
   *
   * Adds the items/cases from the transferObject to their proper location
   * Then calls `this.calculateEmptySlots()` which will make sure we didn't go beyond capacity in config.
   *
   * @param transferObject
   */
  transfer(transferObject: TransferObject) {
    switch (transferObject.type) {
      case 'CASE':
        const cases = transferObject.sourceReceipt ?
          transferObject.sourceReceipt.iCases.map(icase => new InventoryCase().fromICase(icase, transferObject.sourceReceipt.companyId))
          : transferObject.selected;
        this.entity.cases.push(...cases);
        this.entity.cases = this.entity.cases.filter(c => c && c.caseId); // Sanity check
        break;
      case 'ITEM':
        const items = transferObject.sourceReceipt ?
          transferObject.sourceReceipt.items.map(item => new InventoryItem().fromReceiptItem(item, transferObject.sourceReceipt.companyId))
          : transferObject.selected;
        if (this.displayGrids) {
          this.entity.grids.forEach((grid: InventoryGrid) => {
            if (grid.itemId === null && items.length) {
              grid.fromInventory(items.pop() as InventoryItem);
            }
          });
        } else {
          this.entity.items.push(...items);
        }
        break;
    }

    this.calculateEmptySlots();
  }

  removeSelected(transferObject: TransferObject) {
    switch (transferObject.type) {
      case 'CASE':
        this.entity.cases = this.entity.cases.filter(caseObj => !transferObject.selected.find(s => s.id == caseObj.id));
        break;
      case 'ITEM':
        if (this.displayGrids) {
          this.entity.grids.forEach((grid: InventoryGrid) => {
            if (grid.id !== null && transferObject.selected.find(s => s.id == grid.id)) {
              grid.reset();
            }
          });
        } else {
          this.entity.items = this.entity.items.filter(item => !transferObject.selected.find(s => s.id == item.id));
        }
        break;
    }

    this.calculateEmptySlots();
  }

  verify(material: InventoryItem | InventoryCase | InventoryGrid) {
    switch (material._name) {
      case "InventoryCase":
        this.entity.cases = this.entity.cases.map((c) => {
          if (c.id === material.id) c = material;
          return c;
        });
        break;
      case "InventoryGrid":
        this.entity.grids = this.entity.grids.map((c) => {
          if (c.id === material.id) c = material;
          return c;
        });
        break;
      case "InventoryItem":
        this.entity.items = this.entity.items.map((c) => {
          if (c.id === material.id) c = material;
          return c;
        });
        break;

      default:
        throw "Verifying unknown type";
    }
    return this;
  }
}

