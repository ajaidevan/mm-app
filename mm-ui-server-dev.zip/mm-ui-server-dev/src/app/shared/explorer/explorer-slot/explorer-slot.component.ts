import { Component, OnInit, Input, EventEmitter, Output, OnDestroy } from '@angular/core';
import { TransferObject, TransferService } from 'app/inventory-management/services/transfer.service';
import { ExplorerMode } from '../inventory-explorer/inventory-explorer.component';
import { takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { InventoryCase, InventoryItem, InventoryGrid } from '../material.helper';
import { MatDialog } from '@angular/material';
import { MaterialDetailDialog } from '../material-detail-dialog/material-detail-dialog.component';
import { MaterialStoreService } from 'app/inventory-management/services/material-store-service';
import { VerifyDialog } from '../verify-dialog/verify-dialog.component';

export type SlotType = 'ITEM' | 'CASE' | 'GRID' | 'ITEM-COUNT' | 'CASE-COUNT';

const DROP_ZONE = {
  'ITEM': ['ITEM-COUNT', 'GRID'],
  'CASE': ['CASE-COUNT']
};

const ALLOW_PICK = {
  'ITEM': ['ITEM', 'GRID'],
  'CASE': ['CASE']
};

@Component({
  selector: 'app-explorer-slot',
  templateUrl: './explorer-slot.component.html',
  styleUrls: ['./explorer-slot.component.scss']
})
export class ExplorerSlotComponent implements OnInit, OnDestroy {

  @Output() transfer: EventEmitter<any> = new EventEmitter();
  @Output() select: EventEmitter<any> = new EventEmitter();

  @Input() slot: InventoryCase | InventoryItem | InventoryGrid = null;
  @Input() count: number = 0;
  @Input() type: SlotType;
  @Input() explorerMode: ExplorerMode;

  //computed props
  filled: boolean = false;
  canDrop: boolean = false;
  canPick: boolean = false;
  selected: boolean = false;
  notAllowed: boolean = false;
  canOpen: boolean = false;
  public description:any;

  tooltipText = null;
  droppableTooltipText = null;

  detailsText = null;

  private unsubscriber: Subject<any> = new Subject;
  verificationDialog;
  constructor(
    public transferService: TransferService,
    public dialog: MatDialog,
    private materialStoreService: MaterialStoreService) { }

  ngOnInit() {
    this.transferService.transferObject.pipe(
      takeUntil(this.unsubscriber)
    ).subscribe(
      (transferObject: TransferObject) => this._computeStates(transferObject)
    );
    if(this.type=='GRID'||this.type=='ITEM'){
      if(this.slot.id){
       this.materialStoreService
       .getItem(this.slot.id)
       .subscribe((item) => {
        this.description =item.description;
      })
    }
    }

  }

  ngOnDestroy(): void {
    this.unsubscriber.next();
    this.unsubscriber.complete();
  }

  onClick(e: Event) {
    const el = e.target as HTMLElement;
    e.preventDefault();
    e.stopPropagation();
    switch (this.explorerMode) {
      case 'TARGET':
        if (this.canDrop) this.transfer.emit(true);
        break;

      case 'SOURCE':
        if (this.filled) this.select.emit(this.slot);
        break;

      case 'EXPLORE':
        this.openDetailDialog();
        break;

      case 'VERIFY':
        if (el.classList.contains("v-icon")) {
          break;
        } else if (el.classList.contains("verification-btn")) {
          this.openVerificationDialog();
        } else {
          this.openDetailDialog();
        }
        break;
    }

  }


  onHover(e: Event) {

    if (this.explorerMode === 'EXPLORE') return;

    e.preventDefault();
    e.stopImmediatePropagation();

    switch (this.type) {
      case 'CASE':
        this.materialStoreService
          .getCase(this.slot.id)
          .subscribe((caseObj) => {
            this.detailsText =
              `id: ${caseObj.id}\nbarcode: ${caseObj.btext}\ncount: ${caseObj.count}\n\n` +
              `Company Id: ${this.slot.companyId}\nComment: ${this.slot.comment}\nVerified: ${this.slot.verified}`;
          }, () => {
            this.detailsText = "Couldn't find data.";
          });
        break;
      case 'GRID':
      case 'ITEM':
        this.materialStoreService
          .getItem(this.slot.id)
          .subscribe((item) => {
            let labelSize= JSON.parse(item.labelSize);
            this.detailsText =
              Object.keys(item).map(key => {
                if (['id', 'type', 'orderNo',
                  'manufacturer', 'lotNo', 'batchNo', 'catalogNo',
                  'manufactureDate', 'expiryDate'].includes(key)) {
                  return `${key}: ${item[key]}\n`;
                } else {
                  return '';
                }
              }).join('')
              + `\nLabelSize Id:${labelSize.id? labelSize.id:'N/A'}\nLabelSize Height:${labelSize.height ? labelSize.height :'N/A'}\nLabelSize Width:${labelSize.width ? labelSize.width :'N/A'}\nBarcode: ${item.btext}\nCompany Id: ${this.slot.companyId}\nComment: ${this.slot.comment}\nVerified: ${this.slot.verified}`;
            ;
          }, () => {
            this.detailsText = "Couldn't find data.";
          });
        break;

      default:
        throw 'Invalid type on hover';
    }
  }

  private _computeStates(transferObject: TransferObject) {
    this.filled = !!(this.slot && this.slot.id);

    switch (this.explorerMode) {
      case 'SOURCE':
        this.canDrop = false;
        this.canPick = this.filled;
        this.selected = transferObject &&
          transferObject.selected &&
          !!transferObject.selected.find(s => s.id == this.slot.id);
        this.canOpen = false;
        this.notAllowed = transferObject && !ALLOW_PICK[transferObject.type].includes(this.type);
        this.tooltipText = this.notAllowed ? 'You can only transfer either items or cases at one time' : null;
        this.droppableTooltipText = null;
        break;
      case 'TARGET':
        this.canDrop = !this.filled &&
          transferObject &&
          this.count >= transferObject.count &&
          DROP_ZONE[transferObject.type] &&
          DROP_ZONE[transferObject.type].includes(this.type);
        this.canPick = false;
        this.selected = false;
        this.canOpen = false;
        this.notAllowed = transferObject && (this.filled || !this.canDrop);
        this.tooltipText = null;
        this.droppableTooltipText = transferObject ? this.canDrop && !this.filled ?
          `Click here to drop ${this.transferService.transferDescription}`
          : `Can not drop ${this.transferService.transferDescription} here.`
          : "Select suitable material from above!";
        break;
      case 'EXPLORE':
        this.canDrop = false;
        this.canPick = false;
        this.selected = false;
        this.canOpen = true;
        this.notAllowed = false;
        this.tooltipText = this.filled ? "Click to open" : null;
        this.droppableTooltipText = null;
        break;
      case 'VERIFY':
        this.canDrop = false;
        this.canPick = this.slot.verified;
        this.selected = false;
        this.canOpen = true;
        this.notAllowed = this.filled && !this.slot.verified;
        this.tooltipText = null;
        this.droppableTooltipText = null;
        break;
      default:
        throw "Slot explorerMode is not recognized!!";
    }
  }

  openDetailDialog() {
    if (!this.filled) return;
    this.dialog.open(MaterialDetailDialog, {
      disableClose: false,
      width: '450px',
      data: {
        type: this.type,
        id: this.slot.id
      }
    });
  }

  openVerificationDialog() {
    if (!this.filled) return;
    const dialogRef = this.dialog.open(VerifyDialog, {
      disableClose: false,
      width: '450px',
      data: {
        type: this.type,
        slot: this.slot
      }
    });

    dialogRef.afterClosed().pipe(
      takeUntil(this.unsubscriber)
    ).subscribe((slot) => {
      if (!slot) return;
      this.transfer.emit(slot);
    });
  }
}




