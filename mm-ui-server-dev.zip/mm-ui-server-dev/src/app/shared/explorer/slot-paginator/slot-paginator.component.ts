import { Component, OnInit, Input, EventEmitter, Output, OnDestroy, ElementRef } from '@angular/core';
import { ExplorerMode, ExplorerLevel } from '../inventory-explorer/inventory-explorer.component';

import { SlotType } from '../explorer-slot/explorer-slot.component';
import * as $ from 'jquery';
import { InventoryCase, InventoryItem, InventoryGrid } from '../material.helper';

@Component({
  selector: 'app-slot-paginator',
  templateUrl: './slot-paginator.component.html',
  styleUrls: ['./slot-paginator.component.scss']
})
export class SlotPaginatorComponent implements OnInit {

  _currentLevel: ExplorerLevel = null;
  class: string = null;
  slots: Array<number> = [];
  totalRecords: number = 0;
  maxDisplay: number = 0;
  pages: number[] = [];
  activePage: number = 0;
  displayMax: number = 0;
  displayMin: number = 0;

  paginate: boolean = true;

  @Input() explorerMode: ExplorerMode = null;
  @Input() type: SlotType = null;
  @Input() set currentLevel(currentLevel: ExplorerLevel) {
    this._currentLevel = currentLevel;
    this.maxDisplay = this.explorerMode === 'TARGET' ? 5 : 6;
    switch (this.type) {
      case 'ITEM':
        this.slots = currentLevel.current.entity.items;
        this.class = "items";
        break;
      case 'CASE':
        this.slots = currentLevel.current.entity.cases;
        this.class = "cases";
        break;


      default:
        throw 'Slot type not recognized in paginator';
    }

    this.totalRecords = this.slots.length;
    this.pages = this.getArrayOfPage(this.getPageCount());
    this.activePage = 1;
    this.calculateMinMax();
  }

  @Output() transfer: EventEmitter<any> = new EventEmitter();
  @Output() select: EventEmitter<{ slot: Array<InventoryCase | InventoryItem | InventoryGrid>, type: SlotType; }> = new EventEmitter();

  constructor(private elRef: ElementRef) { }

  ngOnInit() { }

  private getPageCount(): number {
    let totalPage: number = 0;

    if (this.totalRecords > 0 && this.maxDisplay > 0) {
      const pageCount = this.totalRecords / this.maxDisplay;
      const roundedPageCount = Math.floor(pageCount);

      totalPage = roundedPageCount < pageCount ? roundedPageCount + 1 : roundedPageCount;
    }

    return totalPage;
  }

  private getArrayOfPage(pageCount: number): number[] {
    let pageArray: number[] = [];

    if (pageCount > 0) {
      for (var i = 1; i <= pageCount; i++) {
        pageArray.push(i);
      }
    }

    return pageArray;
  }

  onClickPage(pageNumber: number) {
    if (pageNumber < 1 ||
      pageNumber == this.activePage ||
      pageNumber > this.pages.length) return;

    $(this.elRef.nativeElement).find(".slot:not(.count)").fadeOut(350);

    setTimeout(() => {
      this.activePage = pageNumber;
      this.calculateMinMax();
    }, 350);
  };

  private calculateMinMax() {
    this.displayMax = this.paginate ? this.activePage * this.maxDisplay : Infinity;
    this.displayMin = this.paginate ? this.displayMax - this.maxDisplay : -1;
  }

  togglePagination() {
    this.paginate = !this.paginate;
    this.activePage = 1;
    this.calculateMinMax();
  }
}




