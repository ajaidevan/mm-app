import { Component, Inject } from '@angular/core';

import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

import { InventoryCase, InventoryItem, InventoryGrid } from '../material.helper';
import { SlotType } from '../explorer-slot/explorer-slot.component';

@Component({
  selector: 'app-verify-dialog',
  templateUrl: './verify-dialog.component.html',
  styleUrls: ['./verify-dialog.component.scss']
})
export class VerifyDialog {

  _slot: InventoryCase | InventoryItem | InventoryGrid;

  constructor(
    public dialogRef: MatDialogRef<VerifyDialog>,
    @Inject(MAT_DIALOG_DATA) public data: { slot: InventoryCase | InventoryItem | InventoryGrid; type: SlotType; }) {
    this._slot = data.slot.clone();
    setTimeout(() => {
      this.change();
    }, 400);
  }

  change() {
    this._slot.verified = !this._slot.verified;
    this._slot.comment = this._slot.verified ? "" : this._slot.comment;
  }

  setComment(e) {
    setTimeout(() => {
      this._slot.comment = e.target.value;
    });
  }

  close(save) {
    this.dialogRef.close(save ? this._slot : false);
  }
}




