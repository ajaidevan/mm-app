import { ReceiptCase, ReceiptItem } from "app/models/qa-receipt.model";

abstract class InventoryMaterial {
  _name: string = "InventoryMaterial";
  companyId: string;
  verified: boolean = false;
  comment: string = "";
  position?;

  clone() {

    switch (this._name) {
      case "InventoryCase":
        return Object.assign(Object.assign(new InventoryCase(), this));

      case "InventoryItem":
        return Object.assign(Object.assign(new InventoryItem(), this));

      case "InventoryGrid":
        return Object.assign(Object.assign(new InventoryGrid(), this));

      default:
        throw "couldn't clone";
    }
  }
}

export class InventoryCase extends InventoryMaterial {
  _name = "InventoryCase";
  caseId: number;

  get id() {
    return this.caseId;
  }

  fromICase(iCase: ReceiptCase, companyId: string) {
    this.caseId = iCase.id;
    this.companyId = companyId;

    return this;
  }
}

export class InventoryItem extends InventoryMaterial {
   _name = "InventoryItem";
  itemId: number;
  get id() {
    return this.itemId;
  }

  fromReceiptItem(item: ReceiptItem, companyId: string) {
    this.itemId = item.id;
    this.companyId = companyId;
    
    return this;
  }
}

export class InventoryGrid extends InventoryItem {
  _name = "InventoryGrid";
  position: number;

  fromInventory(item: InventoryItem) {
    this.itemId = item.id;
    this.companyId = item.companyId;
    this.verified = item.verified;
    this.comment = item.comment;
    return this;
  }

  reset() {
    this.itemId = null;
    this.companyId = null;
    this.verified = false;
    this.comment = "";
  }
}


