import { ExplorerItemType } from "./explorer.helper";
import { TransferType } from "../../inventory-management/services/transfer.service";

export type ExplorerConfig = {
  type: ExplorerItemType;
  max: { [type in TransferType]: number };
};

export const EXPCONFIG: ExplorerConfig[] = [
  // INCUBATOR
  {
    type: 'INCUBATOR-SHELF',
    max: { 'ITEM': Infinity, 'CASE': Infinity }
  },
  {
    type: 'INCUBATOR-RACK-SHELF',
    max: { 'ITEM': Infinity, 'CASE': Infinity }
  },
  {
    type: 'INCUBATOR-SECTION',
    max: { 'ITEM': 100, 'CASE': 100 }
  },

  // OPEN-SHELF
  {
    type: 'OS-SHELF',
    max: { 'ITEM': Infinity, 'CASE': Infinity }
  },
  {
    type: 'OS-SECTION',
    max: { 'ITEM': 100, 'CASE': 100 }
  },

  // REFRIGERATOR
  {
    type: 'REFRIGERATOR',
    max: { 'ITEM': 100, 'CASE': 100 }
  },
  {
    type: 'REFRIGERATOR-SHELF',
    max: { 'ITEM': Infinity, 'CASE': Infinity }
  },
  {
    type: 'REFRIGERATOR-RACK-SHELF',
    max: { 'ITEM': Infinity, 'CASE': Infinity }
  },
  {
    type: 'REFRIGERATOR-SECTION',
    max: { 'ITEM': 100, 'CASE': 100 }
  },

  //FREEZER
  {
    type: 'FREEZER',
    max: { 'ITEM': 100, 'CASE': 100 }
  },
  {
    type: 'FREEZER-SHELF',
    max: { 'ITEM': Infinity, 'CASE': Infinity }
  },
  {
    type: 'FREEZER-RACK-SHELF',
    max: { 'ITEM': Infinity, 'CASE': Infinity }
  },
  {
    type: 'FREEZER-SECTION',
    max: { 'ITEM': 100, 'CASE': 100 }
  },
  {
    type:'ROWS',
    max:{'ITEM':100,'CASE':100}
  }
 
];
