import { Component, Inject } from '@angular/core';

import { MatDialogRef, MAT_DIALOG_DATA, MatSnackBar } from '@angular/material';
import { SlotType } from '../explorer-slot/explorer-slot.component';
import { MaterialStoreService } from 'app/inventory-management/services/material-store-service';

@Component({
  selector: 'app-material-detail-dialog',
  templateUrl: './material-detail-dialog.component.html',
  styleUrls: ['./material-detail-dialog.component.scss']
})
export class MaterialDetailDialog {

  material: any;
  loading: boolean = true;

  constructor(
    private _snackBar: MatSnackBar,
    private materialStoreService: MaterialStoreService,
    public dialogRef: MatDialogRef<MaterialDetailDialog>,
    @Inject(MAT_DIALOG_DATA) public data: { type: SlotType, id: number; }) {

    switch (data.type) {
      case 'CASE':
        this.materialStoreService
          .getCase(data.id)
          .subscribe((caseObj) => {
            this.material = caseObj;
            this.loading = false;
          });
        break;
      case 'GRID':
      case 'ITEM':
        this.materialStoreService
          .getItem(data.id)
          .subscribe((item) => {
            this.material = item;
            this.loading = false;
          });
        break;

      default:
        throw 'MaterialDetailDialog: Invalid type';
    }
  }

  close() {
    this.dialogRef.close(confirm);
  }

  copyToClipboard(str) {
    const el = document.createElement('textarea');
    el.value = str;
    document.body.appendChild(el);
    el.select();
    document.execCommand('copy');
    document.body.removeChild(el);

    this._snackBar.open("Text copied to clipboard!", "", {
      duration: 500,
    });
  };

  display = {
    "batchNo": "Batch Number",
    "btext": "Barcode",
    "catalogNo": "Catalog No",
    "createdAt": "Created At",
    "createdBy": "Created By",
    "expiryDate": "Expiry Date",
    "lotNo": "Lot Number",
    "manufactureDate": "Manufacture Date",
    "orderNo": "Order Number",
    "type": "Type",

    "caseNo": "Case Number",
    "count": "Count",
    "Received Count": "Received Count",
  };
}




