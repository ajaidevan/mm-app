import { Component, OnInit, Input, EventEmitter, Output, ElementRef, OnDestroy, ChangeDetectorRef, ViewChild } from '@angular/core';
import { HelperService } from 'app/services/helper.service';
import { ExplorerItem } from 'app/shared/explorer/explorer.helper';
import { Observable, Subject } from 'rxjs';
import { ExplorerService } from 'app/inventory-management/services/explorer.service';
import { MatDialog, MatTableDataSource, PageEvent, Sort, MatPaginator, MatSort } from '@angular/material';
import { ConfirmDialogComponent } from '../../confirm-dialog/confirm-dialog.component';
import { TransferService, TransferObject, TransferType, TransferStatus } from 'app/inventory-management/services/transfer.service';
import { TitleCasePipe } from '@angular/common';
import { takeUntil } from 'rxjs/operators';
import { InventoryCase, InventoryItem, InventoryGrid } from '../material.helper';
import { Company } from 'app/models/company.model';
import { ValidatorService } from 'app/services/validator.service';
import { QuickSearchService, BreadcrumbsEvent } from 'app/services/quick-search.service';
import { MaterialDetailDialog } from '../material-detail-dialog/material-detail-dialog.component';
import { CommonApiService } from 'app/services/common-api.service';
import { Router } from '@angular/router';
import { trigger, state, style, transition, animate } from '@angular/animations';
import { QAReceipt } from 'app/models/qa-receipt.model';

/**
 * Inventory Explorer Component
 *
 * Main idea is that we have a queue (`breadcrumbs`) with all of the parent `ExplorerLevel`s.
 *
 */

export type ExplorerMode =
  'EXPLORE' | // No interaction
  'SOURCE' | // Items are picked up
  'TARGET' |  // Items are placed
  'VERIFY';  // Items are verified

type ExplorerState =
  'IDLE' |      // Nothing happening
  'LOADING' |   // Request in progress (Navigation or placing items)
  'SELECTING' | // When selecting items to be moved, only works with mode = 'SOURCE'
  'ERROR';      // error

export type ExplorerLevel = {
  current: ExplorerItem;
  children?: ExplorerItem[];
};

@Component({
  selector: 'app-inventory-explorer',
  templateUrl: './inventory-explorer.component.html',
  styleUrls: ['./inventory-explorer.component.scss'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class InventoryExplorerComponent implements OnInit, OnDestroy {

  @Input() mode: ExplorerMode = null;


  _selectedCompany: Company;
  @Input() set selectedCompany(selectedCompany: Company) {
    this._selectedCompany = selectedCompany;
    this.ngOnInit();
  }

  public displayedColumns: string[] = ['receiptNo', 'containerType','status','description','client', 'quantityType', 'createdAt','noOfCases','noOfItems', 'expand'];
  public childDisplayedColumns:any[] = ['id','location'];
  public breadcrumbs: ExplorerLevel[] = []; // A queue of items navigated
  public state: ExplorerState = 'LOADING';
  public dataSource: MatTableDataSource<any>;
  public transferObject: TransferObject = null;
  public pageEvent: PageEvent;
  public pageChildEvent: PageEvent;
  public pageSizeOptions: number[] = [5, 10, 15];
  public paginate:any = {};
  public totalReceivable:number;
  // level computed props
  currentLevel: ExplorerLevel = null;
  emptyView: boolean = false;
  public loading:boolean = false;
  selectType: TransferType;
  selected: Array<InventoryCase | InventoryItem | InventoryGrid> = [];

  selectingTooltip = "Unselect all before navigating to another view";
  STATUS = {
    RECEIPT: [
      { status: 'QUARANTINE', value: 'QUARANTINE_STORAGE' },
      { status: 'RELEASE', value: 'RELEASE_STORAGE' },
      { status: 'N/A', value: 'NA_STORAGE' }, 
      { status: 'REJECT', value: 'REJECTED_STORAGE' }, 
    ],
  };
  searchItem= new MatTableDataSource();
  private unsubscriber: Subject<any> = new Subject;
  private $el;
  expandedElement: QAReceipt | null;
  totalCount:number;
  public paginateChild: any = { page: 0, size: 5 };
  @ViewChild('innerPaginator') paginator: MatPaginator;
  @ViewChild('innerSort') sort: MatSort
  constructor(
    private explorerService: ExplorerService,
    private helper: HelperService,
    private elRef: ElementRef,
    private titleCasePipe: TitleCasePipe,
    private quickSearchService: QuickSearchService,
    public transferService: TransferService,
    private validatorService: ValidatorService,
    public dialog: MatDialog,
    private commonSrv:CommonApiService,
    private router:Router,
    private cdr:ChangeDetectorRef) {
    this.$el = $(this.elRef.nativeElement);
  }

  ngOnInit() {
    this.setDefaultParam();
    // this.showClientName();
    this.breadcrumbs = [];
    this._pushLevel(new ExplorerItem('HOME'), this.explorerService.getAllRoomsByLocation(this.helper.getLocation()));

    // In Explore mode, subscribe to Quick Search breadcrumbs
    if (this.mode == 'EXPLORE') {
      this.quickSearchService.loading.pipe(
        takeUntil(this.unsubscriber)
      ).subscribe((loading) => {
        this.state = loading ? "LOADING" : "IDLE";
      });
      this.quickSearchService.newBreadcrumbs.pipe(
        takeUntil(this.unsubscriber)
      ).subscribe((breadcrumbsEvent: BreadcrumbsEvent) => {
        if (breadcrumbsEvent) {
          setTimeout(() => {
            this.breadcrumbs = breadcrumbsEvent.breadcrumbs;
            this.updateProps();
            this.dialog.open(MaterialDetailDialog, {
              disableClose: false,
              width: '450px',
              data: {
                type: breadcrumbsEvent.result.type,
                id: breadcrumbsEvent.result.type == "CASE" ? breadcrumbsEvent.result.obj.caseId : breadcrumbsEvent.result.obj.itemId
              }
            });
          }, 200);
        }
      });
      return; //
    }

    this.transferService.transferObject.pipe(
      takeUntil(this.unsubscriber)
    ).subscribe((transferObject: TransferObject) => {
      if (this.mode === 'TARGET') {
        this.transferObject = transferObject;
      } else if (this.mode === 'SOURCE') {
        if (transferObject === null) {
          this.clearSelection(false);
        }
      }
    });

    this.transferService.status.pipe(
      takeUntil(this.unsubscriber)
    ).subscribe((status: TransferStatus) => {
      if (status === 'COMPLETE') {
        //refresh current view
        this.onBreadcrumbsClick(this.breadcrumbs[this.breadcrumbs.length - 1], this.breadcrumbs.length);
        this.currentLevel = Object.assign({}, this.currentLevel); // force rerender of paginator
      }
    });
  }

  ngOnDestroy(): void {
    this.unsubscriber.next();
    this.unsubscriber.complete();
  }

  // Navigation functions
  onBreadcrumbsClick(level: ExplorerLevel, i: number) {
    if (this.state === 'SELECTING') {
      return; //disable clicking when selecting
    }

    if (level.current.type === 'HOME') {
      this.breadcrumbs = [];
      this._pushLevel(new ExplorerItem('HOME'), this.explorerService.getAllRoomsByLocation(this.helper.getLocation()));
    } else {

      this.$el.find(`#sub-${i}`).slideToggle("fast");
      this.$el.find(`#br-${i}`).toggleClass("open");
      this.$el.find(`.playground, p.subtitle`).toggleClass("fade");

      this.$el.find(`.sub-menu:not(#sub-${i})`).hide();
      this.$el.find(`.br:not(#br-${i})`).removeClass("open");
    }
  }

  onSiblingClick(i, j) {
    this.state = "LOADING";
    setTimeout(() => {
      this.breadcrumbs = this.breadcrumbs.slice(0, i);
      this.onStorageClick(this.breadcrumbs[this.breadcrumbs.length - 1].children[j]);
      this.state = "IDLE";
    }, 150);

  }

  onStorageClick(explorerItem: ExplorerItem) {
    if (this.state === 'SELECTING') {
      return; //disable clicking when selecting
    }
    this.$el.find(`.sub-menu`).slideUp("fast");
    this.$el.find(`.br`).removeClass("open");
    this.$el.find(`.playground, p.subtitle`).removeClass("fade");

    this._pushLevel(explorerItem, this.explorerService.getChildren(explorerItem, this._selectedCompany));
    this.elRef.nativeElement.scrollIntoView({ behavior: "smooth" });
  }

  private _pushLevel(explorerItem: ExplorerItem, childrenRequest?: Observable<ExplorerItem[]>) {
    this.state = 'LOADING';
    childrenRequest.subscribe(children => {
      this.breadcrumbs.push({
        current: explorerItem,
        children: children.reduce((acc, i) => acc.concat(i), []) || []
      });
      this.state = 'IDLE';
    }, (err) => {
      this.state = 'ERROR';
      throw err;
    }, () => this.updateProps()
    );
  }

  // Update computed props
  private updateProps() {
    this.currentLevel = this.breadcrumbs[this.breadcrumbs.length - 1];

    this.emptyView = this.currentLevel &&
      (this.currentLevel.children.length < 1 &&
        !this.currentLevel.current.displayCases &&
        !this.currentLevel.current.displayGrids &&
        !this.currentLevel.current.displayItems);
  }

  // TARGET TRANSFER FUNCTIONS
  scrollToEmpty() {
    document.querySelector(".target .flash").scrollIntoView({ behavior: 'smooth' });
  }

  transfer(event) {
    if (this.mode === 'VERIFY') this.verify(event);
    else this.openConfirmDialog();
  }

  private verify(material: InventoryItem | InventoryCase | InventoryGrid) {
    this.validatorService.userValidator(material.verified ? "verify" : "unverify").then(res => {
      if (!res.val) {
        return;
      }

      this.state = 'LOADING';
      this.currentLevel.current.verify(material);
      this.transferService._getStorageRequest(this.currentLevel.current, res.comment).subscribe((entity) => {
        this.currentLevel.current = new ExplorerItem(this.currentLevel.current.type, entity);
        this.currentLevel = Object.assign({}, this.currentLevel); // force rerender of paginator
        this.state = 'IDLE';
      }, (err => {
        this.helper.showSnackbar("Error Response :", err.message);
        this.state = 'IDLE';
        //refresh current view
        this.onBreadcrumbsClick(this.breadcrumbs[this.breadcrumbs.length - 1], this.breadcrumbs.length);
        this.currentLevel = Object.assign({}, this.currentLevel); // force rerender of paginator

      }));
    }).catch(err => {
      this.helper.showSnackbar("Error Response :", err.message);
    });
  }

  private openConfirmDialog() {
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      disableClose: true,
      width: '450px',
      data: {
        title: `Are you sure you want to move these ${this.transferObject.type.toLowerCase()}s?`,
        message: `This will transfer ${this.transferService.transferDescription} to ${this.titleCasePipe.transform(this.currentLevel.current.type)} "${this.currentLevel.current.name}"`
      }
    });
    dialogRef.afterClosed().pipe(takeUntil(this.unsubscriber)).subscribe((c) => this._confirmTransfer(c));
  }

  private _confirmTransfer(confirm) {
    if (confirm) {
      this.validatorService.userValidator("move").then(res => {
        if (!res.val) {
          this.transferService.cancelTransfer();
          return;
        }
        this.elRef.nativeElement.scrollIntoView({ behavior: "smooth" });
        this.state = 'LOADING';
        this.transferObject.targetStorage = this.currentLevel.current;
        this.transferObject.comment = res.comment;
        this.transferService.completeTransfer(this.transferObject)
          .subscribe((response: [any, any]) => {
            this.currentLevel.current = new ExplorerItem(this.currentLevel.current.type, response[1]);
            this.state = 'IDLE';
            this.$el.find(`.playground`).removeClass("fade");
          }, (err => {
            this.helper.showSnackbar("Error Response :", err.message);
            this.state = 'IDLE';
            this.$el.find(`.playground`).removeClass("fade");
            //refresh current view
            this.onBreadcrumbsClick(this.breadcrumbs[this.breadcrumbs.length - 1], this.breadcrumbs.length);
            this.currentLevel = Object.assign({}, this.currentLevel); // force rerender of paginator

          }));
      }).catch(err => {
        this.helper.showSnackbar("Error Response :", err.message);
      });
    }
  }

  // SOURCE SELECTION FUNCTIONS
  select(event: { slot: InventoryCase | InventoryItem | InventoryGrid, type: TransferType; }) {
    switch (this.mode) {
      case 'SOURCE':
        this.sourceSelection(event);
        break;

      case 'VERIFY':
        // this.currentLevel.current.toggleVeri
        break;
      default:
        break;
    }
  }

  private sourceSelection(event: { slot: InventoryCase | InventoryItem | InventoryGrid; type: TransferType; }) {
    if (this.selected.length === 0)
      this.selectType = event.type;
    if (this.selectType === event.type) {
      if (this.selected.find(s => event.slot.id == s.id)) {
        //unselect
        this.selected = this.selected.filter(i => i.id != event.slot.id);
      }
      else {
        this.selected.push(event.slot.clone());
      }
    }
    if (this.selected.length < 1) {
      this.clearSelection();
    }
    else {
      this.state = 'SELECTING';
      this.transferSelected();
    }
  }

  clearSelection(sendToService: boolean = true) {
    this.selected = [];
    this.selectType = null;
    this.state = 'IDLE';
    if (sendToService) this.transferService.cancelTransfer();
  }

  selectAll() {
    switch (this.selectType) {
      case 'CASE':
        this.selected = this.currentLevel.current.entity.cases;
        break;
      case 'ITEM':
        this.selected = this.currentLevel.current.displayGrids ?
          this.currentLevel.current.entity.grids.filter(g => g.itemId)
          : this.currentLevel.current.entity.items;
      default:
        break;
    }
    this.transferSelected();
  }

  transferSelected(scrollToTarget = false) {

    this.transferService.initTransfer({
      type: this.selectType,
      sourceStorage: this.currentLevel.current,
      count: this.selected.length,
      selected: this.selected
    }, scrollToTarget);

  }

    /** Set Default Params */
  setDefaultParam() {
    this.paginate = {
      page: 0,
      size: 5,
      sort: 'createdAt,DESC'
    }
    this.getAllReceivables(false,this.paginate)
  }

  getAllReceivables(setPage = true,paginate){
    if (setPage) paginate.page = 0;
    let reqParams = this.commonSrv.createParam(this.paginate);
    this.router.navigate([], { queryParams: reqParams });
    this.explorerService.getReceipts(reqParams).subscribe(res=>{
      this.dataSource = new MatTableDataSource(res.body);
      this.totalReceivable  = res.headers.get('X-Total-Count');
    })
  }

  showReceiptStatus(status){
    let statusOb = this.STATUS.RECEIPT.find(ele => ele.value == status);
    return statusOb.status;
  }

  onChangePage(event?: PageEvent) {
    this.paginate.size = event.pageSize;
    this.paginate.page = event.pageIndex;
    this.getAllReceivables(false,this.paginate);
    return event;
  }

  showExpandedDetails(row){
    this.loading = true;
    switch(row.quantityType) {
      case 'each':
        this.getSearchItems(row);
        break;
      case 'case':
        this.getSearchCases(row);
        break;  
    }
  }

  getSearchItems(row){
    let items = [];
    if(row.items.length != 0) {
      row.items.forEach(ele => {
        this.explorerService.getSearchItems(ele.id).subscribe(res=>{
          if(res) {
            res.body.itemId = ele.id;
            items.push(res.body)
            if(items.length == row.items.length) {
              this.searchItem = new MatTableDataSource(items);
              this.searchItem.paginator = this.paginator; 
              this.totalCount = items.length;
              this.loading = false; 
            }
          }
        })
      })
    }
  }

  getSearchCases(row){
    let cases = [];
    if(row.iCases.length != 0) {
      row.iCases.forEach(ele => {
        this.explorerService.getSearchICase(ele.id).subscribe(res=>{
          if(res) {
            res.body.itemId = ele.id;
            cases.push(res.body);
            if(cases.length == row.iCases.length) {
              this.searchItem = new MatTableDataSource(cases);
              this.searchItem.paginator = this.paginator;
              this.totalCount = cases.length;
              this.loading = false;
            }
          }
        })
      })
    }
  }

  ngAfterViewInit() {
    this.searchItem.paginator = this.paginator;
  }

  /*Sorting*/
  sortData(event: Sort, tableStatus) {
    this.paginate.sort = event.active + ',' + event.direction;
    this.getAllReceivables(false,this.paginate);
  }
 
  /** On Change Page **/
  onChildChangePage(event?: PageEvent) {
    this.paginateChild.size = event.pageSize;
    this.paginateChild.page = event.pageIndex;
    this.searchItem.paginator = this.paginator;
    return event;
  }
   /** SEARCH Receivable */
   search(filter) {
      this.explorerService.searchReceivable(filter).subscribe(res => {
        this.dataSource = new MatTableDataSource(res.body);
      })
    }
    /** Filter Value */  
  applyFilter(filter?:any){
    if(filter.length>2){
     this.search(filter);    
    }
    if(filter.length==0){
      this.getAllReceivables(false,this.paginate);
    }
   }
}
