import { Injectable, Pipe, PipeTransform } from "@angular/core";

@Pipe({
  name: "idList"
})

@Injectable()
export class IdListPipe implements PipeTransform {
  transform(value: Array<any> = [], seperator: string = ", "): string {
    return value.map(i => i.id).join(seperator);
  }
}
