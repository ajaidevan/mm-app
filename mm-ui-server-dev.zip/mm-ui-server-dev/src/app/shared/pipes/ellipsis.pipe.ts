import { Injectable, Pipe, PipeTransform } from "@angular/core";

@Pipe({
  name: "ellipsis"
})

@Injectable()
export class EllipsisPipe implements PipeTransform {
  transform(value: string = "", args: number): string {
    let limit = typeof (args) === "number" && args > 0 ? args : 10;
    let trail = "...";

    return value.length > limit ? value.substring(0, limit) + trail : value;
  }
}
