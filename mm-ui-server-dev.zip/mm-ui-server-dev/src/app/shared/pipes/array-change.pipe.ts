import { Pipe, PipeTransform, IterableDiffers, IterableDiffer } from '@angular/core';

@Pipe({
  name: 'arrayChange',
  pure: false
})
export class ArrayChangePipe implements PipeTransform {
  private differ: IterableDiffer<any>;

  constructor(iDiff: IterableDiffers) {
    this.differ = iDiff.find([]).create();
  }

  transform(value: any[]): any[] {
    if (this.differ.diff(value)) {
      return [...value];
    }
    return value;
  }
}
