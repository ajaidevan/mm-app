import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { DamageBoxComponent } from './damage-box.component';

describe('DamageBoxComponent', () => {
  let component: DamageBoxComponent;
  let fixture: ComponentFixture<DamageBoxComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DamageBoxComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DamageBoxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
