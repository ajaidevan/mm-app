import { Component, OnInit, ViewChild, Inject } from '@angular/core';
import { MatPaginator, MatTableDataSource, MatSort, MatDialogRef, MAT_DIALOG_DATA, PageEvent } from '@angular/material';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-damage-box',
  templateUrl: './damage-box.component.html',
  styleUrls: ['./damage-box.component.scss']
})
export class DamageBoxComponent implements OnInit {

  public displayedColumns: string[] = ['caseNo', 'damageCount'];
  public countSource: string[] = ['data', 'data2'];
  public fieldsArr: any[] = [];
  public dataSource: MatTableDataSource<FieldData>;
  public boxNumber: any;
  public paginate:any = { page:0,size:10};
  public totalCase:number;
  public dailogData:any;
  public pageEvent:PageEvent;


  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(private dialogRef: MatDialogRef<DamageBoxComponent>,
    @Inject(MAT_DIALOG_DATA) dailogData, private fb: FormBuilder) {
    let fields: FieldData[] = [];
    let count = Number(dailogData.damageQty);
    fields = (count) ? Array.apply(null, Array(count)).map(function (_, i) {
      return { id: i, caseNo: '', damageCount: ""};
    }) : 0;
    this.fieldsArr = fields;
    this.totalCase = fields.length;
    this.dataSource = new MatTableDataSource(fields);

  }
  
  ngOnInit() { }

  submit() {
    this.dismiss();
  }

  // Set the paginator and sort after the view init.
  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }
  
  dismiss(){
    this.dialogRef.close(null);
  }

  /** On Change Page **/
  onChangePage(event?:PageEvent) {
    this.paginate.size = event.pageSize;
    this.paginate.page = event.pageIndex;
    return event;
  }
}

export interface FieldData {
  id: string;
  field: string;
  damageCount: string;
  boxNumber: string;
  orderNumber: string;
}
