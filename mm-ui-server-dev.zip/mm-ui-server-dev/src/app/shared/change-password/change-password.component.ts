import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, Validators, FormControl, FormGroupDirective, NgForm } from '@angular/forms';
import { MatSnackBar, ErrorStateMatcher } from '@angular/material';
import { AuthService } from 'app/services/auth.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { HelperService } from 'app/services/helper.service';
import { FrontValidationService } from 'app/services/front-validation/front-validation.service';
import { PatternValidationService } from 'app/services/front-validation/pattern-validation.service';
import { ValidatorService } from '../../services/validator.service';

/** Error when the parent is invalid */
class CrossFieldErrorMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    return (control.dirty || control.touched) && form.invalid;
  }
}


@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class ChangePasswordComponent implements OnInit {

  public hide: boolean[] = [true, true, true];
  public changedPasswordForm: any;
  public durationInSeconds: number = 5;
  public response: string;
  public error: string;
  public resetResponse: string;
  public changePwdVal: any;
  public errorMatcher = new CrossFieldErrorMatcher();

  /** UPDATE password **/
  update() {
    
    this.router.navigate(['/home'])
  }

  constructor(
    private router: Router,private patternSrv:PatternValidationService,
    private fb: FormBuilder,private validatorService : ValidatorService,
    private snackBar: MatSnackBar,
    private authSrv: AuthService, private helper: HelperService,
    private spinnerService: Ng4LoadingSpinnerService,
    private frontValSrv: FrontValidationService
  ) {
    this.changedPasswordForm = this.fb.group({
      currentPassword: ['', [Validators.required, Validators.minLength(8)]],
      newPassword: ['', [Validators.required, Validators.minLength(8), Validators.pattern(this.patternSrv.pwdPattern)]],
      reTypeNewPassword: ['', [Validators.required, Validators.minLength(8)]]
    })
  }

  ngOnInit() {
    /** Validation Message **/
    this.changePwdVal = this.frontValSrv.validationMsg;
    if(this.helper.decryptValue(sessionStorage.getItem('mm-msg'))){
      this.resetResponse = this.helper.decryptValue(sessionStorage.getItem('mm-msg').trim());
    }
  }
  
  /** navigate to HOME **/
  navigate() {
    this.router.navigate(['/home']);
  }

  reloginUser(){
    this.authSrv.logOutUser();
  }

  /** CHANGE password **/
  changePassword() {
    this.validatorService.userValidator('update').then(res => {
      if(res.val){
      delete res.val;
      this.authSrv.changePassword(this.changedPasswordForm.value,res).subscribe(
        res => {
          if (res.status) {
            this.response = res.message;
            this.helper.showSnackbar('Password Successfully Changed');
            this.changedPasswordForm.reset();
          } else {
            this.response = res.message;
          }
          }, err => {
            this.error = err.error.message;
          }
        ) 
      }
    }).catch(err => {
      this.helper.showSnackbar("Error Response :", err);
    });
  }
}
