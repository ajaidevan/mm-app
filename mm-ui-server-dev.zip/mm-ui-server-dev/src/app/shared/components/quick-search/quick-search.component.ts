import { Component, OnInit } from '@angular/core';
import { QuickSearchService, ResultObject } from 'app/services/quick-search.service';
import { AuthService } from 'app/services/auth.service';
import { HelperService } from 'app/services/helper.service';

type SearchType = "barcode" | "id";

@Component({
  selector: 'app-quick-search',
  templateUrl: './quick-search.component.html',
  styleUrls: ['./quick-search.component.scss']
})
export class QuickSearchComponent implements OnInit {


  public quickSearchType: SearchType = "id";
  currentRole: any;
  currentUserLevel: string[];
  loadingItem: boolean = false;
  loadingCase: boolean = false;

  result: ResultObject = null;

  constructor(public quickSearchService: QuickSearchService,
    private authSrv: AuthService,
    private helperSrv: HelperService) {

  }

  ngOnInit() {
    this.authSrv.currentUser.subscribe(userScope => {
      this.currentRole = userScope.replace(/,*$/, "");
      let splitedScope: string[] = userScope.split(",");
      this.currentUserLevel = splitedScope;
    });
  }


  search(data) {
    if (data.length < 1) {
      this._reset(false);
      return;
    }
    switch (this.quickSearchType) {
      case "id":
        this.serachById(data);
        break;
      case "barcode":
        this.serachByBarcode(data);
        break;
      default:
        throw new Error("Search Type not recognized!!");
    }
  }

  serachById(data) {
    this._reset(true);
    this.quickSearchService.quickSearchItemById(data).subscribe(res => {
      this.loadingItem = false;
      this._handleItem(res.body, data);
    }, () => this.loadingItem = false);
    this.quickSearchService.quickSearchCaseById(data).subscribe(res => {
      this.loadingCase = false;
      this._handleCase(res.body, data);
    }, () => this.loadingCase = false);
  }

  serachByBarcode(data) {
    // this.quickSearchService.quickSearchItemByBarcode(data);
    // this.quickSearchService.quickSearchCaseByBarcode(data);
  }

  _handleItem(body, searchId) {
    if (!body) return;

    let parentKey = Object.keys(body)[0];
    this.result = {
      type: "ITEM",
      obj: body[parentKey].items ?
        body[parentKey].items.find(i => i.itemId == searchId) :
        body[parentKey].grids.find(i => i.itemId == searchId),
      parent: body[parentKey],
      parentKey
    };
  }

  _handleCase(body, searchId) {
    if (!body) return;
    let parentKey = Object.keys(body)[0];
    this.result = {
      type: "CASE",
      obj: body[parentKey].cases.find(i => i.caseId == searchId),
      parent: body[parentKey],
      parentKey
    };
  }

  view() {
    this.quickSearchService.goToResult(this.result);
    this._reset(false);
  }


  _reset(loading: boolean) {
    this.loadingCase = loading;
    this.loadingItem = loading;
    this.result = null;
  }
}
