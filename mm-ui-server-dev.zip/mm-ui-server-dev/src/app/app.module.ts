import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule, Http } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';
import { PERFECT_SCROLLBAR_CONFIG } from 'ngx-perfect-scrollbar';
import { PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';
import { TranslateModule, TranslateLoader, TranslateStaticLoader } from 'ng2-translate/ng2-translate';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CommonMaterialModule } from './shared/common.module';

import { MatSidenavModule } from '@angular/material/sidenav';
import { MatInputModule } from '@angular/material/input';
import { MatIconModule } from '@angular/material/icon';
import { MatListModule } from '@angular/material/list';
import { MatMenuModule } from '@angular/material/menu';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatTabsModule } from '@angular/material/tabs';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatSelectModule } from '@angular/material/select';
import { MatCardModule } from '@angular/material/card';

import { AppComponent } from './app.component';
import { AdminLayoutComponent } from './layouts/admin/admin-layout.component';
import { AuthLayoutComponent } from './layouts/auth/auth-layout.component';
import { SharedModule } from './shared/shared.module';

import { CookieService } from 'ngx-cookie-service';
import { CommonApiService } from './services/common-api.service';
import { AuthService } from './services/auth.service';
import { HelperService } from './services/helper.service';

import { Ng4LoadingSpinnerModule } from 'ng4-loading-spinner';
import { AuthGuard } from './services/guard/auth.guard';
import { LoggedInGuard } from './services/guard/loggedIn.guard';
import { RoleGuard } from './services/guard/role.guard';

import { UserIdleModule } from 'angular-user-idle';
import { ValidatorService } from './services/validator.service';
import { ViewInfoComponent } from './shared/view-info/view-info.component';
import { AuditService } from './audit-log/audit.service';
import { DataService } from './services/data.service';
import { MAT_RIPPLE_GLOBAL_OPTIONS, RippleGlobalOptions } from '@angular/material/core';
import { AppRoutes } from './app.routing';
import { QuickSearchService } from './services/quick-search.service';
import { UserRetrievalService } from './services/user.retrieval.service';
import { UserReActivationLinkService} from './services/user-reacivatelink.service';

export function createTranslateLoader(http: Http) {
  return new TranslateStaticLoader(http, './assets/i18n', '.json');
}

const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
  suppressScrollX: true
};
const globalRippleConfig: RippleGlobalOptions = {
  disabled: true
};

@NgModule({
  declarations: [
    AppComponent,
    AdminLayoutComponent,
    AuthLayoutComponent,
    ViewInfoComponent,
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    SharedModule,
    RouterModule.forRoot(AppRoutes),
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    HttpClientModule,
    MatSidenavModule,
    MatInputModule,
    MatIconModule,
    MatListModule,
    MatMenuModule,
    MatToolbarModule,
    MatTabsModule,
    MatCheckboxModule,
    MatProgressBarModule,
    MatSelectModule,
    MatCardModule,
    CommonMaterialModule,
    TranslateModule.forRoot({
      provide: TranslateLoader,
      useFactory: (createTranslateLoader),
      deps: [Http]
    }),
    Ng4LoadingSpinnerModule.forRoot(),
    FlexLayoutModule,
    UserIdleModule.forRoot({ idle: 3600, timeout: 300, ping: 120 }),

  ],
  providers: [CommonApiService, AuthService, CookieService, HelperService, AuthGuard, LoggedInGuard, RoleGuard, ValidatorService, DataService,
    QuickSearchService, UserRetrievalService,UserReActivationLinkService,{
    provide: PERFECT_SCROLLBAR_CONFIG,
    useValue: DEFAULT_PERFECT_SCROLLBAR_CONFIG,

  },
    {
      provide: MAT_RIPPLE_GLOBAL_OPTIONS,
      useValue: globalRippleConfig
    }

  ],
  entryComponents: [ViewInfoComponent],
  bootstrap: [AppComponent]
})
export class AppModule { }
