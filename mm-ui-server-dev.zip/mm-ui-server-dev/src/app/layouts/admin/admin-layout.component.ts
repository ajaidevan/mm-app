import { Component, OnInit, OnDestroy, ViewChild, HostListener } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { MenuItems } from '../../shared/menu-items/menu-items';
import { HorizontalMenuItems } from '../../shared/menu-items/horizontal-menu-items';
import { Subscription } from 'rxjs';
import { filter } from 'rxjs/operators';
import { MatDialog, MatDialogConfig } from '@angular/material';
import { TranslateService } from 'ng2-translate/ng2-translate';
import PerfectScrollbar from 'perfect-scrollbar';
import { PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';
import { AuthService } from 'app/services/auth.service';
import { SupportComponent } from '../../shared/components/support/support.component';
import { HelperService } from 'app/services/helper.service';
import { UserIdleService } from 'angular-user-idle';
import { DataService } from 'app/services/data.service';
import { ViewInfoComponent } from 'app/shared/view-info/view-info.component';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { environment } from '../../../environments/environment';


@Component({
  selector: 'app-layout',
  templateUrl: './admin-layout.component.html'
})
export class AdminLayoutComponent implements OnInit, OnDestroy {

  private _router: Subscription;
  public version: string;
  public today: number = Date.now();
  public url: string;
  public showSettings = false;
  public dark: boolean;
  public boxed: boolean;
  public collapseSidebar: boolean;
  public compactSidebar: boolean;
  public sidebarBg: boolean = true;
  public currentLang: string = 'en';
  public layoutDir: string = 'ltr';
  public currentUserLevel: string[];
  public location: string;
  public loginedInUser: string;
  public loginRole: any;
  public menuLayout: any = 'vertical-menu';
  public selectedSidebarImage: any = 'bg-1';
  public selectedSidebarColor: any = 'sidebar-blue';
  public selectedHeaderColor: any = 'header-default';
  public collapsedClass: any = 'side-panel-opened';
  public disableRipple = true;
  public currentRole: any;
  public selectedRow: any;
  public locationAddress: any;
  @ViewChild('sidemenu') sidemenu;

  public config: PerfectScrollbarConfigInterface = {};
  public displayedColumns = ['firstName', 'lastName', 'username', 'tenantName', 'address', 'locationsRoles'];

  constructor(private router: Router, public menuItems: MenuItems, public horizontalMenuItems: HorizontalMenuItems, private spinnerService: Ng4LoadingSpinnerService,
    public translate: TranslateService, private authSrv: AuthService, private dataService: DataService,
    private dialog: MatDialog, private helperSrv: HelperService, private userIdle: UserIdleService) {
    const browserLang: string = translate.getBrowserLang();
    translate.use(browserLang.match(/en|fr/) ? browserLang : 'en');
    this.loginRole = this.helperSrv.decryptValue(sessionStorage.getItem('mm-rl'));
    this.version = environment.VERSION;
  }

  ngOnInit(): void {
    // getting the user level at the component load
    this.location = this.helperSrv.getLocation();
    this.loginedInUser = this.helperSrv.getEmail();
    this.loginedInUser.split("", 25);
    this.authSrv.choosenLocation.subscribe(location => {
      this.location = location;
    });
    this.authSrv.choosenAddress.subscribe(address => {
      this.locationAddress = address;
    });
    this.authSrv.currentUser.subscribe(userScope => {
      this.currentRole = userScope.replace(/,*$/, "");
      let splitedScope: string[] = userScope.split(",");
      sessionStorage.setItem('mm-rl', this.helperSrv.encryptValue(splitedScope.toLocaleString()));
      this.currentUserLevel = splitedScope;
    });

    const elemSidebar = <HTMLElement>document.querySelector('.sidebar-container ');

    if (window.matchMedia(`(min-width: 960px)`).matches && !this.isMac() && !this.compactSidebar && this.layoutDir != 'rtl') {
      const ps = new PerfectScrollbar(elemSidebar, {
        wheelSpeed: 2,
        suppressScrollX: true
      });
    }

    this._router = this.router.events.pipe(filter(event => event instanceof NavigationEnd)).subscribe((event: NavigationEnd) => {
      this.url = event.url;
      if (this.isOver()) {
        this.sidemenu.close();
      }

      if (window.matchMedia(`(min-width: 960px)`).matches && !this.isMac() && !this.compactSidebar && this.layoutDir != 'rtl') {
        // Ps.update(elemContent);
      }
    });

    //Start watching for user inactivity.
    this.userIdle.startWatching();

    // Start watching when user idle is starting.
    this.userIdle.onTimerStart().subscribe(() => {
      this.redirectToLogin();
    });

  }

  /** redirect to LOGIN **/
  redirectToLogin() {
    this.authSrv.logOutUser();
    sessionStorage.clear();
  }

  @HostListener('click', ['$event'])
  onClick(e: any) {
    const elemSidebar = <HTMLElement>document.querySelector('.sidebar-container ');
    setTimeout(() => {
      if (window.matchMedia(`(min-width: 960px)`).matches && !this.isMac() && !this.compactSidebar && this.layoutDir != 'rtl') {
        const ps = new PerfectScrollbar(elemSidebar, {
          wheelSpeed: 2,
          suppressScrollX: true
        });
      }
    }, 350);
  }

  /** DESTROY **/
  ngOnDestroy() {
    this._router.unsubscribe();
  }

  /**viewInfo */
  viewInfo(selectedRow) {
    this.selectedRow = selectedRow;
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.data = {
      'selectedValue': this.selectedRow,
      'tableColumns': this.displayedColumns,
      'columnName': ['First Name : ', 'Last name : ', 'User Name :', 'Client :', 'Address :'],
      "component": "Users",
      "mode": true,
    };
    let dialogRef = this.dialog.open(ViewInfoComponent, dialogConfig);
  }
  /** open SUPPORT **/
  support(): void {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.width = "700px";
    let dialogRef = this.dialog.open(SupportComponent, dialogConfig);

  }

  /** navigate to CHANGE PASSWORD **/
  changepassword() {
    this.router.navigate(['/change-password']);
  }

  isOver(): boolean {
    if (this.url === '/apps/messages' || this.url === '/apps/calendar' || this.url === '/apps/media' || this.url === '/maps/leaflet') {
      return true;
    } else {
      return window.matchMedia(`(max-width: 960px)`).matches;
    }
  }

  isMac(): boolean {
    let bool = false;
    if (navigator.platform.toUpperCase().indexOf('MAC') >= 0 || navigator.platform.toUpperCase().indexOf('IPAD') >= 0) {
      bool = true;
    }
    return bool;
  }

  menuMouseOver(): void {
    if (window.matchMedia(`(min-width: 960px)`).matches && this.collapseSidebar) {
      this.sidemenu.mode = 'over';
    }
  }

  menuMouseOut(): void {
    if (window.matchMedia(`(min-width: 960px)`).matches && this.collapseSidebar) {
      this.sidemenu.mode = 'side';
    }
  }

  menuToggleFunc() {
    this.sidemenu.toggle();

    if (this.collapsedClass == 'side-panel-opened') {
      this.collapsedClass = 'side-panel-closed';
    }
    else {
      this.collapsedClass = 'side-panel-opened';
    }
  }

  changeMenuLayout(value) {
    if (value) {
      this.menuLayout = 'top-menu';
    }
    else {
      this.menuLayout = 'vertical-menu';
    }
  }

  onSelectSidebarImage(selectedClass, event) {
    this.selectedSidebarImage = selectedClass;
  }

  onSelectedSidebarColor(selectedClass) {
    this.selectedSidebarColor = selectedClass;
  }

  onSelectedHeaderColor(selectedClass) {
    this.selectedHeaderColor = selectedClass;
  }

  isBgActive(value) {
    if (value == this.selectedSidebarImage) {
      return true;
    }
    else {
      return false;
    }
  }

  isSidebarActive(value) {
    if (value == this.selectedSidebarColor) {
      return true;
    }
    else {
      return false;
    }
  }

  isHeaderActive(value) {
    if (value == this.selectedHeaderColor) {
      return true;
    }
    else {
      return false;
    }
  }

  addMenuItem(): void {
    this.menuItems.add({
      state: 'menu',
      name: 'MENU',
      type: 'sub',
      icon: 'trending_flat',
      children: [
        { state: 'menu', name: 'MENU' },
        { state: 'timelmenuine', name: 'MENU' }
      ],
      accessLevel: ["ADMIN"]
    });
  }
  /** LOGOUT **/
  logOut() {
    this.authSrv.logOutUser();
  }


  getUser() {
    this.spinnerService.show();
    this.authSrv.refreshUser().subscribe(res=>{});
    this.authSrv.getUser().subscribe(res => {
      this.selectedRow = res.body;
      this.viewInfo(this.selectedRow);
      this.spinnerService.hide();
    });
  }
}


