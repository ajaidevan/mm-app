import { Component, ViewEncapsulation } from '@angular/core';
import { Router } from "@angular/router";
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { HelperService } from 'app/services/helper.service';
import { AuthService } from 'app/services/auth.service';
import { CookieService } from 'ngx-cookie-service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { MatDialog, MatDialogConfig } from '@angular/material';
import { SelectLocationComponent } from './select-location/select-location.component';
import { UserIdleService } from 'angular-user-idle';
import { FrontValidationService } from 'app/services/front-validation/front-validation.service';
import { PatternValidationService } from 'app/services/front-validation/pattern-validation.service';

@Component({
  selector: 'ms-login-session',
  templateUrl: './login-component.html',
  styleUrls: ['./login-component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class LoginComponent {
  
  public email: string;
  public password: string;
  public showLogin: boolean = true;

  public loginForm = new FormGroup({
    username: new FormControl('', [Validators.required, Validators.pattern(this.patternSrv.emailPattern)]),
    password: new FormControl('', [Validators.required])
  });

  public resetPasswordForm = new FormGroup({
    email: new FormControl('', [Validators.required, Validators.pattern(this.patternSrv.emailPattern)]),
  });

  public passwordToggleObj = {
    password: true
  };

  public fetchLocations: any;
  public error: string;
  public response: string;
  public loginVal: any;
  public emailForgot: any=this.resetPasswordForm.get('email').value;
 
  constructor(
    private router: Router,private patternSrv:PatternValidationService,
    private helper: HelperService,
    private authSrv: AuthService,
    private cookieSrv: CookieService,
    private spinnerService: Ng4LoadingSpinnerService,
    private dialog: MatDialog,
    private userIdle: UserIdleService,
    private FrontValSrv: FrontValidationService
  ) { }

  ngOnInit() {
    /** Validation Message **/
    this.loginVal = this.FrontValSrv.validationMsg
    this.authSrv.currentLocation.subscribe(locations => this.fetchLocations = locations);
    
  }

  /** LOGIN **/
  login() {
    this.spinnerService.show();
    this.authSrv.clearScope();
    let loginData = this.loginForm.value;
    if (this.loginForm.valid) {
      this.authSrv.userLogin(this.loginForm.value).subscribe(data => {
        sessionStorage.setItem("token", this.helper.encryptValue(data["access_token"].trim()));
        if (data.pwd_expired) {
          this.router.navigate(["/change-password"]);
          delete data["token"];
          sessionStorage.setItem("mm-eml", this.helper.encryptValue(data["email"].trim()));
          sessionStorage.setItem("mm-msg", this.helper.encryptValue(data["message"].trim()));
        }
        else {                           
          this._storeUserInfo(data);
          this.spinnerService.hide();
          if (data["rolelocations"].length == 1) {
            sessionStorage.setItem("id", this.helper.encryptValue(data["id"]));
            sessionStorage.setItem("tenant_id", this.helper.encryptValue(data["tenant"]));
            this._hasOneLocation(data["rolelocations"]);
          } else if (data["rolelocations"].length > 0) {
            this._hasMorethanOneLocation(data);
          } else {
            this._hasNoLocation(data);
          }
          this.helper.showSnackbar('Login Successful'); 
          this.router.navigate(["/home"]);
        }
      }, error => {
        // this.error = error.error.error_description;
        this.error = 'You have entered an invalid username or password';
        this.spinnerService.hide();
      })
    }
  }


  toggleForgotPassword() {
   this.error=null;
    setTimeout(() => {
      this.showLogin = !this.showLogin;
    }, 2000)
  }

  /** FORGOT PASSWORD **/
  forgotPassoword() {
    
    this.spinnerService.show();
    let email = this.resetPasswordForm.controls['email'].value;
    this.authSrv.forgotPassword({ "email": email }).subscribe(
      res => {
        this.spinnerService.hide();
        this.response = res.message;
        this.error = null;
      }, err => {
        this.spinnerService.hide();
        //this.error = err.error.message;
        this.response = null;
      }
    )
    this.helper.showSnackbar('If user found, a reset link will be sent to your email.');
    this.resetPasswordForm.reset();
  }

  /** has one LOCATION **/
  private _hasOneLocation(data) {
    let scope: string = '';
    for (let role of data[0].role) {
      scope += role.name + ","
    }
    sessionStorage.setItem("scope", this.helper.encryptValue(scope));
    sessionStorage.setItem("mm-lotn", this.helper.encryptValue(data[0].location.name));
    sessionStorage.setItem("address",this.helper.encryptValue(data[0].location.address))
    this.authSrv.setScope();    
    this.authSrv.loginAuditLog().subscribe(res=>{},err=>{});
  }

  /** store user INFO **/
  private _storeUserInfo(data) {
    sessionStorage.setItem("token", this.helper.encryptValue(data["access_token"].trim()));
    sessionStorage.setItem("mm-eml", this.helper.encryptValue(data["email"].trim()));
    sessionStorage.setItem("id", this.helper.encryptValue(data["id"]));
    sessionStorage.setItem("username", this.helper.encryptValue(data["username"]));
    sessionStorage.setItem("tenant_id", this.helper.encryptValue(data["tenant"]));
    sessionStorage.setItem("tenant_name", this.helper.encryptValue(data["tenantName"]));
    sessionStorage.setItem("companies", this.helper.encryptValue(JSON.stringify(data["companies"])));
  }

  /** has more than a LOCATION **/
  private _hasMorethanOneLocation(data) {
    this.authSrv.setLocations(data["rolelocations"]);
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    setTimeout(()=>{
      let dialogRef = this.dialog.open(SelectLocationComponent, dialogConfig);
    },2000);
  }

  /** has no LOCATION **/
  private _hasNoLocation(data) {
    sessionStorage.setItem("scope", this.helper.encryptValue(data["scope"].trim()));
    this.authSrv.setScope();
    this.authSrv.loginAuditLog().subscribe(res=>{},err=>{});
  }
}
