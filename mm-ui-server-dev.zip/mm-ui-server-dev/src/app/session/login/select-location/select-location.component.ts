import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from 'app/services/auth.service';
import { HelperService } from 'app/services/helper.service';

@Component({
  selector: 'app-select-location',
  templateUrl: './select-location.component.html',
  styleUrls: ['./select-location.component.scss']
})
export class SelectLocationComponent implements OnInit {

  public locationList: any;
  public clicked:boolean = false;
  public selectLocation = this.fb.group({
    locations: ['']
  })

  constructor(private dialogRef: MatDialogRef<SelectLocationComponent>,
    private fb: FormBuilder, private router: Router,
    private authSrv: AuthService, private helper: HelperService) { }

  ngOnInit() {
    this.authSrv.currentLocation.subscribe(locations => this.locationList = locations);
  }

  /** CLOSE mat dialog **/
  close() {
    this.dialogRef.close(null);
    this.authSrv.logOutUser();
  }

  /** submit LOCATION **/
  submit() {
    this.clicked = false;
    this.dialogRef.close(this.selectLocation.value);
    sessionStorage.setItem("mm-lotn", this.helper.encryptValue(this.selectLocation.value.locations));
    this.authSrv.changeLocations(this.selectLocation.value.locations);
    this.authSrv.setScope();
    this.authSrv.loginAuditLog().subscribe(res=>{},err=>{});
    this.router.navigate(["/home"]);
  }

  /** select ROLES **/
  selectRolesFromLocation(ln) {
    let scope: string = '';
    for (let role of ln["role"]) {
      scope += role.name + ","
    }
    sessionStorage.setItem("scope", this.helper.encryptValue(scope.trim()));
    sessionStorage.setItem("address", this.helper.encryptValue(ln.location.address.trim()));
  }

}
