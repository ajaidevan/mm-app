import { Component, ViewEncapsulation } from '@angular/core';
import { Router } from "@angular/router";

@Component({
  selector: 'ms-lockscreen',
  templateUrl: './lockscreen-component.html',
  styleUrls: ['./lockscreen-component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class LockScreenComponent {

  public username: string;

  constructor(
    private router: Router
  ) { }

  /** SUBMIT **/
  onSubmit() {
    this.router.navigate(['/']);
  }

}
