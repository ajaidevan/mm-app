import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Router } from "@angular/router";

@Component({
  selector: 'ms-register-session',
  templateUrl: './register-component.html',
  styleUrls: ['./register-component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class RegisterComponent {

  public name: string;
  public email: string;
  public password: string;
  public passwordConfirm: string;

  constructor(
    private router: Router
  ) { }

  /** REGISTER **/
  register() {
    this.router.navigate(['/']);
  }

}
