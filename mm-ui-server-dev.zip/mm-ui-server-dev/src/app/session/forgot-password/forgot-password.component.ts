import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Router, ActivatedRoute } from "@angular/router";
import { FormBuilder, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material';
import { AuthService } from 'app/services/auth.service';
import { HelperService } from 'app/services/helper.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { FrontValidationService } from 'app/services/front-validation/front-validation.service';
import { PatternValidationService } from 'app/services/front-validation/pattern-validation.service';

@Component({
  selector: 'ms-forgot-password',
  templateUrl: './forgot-password-component.html',
  styleUrls: ['./forgot-password-component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class ForgotPasswordComponent {

  public hide: boolean[] = [true, true, true];
  public forgetPasswordForm: any;
  public email: string;
  public password: string;
  public token: string;
  public forgotPwdVal: any;

  constructor(
    private router: Router,private patternSrv:PatternValidationService,
    private fb: FormBuilder,
    private helper: HelperService,
    private authSrv: AuthService,
    private activatedRoute: ActivatedRoute,
    private spinnerService: Ng4LoadingSpinnerService,
    private frontValSrv: FrontValidationService
  ) {
    // forgot password form
    this.forgetPasswordForm = this.fb.group({
      newPassword: ['', [Validators.required, Validators.minLength(8), Validators.pattern(this.patternSrv.pwdPattern)]],
      reTypeNewPassword: ['', [Validators.required, Validators.minLength(8)]]
    });

    this.activatedRoute.queryParams.subscribe(params => {
      this.token = params['token'];
    });
  }

  ngOnInit() {
    /** Validation Message **/
    this.forgotPwdVal = this.frontValSrv.validationMsg;
  }

  /** RSEST password **/
  resetPassword() {
    this.spinnerService.show();
    let newPassword = this.forgetPasswordForm.controls['newPassword'].value;
    let data = { token: this.token, newPassword: newPassword }
    this.authSrv.forgotPasswordFinish(data).subscribe(
      res => {
        if (res.status) {
          this.helper.showSnackbar('Password has been changed successfully please proceed with login');
          this.spinnerService.hide();
          this.router.navigate(['/authentication/login']);
        }
      },
      err => {
        this.spinnerService.hide();
        if(err.error.message.includes('User Not Found')){
          this.helper.showSnackbar('Password has been changed successfully please proceed with login')
        }
        else{
          this.helper.showSnackbar("Something Went Wrong Please Try Again Later",false,true);
        }
      }
    )
  }
  
}
