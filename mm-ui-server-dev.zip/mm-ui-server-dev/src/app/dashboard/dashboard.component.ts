import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HelperService } from 'app/services/helper.service';
import { DashboardService } from './dashboard.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  constructor(private helperSrv: HelperService, private dashboardSrv: DashboardService, private router: Router) {

  }
  public loginRole;
  public dashboardData: any = {};
  ngOnInit() {
  }

  ngDoCheck(){
    if(sessionStorage.getItem('mm-rl') !== "undefined") {
      let login = this.helperSrv.decryptValue(sessionStorage.getItem('mm-rl'));
      this.loginRole = login.split(',');
      this.getDashboard();
    }
  }
  getDashboard() {
    this.loginRole.forEach(ele => {
      switch (ele) {
        case 'Admin':
          this.dashboardSrv.getLocAdminDashboard().subscribe(data => {
            this.dashboardData = data.body;
          })
          break;
        case 'role_client_admin':
          this.dashboardSrv.getClientDashboard().subscribe(data => {
            this.dashboardData = data.body;
          })
          break;
        case 'role_super_admin':
          this.dashboardSrv.getSuperDashboard().subscribe(data => {
            this.dashboardData = data.body;
          })
          break;
        case 'Reviewer':
          this.router.navigate(['/explore-inventory']);
          break;
        default:
          break;
      }
    })
  }

}
