import { Injectable } from '@angular/core';
import { CommonApiService } from 'app/services/common-api.service';
import { environment } from 'environments/environment';
import { HelperService } from 'app/services/helper.service';

@Injectable({
  providedIn: 'root'
})
export class DashboardService {
  
  constructor(private httpRequest: CommonApiService,private helperSrv: HelperService) { }

  getLocAdminDashboard(){
    return this.httpRequest.getRequestWithToken(environment.BASEURL + '/mm/receivables/count')
  }

  getSuperDashboard(){
    return this.httpRequest.getRequestWithToken(environment.BASEURL + '/auth/users/count')
  }

  getClientDashboard(){
    return this.httpRequest.getRequestWithToken(environment.BASEURL + '/auth/users/count?tenantId=' + this.helperSrv.getTenantId())
  }
}
