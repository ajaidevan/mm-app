import { NgModule } from '@angular/core';
import { CommonModule, TitleCasePipe } from '@angular/common';
import { RouterModule } from '@angular/router';

import { ExploreInventoryRoutes } from './explore-inventory-routing';
import { InventoryExplorerComponent } from 'app/shared/explorer/inventory-explorer/inventory-explorer.component';
import { ExplorerSlotComponent } from 'app/shared/explorer/explorer-slot/explorer-slot.component';
import { SlotPaginatorComponent } from 'app/shared/explorer/slot-paginator/slot-paginator.component';
import { ExplorerService } from 'app/inventory-management/services/explorer.service';
import { SharedModule } from 'app/shared/shared.module';
import { ExploreInventoryComponent } from './explore-inventory/explore-inventory.component';
import { MatTooltipModule, MatCardModule } from '@angular/material';
import { TransferService } from 'app/inventory-management/services/transfer.service';
import { MaterialStoreService } from 'app/inventory-management/services/material-store-service';

@NgModule({
  declarations: [
    ExploreInventoryComponent
  ],

  imports: [
    CommonModule,
    RouterModule.forChild(ExploreInventoryRoutes),
    SharedModule,
    MatCardModule,
    MatTooltipModule,
  ],
  entryComponents: [ExploreInventoryComponent],
  providers: [TransferService, MaterialStoreService, TitleCasePipe]
})
export class InventoryManagementModule { }
