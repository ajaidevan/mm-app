import { Routes } from '@angular/router';
import { ExploreInventoryComponent } from './explore-inventory/explore-inventory.component';

export const ExploreInventoryRoutes: Routes = [
  {
    path: '',
    redirectTo: 'explore-inventory',
    pathMatch: 'full',
  }, {
    path: '',
    children: [
      {
        path: 'explore-inventory',
        component: ExploreInventoryComponent,
      },
    ]
  }
];


