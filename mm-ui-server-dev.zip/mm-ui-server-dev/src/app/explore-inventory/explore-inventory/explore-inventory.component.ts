import { Component, OnInit, ViewEncapsulation, ElementRef } from '@angular/core';
import { QuickSearchService } from 'app/services/quick-search.service';

@Component({
  selector: 'app-explore-inventory',
  templateUrl: './explore-inventory.component.html',
  styleUrls: ['./explore-inventory.component.scss']
})
export class ExploreInventoryComponent implements OnInit {

  constructor() { }

  ngOnInit() {

  }

}
