import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ExploreInventoryComponent } from './explore-inventory.component';

describe('ExploreInventoryComponent', () => {
  let component: ExploreInventoryComponent;
  let fixture: ComponentFixture<ExploreInventoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExploreInventoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExploreInventoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
