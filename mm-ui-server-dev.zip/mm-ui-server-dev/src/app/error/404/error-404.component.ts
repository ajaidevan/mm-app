import { Component, OnInit,ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';

@Component({
    selector: 'ms-error-404',
  	templateUrl:'./error-404-component.html',
 	  styleUrls: ['./error-404-component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class ErrorOneComponent implements OnInit {

	constructor(private router:Router) {}

   	ngOnInit() {

   	}
	toHome(){
		this.router.navigate(['/home']);
	}
 
}
