import { Routes } from '@angular/router';

import { ErrorOneComponent } from './404/error-404.component';
import { ErrorTwoComponent } from './503/error-503.component';
import { ErrorFourOOneComponent } from './401/error-401.component';

export const ErrorRoutes: Routes = [{
  path: '',
  redirectTo: '404',
  pathMatch: 'full',
}, {
  path: '',
  children: [{
    path: '401',
    component: ErrorFourOOneComponent
  }, {
    path: '404',
    component: ErrorOneComponent
  }, {
    path: '503',
    component: ErrorTwoComponent
  }]
}];
