import { Component, OnInit,ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';

@Component({
    selector: 'ms-error-401',
  	templateUrl:'./error-401-component.html',
 	  styleUrls: ['./error-401-component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class ErrorFourOOneComponent implements OnInit {

	constructor(private router:Router) {}

   	ngOnInit() {

   	}
	toHome(){
		this.router.navigate(['/home']);
	}
 
}
