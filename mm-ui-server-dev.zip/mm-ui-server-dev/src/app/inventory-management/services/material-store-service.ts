import { Injectable } from '@angular/core';
import { of, Observable } from 'rxjs';
import { CommonApiService } from 'app/services/common-api.service';
import { environment } from '../../../environments/environment';
import { ReceiptCase, ReceiptItem } from 'app/models/qa-receipt.model';


/**
 * Material Store Service
 *
 * This service fetches and caches items and cases details especially for the
 * `InventoryExplorerComponent` and the `ExplorerSlotComponent` components which displays
 * items/cases details on hover
 */
@Injectable()
export class MaterialStoreService {

  // CACHE
  private cases: { [id: number]: ReceiptCase; } = {};
  private items: { [id: number]: ReceiptItem; } = {};


  constructor(private httpRequest: CommonApiService) { }

  getCase(caseId?: number): Observable<ReceiptCase> {
    const caseObj = this.cases[caseId];
    if (caseObj) {
      return of(caseObj);
    } else {
      return this.httpRequest.getRequestWithToken(environment.BASEURL + `/mm/i-cases/${caseId}`, {})
        .map(response => {
          const caseObj = response.body;
          this.cases[caseObj.id] = caseObj;
          this.capStore();
          return caseObj;
        });
    }
  }

  getItem(itemId?: number): Observable<ReceiptItem> {
    const item = this.items[itemId];
    if (item) {
      return of(item);
    } else {
      return this.httpRequest.getRequestWithToken(environment.BASEURL + `/mm/items/${itemId}`, {})
        .map(response => {
          const item = response.body;
          this.items[item.id] = item;
          this.capStore();
          return item;
        });
    }
  }

  setCases(cases: Array<any>) {
    cases.forEach((caseObj) => this.cases[caseObj.id] = caseObj);
    this.capStore();
  }

  setItems(items: Array<any>) {
    items.forEach((item) => this.items[item.id] = item);
    this.capStore();
  }

  // To avoid memory leak..maybe we'll have 1000s of items/cases in future
  private capStore() {
    Object.keys(this.items).reverse().forEach((itemId, i) => {
      if (i > 1000) delete this.items[itemId];
    });
    Object.keys(this.cases).reverse().forEach((caseId, i) => {
      if (i > 1000) delete this.cases[caseId];
    });
  }
}
