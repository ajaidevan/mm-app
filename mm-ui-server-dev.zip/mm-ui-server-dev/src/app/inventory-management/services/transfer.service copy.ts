import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { CommonApiService } from 'app/services/common-api.service';
import { environment } from '../../../environments/environment';
import { Company } from 'app/models/company.model';

@Injectable()
export class VerificationService {


  constructor(private httpRequest: CommonApiService) {

  }

  /** GET All companies */
  getAllCompanies(): Observable<Array<Company>> {
    return this.httpRequest.getRequestWithToken(environment.BASEURL + '/auth/company', {})
      .map(r => r.body as Array<Company>);
  }

}
