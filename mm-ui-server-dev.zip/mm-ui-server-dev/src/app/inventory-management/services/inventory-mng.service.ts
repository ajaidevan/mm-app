import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Observable, BehaviorSubject } from 'rxjs';
import { CommonApiService } from 'app/services/common-api.service';
import { environment } from '../../../environments/environment';
import { QAReceipt } from 'app/models/qa-receipt.model';
import { MaterialStoreService } from './material-store-service';
import { HelperService } from '../../services/helper.service';



@Injectable()
export class InventoryMngService {

  private httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  };

  constructor(private http: HttpClient,
    private httpRequest: CommonApiService,
    private helper:HelperService,
    private materiaStoreService: MaterialStoreService) { }

  private verifiedGrids = new BehaviorSubject<any>("");
  public verified = this.verifiedGrids.asObservable();
  //getreceivables

  sendVerifiedGrids(verified) {
    this.verifiedGrids.next(verified);
  }
  //getreceivables
  getAllReceivables(paramObj: any) {
    return this.httpRequest.getRequestWithToken(environment.BASEURL + '/mm/receivables?status=MATERIAL_COUNT', paramObj);
  }

  getReceipts(reqParams): Observable<{ receipts: QAReceipt[], total: number; }> {
    const status = ['APPROVED'];
    reqParams.status = status.join(',');
    reqParams.sort = reqParams.sort || 'createdAt,DESC';
    return this.httpRequest.getRequestWithToken(environment.BASEURL + `/mm/receivables/summary?locationId=${this.helper.getLocation()}`, reqParams)
      .map((response) => {
        const receipts = response.body.map(r => {
          this.materiaStoreService.setCases(r.iCases);
          this.materiaStoreService.setItems(r.items);
          return new QAReceipt(r);
        });

        return {
          receipts,
          total: response.headers.get('X-Total-Count')
        };
      });
  }

  getCases(paramObj?: any) {
    return this.httpRequest.getRequestWithToken(environment.BASEURL + '/mm/i-cases?quantityType=case-w', paramObj);
  }

  //getCaseItems
  getICaseItems(caseId) {
    return this.httpRequest.getRequestWithToken(environment.BASEURL + '/mm/i-cases/' + caseId + '/items/', {});
  }

  //updateCases
  updateICase(cases) {
    return this.httpRequest.putRequest(environment.BASEURL + '/mm/i-cases', cases);
  }

  //update inventories
  updateFreezer(freezer) {
    return this.httpRequest.putRequest(environment.BASEURL + '/st/freezers/', freezer);
  }
  updateIncubator(incubator) {
    return this.httpRequest.putRequest(environment.BASEURL + '/st/incubators/', incubator);
  }
  updateRefrigerator(refrigerator) {
    return this.httpRequest.putRequest(environment.BASEURL + '/st/refrigerators/', refrigerator);
  }
  updateOpernStorage(open) {
    return this.httpRequest.putRequest(environment.BASEURL + '/st/open-storages/', open);
  }
  //update shelf
  updateFreezerShelf(shelf) {
    return this.httpRequest.putRequest(environment.BASEURL + '/st/freezer-shelves', shelf);
  }
  updateIncubatorShelf(shelf) {
    return this.httpRequest.putRequest(environment.BASEURL + '/st/inc-shelves/', shelf);
  }
  updateRefrigeratorShelf(shelf) {
    return this.httpRequest.putRequest(environment.BASEURL + '/st/ref-shelves/', shelf);
  }
  updateOsShelf(shelf) {
    return this.httpRequest.putRequest(environment.BASEURL + '/st/os-shelves/', shelf);
  }

  //update rack
  updateFreezerRack(rack) {
    return this.httpRequest.putRequest(environment.BASEURL + '/st/freezer-racks', rack);
  }
  updateIncubatorRack(rack) {
    return this.httpRequest.putRequest(environment.BASEURL + '/st/inc-racks/', rack);
  }
  updateRefrigeratorRack(rack) {
    return this.httpRequest.putRequest(environment.BASEURL + '/st/ref-racks/', rack);
  }
  updateOsRack(rack) {
    return this.httpRequest.putRequest(environment.BASEURL + '/st/os-racks/', rack);
  }

  //update rows
  updateFreezerRow(row) {
    return this.httpRequest.putRequest(environment.BASEURL + '/st/freezer-rows', row);
  }
  updateIncubatorRow(row) {
    return this.httpRequest.putRequest(environment.BASEURL + '/st/inc-rows/', row);
  }
  updateRefrigeratorRow(row) {
    return this.httpRequest.putRequest(environment.BASEURL + '/st/ref-rows/', row);
  }
  updateOsRow(row) {
    return this.httpRequest.putRequest(environment.BASEURL + '/st/os-rows/', row);
  }

  //update slots
  updateFreezerSlot(row) {
    return this.httpRequest.putRequest(environment.BASEURL + '/st/freezer-slots', row);
  }
  updateIncubatorSlot(row) {
    return this.httpRequest.putRequest(environment.BASEURL + '/st/inc-slots/', row);
  }
  updateRefrigeratorSlot(row) {
    return this.httpRequest.putRequest(environment.BASEURL + '/st/ref-slots/', row);
  }
  updateOsSlot(row) {
    return this.httpRequest.putRequest(environment.BASEURL + '/st/os-slots/', row);
  }

  //update sections
  updateFreezerSection(row) {
    return this.httpRequest.putRequest(environment.BASEURL + '/st/freezer-sections', row);
  }
  updateIncubatorSection(row) {
    return this.httpRequest.putRequest(environment.BASEURL + '/st/inc-sections/', row);
  }
  updateRefrigeratorSection(row) {
    return this.httpRequest.putRequest(environment.BASEURL + '/st/ref-sections/', row);
  }
  updateOsSection(row) {
    return this.httpRequest.putRequest(environment.BASEURL + '/st/os-sections/', row);
  }

}
