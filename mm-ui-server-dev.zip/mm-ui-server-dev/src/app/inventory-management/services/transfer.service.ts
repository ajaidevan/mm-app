import { Injectable } from '@angular/core';
import { Observable, forkJoin, throwError, BehaviorSubject } from 'rxjs';
import { CommonApiService } from 'app/services/common-api.service';
import { environment } from '../../../environments/environment';
import { ExplorerItem } from '../../shared/explorer/explorer.helper';
import { tap } from 'rxjs/operators';
import { QAReceipt } from 'app/models/qa-receipt.model';
import { MatSnackBar } from '@angular/material';
import { Router, NavigationStart } from '@angular/router';
import { TitleCasePipe } from '@angular/common';
import { InventoryCase, InventoryItem, InventoryGrid } from '../../shared/explorer/material.helper';

// Type of transfered Object
export type TransferType = 'CASE' | 'ITEM';

const RECEIPT_STATUS_MAP = {
  'Quarantine': 'QUARANTINE_STORAGE',
  'Release': 'RELEASE_STORAGE',
  'N/A': 'NA_STORAGE',
  'Reject': 'REJECTED_STORAGE',
};

/**
 * This is the object that gets transferred from any component to another
 *
 * Note: `storage` is empty at start of transfer, only gets added after
 * the transfer is confirmed and before sending to `completeTransfer()`
 */
export type TransferObject = {
  type: TransferType;
  sourceReceipt?: QAReceipt;
  sourceStorage?: ExplorerItem;
  selected?: Array<InventoryCase | InventoryItem | InventoryGrid>;
  count: number;
  targetStorage?: ExplorerItem;
  comment?: string;
};

export type TransferStatus = 'IDLE' | 'LOADING' | 'COMPLETE';

/**
 * Transfer Service
 *
 * This service handles transfering items request and it has a `status` BehaviorSubject
 * that is subscribed to in both `OrdersTableComponent` and `InventoryExplorerComponent`
 */
@Injectable()
export class TransferService {

  public readonly status: BehaviorSubject<TransferStatus> = new BehaviorSubject('IDLE' as TransferStatus);

  public readonly transferObject: BehaviorSubject<TransferObject> = new BehaviorSubject(null);

  private snackBarRef = null;

  constructor(private httpRequest: CommonApiService,
    private _snackBar: MatSnackBar,
    private titlecasePipe: TitleCasePipe,
    private router: Router) {
    this.router.events.subscribe(e => {
      if (e instanceof NavigationStart && this.snackBarRef) {
        this.cancelTransfer();
      }
    });
  }

  /**
   * - Sets the BehaviorSubject with the received transferObject
   * - Starts a SnackBar with transfer details
   * - Scrolls to TARGET InventoryExplorer Component
   *
   * @param transferObject
   * @param scrollToTarget
   */
  public initTransfer(transferObject: TransferObject, scrollToTarget: boolean = true) {
    this.transferObject.next(transferObject);

    if (transferObject) {
      if (scrollToTarget) document.querySelector('h2.target') && document.querySelector('h2.target').scrollIntoView({ behavior: "smooth" });

      this.snackBarRef = this._snackBar.open(`You are placing ${this.transferDescription}`, "Cancel", { panelClass: 'transfer-snackbar' });
      this.snackBarRef.onAction().subscribe(() => this.cancelTransfer(true));
    }
  }

  public cancelTransfer(scrollToSource: boolean = false) {
    if (this.snackBarRef) this.snackBarRef.dismiss();
    this.transferObject.next(null);
    this.status.next('IDLE');
    if (scrollToSource) {
      document.querySelector('.source').scrollIntoView({ behavior: "smooth" });
    }
  }

  /**
   * Changes the service status to `LOADING`
   *
   * Generates 2 requests
   * 1. Updates source (sourceStorage/sourceReceipt) with the items/cases/grids being transferred or QUARANTINE_STORAGE status
   * 2. Update target
   *
   * Upon receiving response it calls `_onSuccess()` to handle status and snackBar
   * then emits updated items to updateItems behaviorSubject to update all items in all Inventory Explorer instances
   *
   * @param transferObject
   */
  public completeTransfer(transferObject: TransferObject): Observable<any> {
    let sourceReq, targetReq;

    if (!transferObject.targetStorage) {
      return throwError("Incomplete TransferObject: Missing the target storage ExplorerItem in which items will be added.");
    }


    //SOURCE
    if (transferObject.sourceStorage) {
      // MOVING FROM STORAGE TO STORAGE
      transferObject.sourceStorage.removeSelected(transferObject);
      sourceReq = this._getStorageRequest(transferObject.sourceStorage, transferObject.comment);

    } else if (transferObject.sourceReceipt) {
      // MOVING FROM RECEIPT TO STORAGE
      const receipt = transferObject.sourceReceipt.toJSON();
     /** Adding 'move_storage' status in items, cases and receipt after moving */
      if(receipt.items && receipt.items.length > 0) {
        receipt.items.forEach(items => { 
            items.status = 'move_storage';
            this.updateItem(items).subscribe(res=>{})
          }) 
        }
      if(receipt.iCases && receipt.iCases.length >0){
        receipt.iCases.forEach(iCase => { 
          iCase.status = 'move_storage';
          this.updateIcase(iCase).subscribe(res=>{})
        }) 
      }
      receipt.status = RECEIPT_STATUS_MAP[transferObject.targetStorage.entity.statusType];
      if (!receipt.status) throw "target storage statusType not found";
      sourceReq = this._getReceiptRequest(receipt, transferObject.comment);

    } else {
      return throwError("Incomplete TransferObject: Missing the source.");
    }

    // TARGET: add transferred materials to target
    // Moving within same storage
    if (transferObject.sourceStorage &&
      transferObject.targetStorage.entity.id === transferObject.sourceStorage.entity.id) {
      // we can omit backend calls ata ll here and just return an observable
      // with the modified targetStorage, BUT later order will matter so just keep it
      transferObject.targetStorage = transferObject.sourceStorage;
    }


    transferObject.targetStorage.transfer(transferObject);
    targetReq = this._getStorageRequest(transferObject.targetStorage, transferObject.comment);

    // return both requests
    return forkJoin([sourceReq, targetReq])
      .pipe(
        tap((r) => {
          this._onSuccess();
          return r;
        })
      );
  }


  public _getStorageRequest(storage: ExplorerItem, comment: string) {
    switch (storage.type) {
      case 'REFRIGERATOR':
        return this.httpRequest.putRequest(environment.BASEURL + "/st/refrigerators/update-items", storage.entity, { comment });
      case 'REFRIGERATOR-SECTION':
        return this.httpRequest.putRequest(environment.BASEURL + "/st/ref-sections/update-items", storage.entity, { comment });
      case 'REFRIGERATOR-SLOT':
        return this.httpRequest.putRequest(environment.BASEURL + "/st/ref-slots/update-items", storage.entity, { comment });
      case 'REFRIGERATOR-RACK-SHELF':
      case 'REFRIGERATOR-SHELF':
        return this.httpRequest.putRequest(environment.BASEURL + "/st/ref-shelves/update-items", storage.entity, { comment });

      case 'FREEZER':
        return this.httpRequest.putRequest(environment.BASEURL + "/st/freezers/update-items", storage.entity, { comment });
      case 'FREEZER-SECTION':
        return this.httpRequest.putRequest(environment.BASEURL + "/st/freezer-sections/update-items", storage.entity, { comment });
      case 'FREEZER-RACK-SHELF':
      case 'FREEZER-SHELF':
        return this.httpRequest.putRequest(environment.BASEURL + "/st/freezer-shelves/update-items", storage.entity, { comment });
      case 'FREEZER-SLOT':
        return this.httpRequest.putRequest(environment.BASEURL + "/st/freezer-slots/update-items", storage.entity, { comment });

      case 'INCUBATOR-SHELF':
      case 'INCUBATOR-RACK-SHELF':
        return this.httpRequest.putRequest(environment.BASEURL + "/st/inc-shelves/update-items", storage.entity, { comment });
      case 'INCUBATOR-SECTION':
        return this.httpRequest.putRequest(environment.BASEURL + "/st/inc-sections/update-items", storage.entity, { comment });


      case 'OS-SHELF':
        return this.httpRequest.putRequest(environment.BASEURL + "/st/os-shelves/update-items", storage.entity, { comment });
      case 'OS-SECTION':
        return this.httpRequest.putRequest(environment.BASEURL + "/st/os-sections/update-items", storage.entity, { comment });
      case 'ROWS':
        return this.httpRequest.putRequest(environment.BASEURL +"/st/room-rows/update-items",storage.entity,{comment});
      default:
        return throwError(`Cannot transfer to Unrecognized ExplorerItem type: ${storage.type}`);
    }
  }

  private _getReceiptRequest(receipt, comment: string): Observable<any> {
    return this.httpRequest.putRequest(environment.BASEURL + '/mm/receivables', receipt, { comment }); // Updating receipt
  }

  private _onSuccess() {
    this.status.next('COMPLETE');
    this.status.next('IDLE');
    this.transferObject.next(null);
    this.snackBarRef = this._snackBar.open(`Transfer Successful`, null, { duration: 2000, panelClass: "success-snackbar" });
  }

  // Helper text
  get transferDescription(): string {
    const current = this.transferObject.value;
    if (current) {
      const from = current.sourceReceipt ?
        `Receipt #${current.sourceReceipt.id}` :
        `${this.titlecasePipe.transform(current.sourceStorage.type)} "${current.sourceStorage.name}"`;
      const pluralS = current.count > 1 ? 's' : '';
      return `${current.count} ${this.titlecasePipe.transform(current.type)}${pluralS} from ${from}`;
    } else {
      return;
    }
  }

  /** Update Icase */
  updateIcase(iCases) {
    return this.httpRequest.putRequest(environment.BASEURL + `/mm/i-cases`,iCases);
  }

  /** Update Icase */
  updateItem(items) {
    return this.httpRequest.putRequest(environment.BASEURL + `/mm/items`,items);
  }
}
