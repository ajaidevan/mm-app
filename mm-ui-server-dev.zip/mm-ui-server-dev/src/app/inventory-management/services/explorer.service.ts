import { Injectable } from '@angular/core';
import { Observable, of, forkJoin, throwError } from 'rxjs';
import { CommonApiService } from 'app/services/common-api.service';
import { environment } from '../../../environments/environment';
import { ExplorerItem, ExplorerItemType } from '../../shared/explorer/explorer.helper';
import { HelperService } from 'app/services/helper.service';
import { Company } from 'app/models/company.model';

@Injectable()
export class ExplorerService {
 
  selectedCompany: any = null;

  constructor(private httpRequest: CommonApiService, private helper: HelperService) { }
  STATUS = {
    ALL:'QUARANTINE_STORAGE,RELEASE_STORAGE,NA_STORAGE,REJECTED_STORAGE'
  }
  // GET Rooms by location
  getAllRoomsByLocation(locationId: string): Observable<ExplorerItem[]> {
    return this._generateRequest([{ type: 'ROOM', selectedCompany: null, endpoint: `/st/rooms/?locationId=${locationId}` }]);
  }

  getChildren(parent: ExplorerItem, selectedCompany: Company): Observable<ExplorerItem[] | null> {
    const entityId = parent.entity.id;

    // if leaf return nothing
    if (parent.isLeafNode) {
      return of([]);
    }


    switch (parent.type) {

      // ROOM view -> Fake `ExplorerItem`s
      case 'ROOM':
        return of([
          new ExplorerItem('OS-STORAGE TYPE', { id: entityId, name: 'Open Shelves' }),
          new ExplorerItem('FREEZER-STORAGE TYPE', { id: entityId, name: 'Freezers' }),
          new ExplorerItem('INCUBATOR-STORAGE TYPE', { id: entityId, name: 'Incubators' }),
          new ExplorerItem('REFRIGERATOR-STORAGE TYPE', { id: entityId, name: 'Refrigerators' }),
          new ExplorerItem('ROW-STORAGE TYPE', { id: entityId, name: 'Rows' }),
        ]);


      // CATEGORIES
      case 'OS-STORAGE TYPE':
        return this._generateRequest([{ type: 'OPEN-STORAGE', selectedCompany, endpoint: `/st/rooms/${entityId}/open-storage` }]);
      case 'FREEZER-STORAGE TYPE':
        return this._generateRequest([{ type: 'FREEZER', selectedCompany, endpoint: `/st/rooms/${entityId}/freezers` }]);
      case 'INCUBATOR-STORAGE TYPE':
        return this._generateRequest([{ type: 'INCUBATOR', selectedCompany, endpoint: `/st/rooms/${entityId}/incubators` }]);
      case 'REFRIGERATOR-STORAGE TYPE':
        return this._generateRequest([{ type: 'REFRIGERATOR', selectedCompany, endpoint: `/st/rooms/${entityId}/refrigerators` }]);
      case 'ROW-STORAGE TYPE':
        return this._generateRequest([{ type: 'ROWS', selectedCompany, endpoint: `/st/rooms/${entityId}/room-rows` }]);

      // OPEN-STORAGE
      case 'OPEN-STORAGE':
        return this._generateRequest([{ type: 'OS-RACK', selectedCompany, endpoint: `/st/open-storages/${entityId}/os-racks` }]);

      case 'OS-RACK':
        return this._generateRequest([{ type: 'OS-SHELF', selectedCompany, endpoint: `/st/os-racks/${entityId}/os-shelves` }]);

      case 'OS-SHELF':
        return this._generateRequest([{ type: 'OS-SECTION', selectedCompany, endpoint: `/st/os-shelves/${entityId}/os-sections` }]);


      // FREEZER
      case 'FREEZER':
        if (['Freezer Upright', 'Ultra-Low Upright'].includes(parent.entity["freezerType"])) {
          return this._generateRequest([
            { type: 'FREEZER-SHELF', selectedCompany, endpoint: `/st/freezers/${entityId}/freezer-shelves` }]);
        } else if (['LN2', 'Ultra-Low Chest', 'Freezer Chest'].includes(parent.entity["freezerType"])) {
          return this._generateRequest([
            { type: 'FREEZER-RACK', selectedCompany, endpoint: `/st/freezers/${entityId}/freezer-racks` }]);
        } else if (parent.entity["freezerType"] === 'Walk In') {
          return this._generateRequest([
            { type: 'FREEZER-ROW', selectedCompany, endpoint: `/st/freezers/${entityId}/freezer-rows` }]);
        } else {
          return throwError('Unrecognized Freezer type!');
        }
      case 'FREEZER-SHELF': // FREEZER -> FREEZER-SHELF -> FREEZER-RACK
        return this._generateRequest([{ type: 'FREEZER-RACK', selectedCompany, endpoint: `/st/freezer-shelves/${entityId}/freezer-racks` }]);

      case 'FREEZER-RACK':
        // FREEZER -> FREEZER-RACK -> FREEZER-SLOT
        // FREEZER -> FREEZER-SHELF -> FREEZER-RACK -> FREEZER-SLOT
        return this._generateRequest([{ type: 'FREEZER-SLOT', selectedCompany, endpoint: `/st/freezer-racks/${entityId}/freezer-slots` }]);


      case 'FREEZER-ROW': // FREEZER -> FREEZER-ROW -> FREEZER-ROW-RACK
        return this._generateRequest([{ type: 'FREEZER-ROW-RACK', selectedCompany, endpoint: `/st/freezer-rows/${entityId}/freezer-racks` }]);

      case 'FREEZER-ROW-RACK':  // FREEZER -> FREEZER-ROW -> FREEZER-ROW-RACK -> FREEZER-RACK-SHELF
        return this._generateRequest([{ type: 'FREEZER-RACK-SHELF', selectedCompany, endpoint: `/st/freezer-racks/${entityId}/freezer-shelves` }]);

      case 'FREEZER-RACK-SHELF': // FREEZER -> FREEZER-ROW -> FREEZER-RACK -> FREEZER-RACK-SHELF -> FREEZER-SECTION
        return this._generateRequest([{ type: 'FREEZER-SECTION', selectedCompany, endpoint: `/st/freezer-shelves/${entityId}/freezer-sections` }]);


      // INCUBATOR
      case 'INCUBATOR':
        if (parent.entity["incType"] === 'Walk In') {
          return this._generateRequest([{ type: 'INCUBATOR-ROW', selectedCompany, endpoint: `/st/incubators/${entityId}/inc-rows` }]);
        } else {
          return this._generateRequest([
            { type: 'INCUBATOR-SHELF', selectedCompany, endpoint: `/st/incubators/${entityId}/inc-shelves` }]);
        }
      case 'INCUBATOR-ROW': // INCUBATOR -> INCUBATOR-ROW -> INCUBATOR-RACK
        return this._generateRequest([{ type: 'INCUBATOR-RACK', selectedCompany, endpoint: `/st/inc-rows/${entityId}/inc-racks` }]);
      case 'INCUBATOR-RACK': // INCUBATOR -> INCUBATOR-ROW -> INCUBATOR-RACK -> INCUBATOR-RACK-SHELF
        return this._generateRequest([{ type: 'INCUBATOR-RACK-SHELF', selectedCompany, endpoint: `/st/inc-racks/${entityId}/inc-shelves` }]);
      case 'INCUBATOR-RACK-SHELF': // INCUBATOR -> INCUBATOR-ROW -> INCUBATOR-RACK -> INCUBATOR-RACK-SHELF -> INCUBATOR-SECTION
        return this._generateRequest([{ type: 'INCUBATOR-SECTION', selectedCompany, endpoint: `/st/inc-shelves/${entityId}/inc-sections` }]);

      // REFRIGERATOR
      case 'REFRIGERATOR':
        if (parent.entity["refType"] === '+5 Upright') {
          return this._generateRequest([
            { type: 'REFRIGERATOR-SHELF', selectedCompany, endpoint: `/st/refrigerators/${entityId}/ref-shelves` }]);
        } else if (parent.entity["refType"] === '+5 Chest') {
          return this._generateRequest([{ type: 'REFRIGERATOR-RACK', selectedCompany, endpoint: `/st/refrigerators/${entityId}/ref-racks` }]);
        }
        else if (parent.entity["refType"] === '+5 WalkIn') {
          return this._generateRequest([{ type: 'REFRIGERATOR-ROW', selectedCompany, endpoint: `/st/refrigerators/${entityId}/ref-rows` }]);
        } else {
          return throwError('Unrecognized Refrigerator type!');
        }
      case 'REFRIGERATOR-SHELF': // REFRIGERATOR -> REFRIGERATOR-SHELF -> REFRIGERATOR-RACK
        return this._generateRequest([
          { type: 'REFRIGERATOR-RACK', selectedCompany, endpoint: `/st/ref-shelves/${entityId}/ref-racks` }]);
      case 'REFRIGERATOR-ROW': // REFRIGERATOR -> REFRIGERATOR-ROW -> REFRIGERATOR-RACK
        return this._generateRequest([
          { type: 'REFRIGERATOR-RACK', selectedCompany, endpoint: `/st/ref-rows/${entityId}/ref-racks` }]);
      case 'REFRIGERATOR-RACK':
        // REFRIGERATOR -> REFRIGERATOR-ROW -> REFRIGERATOR-RACK -> REFRIGERATOR-RACK-SHELF
        // REFRIGERATOR -> REFRIGERATOR-ROW -> REFRIGERATOR-RACK -> REFRIGERATOR-SLOT
        return this._generateRequest([
          { type: 'REFRIGERATOR-RACK-SHELF', selectedCompany, endpoint: `/st/ref-racks/${entityId}/ref-shelves` },
          { type: 'REFRIGERATOR-SLOT', selectedCompany, endpoint: `/st/ref-racks/${entityId}/ref-slots` }]);
      case 'REFRIGERATOR-RACK-SHELF': // ...-> REFRIGERATOR-RACK -> REFRIGERATOR-RACK-SHELF -> REFRIGERATOR-SECTION
        return this._generateRequest([
          { type: 'REFRIGERATOR-SECTION', selectedCompany, endpoint: `/st/ref-shelves/${entityId}/ref-sections` }]);


      default:
        return throwError(`Unrecognized ExplorerItem type: ${parent.type}`);
    }
  }


  public _generateRequest(reqs: Array<{ selectedCompany: Company, endpoint: string, type: ExplorerItemType; }>): Observable<ExplorerItem[]> {
    return forkJoin(reqs.map(req => {
      return this.httpRequest.getRequestWithToken(environment.BASEURL + req.endpoint, this.generateParams(req.type, req.selectedCompany))
        .map((response) => response.body.map(i => new ExplorerItem(req.type, i)));
    }));
  }

  public generateParams(type: ExplorerItemType, selectedCompany: Company) {
    if (selectedCompany) return { companyIds: selectedCompany.id };

    if (type !== 'ROOM' && this.helper.getRoles().includes("Reviewer")) {
      return {
        companyIds: this.helper.getCompanies().map(c => c.id).join(",")
      };
    }

    return {};
  }
  
  getReceipts(paramObj?:any) {
    return this.httpRequest.getRequestWithToken(environment.BASEURL + `/mm/receivables/summary?status=${this.STATUS.ALL}&locationId=${this.helper.getLocation()}`, paramObj);
  }

   /**GET company */
  getCompanyById(compId?:any): Observable<any>{
    return this.httpRequest.getRequestWithToken(environment.BASEURL + `/auth/company/${compId}?tenant=${this.helper.getTenantId()}`,{});
  }

  getSearchItems(itemId:any) {
    return this.httpRequest.getRequestWithToken(environment.BASEURL + `/st/search/${itemId}/items`, {});
  }

  getSearchICase(iCaseId:any) {
    return this.httpRequest.getRequestWithToken(environment.BASEURL + `/st/search/${iCaseId}/i-cases`, {});
  }
  searchReceivable(filterValue?: string){
    return this.httpRequest.getRequestWithToken(environment.BASEURL + '/mm/receivables/summary?status='+this.STATUS.ALL+'&locationId='+this.helper.getLocation()+'&query=' + filterValue, {});
  }
}
