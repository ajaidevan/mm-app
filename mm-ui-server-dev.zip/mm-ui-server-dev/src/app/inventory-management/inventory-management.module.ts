import { NgModule } from '@angular/core';
import { CommonModule, TitleCasePipe } from '@angular/common';
import { InventoryRoutes } from './inventory-mng-routing.module';
import { RouterModule } from '@angular/router';
import { MatFormFieldModule, MatInputModule, MatIconModule, MatCardModule, MatButtonModule, MatListModule, MatProgressBarModule, MatMenuModule, MatSelectModule, MatSortModule, MatTableModule, MatPaginatorModule, MatRadioModule, MatCheckboxModule, MatDatepickerModule, MatDialogModule, MatBadgeModule, MatSnackBarModule, MatTooltipModule } from '@angular/material';
import { FlexLayoutModule } from '@angular/flex-layout';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { InventoryMngService } from "./services/inventory-mng.service";

import { SharedModule } from 'app/shared/shared.module';
import { ExplorerService } from './services/explorer.service';
import { TransferService } from './services/transfer.service';
import { MaterialCountComponent } from './material-count/material-count.component';
import { EditMaterialComponent } from './material-count/edit-material/edit-material.component';
import { AddItemsComponent } from './add-items/add-items.component';
import { InventoryVerificationComponent } from './inventory-verification/inventory-verification.component';
import { OrdersTableComponent } from './helpers/orders-table/orders-table.component';

import { MoveItemsComponent } from './move-items/move-items.component';
import { InventoryConfirmationComponent } from './inventory-verification/inventory-confirmation/inventory-confirmation.component';
import { MaterialStoreService } from './services/material-store-service';
import { VerificationService } from './services/transfer.service copy';

@NgModule({
  declarations: [
    MaterialCountComponent,
    EditMaterialComponent,
    AddItemsComponent,
    InventoryVerificationComponent,
    OrdersTableComponent,
    EditMaterialComponent,
    AddItemsComponent,
    MoveItemsComponent,
    InventoryConfirmationComponent
  ],
  imports: [
    CommonModule,
    MatIconModule,
    MatBadgeModule,
    MatTooltipModule,
    RouterModule.forChild(InventoryRoutes),
    MatFormFieldModule,
    MatInputModule,
    MatIconModule,
    MatCardModule,
    MatButtonModule,
    MatListModule,
    MatProgressBarModule,
    MatMenuModule,
    FlexLayoutModule,
    FormsModule,
    ReactiveFormsModule,
    MatSelectModule,
    MatSortModule,
    MatTableModule,
    MatPaginatorModule,
    MatRadioModule,
    MatCheckboxModule,
    MatDatepickerModule,
    MatDialogModule,
    SharedModule,
    MatCardModule
  ],
  providers: [TitleCasePipe, InventoryMngService, TransferService, MaterialStoreService, VerificationService],
  entryComponents: [EditMaterialComponent, InventoryConfirmationComponent]
})
export class InventoryManagementModule { }
