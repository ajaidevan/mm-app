import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { MoveItemsComponent } from './move-items.component';

describe('AddItemsComponent', () => {
  let component: MoveItemsComponent;
  let fixture: ComponentFixture<MoveItemsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [MoveItemsComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MoveItemsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
