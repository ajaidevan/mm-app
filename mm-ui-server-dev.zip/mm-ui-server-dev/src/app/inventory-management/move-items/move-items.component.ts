import { Component, OnInit, ViewChild } from '@angular/core';
import { MatSnackBar, } from '@angular/material';
import { ActivatedRoute, Router, NavigationStart } from '@angular/router';
import { TransferObject } from '../services/transfer.service';

/**
 * Add Items Page
 */

@Component({
  selector: 'app-move-items',
  templateUrl: './move-items.component.html',
  styleUrls: ['./move-items.component.scss']
})
export class MoveItemsComponent {

  constructor(
    private _snackBar: MatSnackBar,
    private router: Router) {
  }

}
