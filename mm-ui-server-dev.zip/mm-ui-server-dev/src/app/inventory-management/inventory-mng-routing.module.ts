import { Routes } from '@angular/router';
import { InventoryVerificationComponent } from './inventory-verification/inventory-verification.component';
import { MaterialCountComponent } from './material-count/material-count.component';
import { AddItemsComponent } from './add-items/add-items.component';
import { MoveItemsComponent } from './move-items/move-items.component';

export const InventoryRoutes: Routes = [
  {
    path: '',
    redirectTo: 'inventory-management',
    pathMatch: 'full',
  }, {
    path: '',
    children: [
      {
        path: 'material-count',
        component: MaterialCountComponent,
      },
      {
        path: 'add-item',
        component: AddItemsComponent,
      },
      {
        path: 'move-item',
        component: MoveItemsComponent,
      },
      {
        path: 'inventory-verification',
        component: InventoryVerificationComponent,
      }
    ]
  }
];


