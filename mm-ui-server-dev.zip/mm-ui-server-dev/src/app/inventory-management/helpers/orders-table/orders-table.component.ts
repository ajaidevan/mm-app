import { Component, ViewChild, OnInit, Output, EventEmitter, OnDestroy } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort, MatPaginator, PageEvent, Sort } from '@angular/material';
import { InventoryMngService } from 'app/inventory-management/services/inventory-mng.service';
import { QAReceipt } from 'app/models/qa-receipt.model';
import { trigger, state, style, transition, animate } from '@angular/animations';
import { TransferService, TransferStatus, TransferObject, TransferType } from 'app/inventory-management/services/transfer.service';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { CommonApiService } from 'app/services/common-api.service';

/**
 * Orders Table
 *
 * This component should allow selecting cases/orders that emit data to parent page
 * then transfer it to the inventory explorer component
 *
 * take care:
 * - Removing an item from page 5 will rerender the whole table and reset to page 1
 *
 */

@Component({
  selector: 'app-orders-table',
  templateUrl: './orders-table.component.html',
  styleUrls: ['./orders-table.component.scss'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class OrdersTableComponent implements OnInit, OnDestroy {

  // loading
  public loading: boolean = true;

  // Material table config
  @ViewChild('innerPaginator') paginator: MatPaginator;
  @ViewChild('innerSort') sort: MatSort;

  public paginate: any = { size: 5 };
  dataSource: MatTableDataSource<QAReceipt>;
  expandedElement: QAReceipt | null;
  displayedColumns: string[] = [
    'id',
    'containerType',
    'status',
    'description',
    'client',
    'quantityType',
    'createdAt',
    'casesCount',
    'itemsCount',
    'expand'
  ];

  private unsubscriber: Subject<any> = new Subject;
  public searchItem=new MatTableDataSource();
  public totalCount:number;
  public paginateChild: any = { page: 0, size: 5 };
  public childDisplayedColumns:any[] = ['id'];


  constructor(
    private inventoryMngService: InventoryMngService,
    private commonSrv: CommonApiService,
    public transferService: TransferService) { }

  ngOnInit() {
    this.transferService.status.pipe(
      takeUntil(this.unsubscriber)
    ).subscribe((status: TransferStatus) => {
      if (status === 'IDLE') {
        this.getPaginatedOrders();
      }
    });
  }

  ngOnDestroy(): void {
    this.unsubscriber.next();
    this.unsubscriber.complete();
  }

  /** Paginate The Rooms **/
  getPaginatedOrders(setPage = true, filter = null) {
    if (setPage || filter) this.paginate.page = 0;
    if(filter){
      delete this.paginate.size;
      delete this.paginate.length;
    }
    this.paginate.query = filter;
    let reqParams = this.commonSrv.createParam(this.paginate);
    this.loading = true;
    this.inventoryMngService.getReceipts(reqParams).subscribe((response: { receipts: QAReceipt[], total: number; }) => {
      this.dataSource = new MatTableDataSource(response.receipts);
      this.dataSource.sort = this.sort;
      this.paginate.length = response.total;
      this.loading=false;
    });
  }

  /** Onchange Page **/
  onChangePage(event?: PageEvent) {
    this.paginate.size = event.pageSize;
    this.paginate.page = event.pageIndex;
    this.getPaginatedOrders(false);
    return event;
  }

  applyFilter(filter: any = "") {
    this.getPaginatedOrders(false, filter.trim());
  }

  sortData(event: Sort) {
    this.paginate.sort = event.active + ',' + event.direction;
    this.getPaginatedOrders();
  }

  transfer(event: MouseEvent, receipt, type: TransferType) {
    event.preventDefault();
    const transferObject: TransferObject = {
      type,
      sourceReceipt: receipt,
      count: type === 'CASE' ? receipt.iCases.length : receipt.items.length
    };

    if (transferObject.count) {
      this.transferService.initTransfer(transferObject);
    }
  }

  /**Expanded row Details */
  showExpandedDetails(row){
    this.loading = true;
    switch(row.quantityType) {
      case 'each':
        this.getSearchItems(row);
        break;
      case 'case':
        this.getSearchCases(row);
        break;  
    }
  }
 /**Item Details in Expanded Cell */
  getSearchItems(row){
    if(row.items.length != 0) {
            this.searchItem =new MatTableDataSource(row.items);
            this.searchItem.paginator = this.paginator; 
            this.totalCount = row.items.length;
            this.loading=false;
     }
  }

 /**Case Details in Expanded Cell */
  getSearchCases(row){
    if(row.iCases.length != 0) {
          this.searchItem =new MatTableDataSource(row.iCases);
          this.searchItem.paginator = this.paginator; 
          this.totalCount = row.iCases.length;
          this.loading=false;
    }
  }

  ngAfterViewInit() {
    this.searchItem.paginator = this.paginator;
  }
   /** On Change Page **/
   onChildChangePage(event?: PageEvent) {
    this.paginateChild.size = event.pageSize;
    this.paginateChild.page = event.pageIndex;
    this.searchItem.paginator = this.paginator; 
    return event;
  }
 
}
