import { Component, OnInit } from '@angular/core';
import { HelperService } from 'app/services/helper.service';
import { InventoryMngService } from '../services/inventory-mng.service';
import { VerificationService } from '../services/transfer.service copy';
import { Company } from 'app/models/company.model';

@Component({
  selector: 'app-inventory-verification',
  templateUrl: './inventory-verification.component.html',
  styleUrls: ['./inventory-verification.component.scss']
})
export class InventoryVerificationComponent implements OnInit {

  companies: Array<Company> = [];
  constructor(private verificationService: VerificationService) { }

  selectedCompany: Company = null;

  ngOnInit() {
    this.verificationService.getAllCompanies().subscribe((companies) => {
      this.companies = companies;
    });
  }
}
