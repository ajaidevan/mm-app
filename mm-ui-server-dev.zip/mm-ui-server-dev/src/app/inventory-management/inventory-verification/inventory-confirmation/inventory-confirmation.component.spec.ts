import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InventoryConfirmationComponent } from './inventory-confirmation.component';

describe('InventoryConfirmationComponent', () => {
  let component: InventoryConfirmationComponent;
  let fixture: ComponentFixture<InventoryConfirmationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InventoryConfirmationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InventoryConfirmationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
