import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { InventoryMngService } from 'app/inventory-management/services/inventory-mng.service';
import { FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-inventory-confirmation',
  templateUrl: './inventory-confirmation.component.html',
  styleUrls: ['./inventory-confirmation.component.scss']
})
export class InventoryConfirmationComponent implements OnInit {
  public gridType:any;
  constructor(private dialogRef: MatDialogRef<InventoryConfirmationComponent> ,@Inject(MAT_DIALOG_DATA) data,
  private fb:FormBuilder,private inventoryMngSrv:InventoryMngService) { 
    if(data){
      this.gridType = data;
    }
  }
  public clients:any[] = ['VIALOGIC','BIOLOGIC','METSON'];
  public selectedClient:any = 'VIALOGIC';
  public verificationForm = this.fb.group({
    reviewer : [''],
    comment : ['']
  })
  ngOnInit() {
  }

  submit(){
    this.inventoryMngSrv.sendVerifiedGrids(this.verificationForm.value);
    this.close();
  }
  close(){
    this.dialogRef.close(null)
  }
}
