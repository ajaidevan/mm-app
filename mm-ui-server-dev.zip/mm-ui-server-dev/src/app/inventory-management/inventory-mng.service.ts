import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Observable, BehaviorSubject } from 'rxjs';
import { InventoryMngModel } from 'app/models/inventory-mng.model';
import { CommonApiService } from 'app/services/common-api.service';
import { environment } from '../../environments/environment';



@Injectable(

)
export class InventoryMngService {

  private httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  };

  constructor(private http: HttpClient,private httpRequest:CommonApiService) { }
 

 //getreceivables
 getAllReceivables(paramObj?:any){
  return this.httpRequest.getRequestWithToken(environment.BASEURL + '/mm/receivables?status=MATERIAL_COUNT',paramObj)
}

//getCases
getCases(receivableId) {
  return this.httpRequest.getRequestWithToken(environment.BASEURL + '/mm/receivables/'+ receivableId +'/i-cases', {});
}
//getCaseItems
getICaseItems(caseId){
  return this.httpRequest.getRequestWithToken(environment.BASEURL + '/mm/i-cases/'+ caseId +'/items/', {});
}
//updateCases
updateICase(receivableId,cases) {
  return this.httpRequest.putRequest(environment.BASEURL + '/mm/receivables/'+ receivableId +'/i-cases',cases);
}

}
