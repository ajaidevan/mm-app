import { Component, OnInit, ViewChild } from '@angular/core';
import { MatSnackBar, } from '@angular/material';
import { ActivatedRoute, Router, NavigationStart } from '@angular/router';
import { TransferObject } from '../services/transfer.service';

/**
 * Add Items Page
 *
 * This page contains two main components
 * 1. Orders Table
 * 2. Inventory Explorer
 *
 * `TransferObject` lives here.
 *  It is received from Orders Table and passed down to the Inventory Explorer
 *
 */

@Component({
  selector: 'app-add-items',
  templateUrl: './add-items.component.html',
  styleUrls: ['./add-items.component.scss']
})
export class AddItemsComponent implements OnInit {


  constructor() {
  }

  ngOnInit() {

  }

}
