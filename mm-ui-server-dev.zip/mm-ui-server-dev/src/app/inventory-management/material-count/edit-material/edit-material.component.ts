import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { FormGroup, FormControl, Validators, FormGroupDirective, NgForm, AbstractControl } from '@angular/forms';
import { InventoryMngService } from '../../services/inventory-mng.service';
import { HelperService } from '../../../services/helper.service';
import { ErrorStateMatcher } from '@angular/material/core';

/*export class MyErrorStateMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = form && form.submitted;
    return (control && control.invalid);
  }
}*/


@Component({
  selector: 'app-edit-material',
  templateUrl: './edit-material.component.html',
  styleUrls: ['./edit-material.component.scss']
})
export class EditMaterialComponent implements OnInit {

  public quantityRemaining: any;
  public editMaterialForm = new FormGroup({
    count: new FormControl(''),
    suppliedTo: new FormControl('')
  });
  public errMsg: string;
  public buttonDisabled: boolean = false;
  // public errormatcher = new MyErrorStateMatcher();
  public inValidCount: boolean = false;
  constructor(private dialogRef: MatDialogRef<EditMaterialComponent>, @Inject(MAT_DIALOG_DATA) public dialogData: any,
    private inventoryMngService: InventoryMngService, public helper: HelperService) { }

  ngOnInit() {

  }


  /** CLOSE mat dialog **/
  close() {
    this.dialogRef.close(null);
  }
  checkCount() {
    if (this.editMaterialForm.get('count').value > this.dialogData.count) {
      this.inValidCount = true;
      this.buttonDisabled = true;
      this.errMsg = "*Sorry quantity is less";
    } else {
      this.errMsg = null;
      this.buttonDisabled = false;

    }
  }

  updateQuantity() {

    this.dialogData.count = this.dialogData.count - this.editMaterialForm.value.count;
    this.dialogData.comment = this.editMaterialForm.value.suppliedTo;
    if (this.editMaterialForm.valid || !this.inValidCount) {
      this.inventoryMngService.updateICase(this.dialogData).subscribe(res => {
        this.helper.showSnackbar('Updated Successfully');
        this.close();
      }, err => {
        console.log(err);
      });
    }
  }
}
