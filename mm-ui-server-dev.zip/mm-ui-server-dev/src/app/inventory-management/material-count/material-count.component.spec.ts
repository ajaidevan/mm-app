import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { MaterialCountComponent } from './material-count.component';

describe('MaterialCountComponent', () => {
  let component: MaterialCountComponent;
  let fixture: ComponentFixture<MaterialCountComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MaterialCountComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MaterialCountComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
