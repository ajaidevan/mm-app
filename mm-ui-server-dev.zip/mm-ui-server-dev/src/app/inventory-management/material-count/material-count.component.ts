import { Component, OnInit, ViewChild } from '@angular/core';
import { Observable } from 'rxjs';
import { MatPaginator, MatSort, MatDialog, MatTableDataSource, MatDialogConfig, PageEvent, Sort } from '@angular/material';
import { Router } from '@angular/router';
import { EditMaterialComponent } from './edit-material/edit-material.component';
import { InventoryMngModel } from 'app/models/inventory-mng.model';
import { CommonApiService } from 'app/services/common-api.service';
import { InventoryMngService } from '../services/inventory-mng.service';

@Component({
  selector: 'app-material-count',
  templateUrl: './material-count.component.html',
  styleUrls: ['./material-count.component.scss']
})
export class MaterialCountComponent implements OnInit {

  public displayedColumns: string[] = ['orderNo', 'itemName', 'item', 'count', 'createdBy', 'comment', 'modifiedAt', 'action'];
  public dataSource = new MatTableDataSource();
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  public totalMaterial: number = 0;
  public pageEvent: PageEvent;
  public pageSizeOptions: number[] = [10, 20, 30];
  public paginate: any = {};
  public receivable: any;
  public materialList: any = [];
  public totalCases: any = [];
  public totalItems: number;
  public paginateCases: any;
  public totalReceivable:number;
  constructor(private inventoryMngSrv: InventoryMngService, private dialog: MatDialog, private router: Router,
    private commonSrv: CommonApiService) { }

  ngOnInit() {
    this.setDefaultParam();
    //this.getReceivableWithCaseAndItem();
  }

  /** EDIT material **/
  onEditMaterial(newData?: any) {
    // this.inventoryMngSrv.setSharedCount(newData);
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.data = newData;

    let dialogRef = this.dialog.open(EditMaterialComponent, dialogConfig);
  }
  /** Set Default Params */
  setDefaultParam() {
    this.paginate = {
      page: 0,
      size: 10,
      sort: 'createdAt,DESC'
    };
    this.paginateMaterial(false);
  }


  /**paginate MaterialCount */
  paginateMaterial(setPage = true) {
    if (setPage) this.paginate.page = 0;
    let reqParams = this.commonSrv.createParam(this.paginate);
    this.router.navigate([], { queryParams: reqParams });
    this.inventoryMngSrv.getCases(reqParams).subscribe(res => {
      this.dataSource = new MatTableDataSource(res.body);
      this.receivable=res.body;
      this.totalReceivable = res.headers.get('X-Total-Count');
    });
  }

  /** On change Page */
  onChangePage(event?: PageEvent) {
    this.paginate.size = event.pageSize;
    this.paginate.page = event.pageIndex;
    this.paginateMaterial(false);
    return event;
  }

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim();
    filterValue = filterValue.toLowerCase();
    //TODO : Add filter
    // this.dataSource.filter = filterValue;
  };

}

