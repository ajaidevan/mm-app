import { Routes } from '@angular/router';
import { AdminLayoutComponent } from './layouts/admin/admin-layout.component';
import { AuthLayoutComponent } from './layouts/auth/auth-layout.component';
import { ActivateComponent } from './shared/activate/activate.component';
import { AuthGuard } from './services/guard/auth.guard';
import { RoleGuard } from './services/guard/role.guard';
import { ChangePasswordComponent } from './shared/change-password/change-password.component';

export const AppRoutes: Routes = [
  {
    path: '',
    redirectTo: '/authentication/login',
    pathMatch: 'full',
  }, {
    path: '',
    component: AdminLayoutComponent,
    children: [{
      path: 'home',
      loadChildren: './dashboard/dashboard.module#DashboardModule',
      canActivate: [AuthGuard]
    }, {
      path: 'super',
      loadChildren: './super-admin/admin.module#AdminModule',
      canActivate: [AuthGuard, RoleGuard],
      data: { roles: ['role_super_admin'] }
    }, {
      path: 'client',
      loadChildren: './client-admin/admin.module#AdminModule',
      canActivate: [AuthGuard, RoleGuard],
      data: { roles: ['role_client_admin'] }
    }, {
      path: 'admin',
      loadChildren: './admin/admin.module#AdminModule',
      canActivate: [AuthGuard,RoleGuard],
      data: { roles: ['Admin'] }
    }, {
      path: 'inventory-management',
      loadChildren: './inventory-management/inventory-management.module#InventoryManagementModule',
      canActivate: [AuthGuard,RoleGuard],
      data: { roles: ['Technician','QA'] }
    }, {
      path: 'audit-log',
      loadChildren: './audit-log/audit-log.module#AuditLogModule',
      canActivate: [AuthGuard,RoleGuard],
      data: { roles: ['Admin','role_client_admin'] }
    }, {
      path: 'adv-search',
      loadChildren: './adv-search/adv-search.module#AdvSearchModule',
      canActivate: [AuthGuard,RoleGuard],
      data: { roles: ['Admin','role_super_admin','Reviewer'] }
    }, {
      path: 'explore-inventory',
      loadChildren: './explore-inventory/explore-inventory.module#InventoryManagementModule',
      canActivate: [AuthGuard,RoleGuard],
      data: { roles: ['Technician','Reviewer','QA'] }
    }, {
      path: 'receipt',
      loadChildren: './receipt/receipt.module#ReceiptModule',
      canActivate: [AuthGuard,RoleGuard],
      data: { roles: ['QA','Technician'] }
    }, {
      path: 'change-password',
      component: ChangePasswordComponent,    
    }
  ]
  }, {
    path: 'user/activate',
    component: ActivateComponent
  }, {
    path: '',
    component: AuthLayoutComponent,
    children: [{
      path: 'authentication',
      loadChildren: './session/session.module#SessionModule',
      // canActivate:[LoggedInGuard]
    }, {
      path: 'error',
      loadChildren: './error/error.module#ErrorModule'
    }]
  }, {
    path: '**',
    redirectTo: 'error/404'
  }
];







