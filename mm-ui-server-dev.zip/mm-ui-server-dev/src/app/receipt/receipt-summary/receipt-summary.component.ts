import { Component, OnInit, Input, ChangeDetectorRef } from '@angular/core';
import { ValidatorService } from 'app/services/validator.service';
import { HelperService } from 'app/services/helper.service';
import { Router } from '@angular/router';
import { ReceiptService } from '../receipt.service';

@Component({
  selector: 'app-receipt-summary',
  templateUrl: './receipt-summary.component.html',
  styleUrls: ['./receipt-summary.component.scss']
})
export class ReceiptSummaryComponent implements OnInit {

  public receiptSummaryData: any;
  public fetchedCompany: any;
  public dimentions: any = { height: 1, width: 1 };
  public editMode: boolean = false;
  public totalCasesList: any;
  public receivable: any;
  public receiptMode: any;

  @Input() set receiptSummary(data: any) {
    if (data) {
      this.receiptSummaryData = data;
      this.receivable = data;
      this.receiptMode = data.receiptMode;
      if (this.receiptSummaryData.companyId) this.getCompany(this.receiptSummaryData.companyId);
      if (this.receiptSummaryData && this.receiptSummaryData.quantityType == 'case') {
        this.fetchCases();
      }
    }
  }

  constructor(private receiptService: ReceiptService, private cd: ChangeDetectorRef, private validatorService: ValidatorService,
    private helper: HelperService, private router: Router) { }

  ngOnInit() { }

  /** GET a company */
  getCompany(compId: any) {
    this.receiptService.getCompanyById(compId).subscribe(data => {
      this.fetchedCompany = data.body;
    }
    )
  }

  /**  Print Barcode for cases or items */
  printBarcode() {
    if (this.receiptSummaryData.quantityType == 'each')
      this.generateItemsBarcode();
    if (this.receiptSummaryData.quantityType == 'case') {
      this.generateICaseBarcode();
      this.totalCasesList.forEach(element => {
        this.generateBarcodeForItemsInICase(element.id);
      });
    }
    if (this.receiptSummaryData.receiptMode != 'receiving') {
      this.router.navigate(['/receipt/qa-receipt']);
    }
    else{
      this.router.navigate(['/receipt/receipt']);
    }
  }

  /** Generate Barcode for Items */
  generateItemsBarcode() {
    this.dimentions = JSON.parse(this.receivable.items[0].labelSize);
    if (this.dimentions !== 'N/A') {
      this.receiptService.generateItemsBarcode(this.receivable['id'], this.dimentions).subscribe(res => {
        if (res) {
          let file = new Blob([res], { type: 'application/pdf' });
          var fileURL = URL.createObjectURL(file);
          window.open(fileURL);
        }
      })
    }
  }

  /** Generate Barcode for Case */
  generateICaseBarcode() {
    if (this.dimentions !== 'N/A') {
      this.receiptService.generateICaseBarcode(this.receivable['id'], this.dimentions).subscribe(res => {
        if (res) {
          let file = new Blob([res], { type: 'application/pdf' });
          var fileURL = URL.createObjectURL(file);
          window.open(fileURL);
        }
      })
    }
  }

  /** Generate Barcode Items inside a case */
  generateBarcodeForItemsInICase(caseId) {
    if (this.dimentions !== 'N/A') {
      this.receiptService.generateIcaseItemsBarcode(caseId, this.dimentions).subscribe(res => {
        if (res) {
          let file = new Blob([res], { type: 'application/pdf' });
          var fileURL = URL.createObjectURL(file);
          window.open(fileURL);
        }
      })
    }
  }

  /**   Submit By Tech */
  submitByTech() {
    this.validatorService.userValidator('submit').then(res => {
      if (res.val) {
        delete res.val;
        if (this.receiptSummaryData.quantityType != 'case-w') {
          this.receivable.status = "APPROVED";
        } else {
          this.receivable.status = "MATERIAL_COUNT";
        }
        this.receiptService.updateReceivable(this.receivable, res).subscribe(res => {
          this.receivable = res;
          this.helper.showSnackbar('Submitted by Tech Successfully!');
          this.editMode = true;
          this.gotoAllReceiving();
        });
      }
    })
  }

  /** Navigate receipt home */
  gotoAllReceiving() {
    if (this.receiptSummaryData.qaNotified == false) {
      this.printBarcode();
    }
    this.router.navigate(['/receipt/receipt']);
  }

  /** Submit for Qa Approval */
  submitForQa() {
    this.receivable.status = "QA_PENDING"
    this.receiptService.updateReceivable(this.receivable).subscribe(res => {
      this.receivable = res;
      this.helper.showSnackbar('Submitted For QA Successfully!');
      this.editMode = true;
      this.router.navigate(['/receipt/receipt']);
    });
  }

  /** save as draft */
  saveAsDraft() {
    if (this.receiptSummaryData) {
      this.validatorService.userValidator(this.editMode ? 'update' : 'create').then(res => {
        if (res.val) {
          delete res.val;
          this.receivable.status = "DRAFT";
          this.receiptService.updateReceivable(this.receivable, res).subscribe(
            res => {
              if (res.status === "DRAFT") {
                this.router.navigateByUrl('/receipt/receipt');
              }
              this.helper.showSnackbar("Saved as Draft successfully");
            },
            err => { this.helper.showSnackbar(err.error.message, false, true); });
        }
      })
    } else {
      this.receivable.status = 'DRAFT';
      this.addNewReceivables();
    }
  }

  /** Add a new Receipt */
  addNewReceivables() {
    this.validatorService.userValidator(this.editMode ? 'update' : 'create').then(res => {
      if (res.val) {
        delete res.val;
        if (this.receiptSummaryData) {
          if (this.receiptSummaryData.quantityType == 'case-w') {
            this.receiptSummaryData.qaNotified = false;
            this.receiptSummaryData.recipientNotified = false;
          }
          this.receiptService.addNewReceivable(this.receiptSummaryData, res).subscribe(
            res => {
              if (res.status === "DRAFT") {
                this.router.navigateByUrl('/receipt/receipt');
              } else {
                this.receiptSummaryData = res;
                this.editMode = true;
              }
            },
            err => { },
          );
        }
      }
    })
  }

  /** Approved by QA */
  approvedByQA() {
    this.validatorService.userValidator('approve').then(res => {
      if (res.val) {
        delete res.val;
        this.receivable.status = "APPROVED";
        this.receiptService.updateReceivable(this.receivable, res).subscribe(res => {
          this.receivable = res;
          this.helper.showSnackbar("Approved Successfully")
          this.editMode = true;
        });
      }
    })
  }

  /** Get all Cases */
  fetchCases() {
    this.receiptService.getICases(this.receiptSummaryData.id).subscribe(res => {
      this.totalCasesList = res.body;
    })
  }

}
