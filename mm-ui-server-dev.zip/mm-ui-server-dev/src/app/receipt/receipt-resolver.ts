import{Injectable}from"@angular/core";
import{ ReceiptService }from './receipt.service';
import{Resolve,ActivatedRouteSnapshot,RouterStateSnapshot,Router,ActivatedRoute}from"@angular/router";
import{Observable, of, EMPTY}from"rxjs";
import { catchError, mergeMap } from "rxjs/operators";
import { CommonApiService } from 'app/services/common-api.service';
import { DataService } from "app/services/data.service";


@Injectable()
export class ReceptResolver implements Resolve<any> {
    constructor(private receiptService:ReceiptService , private commonSrv: CommonApiService,private dataSrv :DataService){}
    resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot):Observable<any>|Observable<never>{
        let reqParams = this.commonSrv.createParam(route.data['params']);
            return this.receiptService.getAllReceivablesByStatus(this.dataSrv.STATUS.ALL,reqParams).pipe(catchError(error   => {
                return EMPTY;
        }),
        mergeMap(response => {
                if (response) {
                return of(response); 

                } 
                else {
                return EMPTY;
                }
            })
        )
    }
}