import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { MatPaginator, MatSort, MatDialog, MatDialogConfig, MatTableDataSource, PageEvent, Sort } from '@angular/material';
import { Router, ActivatedRoute } from '@angular/router';
import { DamageToolTipComponent } from '../shared/damage-tool-tip/damage-tool-tip.component';
import { CommonApiService } from 'app/services/common-api.service';
import { ValidatorService } from 'app/services/validator.service';
import { DataService } from 'app/services/data.service';
import { ReceiptService } from './receipt.service';
import { Material } from 'app/models/material.model';

@Component({
  selector: 'app-receipt-list',
  templateUrl: './receipt-list.component.html',
  styleUrls: ['./receipt-list.component.scss'],
  encapsulation: ViewEncapsulation.None,
})

export class ReceiptListComponent implements OnInit {

  public receiptStatus: any = [];
  public displayedColumns: string[] = ['id', 'origin', 'vendorName', 'clientName', 'containerType', 'itemType', 'quantityType', 'qaNotified', 'recipientNotified', 'createdBy', 'createdAt', 'receivableDate', 'isDamaged', 'status', 'action'];
  public dataSource: MatTableDataSource<any>;
  public totalReceivable: number = 0;
  public totalDraft: number = 0;
  public pageEvent: PageEvent;
  public paginateDraft: any = {};
  public pageSizeOptions: number[] = [5, 10, 15];
  public paginateAll: any = {};
  public draftDataSource: MatTableDataSource<Material>;
  public loading: boolean = true;
  public receivableData: any;
  public receipt: any;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(private dialog: MatDialog, private receiptService: ReceiptService, private router: Router, private route: ActivatedRoute,
    private commonSrv: CommonApiService, private validatorService: ValidatorService, public dataSrv: DataService) {
    this.receiptStatus = this.dataSrv.STATUS.RECEIPT;
    this.draftDataSource = new MatTableDataSource;
  }

  ngOnInit() {
    this.setDefaultParam();
  }

  openCreateReceipt(newData?:any): void {
    if(newData){
      newData.receiptMode = 'receiving';
      this.receiptService.setSharedReceviable(newData);
      this.router.navigate(['/receipt/new-receipt']);
    } else {
      this.receiptService.setSharedReceviable('');
      this.router.navigate(['/receipt/new-receipt']);
    }
  }

  /** Remove Receipt from Receivable */
  onDeleteReceivable(receivable) {
    for (const index in this.receivableData) {
      if (receivable.id == this.receivableData[index]["id"]) {
        this.receivableData.splice(Number(index), 1)
        break;
      }
    }
  }

  /** Delete Receipt */
  onDeleteReceipt(receivable) {
    this.validatorService.userValidator('delete').then(res => {
      if (res.val) {
        delete res.val;
        this.receiptService.deleteReceivable(receivable, res).subscribe(res => {
          if (receivable.status == 'DRAFT') {
            this.receivableData = this.draftDataSource.data;
            this.onDeleteReceivable(receivable);
            this.draftDataSource.data = this.receivableData;
            this.paginateReceviable(false, this.dataSrv.STATUS.DRAFT, "draft", this.paginateDraft);
          }
          else {
            this.receivableData = this.dataSource.data;
            this.onDeleteReceivable(receivable);
            this.dataSource.data = this.receivableData;
            this.paginateReceviable(false, this.dataSrv.STATUS.ALL, "all", this.paginateAll);
          }
        });
      }
    })
  }

  /** open Damaged QTY **/
  damageQty(data) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true
    dialogConfig.data = {
      receivableData: data
    }
    let dialogRef = this.dialog.open(DamageToolTipComponent, dialogConfig)
  }

  /** Set Default Params */
  setDefaultParam() {
    this.paginateAll = {
      page: 0,
      size: 5,
      sort: 'createdAt,DESC'
    }
    this.paginateDraft = {
      page: 0,
      size: 5,
      sort: 'createdAt,DESC'
    }
    let reqParams = this.commonSrv.createParam(this.paginateAll);
    this.router.navigate([], { queryParams: reqParams });
    this.dataSource = new MatTableDataSource(this.route.snapshot.data['receipt'].body);
    this.totalReceivable = this.route.snapshot.data['receipt'].headers.get('X-Total-Count');
    this.paginateReceviable(false, this.dataSrv.STATUS.ALL, "all", this.paginateAll);
    this.paginateReceviable(false, this.dataSrv.STATUS.DRAFT, "draft", this.paginateDraft);
    this.loading = false;
  }

  /** Paginate Receviable */
  paginateReceviable(setPage = true, status, tableStatus, paginate) {
    if (tableStatus == 'all') {
      if (setPage) paginate.page = 0;
      let reqParams = this.commonSrv.createParam(this.paginateAll);
      this.router.navigate([], { queryParams: reqParams });
      this.receiptService.getAllReceivablesByStatus(status, reqParams).subscribe(res => {
        this.dataSource = new MatTableDataSource(res.body);
        this.totalReceivable = res.headers.get('X-Total-Count');
        this.loading = false
      })
    }

    if (tableStatus == "draft") {
      if (setPage) paginate.page = 0;
      let reqParams = this.commonSrv.createParam(this.paginateDraft);
      this.router.navigate([], { queryParams: reqParams });
      this.receiptService.getAllReceivablesByStatus(status, reqParams).subscribe(res => {
        this.draftDataSource = new MatTableDataSource(res.body);
        this.totalDraft = res.headers.get('X-Total-Count');
      })
    }

  }

  /** On change Page */
  onChangePage(event?: PageEvent) {
    this.paginateAll.size = event.pageSize;
    this.paginateAll.page = event.pageIndex;
    this.paginateReceviable(false, this.dataSrv.STATUS.ALL, "all", this.paginateAll);
    return event;
  }

  /** On change Page for draft*/
  onChangePageDraft(event?: PageEvent) {
    this.paginateDraft.size = event.pageSize;
    this.paginateDraft.page = event.pageIndex;
    this.paginateReceviable(false, this.dataSrv.STATUS.DRAFT, "draft", this.paginateDraft);
    return event;
  }

  /**  Receipt Status */
  showReceiptStatus(status) {
    let statusOb = this.dataSrv.STATUS.RECEIPT.find(o => o.value === status);
    return statusOb.status;
  }

  /*Sorting*/
  sortData(event: Sort, tableStatus) {
    if (tableStatus == "all") {
      this.paginateAll.sort = event.active + ',' + event.direction;
      this.paginateReceviable(false, this.dataSrv.STATUS.ALL, "all", this.paginateAll);
    }
    if (tableStatus == 'draft') {
      this.paginateDraft.sort = event.active + ',' + event.direction;
      this.paginateReceviable(false, this.dataSrv.STATUS.DRAFT, "draft", this.paginateDraft);
    }
  }

  /** SEARCH Receivable */
  search(filter, tableStatus) {
    if (tableStatus == 'all') {
      this.receiptService.searchReceivable(this.dataSrv.STATUS.ALL, filter).subscribe(res => {
        this.dataSource = new MatTableDataSource(res.body);
      })
    }
    if (tableStatus == 'draft') {
      this.receiptService.searchReceivable(this.dataSrv.STATUS.DRAFT, filter).subscribe(res => {
        this.draftDataSource = new MatTableDataSource(res.body);
      })
    }
  }

  /** Apply Filter */
  applyFilter(filter: any, tableStatus) {
    if (tableStatus == 'all' && filter.length > 2) {
      this.search(filter, tableStatus);
    }
    if (tableStatus == 'draft' && filter.length > 2) {
      this.search(filter, tableStatus);
    }
    if (tableStatus == 'all' && filter.length == 0) {
      this.paginateReceviable(false, this.dataSrv.STATUS.ALL, "all", this.paginateAll);
    }
    if (tableStatus == 'draft' && filter.length == 0) {
      this.paginateReceviable(false, this.dataSrv.STATUS.DRAFT, "draft", this.paginateDraft);
    }
  }

}
