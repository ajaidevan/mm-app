import { Component, OnInit, ViewChild, Inject, ElementRef } from '@angular/core';
import {  PageEvent, MatPaginator, MatSort, MatDialogRef, MAT_DIALOG_DATA, MatTableDataSource } from '@angular/material';
import { ReceiptService } from '../receipt.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

@Component({
  selector: 'app-total-case',
  templateUrl: './total-case.component.html',
  styleUrls: ['./total-case.component.scss']
})
export class TotalCaseComponent implements OnInit {
  public displayedColumns: string[] = ['caseNo', 'count'];
  public displayedColumnsCW: string[] = ['caseNo', 'count', 'name'];
  public countSource: string[] = ['data', 'data2'];
  public fieldsArr: any[] = [];
  public dataSource: any;
  public CaseNumber: any;
  public paginate: any = { page: 0, size: 10 };
  public totalCase: number;
  public dailogData: any;
  public pageEvent: PageEvent;
  public submittedFieldArr: any;
  public newCases: any[] = [];
  public updateStatus: string;
  public isNewItems: boolean = false;
  public iCaseHandler:any;
  public defaultItem: any = {
    labelSize: '', comment: '', orderNo: '', manufacturer: '', lotNo: '',
    batchNo: '', catalogNo: '', manufactureDate: '', expiryDate: '', type: 'client/vendor'
  };
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  
  constructor(private dialogRef: MatDialogRef<TotalCaseComponent>, private receiptSrv: ReceiptService,
    @Inject(MAT_DIALOG_DATA) dailogData, private elRef: ElementRef,private spinner:Ng4LoadingSpinnerService) {
    /** Verify Change in cases quantity */
    
      if (dailogData) {
        this.submittedFieldArr = dailogData.receivable.iCases ? dailogData.receivable.iCases : dailogData.caseList;
        this.dailogData = dailogData;
      }
      
    if (dailogData) {
      let fields: FieldData[] = [];
      let count = Number(dailogData.recivedQty);
      this.dailogData = dailogData;
      fields = (count) ? Array.apply(null, Array(count)).map(function (_, i) {
        return { caseNo: i, count: "", receivedCount: "", itemName: "" };
      }) : 0;
      this.fieldsArr = (dailogData.receivable.iCases) ? dailogData.receivable.iCases : fields ? fields : dailogData.caseList;
      if((dailogData.receivable.iCases || dailogData.receivable.iCase) || dailogData.caseList.length !== dailogData.recivedQty) {
        this.fieldsArr.forEach(icase=>{
          if(icase.items) icase.count = icase.items.length;
        })
        let count = this.dailogData.recivedQty - this.fieldsArr.length;
        let caseNo = (this.fieldsArr.length > 0) ? this.fieldsArr[this.fieldsArr.length - 1].caseNo : 0;
        if (count > 0) {
          this.addCases(count, caseNo);
        } else if (count < 0) {
          this.removeCase(this.fieldsArr.slice(this.dailogData.recivedQty));
        } else if (count == 0) {
          this.isNewItems = true;
        }
      }
      this.totalCase = fields.length;
      this.dataSource = new MatTableDataSource(fields);
    }
  }

  ngOnInit() {
    if (this.submittedFieldArr && this.dailogData.viewCaseMode) {
      this.fieldsArr = this.submittedFieldArr;
    }
  }
  async submit() {
    this.spinner.show();
    this.fieldsArr.map(obj => obj.receivedCount = obj.count);
    this.submittedFieldArr = this.fieldsArr;
    this.dailogData.viewCaseMode = true;
    if (this.dailogData.editMode && this.dailogData.receivable.id && (this.updateStatus == 'addCase' || (this.dailogData.receivable.iCases && this.dailogData.receivable.iCases.length == 0))) {
      let icases = this.newCases.length > 0 ? this.newCases : this.fieldsArr;
      this.receiptSrv.addNewICases(this.dailogData.receivable.id, icases).subscribe(res => { });
    } else if (this.dailogData.editMode && this.dailogData.receivable.id && this.updateStatus == 'removeCase') {
      if (await this.receiptSrv.confirm(this.newCases, "case")) {
        for (let c of this.newCases) {
          this.receiptSrv.deleteICase(c).subscribe(res => { })
          this.spinner.show();
        }
      };
    }
    this.addNewItemIcase(this.fieldsArr);
    this.removeItemICase(this.fieldsArr);
    this.dismiss();
  }

  // Set the paginator and sort after the view init.
  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  dismiss() {
    this.dailogData.receivable.iCase = this.fieldsArr
    this.dialogRef.close(this.dailogData);
  }

  /** On Change Page **/
  onChangePage(event?: PageEvent) {
    this.paginate.size = event.pageSize;
    this.paginate.page = event.pageIndex;
    return event;
  }

  /** Add aditional cases */
  addCases(count: number, caseNo: any) {
    this.updateStatus = "addCase";
    for (let i = 0; i < count; i++) {
      caseNo = (caseNo == 0) ? caseNo + i : caseNo + 1;
      this.fieldsArr.push({ caseNo: caseNo, count: "", receivedCount: "", itemName: "" });
    }
    this.newCases = this.fieldsArr.slice(this.dailogData.recivedQty - count);
  }
  /** Remove cases */
  removeCase(cases) {
    this.newCases = cases;
    this.updateStatus = "removeCase";
  }

  /** Add new Items in Case */
  async addNewItemIcase(data) {
    if(this.dailogData.receivable.id) {
      await this.receiptSrv.getICases(this.dailogData.receivable.id).subscribe(res => {
        this.iCaseHandler = res.body;
        this.iCaseHandler.forEach((ele1,i) =>{
          if( ele1.id == data[i].id) {
            ele1.receivedCount = data[i].receivedCount;
          }
          return ele1;
        })
        this.addItems(this.iCaseHandler);
        })
    }
  }

  removeItemICase(data) {
    if (data) {
      let item: any = [];
      data.forEach(ele => {
        if (ele.items && (ele.items.length > ele.receivedCount))
          item.push(ele);
      })
      if (item.length > 0) {
        let newItems: any = [];
        for (let index in item) {
          if (item[index].items.length > item[index].receivedCount)
            newItems = item[index].items.slice(item[index].receivedCount);
          newItems.forEach(ele => {
            this.receiptSrv.deleteItem(ele).subscribe(res => { })
          })
          newItems = [];
        }
      }
    }
  }
  /** Sub method for Add new Items in Case */
  addItems(data){
    let item: any = [];
    if (data && this.dailogData.receivable.id) {
      data.forEach(ele => {
        if (ele.items && (ele.receivedCount > ele.items.length))
          item.push(ele);
      })
      if (item.length > 0) {
        let newItems = [];
        for (let index in data) {
          for (let innerIndex in item) {
            if (data[index].id == item[innerIndex].id) {
              for (let i = 0; i < item[innerIndex].receivedCount - item[innerIndex].items.length; i++) {
                newItems.push({
                  labelSize: '', comment: '', orderNo: '', manufacturer: '', lotNo: '',
                  batchNo: '', catalogNo: '', manufactureDate: '', expiryDate: '', type: 'client/vendor'
                });
              }
              this.receiptSrv.addNewICaseItems(item[innerIndex].id, newItems).subscribe(res => { })
            }
          }
        }
      }
    }
  }
}

export interface FieldData {
  id: string;
  caseNo: string;
  count: string;
  receivedCount: string;
}