import { Component, OnInit, Inject } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { FrontValidationService } from 'app/services/front-validation/front-validation.service';
import { PatternValidationService } from 'app/services/front-validation/pattern-validation.service';
import { ReceiptService } from '../receipt.service';
import {DatePipe} from '@angular/common';

@Component({
  selector: 'app-material-info',
  templateUrl: './material-info.component.html',
  styleUrls: ['./material-info.component.scss']
})

export class MaterialInfoComponent implements OnInit {

  public labels = ["Big Barcode (2.5*1)", "Small Barcode (1.5*1)"];
  public data: any = {
    recivedQty: 0,
    qaNotified: 0
  };
  public confirmSubmit: boolean = false;
  public editMode: boolean = false;
  public multiSelectMode: boolean = false;
  public materialInfoValMsg: string;
  public isValidDate: boolean = false;
  public message: string;
  public currentDate: any = new Date();
  public expirationDate: any;
  public barcodes: any;
  public barcodeSize: any; 
  public isExpiryDate:boolean = false;

  constructor(private dialogRef: MatDialogRef<MaterialInfoComponent>, @Inject(MAT_DIALOG_DATA) data, private fb: FormBuilder,
    private receiptSrv: ReceiptService, private frontValSrv: FrontValidationService, public patternValSrv: PatternValidationService,
    private datePipe: DatePipe) {
    if (data) {
      this.data.recivedQty = data.recivedQty;
      this.data.qaNotified = data.qaNotified;
      this.data.caseNo = data.caseNo;
      this.data.type = data.type;
      //for multi select and update.
      this.multiSelectMode = data.multiSelectMode;
      if (data.caseData) {
        this.barcodeSize = (data.caseData.labelSize) ? JSON.parse(data.caseData.labelSize) : null;
        this.addMaterialForm.patchValue(data.caseData);
        this.addMaterialForm.get('labelSize').setValue(this.barcodeSize);
        this.editMode = true;
      }
    }
  }

  ngOnInit() {
    this.materialInfoValMsg = this.frontValSrv.validationMsg;
    this.getAllBarcodes();
  }

  public addMaterialForm = this.fb.group({
    id: [''],
    barcodes: [],
    damages: [],
    labelSpecs: [],
    labelSize: [''],
    comment: [''],
    orderNo: [''],
    manufacturer: ['', [Validators.required, Validators.maxLength(50)]],
    lotNo: [''],
    batchNo: [''],
    catalogNo: [''],
    manufactureDate: [''],
    expiryDate: [''],
    replicate: [false],
    type: ['client/vendor'],
    description: ['']
  })

  /** Get All Barcodes */
  getAllBarcodes() {
    this.receiptSrv.getAllBarcodes().subscribe(res => {
      this.barcodes = res.body;
      this.barcodes.push('N/A');
      if (this.barcodeSize) {
        for (let index in this.barcodes) {
          if (this.barcodes[index].id == this.barcodeSize.id) {
            this.barcodes.splice(index, 1);
          }
        }
        this.barcodes.push(this.barcodeSize);
      }
    })
  }

  /** CLOSE mat dialog **/
  close() {
    this.dialogRef.close(null);
  }
  dateFormat(){
    this.addMaterialForm.controls['manufactureDate'].patchValue( this.datePipe.transform(this.addMaterialForm.get('manufactureDate').value,'yyyy-MM-dd'));
    this.addMaterialForm.controls['expiryDate'].patchValue( this.datePipe.transform(this.addMaterialForm.get('expiryDate').value,'yyyy-MM-dd'));
  }

  /** Add material info */
  createMaterials(replicate) {
    this.addMaterialForm.get('labelSize').patchValue(JSON.stringify(this.addMaterialForm.get('labelSize').value));
    this.dateFormat();
    this.addMaterialForm.get('replicate').patchValue(replicate);
    if (this.addMaterialForm.valid) {
      this.addMaterialForm.value.editMode = this.editMode;
      this.dialogRef.close(this.addMaterialForm.value);
    }
  }

  /** Update materila info */
  updateMaterial(replicate) {
    this.addMaterialForm.get('labelSize').patchValue(JSON.stringify(this.addMaterialForm.get('labelSize').value));
    this.dateFormat();
    if (this.addMaterialForm.valid) {
      this.addMaterialForm.value.editMode = this.editMode;
      this.dialogRef.close(this.addMaterialForm.value);
    }
  }

  /** Update multi material info */
  updateMultiMaterial() {
    this.addMaterialForm.get('labelSize').patchValue(JSON.stringify(this.addMaterialForm.get('labelSize').value));
    this.dateFormat();
    if (this.addMaterialForm.valid) {
      this.addMaterialForm.value.editMode = this.editMode;
      this.addMaterialForm.value.multiSelectMode = this.multiSelectMode;
      this.dialogRef.close(this.addMaterialForm.value);
    }
  }

  /** Expiration Date Validation */
  expirationDateVal() {
    this.expirationDate = this.addMaterialForm.get('manufactureDate').value;
    let newExpiryDate = this.addMaterialForm.get('expiryDate').value
    if(this.convertDate(newExpiryDate) < this.convertDate(this.expirationDate))  
          this.isExpiryDate = true;
    if(this.convertDate(newExpiryDate) > this.convertDate(this.expirationDate)) 
          this.isExpiryDate = false;
  }

  convertDate(date) {
    return this.datePipe.transform(date,'yyyy-MM-dd')
  }
}
