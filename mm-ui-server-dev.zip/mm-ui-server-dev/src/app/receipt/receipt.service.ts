import { Injectable } from '@angular/core';
import { HttpHeaders } from '@angular/common/http';
import { BehaviorSubject, Observable} from 'rxjs';
import { CommonApiService } from 'app/services/common-api.service';
import { environment } from '../../environments/environment';
import { HelperService } from '../services/helper.service';
import Swal from 'sweetalert2';

@Injectable()

export class ReceiptService {

  private sharableReceivable = new BehaviorSubject("");
  public sharedReceivable = this.sharableReceivable.asObservable();

  private createdDamageCases = new BehaviorSubject('');
  public createdTotalDamageCases = this.createdDamageCases.asObservable();

  constructor(private httpRequest: CommonApiService,private helper: HelperService) { }

  sendTotalDamageCases(cases) {
    this.createdDamageCases.next(cases);
  }

  /** SET shared receviable */
  setSharedReceviable(receviableObj) {
    this.sharableReceivable.next(receviableObj);
  }

  getAllReceivablesByStatus(status,paramObj?:any){
    return this.httpRequest.getRequestWithToken(environment.BASEURL + `/mm/receivables/summary?status=${status}&locationId=${this.helper.getLocation()}`,paramObj);
  }
  getAll(){
    return this.httpRequest.getRequestWithToken(environment.BASEURL + '/mm/receivables',{});
  }
  getAllBarcodes(){
    return this.httpRequest.getRequestWithToken(environment.BASEURL + '/mm/barcodes',{});
  }

  addNewReceivable(receivables,header?) {
    return this.httpRequest.postRequest(environment.BASEURL + '/mm/receivables', receivables,header);
  }

  updateReceivable(receivables,header?) {
    return this.httpRequest.putRequest(environment.BASEURL + '/mm/receivables/',receivables,header);
  }

  deleteReceivable(receivables: any, headers:any) {
    return this.httpRequest.deleteReqeust(environment.BASEURL + '/mm/receivables/' + receivables.id, receivables,headers);
  }
  searchReceivable(status,filterValue?: string){
    return this.httpRequest.getRequestWithToken(environment.BASEURL + '/mm/receivables/summary?status='+status+'&locationId='+this.helper.getLocation()+'&query=' + filterValue, {});
  }
  getDraftRceivables(paramObj?:any){
    return this.httpRequest.getRequestWithToken(environment.BASEURL + '/mm/receivables?status=DRAFT',{});
  }
  
  // items
  getItems(receivableId) {
    return this.httpRequest.getRequestWithToken(environment.BASEURL + '/mm/receivables/'+ receivableId +'/items',{})
  }
  addNewItems(receivableId,item) {
    return this.httpRequest.postRequest(environment.BASEURL + '/mm/receivables/'+ receivableId +'/items', item);
  }

  updateItems(receivableId,item) {
    return this.httpRequest.putRequest(environment.BASEURL + '/mm/receivables/'+ receivableId +'/items', item);
  }
  updateItem(item) {
    return this.httpRequest.putRequest(environment.BASEURL + '/mm/items',item);
  }
  deleteItem(item: any) {
    return this.httpRequest.deleteReqeust(environment.BASEURL + '/mm/items/' + item.id, item);
  }
  getICaseItems(caseId){
    return this.httpRequest.getRequestWithToken(environment.BASEURL + '/mm/i-cases/'+ caseId +'/items/', {});
  }
  generateItemsBarcode(receivableId,dimentions,header?){
    return this.httpRequest.getImage(environment.BASEURL + '/mm/receivables/' + receivableId +
    '/items/barcodes'+'?height='+dimentions.height+'&width='+dimentions.width,{},header);
  }
  generateICaseBarcode(receivableId,dimentions,header?){
    return this.httpRequest.getImage(environment.BASEURL + '/mm/receivables/' + receivableId +'/i-cases/barcodes'+
    '?height='+dimentions.height+'&width='+dimentions.width,{},header);
  }
  generateIcaseItemsBarcode(caseId,dimentions,header?){
    return this.httpRequest.getImage(environment.BASEURL + '/mm/i-cases/' + caseId +'/items/barcodes'+
    '?height='+dimentions.height+'&width='+dimentions.width,{},header);
  }
  //cases
  getICases(receivableId,paramObj?) {
    return this.httpRequest.getRequestWithToken(environment.BASEURL + '/mm/receivables/'+ receivableId +'/i-cases', paramObj);
  }
  addNewICases(receivableId,cases) {
    return this.httpRequest.postRequest(environment.BASEURL + '/mm/receivables/'+ receivableId +'/i-cases', cases);
  }

  updateICase(receivableId,cases) {
    return this.httpRequest.putRequest(environment.BASEURL + '/mm/receivables/'+ receivableId +'/i-cases',cases);
  }

  deleteICase(cases: any) {
    return this.httpRequest.deleteReqeust(environment.BASEURL + '/mm/i-cases/' + cases.id, cases);
  }

  addNewICaseItems(caseId,items) {
    return this.httpRequest.postRequest(environment.BASEURL + '/mm/i-cases/'+ caseId +'/items', items);
  }
  
  updateICaseItems(caseId,items) {
    return this.httpRequest.putRequest(environment.BASEURL + '/mm/i-cases/'+ caseId +'/items', items);
  }
 /**GET All companies */
 getAllCompanies(paramObj?:any): Observable<any>{
  return this.httpRequest.getRequestWithToken(environment.BASEURL + `/auth/company/?tenant=${this.helper.getTenantId()}`,paramObj);
 }

 /**GET company */
 getCompanyById(compId?:any): Observable<any>{
  return this.httpRequest.getRequestWithToken(environment.BASEURL + `/auth/company/${compId}?tenant=${this.helper.getTenantId()}`,{});
 }

 /**POST companies */
 addCompanies(company){
  return this.httpRequest.postRequest(environment.BASEURL +'/auth/company',company)
 }

 /** Update Icase */
 updateICaseById(icase){
  return this.httpRequest.putRequest(environment.BASEURL + '/mm/i-cases/' + icase.id, icase);
 }

  /** Confirmation Pop up */
  confirm(cases,type){
    let caseId;
    cases.forEach(items=>{
      caseId = items.id;
    })
    if(caseId){
      let res= (type=='case') ? `Deleting Cases ${cases.map(c => (c.caseNo+1) )} ` : `Deleting Items with Sr No. ${cases.map(c => (c.id) )}`;
      return Swal.fire({
        html: `<span style="font-weight:500ld">
                This action will Remove cases and items automatically <br> If receipt quantity changed.
                </span><br><br>
                <hr><br>
                <span> ${res}</span>`,
        showCloseButton: true,
        showCancelButton: true,
        showConfirmButton: true
      }).then(res=>{
        return res.value;
      })
    }
  }
}
