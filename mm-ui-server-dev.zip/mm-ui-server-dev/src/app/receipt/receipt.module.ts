import { NgModule, forwardRef } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule, DatePipe } from '@angular/common';
import { MatIconModule, MatCardModule, MatButtonModule, MatListModule, MatProgressBarModule, MatMenuModule, MatFormFieldModule, MatInputModule, MatRippleModule, MatSelectModule, MatSortModule, MatTableModule, MatPaginatorModule, MatRadioModule, MatCheckboxModule, MatDatepickerModule, MatDialogModule, NativeDateAdapter, DateAdapter, MatStepperModule } from '@angular/material';
import { FlexLayoutModule } from '@angular/flex-layout';
import { ChartsModule } from 'ng2-charts/ng2-charts';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import {MatTooltipModule} from '@angular/material/tooltip';
import { Ng2CarouselamosModule } from 'ng2-carouselamos';
import { DataService } from 'app/services/data.service';
import { SharedModule } from 'app/shared/shared.module';
import { OwlDateTimeModule, OwlNativeDateTimeModule } from 'ng-pick-datetime';
import { ReceiptRoute } from './receipt.routing';
import { NewReceiptComponent } from './new-receipt/new-receipt.component';
import { ReceiptInfoComponent } from './receipt-info/receipt-info.component';
import { MaterialInfoComponent } from './material-info/material-info.component';
import { DamageInfoComponent } from './damage-info/damage-info.component';
import { ReceiptSummaryComponent } from './receipt-summary/receipt-summary.component';
import { TotalCaseComponent } from './total-case/total-case.component';
import { CaseInfoComponent } from './case-info/case-info.component';
import { ReceiptListComponent } from './receipt-list.component';
import { ReceiptService } from './receipt.service';
import { ReceptResolver } from './receipt-resolver';
import { QaApprovalListComponent } from './qa-approval-list.component';


@NgModule({
  declarations: [
    NewReceiptComponent,
    ReceiptInfoComponent,
    MaterialInfoComponent,
    DamageInfoComponent,
    ReceiptSummaryComponent,
    TotalCaseComponent,
    CaseInfoComponent,
    ReceiptListComponent,
    QaApprovalListComponent
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(ReceiptRoute),
    MatFormFieldModule,
    MatInputModule,
    MatIconModule,
    MatCardModule,
    MatButtonModule,
    MatListModule,
    MatProgressBarModule,
    MatMenuModule,
    ChartsModule,
    NgxChartsModule,
    NgxDatatableModule,
    FlexLayoutModule,
    FormsModule,
    ReactiveFormsModule,
    MatSelectModule,
    MatSortModule,
    MatTableModule,
    MatPaginatorModule,
    MatRadioModule,
    MatCheckboxModule,
    MatDatepickerModule,
    MatDialogModule,
    MatCardModule,
    MatTooltipModule,
    MatStepperModule,
    Ng2CarouselamosModule,
    SharedModule,
    OwlDateTimeModule, 
    OwlNativeDateTimeModule,
  ],
  
  providers: [
    ReceiptService,
    DataService,
    ReceptResolver,
    DatePipe
    // { provide: DateAdapter, useClass: NativeDateAdapter },ReceivingResolver,DataService
  ],
  entryComponents: [ MaterialInfoComponent,TotalCaseComponent],
})
export class ReceiptModule { }
