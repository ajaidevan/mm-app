import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogConfig, MatTableDataSource, PageEvent, Sort } from '@angular/material';
import { ViewInfoComponent } from 'app/shared/view-info/view-info.component';
import { CommonApiService } from 'app/services/common-api.service';
import { Router } from '@angular/router';
import { HelperService } from 'app/services/helper.service';
import { DataService } from 'app/services/data.service';
import { QAApprovalModal } from 'app/models/qa-approval-model';
import { ValidatorService } from 'app/services/validator.service';
import { DamageToolTipComponent } from 'app/shared/damage-tool-tip/damage-tool-tip.component';
import { ReceiptService } from './receipt.service';
import { Material } from 'app/models/material.model';

@Component({
  selector: 'app-qa-approval-list',
  templateUrl: './qa-approval-list.component.html',
  styleUrls: ['./qa-approval-list.component.scss']
})
export class QaApprovalListComponent implements OnInit {

  public displayedColumns: string[] = ['receiptNo', 'origin', 'vendorName', 'containerType', 'itemType', 'quantityType', 'qaNotified', 'recipientNotified', 'createdBy', 'createdAt', 'receivableDate', 'isDamage', 'status', 'action']
  public dataSource: MatTableDataSource<Material>;
  public selected: string = 'option2';
  public qaDataSource = new MatTableDataSource();
  public releaseDataSource = new MatTableDataSource();
  public paginateApproved: any = {};
  public paginateApproval: any = {};
  public paginateSubmitted: any = {};
  public totalReceivable;
  public totalApproved;
  public totalSubmitted;
  public pageEvent: PageEvent;
  public pageSizeOptions: number[] = [5, 10, 15];
  public receiptStatus: any = [];
  public selectedRow: QAApprovalModal;
  public receivableData: any;
  constructor(private dialog: MatDialog, private commonSrv: CommonApiService,
    private receiptService: ReceiptService, private validatorService: ValidatorService, private router: Router,
    private helper: HelperService, public dataSrv: DataService) {
    this.receiptStatus = this.dataSrv.STATUS.RECEIPT;
  }

  ngOnInit() {
    this.setDefaultParam();
  }

  /** open VIEW INFO **/
  openViewMode(selectedRow: QAApprovalModal) {
    this.selectedRow = selectedRow;
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.data = {
      'selectedValue': this.selectedRow,
      'tableColumns': this.displayedColumns,
      'columnName': ['Receipt No', 'Origin', 'Vendor', 'Container Type', 'Item Type', 'Quantity Type', 'QaNotified', 'Recipient Notified', 'Created By', 'Created At', 'Receivable Date', 'Damaged', 'Status'],
      "component": "Qa Approval",
      "mode": true
    };
    let dialogRef = this.dialog.open(ViewInfoComponent, dialogConfig);
  };

  onDeleteReceivable(receivable) {
    for (const index in this.receivableData) {
      if (receivable.id == this.receivableData[index]["id"]) {
        this.receivableData.splice(Number(index), 1)
        break;
      }
    }
  }

  /*Delete-Receipt*/
  onDeleteReceipt(receivable) {
    this.validatorService.userValidator('delete').then(res => {
      if (res.val) {
        delete res.val;
        this.receiptService.deleteReceivable(receivable, res).subscribe(res => {
          if (receivable.status == 'APPROVED') {
            this.receivableData = this.qaDataSource.data;
            this.onDeleteReceivable(receivable);
            this.qaDataSource.data = this.receivableData;
            this.paginateReceviable(false, this.dataSrv.STATUS.APPROVED, "approved", this.paginateApproved)
          }
          if (receivable.status == 'SHIPPED') {
            this.receivableData = this.releaseDataSource.data;
            this.onDeleteReceivable(receivable);
            this.releaseDataSource.data = this.receivableData;
            this.paginateReceviable(false, this.dataSrv.STATUS.SHIPPED, "submitted", this.paginateSubmitted)
          }
          else {
            this.receivableData = this.dataSource.data;
            this.onDeleteReceivable(receivable);
            this.dataSource.data = this.receivableData;
            this.paginateReceviable(false, this.dataSrv.STATUS.QA_PENDING, "awaiting", this.paginateApproval);
          }
        });
      }
    })
  }

  /**  Receipt Status */
  showReceiptStatus(status) {
    let statusOb = this.dataSrv.STATUS.RECEIPT.find(o => o.value === status);
    return statusOb.status;
  }

  /** Set Default Params */
  setDefaultParam() {
    this.paginateApproval = {
      page: 0,
      size: 5,
      sort: 'createdAt,DESC'
    }
    this.paginateApproved = {
      page: 0,
      size: 5,
      sort: 'createdAt,DESC'
    }
    this.paginateSubmitted = {
      page: 0,
      size: 5,
      sort: 'createdAt,DESC'
    }
    this.paginateReceviable(false, this.dataSrv.STATUS.QA_PENDING, "awaiting", this.paginateApproval);
    this.paginateReceviable(false, this.dataSrv.STATUS.APPROVED, "approved", this.paginateApproved)
    this.paginateReceviable(false, this.dataSrv.STATUS.SHIPPED, "submitted", this.paginateSubmitted)
  }

  /** Paginate Receviable */
  paginateReceviable(setPage = true, status, tableStatus, paginate) {
    if (tableStatus == 'awaiting') {
      if (setPage) paginate.page = 0;
      let reqParams = this.commonSrv.createParam(this.paginateApproval);
      this.router.navigate([], { queryParams: reqParams });
      this.receiptService.getAllReceivablesByStatus(status, reqParams).subscribe(res => {
        this.dataSource = new MatTableDataSource(res.body);
        this.totalReceivable = res.headers.get('X-Total-Count');
      })
    }
    if (tableStatus == 'approved') {
      if (setPage) paginate.page = 0;
      let reqParams = this.commonSrv.createParam(this.paginateApproved);
      this.router.navigate([], { queryParams: reqParams });
      this.receiptService.getAllReceivablesByStatus(status, reqParams).subscribe(res => {
        this.qaDataSource = new MatTableDataSource(res.body);
        this.totalApproved = res.headers.get('X-Total-Count');
      })
    }
    if (tableStatus == 'submitted') {
      if (setPage) paginate.page = 0;
      let reqParams = this.commonSrv.createParam(this.paginateSubmitted);
      this.router.navigate([], { queryParams: reqParams });
      this.receiptService.getAllReceivablesByStatus(status, reqParams).subscribe(res => {
        this.releaseDataSource = new MatTableDataSource(res.body);
        this.totalSubmitted = res.headers.get('X-Total-Count');
      })
    }

  }

  /** On change Page */
  onChangePage(event?: PageEvent) {
    this.paginateApproval.size = event.pageSize;
    this.paginateApproval.page = event.pageIndex;
    this.paginateReceviable(false, this.dataSrv.STATUS.QA_PENDING, "awaiting", this.paginateApproval);
    return event;
  }

  /** On change Page for QA_Approved */
  onChangePageQAApproved(event?: PageEvent) {
    this.paginateApproved.size = event.pageSize;
    this.paginateApproved.page = event.pageIndex;
    this.paginateReceviable(false, this.dataSrv.STATUS.APPROVED, "approved", this.paginateApproved);
    return event;
  }
  /**On change Page for QA-release */
  onChangePageQAReleased(event?: PageEvent) {
    this.paginateSubmitted.size = event.pageSize;
    this.paginateSubmitted.page = event.pageIndex;
    this.paginateReceviable(false, this.dataSrv.STATUS.SHIPPED, "submitted", this.paginateSubmitted);
    return event;
  }

  /** Edit receipt by QA */
  onEditReceipt(newData?: any): void {
    if (newData) {
      newData.receiptMode = 'qa-approval';
      this.receiptService.setSharedReceviable(newData);
      this.router.navigate(['/receipt/new-receipt']);
    }
  }
  
  /*Sorting*/
  sortData(event: Sort, tableStatus) {
    if (tableStatus == 'awaiting') {
      this.paginateApproval.sort = event.active + ',' + event.direction;
      this.paginateReceviable(false, this.dataSrv.STATUS.QA_PENDING, "awaiting", this.paginateApproval);
    }
    if (tableStatus == 'approved') {
      this.paginateApproved.sort = event.active + ',' + event.direction;
      this.paginateReceviable(false, this.dataSrv.STATUS.APPROVED, "approved", this.paginateApproved);
    }
    if (tableStatus == 'submitted') {
      this.paginateSubmitted.sort = event.active + ',' + event.direction;
      this.paginateReceviable(false, this.dataSrv.STATUS.SHIPPED, "submitted", this.paginateSubmitted);
    }
  }

  /** SEARCH Receivable */
  searchReceivables(filter: any, tableStatus) {
    if (tableStatus == 'awaiting') {
      this.receiptService.searchReceivable(this.dataSrv.STATUS.QA_PENDING, filter).subscribe(res => {
        this.dataSource = new MatTableDataSource(res.body);
      })
    }
    if (tableStatus == 'approved') {
      this.receiptService.searchReceivable(this.dataSrv.STATUS.APPROVED, filter).subscribe(res => {
        this.qaDataSource = new MatTableDataSource(res.body);
      })
    }
    if (tableStatus == 'submitted') {
      this.receiptService.searchReceivable(this.dataSrv.STATUS.SHIPPED, filter).subscribe(res => {
        this.releaseDataSource = new MatTableDataSource(res.body);
      })
    }
  }

  /** Apply Filter */
  applyFilter(filter: any, tableStatus) {
    if (tableStatus == 'awaiting' && filter.length > 2) {
      this.searchReceivables(filter, tableStatus);
    }
    if (tableStatus == 'approved' && filter.length > 2) {
      this.searchReceivables(filter, tableStatus);
    }
    if (tableStatus == 'submitted' && filter.length > 2) {
      this.searchReceivables(filter, tableStatus);
    }
    if (tableStatus == 'awaiting' && filter.length == 0) {
      this.paginateReceviable(false, this.dataSrv.STATUS.QA_PENDING, "awaiting", this.paginateApproval);
    }
    if (tableStatus == 'approved' && filter.length == 0) {
      this.paginateReceviable(false, this.dataSrv.STATUS.APPROVED, "approved", this.paginateApproved);
    }
    if (tableStatus == 'submitted' && filter.length == 0) {
      this.paginateReceviable(false, this.dataSrv.STATUS.SHIPPED, "submitted", this.paginateSubmitted);
    }
  }
  /** open Damaged QTY **/
  damageQty(data) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true
    dialogConfig.data = {
      receivableData: data
    }
    let dialogRef = this.dialog.open(DamageToolTipComponent, dialogConfig)
  }
}
