import { Component, OnInit, ChangeDetectorRef, Output, EventEmitter, ViewChild, Input, ViewChildren, QueryList } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HelperService } from 'app/services/helper.service';
import { MatDialog, MatTableDataSource, MatPaginator, MatSort, MatDialogConfig, PageEvent, } from '@angular/material';
import { DamageBoxComponent } from 'app/shared/damage-box/damage-box.component';
import { SelectionModel } from '@angular/cdk/collections';
import { ReceiptService } from '../receipt.service';
import { Material } from 'app/models/material.model';
import { CommonApiService } from 'app/services/common-api.service';

@Component({
  selector: 'app-damage-info',
  templateUrl: './damage-info.component.html',
  styleUrls: ['./damage-info.component.scss']
})

export class DamageInfoComponent implements OnInit {
  public damageInfoForm: FormGroup;
  public receiptInfoData: any;
  public materialList: any;
  public damagelist: any = [];
  public totalCasesList: any;
  public totalMaterial: number = 0;
  public listOfItems = [];
  public editMode: boolean = false;
  public damagedComment: any;
  public dimentions: any;
  public paginate: any = { page: 0, size: 10 };
  public selection = new SelectionModel(true, []);
  public caseInfoData: any;
  public damagedColumns: string[] = ['srno', 'label_size', 'manufacturer', 'lotNo', 'batchNo', 'itemNo', 'action'];
  public dataSource: MatTableDataSource<Material>;
  public isCaseSelected: boolean = false;
  public caseList:any={}
  public paginateCases : any = { };
  public caseIndex:number;
  public checkPageNo:number;
  public loading:boolean = false;
  public damageCount:number;

  @Output() damageInfoData = new EventEmitter();
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChildren('damageCheckBox') private damageCheckBoxes: QueryList<any>;

  @Input() set receiptWithDamageInfoData(data: any) {
    this.receiptInfoData = data;
    if (this.receiptInfoData) {
      this.editMode = true;
      if (this.receiptInfoData && this.receiptInfoData.quantityType == "case") {
        this.setDefaultParam();
        this.setQuantity(this.receiptInfoData.quantity);
      }
      if (this.receiptInfoData && this.receiptInfoData.quantityType == "each") {
        this.getItems();
      }
      if (this.receiptInfoData.receiptMode) {
        this.damageInfoForm.controls['isDamage'].patchValue(this.receiptInfoData.isDamage)
      }
    }
  }

  constructor(private helper: HelperService, private _formBuilder: FormBuilder, private cd: ChangeDetectorRef,
    private receiptService: ReceiptService, private dialog: MatDialog,private commonSrv:CommonApiService) { }

  ngOnInit() {

    /** Damage Info Form */
    this.damageInfoForm = this._formBuilder.group({
      isDamage: ['', Validators.required],
      count: [''],
      comment: ['']
    })
    this.resetDamageValidation();
  }

  /** Continoue */
  continue(data) {
    this.damageInfoData.emit(data)
  }

  /** navigate to DAMAGE BOX **/
  damageBox() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.data = {
      'damageQty': this.damageInfoForm.get('count').value
    }
    let dialogRef = this.dialog.open(DamageBoxComponent, dialogConfig)
  }

  /** Reset Damage Validation */
  resetDamageValidation() {
    this.damageInfoForm.get('isDamage').valueChanges.subscribe(damage => {
      if (Boolean(damage)) {
        this.damageInfoForm.get('count').setValidators([Validators.required]);
        this.damageInfoForm.get('comment').setValidators([Validators.required]);
      } else {
        this.resetFormControlValidation(this.damageInfoForm.get('count'));
        this.resetFormControlValidation(this.damageInfoForm.get('comment'));
      }
    })
  }

  /** Reset Form Control Validation */
  private resetFormControlValidation(control) {
    if (control) {
      control.reset();
      control.clearValidators();
      control.updateValueAndValidity();
    }
  }

  /** Add Damaged */
  addDamaged(id, index) {
    let damageCheckBoxes = this.damageCheckBoxes.toArray();
    this.materialList = this.dataSource.data;
    if (this.materialList[index]['id'] === id && this.damagelist.length < this.damageInfoForm.get('count').value
      && this.damageInfoForm.controls['comment'].value && damageCheckBoxes[index].checked) {
      this.materialList[index]['isDamage'] = true;
      if (this.materialList[index]['isDamage']) {
        this.materialList[index]['damage'] = { comment: this.damageInfoForm.get('comment').value }; // add damge to meterial
        this.damagelist.push(this.materialList[index]); // update damage list with items
      }
      damageCheckBoxes[index].checked = true;
    } else {
      damageCheckBoxes[index].checked = false;
      this.materialList[index]['isDamage'] = false;
      delete this.materialList[index]['damage'];
      for (let dIndex in this.damagelist) {
        if (this.damagelist[dIndex].id === this.materialList[index]['id']) {
          this.damagelist.splice(dIndex, 1);
        }
      }
    }
    this.dataSource.data = this.materialList;
  }

  /** Check Damage */
  checkDamage() {
    this.materialList = this.dataSource.data;
    this.damagelist=[];
    this.materialList.forEach(ele => {
      ele.damage = null;
    })
    let count = this.damageInfoForm.get('count').value;
    for (let i = 0; i < count; i++) {
      if (this.damageInfoForm.get('comment').value) {
        this.materialList[i].damage = { comment: this.damageInfoForm.get('comment').value };
        this.damagelist.push(this.materialList[i]);
      }
    }
  }
  setDefaultParam() {
    this.paginateCases = {
      page: 0,
      size: 10,
      sort: 'caseNo'
    }
    this.getICases(false,this.paginateCases)
  }

  /** Get ICases and Underlying Items */
  getICases(setPage = true,paginate?) {
    this.loading=true;
    if (this.receiptInfoData) {
      if (setPage) paginate.page = 0;
      let reqParams = this.commonSrv.createParam(this.paginateCases);
      this.receiptService.getICases(this.receiptInfoData['id'],reqParams).subscribe(res => {
        this.totalCasesList = res.body;
        let sizeArray = String(res.headers.get('X-Total-Count') / 10).split('.');
        this.checkPageNo = Number(sizeArray[1]) == 0 ? Number(sizeArray[0]) - 1 : Number(sizeArray[0]); 
        this.setQuantity(res.body.length);
        this.loading = false;
      }, err => { this.helper.showSnackbar(err.error.message, false, true); },
        () => {
          this.totalCasesList.forEach(element => {
            this.receiptService.getICaseItems(element.id).subscribe(res => {
              if (element.caseNo == 0 && !this.isCaseSelected) {
                this.caseList.materialList = res.body;
                this.dataSource = new MatTableDataSource(res.body);
                this.totalMaterial = res.headers.get('X-Total-Count');
                this.dataSource.paginator=this.paginator;
                if (this.receiptInfoData.receiptMode)
                  this.autoFillDamageInfo();
              }
              element.materialList = res.body;
            })
          });
        })
    }
  }
   /** On change Page */
   onChangePageCases(caseEvent,event) {
    if(caseEvent == 'prev') {
      this.paginateCases.page = this.paginateCases.page - 1;
      this.getICases(false, this.paginateCases);
    }
    if(caseEvent == 'next' && event.detail == 1) {
      this.paginateCases.page = this.paginateCases.page + 1;
      this.getICases(false, this.paginateCases);
    } 
  }

  /** Get Items */
  getItems() {
    if (this.receiptInfoData) {
      this.receiptService.getItems(this.receiptInfoData['id']).subscribe(res => {
        this.totalMaterial = res.body.length;
        this.dataSource = new MatTableDataSource(res.body);
        this.dataSource.paginator = this.paginator;
        if (this.receiptInfoData.receiptMode)
          this.autoFillDamageInfo();
      })
    }
  }

  /**  Show Case Data */
  showCase(index) {
    this.caseIndex = index;
    this.isCaseSelected = true;
    let res = this.totalCasesList[index];
    if (res.materialList) {
      this.dataSource = new MatTableDataSource(res.materialList);
      this.totalMaterial = res.materialList.length;
      this.dataSource.paginator=this.paginator;
      this.autoFillDamageInfo();
    } else {
      this.dataSource = new MatTableDataSource([]);
      this.totalMaterial = 0;
    }
  }

  /** Auto Fill Damage Info */
  autoFillDamageInfo() {
    this.materialList = this.dataSource.data;
    this.damagelist = this.materialList.filter(function (o) { return o['damage'] != null; });
    if (this.damagelist.length > 0) {
      this.damageInfoForm.get('count').patchValue(this.damagelist.length);
      this.materialList.forEach(element => {
        if (element.damage != null) {
          this.damagedComment = element.damage.comment
          this.damageInfoForm.get('comment').setValue(this.damagedComment);
        }
      });
      this.damageInfoForm.controls['isDamage'].patchValue(true);
    }
    else {
      this.damageInfoForm.get('count').patchValue('');
      this.damageInfoForm.get('comment').patchValue('');
    }
  }

  /** generating case boxes */
  setQuantity(quantity) {
    this.listOfItems = Array.from(Array(quantity).keys());
  }

  /** Convert Barcode */
  convertBarcodes(barcode) {
    if (barcode) {
      barcode = JSON.parse(barcode);
      this.dimentions = barcode;
      if (this.dimentions == 'N/A') {
        return `Barcode size X N/A`;
      }
      else {
        return `Barcode Size ${barcode.height} X ${barcode.width}`;
      }
    }
  }

  /** Whether the number of selected elements matches the total number of rows. */
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return (numSelected > numRows || numSelected === numRows);
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    this.isAllSelected() ?
      this.selection.clear() :
      this.dataSource.data.forEach(row => this.selection.select(row));
  }

  /** The label for the checkbox on the passed row */
  checkboxLabel(row?: Material) {
    if (!row) {
      return `${this.isAllSelected() ? 'select' : 'deselect'} all`;
    }
    return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${row.id + 1}`;
  }

  /** Update Items */
  updateItems() {
    if (this.receiptInfoData.quantityType === "case") {
      this.updateICases();
    } else if (this.receiptInfoData.quantityType === "each") {
      this.updateEachItems();
    }
    if(this.receiptInfoData.quantityType === "each"){
      this.damageInfoData.emit(this.damageInfoForm.value);
    }
    if(this.receiptInfoData.quantityType === "case"){
      this.damageCount=0;
      this.totalCasesList.forEach(element => {
           let caseDamage = element.materialList.filter(function (o) { return o['damage'] != null; });
           this.damageCount= this.damageCount + caseDamage.length;
           this.damageInfoForm.value.count=this.damageCount;
      })
      this.damageInfoData.emit(this.damageInfoForm.value);
    }
  }

  /** Update Each Item */
  updateEachItems() {
    if (this.damageInfoForm.get('isDamage').value == 'false') {
      this.materialList = this.dataSource.data;
    }
    this.receiptInfoData.isDamage = this.damageInfoForm.get('isDamage').value;
    if (this.materialList && this.materialList.length > 0)
      this.receiptService.updateItems(this.receiptInfoData['id'], this.materialList).subscribe(res => {
        this.dataSource = new MatTableDataSource(res);
        this.cd.markForCheck();
      })
  }

  /** Update ICases */
  updateICases() {
    this.receiptInfoData.isDamage = this.damageInfoForm.get('isDamage').value;
    this.receiptService.updateICase(this.receiptInfoData['id'], this.totalCasesList).subscribe(
      res => {
      }, err => {
        this.helper.showSnackbar(err.error.message, false, true);
      }, () => {
        //update each item after updating case with barcode
        this.updateICaseItems();
      }
    )
  }

  /** Update ICase Items */
  updateICaseItems() {
    this.totalCasesList.forEach(element => {
      this.materialList = element.materialList;
      if (this.materialList.length > 0)
        this.receiptService.updateICaseItems(element.id, this.materialList).subscribe(res => {
          this.dataSource = new MatTableDataSource(res);
        })
    });
  }
 /** On Change Page **/
 onChangePage(event?: PageEvent) {
  this.paginate.size = event.pageSize;
  this.paginate.page = event.pageIndex;
  this.dataSource.paginator = this.paginator;
  return event;
}
}
