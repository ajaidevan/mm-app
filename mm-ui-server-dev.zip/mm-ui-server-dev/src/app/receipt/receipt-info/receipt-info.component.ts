import { Component, OnInit, Output, EventEmitter, ChangeDetectorRef, ViewChild, Input } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { HelperService } from 'app/services/helper.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { MatDialog, MatDialogConfig } from '@angular/material';
import { TotalCaseComponent } from '../total-case/total-case.component';
import { Router } from '@angular/router';
import { ValidatorService } from 'app/services/validator.service';
import { ReceiptService } from '../receipt.service';

@Component({
  selector: 'app-receipt-info',
  templateUrl: './receipt-info.component.html',
  styleUrls: ['./receipt-info.component.scss']
})

export class ReceiptInfoComponent implements OnInit {

  public fetchReceiptData: any;
  public receiptInfo: any;
  public containerArr: string[] = ["LN2 Dewar", "Ice pack", "Room Temperature", "Wet Ice", "Dry Ice", "Cold Packs"];
  public paginateCompany: any = {};
  public fetchedCompanyLength: number;
  public fetchedCompany: [any];
  public editMode: boolean = false;
  public receivable: any;
  public totalCasesList: any;
  public viewCaseMode: boolean = false;
  public resetPOList: string[] = ['itemType', 'quantityType', 'origin', 'quantity', 'containerType', 'clientType'];
  public hour12Timer:boolean = true;
  public receiptMode:any;
  public paginateElements:number;
  public isDetailsFilled:boolean = false;
  @Output() receiptInfoData = new EventEmitter();
  @Input() set receiptData(data: any) {
    if (data) {
      this.editMode = true;
      this.receivable = data;
      this.receiptInfoForm.patchValue(this.receivable);
      if(this.receivable.purchaseOrder==false){
        this.receiptInfoForm.controls['qaNotified'].patchValue(null);
        this.receiptInfoForm.controls['recipientNotified'].patchValue(null);
      }
      if(this.receivable.purchaseOrder==true){
        this.receiptInfoForm.get('quantityType').disable();
        this.receiptInfoForm.get('qaNotified').disable();
      }
      if(this.receivable.purchaseOrder== false){
        this.resetPOList.forEach(item => {
          this.resetFormControlValidation(this.receiptInfoForm.get(item));
        });
      }
    }
  }

  @ViewChild('companySelect') companySelect: any;

  constructor(
    private helper: HelperService, private router: Router, private _formBuilder: FormBuilder, private spinnerService: Ng4LoadingSpinnerService,
    private receiptService: ReceiptService, private dialog: MatDialog, private validatorService: ValidatorService, private cd: ChangeDetectorRef) {
  }

  public receiptInfoForm = this._formBuilder.group({
    receiptNo: ['',Validators.required],
    purchaseOrder: ['', Validators.required],
    origin: [''],
    itemType: [''],
    containerType: [''],
    recipientNotified: [''],
    qaNotified: [''],
    quantityType: [''],
    status: ['CREATE'],
    quantity: [''],
    comment: ['',],
    clientType: ['', ],
    vendorName: [''],
    companyId: [''],
    createdBy: [this.helper.getEmail()],
    createdAt: [new Date()],
    location: [this.helper.getLocation()],
    receivableDate: ['', Validators.required],
    description: [''],
    isDamage:['']
  });

  ngOnInit() {
    this.setValdationBasedOnpurchaseOrder();
    this.setValidationBasedOnClientType();
    if (this.receivable) {
      if (this.receivable.quantityType == 'each') this.receiptInfoForm.controls['quantity'].setValue(this.receivable.items.length);
      if (this.receivable.quantityType == 'case') this.receiptInfoForm.controls['quantity'].setValue(this.receivable.iCases.length);
      if (this.receivable.quantityType == 'case-w') this.receiptInfoForm.controls['quantity'].setValue(this.receivable.iCases.length);

      this.receiptMode=this.receivable.receiptMode;
      //load all companies while edit
      this.receiptService.getAllCompanies(this.paginateCompany).subscribe(
          data=>{this.fetchedCompanyLength=data.body.totalElements},
          err=>{
             if(err.status=='500'){
               this.helper.showSnackbar('Something Went Wrong Failed To Fetch Clients !',false, true);
             }
            else{
               this.helper.showSnackbar(err.error.message,false,true);
             }
          },
           ()=>{this.paginateCompanies();})
    }
    else {
    //load  paginate companies while create.
     this.paginateCompanies();
    }
  }

  /** Update Validation based on client type.  */
  setValidationBasedOnClientType(): void {
    this.receiptInfoForm.get('clientType').valueChanges.subscribe(value => {
      if (value === 'client') {
        this.receiptInfoForm.get('vendorName').clearValidators();
        this.receiptInfoForm.get('companyId').setValidators(Validators.required);
      } if (value === 'vendor') {
        this.receiptInfoForm.get('companyId').clearValidators();
        this.receiptInfoForm.get('vendorName').setValidators(Validators.required);
      } if (value === 'both') {
        this.receiptInfoForm.get('companyId').setValidators(Validators.required);
        this.receiptInfoForm.get('vendorName').setValidators(Validators.required);
      }
      this.receiptInfoForm.get('companyId').updateValueAndValidity();
      this.receiptInfoForm.get('vendorName').updateValueAndValidity();
    })
  }

  /** Updte validation based on purchase order */
  setValdationBasedOnpurchaseOrder() {
    this.receiptInfoForm.get('purchaseOrder').valueChanges
      .subscribe(purchaseOrder => {
        if (purchaseOrder) {
          this.resetPOList.forEach(item => {
            this.receiptInfoForm.get(item).setValidators([Validators.required]);
          });
        } else {
          this.resetPOList.forEach(item => {
            this.resetFormControlValidation(this.receiptInfoForm.get(item));
          });
        }
      });
  }
 
  /** GET All companies  */
  paginateCompanies(paginateCompany?: any) {
    this.spinnerService.show();
    this.paginateCompany.page = 0;
    this.paginateCompany.size = (this.fetchedCompanyLength) ? this.fetchedCompanyLength : 10;
    this.paginateCompany.sort = "creationAt,DESC";
    this.receiptService.getAllCompanies(this.paginateCompany).subscribe(
      data => {
        this.fetchedCompany = data.body.content;
        this.fetchedCompanyLength=data.body.totalElements;
        this.paginateElements=data.body.numberOfElements;
        this.cd.markForCheck();
        this.spinnerService.hide();
      }, err => {
        this.helper.showSnackbar('Failed To Fetch Companies !', false, true);
        this.spinnerService.hide();
      }
    )
  }

  /** Case Details */
  caseDetails() {
    if (this.editMode) this.fetchCases();
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.data = {
      recivedQty: this.receiptInfoForm.get('quantity').value,
      quantityType: this.receiptInfoForm.get('quantityType').value,
      viewCaseMode: this.viewCaseMode,
      editMode: this.editMode,
      receivable: (this.editMode) ? this.receivable : {},
      caseList: (this.totalCasesList) ? this.totalCasesList : ''
    }
    let dialogRef = this.dialog.open(TotalCaseComponent, dialogConfig);
    dialogRef.afterClosed().subscribe(data => {
      if(data) this.isDetailsFilled = false;
      this.totalCasesList = data.receivable.iCase;
      this.viewCaseMode = data.viewCaseMode;
    });
  }

  /** Get all cases  */
  fetchCases() {
    this.receiptService.getICases(this.receivable.id).subscribe(res => {
      this.totalCasesList = res.body;
    })
  }

  /** Paginate company as load more  */
  loadMoreCompanies() {
    this.companySelect.open();
    this.paginateCompany.size = this.paginateCompany.size + 10;
    this.receiptService.getAllCompanies(this.paginateCompany).subscribe(
      data => {
        this.fetchedCompany = data.body.content;
        this.fetchedCompanyLength=data.body.totalElements;
        this.paginateElements=data.body.numberOfElements;
        this.spinnerService.hide();
      }, err => {
        this.spinnerService.hide();
      }
    )
    return false;
  }

  /** Add new Receivables */
  addNewReceivables() {
    this.validatorService.userValidator(this.editMode ? 'update' : 'create').then(res => {
      if (res.val) {
        delete res.val;
          if (this.receiptInfoForm.controls['quantityType'].value == 'case-w') {
            this.receiptInfoForm.value.qaNotified = false;
            this.receiptInfoForm.value.recipientNotified = false;
          }
          this.receiptService.addNewReceivable(this.receiptInfoForm.value, res).subscribe(
            res => {
              if (res.status === "DRAFT") {
                this.receivable = res;
                if(res) this.addItemsToUpdateReceipt([],this.receiptInfoForm.get('quantity').value,this.receivable['id']);
                this.router.navigateByUrl('/receipt/receipt');
              } else {
                this.receivable = res;
                this.editMode = true;
                this.receivable.quantity = this.receiptInfoForm.get('quantity').value;
                this.receivable.mode="CREATE";
                this.receiptInfoData.emit(res);
              }
            },
            err => {if(err.status=='500'){
              this.helper.showSnackbar('Something Went Wrong Please Try Again Later!',false, true);
            }
            else if(err.error.messages[0]=='must not be null'){
              this.helper.showSnackbar('Please Fill Required Fields',false,true);
            }
           },
            () => { if (this.receiptInfoForm.get('quantityType').value === "case" || this.receiptInfoForm.get('quantityType').value === "case-w") this.addNewICases() }
          )
      }
    })
  }

  addNoPurchaseOrderReceipt() {
    this.PurchaseOrderDefaultInfo();
    this.validatorService.userValidator(this.editMode ? 'update' : 'create').then(res => {
      if (res.val) {
        delete res.val;
       if(!this.editMode){
         this.receiptService.addNewReceivable(this.receiptInfoForm.value,res).subscribe(
           res => { this.router.navigateByUrl('/receipt/receipt'); });
       }
       else{
          this.receiptInfoForm.value.id = this.receivable.id;
          this.receiptInfoForm.value.purchaseOrder=this.receivable.purchaseOrder;
          this.receiptInfoForm.value.status='CREATE';
          this.receiptService.updateReceivable(this.receiptInfoForm.value,res).subscribe( res=>{
             this.router.navigateByUrl('/receipt/receipt');
          })
       }
     }
    })
  }
  PurchaseOrderDefaultInfo(){
    let receiCompFields = ['quantityType','qaNotified','origin','itemType','containerType','recipientNotified'];
    receiCompFields.forEach(field =>{
      (field != 'qaNotified' && field != 'recipientNotified') ? this.receiptInfoForm.value[field] = 'N/A' :
      this.receiptInfoForm.value[field]= false;
    });
  }

  updateReceivables() {
    this.validatorService.userValidator(this.editMode ? 'update' : 'create').then(res => {
      if (res.val) {
        delete res.val;
          this.receiptInfoForm.value.id = this.receivable.id;
          //added because disabled feilds.
          if(this.receivable.purchaseOrder==true){
           this.receiptInfoForm.value.quantityType = this.receivable.quantityType;
           this.receiptInfoForm.value.qaNotified = this.receivable.qaNotified;
          }
          if (this.receiptInfoForm.controls['quantityType'].value == 'case-w') {
            this.receiptInfoForm.value.qaNotified = false;
            this.receiptInfoForm.value.recipientNotified = false;
          }
          this.receiptService.updateReceivable(this.receiptInfoForm.value, res).subscribe(res => {
            this.receivable = res;
            this.editMode = true;
            this.receivable.quantity = this.receiptInfoForm.get('quantity').value;
            this.receivable.mode="UPDATE";
            this.receiptInfoData.emit(res);
          }, err => { this.helper.showSnackbar(err.error.message, false, true); },
            () => { });
      }
    });
  }

  private resetFormControlValidation(control) {
    if (control) {
      control.clearValidators();
      control.updateValueAndValidity();
    }
  }

  cancel() {
    if((!this.editMode || this.receivable.receiptMode=='receiving')){
      this.router.navigate(['/receipt/receipt']);
    } else if(this.receivable.receiptMode=='qa-approval') {
      this.router.navigate(['/receipt/qa-receipt']);
    }else{
      this.router.navigate(['/receipt/receipt']);
    }
  }

  //save as draft
  saveAsDraft() {
    if (this.receivable) {
      this.validatorService.userValidator(this.editMode ? 'update' : 'create').then(res => {
        if (res.val) {
          delete res.val;
          this.receiptInfoForm.get('status').patchValue("DRAFT");
          switch(this.receiptInfoForm.value.purchaseOrder){
            case false:
             this.PurchaseOrderDefaultInfo();
             this.updateDraft(res);
            break;
            case true:
             this.updateDraft(res);
            break;
          }
        }
      })
    } else {
      this.receiptInfoForm.get('status').patchValue("DRAFT");
      switch(this.receiptInfoForm.value.purchaseOrder){
        case true:
         this.addNewReceivables();
        break;
        case false:
          this.PurchaseOrderDefaultInfo();
          this.addNewReceivables();
        break;
      }
    }
  }
  updateDraft(res){
    this.receiptInfoForm.value.id = this.receivable.id;
    if(this.receivable.purchaseOrder==true){
     this.receiptInfoForm.value.quantityType = this.receivable.quantityType;
     this.receiptInfoForm.value.qaNotified = this.receivable.qaNotified;
    }
    this.receiptService.updateReceivable(this.receiptInfoForm.value, res).subscribe(
      res => {
        if (res.status === "DRAFT") {
          this.router.navigateByUrl('/receipt/receipt');
        }
        this.helper.showSnackbar("Saved as Draft successfully");
      },
      err => { this.helper.showSnackbar(err.error.message, false, true); });
  }

  //Cases
  addNewICases() {
    this.spinnerService.show();
    this.receiptService.addNewICases(this.receivable['id'], this.totalCasesList).subscribe(res => {
      this.totalCasesList = res;
      this.spinnerService.hide();
    })
  }

  confirm() {
    this.getItems();
    if (this.receivable.items.length > this.receiptInfoForm.get('quantity').value) {
      let itemQty = this.receivable.items.slice(this.receiptInfoForm.get('quantity').value);
      this.receiptService.confirm(itemQty, "each");
    }
    if(this.receiptInfoForm.get('quantity').value > this.receivable.items.length) {
      this.helper.showSnackbar("Items are added successfully",true);
    }
  }

  // Edit quantity of items. Decrease or Increase
  updateMaterialsInReceipt(res) {
    let quantityUpdated = this.receiptInfoForm.get('quantity').value;
    let actualQuantity = res.body.length;
    if (actualQuantity < quantityUpdated) {
      this.addItemsToUpdateReceipt(res.body, quantityUpdated - actualQuantity,this.receivable['id']);
    }
    if (actualQuantity > quantityUpdated) {
      this.removeItemsToUpdateReceipt(res.body, quantityUpdated);
    }
  }
  // Remove items when decrease a receipt quantity.
  removeItemsToUpdateReceipt(res: any, quantityUpdated: any) {
    let removeItemList = res.slice(quantityUpdated);
    removeItemList.forEach(item => {
      this.receiptService.deleteItem(item).subscribe(res => { });
    });
    this.getItems()
  }

  // Add items when increase a receipt quantity.
  addItemsToUpdateReceipt(items: any, quantity, id) {
    let newItems = [];
    let item = {
      labelSize: '', comment: '', orderNo: '', manufacturer: '', lotNo: '',
      batchNo: '', catalogNo: '', manufactureDate: '', expiryDate: '', type: 'client/vendor'
    };
    for (let i = 0; i < quantity; i++) { newItems.push(item) }
    this.receiptService.addNewItems(id, newItems).subscribe(res => {
        this.getItems()
      });
  }

  getItems() {
    this.receiptService.getItems(this.receivable['id']).subscribe(res => {
      if (this.editMode) this.updateMaterialsInReceipt(res);
    })
  }

  qtyTypeHandler(){
    if((this.receiptInfoForm.get('quantityType').value == 'case' || this.receiptInfoForm.get('quantityType').value == 'case-w')  && !this.editMode)
        this.isDetailsFilled = true;
  }
}
