import { Component, OnInit, Output, EventEmitter, Input, ChangeDetectorRef, ViewChild } from '@angular/core';
import { MatDialogConfig, MatDialog, MatTableDataSource, MatPaginator, MatSort, PageEvent } from '@angular/material';
import { MaterialInfoComponent } from '../material-info/material-info.component';
import { SelectionModel } from '@angular/cdk/collections';
import { HelperService } from 'app/services/helper.service';
import { ValidatorService } from 'app/services/validator.service';
import { Router } from '@angular/router';
import { ReceiptService } from '../receipt.service';
import { Material } from 'app/models/material.model';
import { CommonApiService } from 'app/services/common-api.service';

@Component({
  selector: 'app-case-info',
  templateUrl: './case-info.component.html',
  styleUrls: ['./case-info.component.scss']
})

export class CaseInfoComponent implements OnInit {

  public displayedColumns: string[] = ['select', 'srno', 'orderNo', 'label_size', 'manufacturer', 'lotNo', 'batchNo', 'itemNo', 'action'];
  public receiptInfoData: any;
  public selection = new SelectionModel(true, []);
  public selectCase: number = -1;
  public totalCasesList: any;
  public totalMaterial: number = 0;
  public listOfItems = [];
  public totalMaterialList: any;
  public isMaterial: boolean = false;
  public materialList: any = [];
  public dimentions: any = { height: 1, width: 1 };
  public dataSource: MatTableDataSource<Material>;
  public paginate: any = { page: 0, size: 10 };
  public editMode: boolean = false;
  public isCaseSelected:boolean=false;
  public updateCaseData:any;
  public caseList:any = {};
  public paginateCases : any = { };
  public caseIndex:number;
  public checkPageNo:number;
  public loading:boolean = false;
  @Input() set receiptWithCaseInfoData(data: any) {
    this.receiptInfoData = data;
    if (this.receiptInfoData && this.receiptInfoData.quantityType == "case") {
      this.setDefaultParam();
    }
    if (this.receiptInfoData.quantityType == 'each') {
      this.getItems();
    }
  };
  @Output() caseData = new EventEmitter();
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(private receiptService: ReceiptService, private dialog: MatDialog, private helper: HelperService, private cd: ChangeDetectorRef,
    private validatorService: ValidatorService, private router: Router,private commonSrv:CommonApiService) {
    this.dataSource = new MatTableDataSource([]);
  }

  ngOnInit() {
    if(this.receiptInfoData) this.editMode=true;
   }

  //save as draft
  saveAsDraft() {
    if (this.receiptInfoData) {
      this.validatorService.userValidator(this.editMode ? 'update' : 'create').then(res => {
        if (res.val) {
          delete res.val;
          this.receiptInfoData.status = "DRAFT";
          this.receiptService.updateReceivable(this.receiptInfoData, res).subscribe(
            res => {
              if (res.status === "DRAFT") {
                this.router.navigateByUrl('/receipt/receipt');
              }
              this.helper.showSnackbar("Saved as Draft successfully");
            },
            err => { this.helper.showSnackbar(err.error.message, false, true); });
        }
      })
    }
  }

  /** open ADD BARCODE **/
  addMaterialInfo(caseNo, newData?): void {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true
    dialogConfig.data = {
      recivedQty: this.receiptInfoData.quantity,
      qaNotified: this.receiptInfoData.qaNotified,
      type: this.receiptInfoData.clientType,
      caseNo: this.paginateCases.page ==0 ? this.caseIndex: (this.paginateCases.page * this.paginateCases.size )+this.caseIndex,
      multiSelectMode: this.selection.hasValue(),
      caseData: this.editMode ? newData : ''
    }
    let dialogRef = this.dialog.open(MaterialInfoComponent, dialogConfig);
    dialogRef.afterClosed().subscribe(
      data => {
        if (data) {
          if (!data.editMode && !data.multiSelectMode) this.createdMaterials(data);
          if (data.editMode) this.updatedMaterial(data);
          if (data.multiSelectMode) this.updatedMultiMaterial(data);
        }
      });
  }

  /** EDIT Material **/
  onEditMaterial(caseNo, materialInfo) {
    this.editMode = true;
    this.addMaterialInfo(caseNo, materialInfo);
  }

  setDefaultParam() {
    this.paginateCases = {
      page: 0,
      size: 10,
      sort: 'caseNo'
    }
    this.getICases(false,this.paginateCases)
  }

  //Get ICases and Underlying Items
  getICases(setPage = true,paginate?) {
    this.loading = true;
    if (this.receiptInfoData) {
      if (setPage) paginate.page = 0;
      let reqParams = this.commonSrv.createParam(this.paginateCases);
      this.receiptService.getICases(this.receiptInfoData['id'],reqParams).subscribe(res => {
        this.totalCasesList = res.body;
        let sizeArray = String(res.headers.get('X-Total-Count') / 10).split('.');
        this.checkPageNo = Number(sizeArray[1]) == 0 ? Number(sizeArray[0]) - 1 : Number(sizeArray[0]); 
        this.setQuantity(res.body.length);
        this.loading = false;
      }, err => { this.helper.showSnackbar(err.error.message, false, true); },
        () => {
          this.totalCasesList.forEach(element => {
            this.receiptService.getICaseItems(element.id).subscribe(res => {
              if (element.caseNo == 0 && !this.isCaseSelected) {
                this.caseList.materialList = res.body;
                this.dataSource = new MatTableDataSource(res.body);
                this.totalMaterial = res.headers.get('X-Total-Count');
                this.dataSource.paginator=this.paginator;
              }
              element.materialList = res.body;
            })
          });
        })
    }
  }

  /** On change Page */
  onChangePageCases(caseEvent,event) {
    if(caseEvent == 'prev') {
      this.paginateCases.page = this.paginateCases.page - 1;
      this.getICases(false, this.paginateCases);
    }
    if(caseEvent == 'next' && event.detail == 1) {
      this.paginateCases.page = this.paginateCases.page + 1;
      this.getICases(false, this.paginateCases);
    } 
  }

  /** Get Items */
  getItems() {
    this.receiptService.getItems(this.receiptInfoData['id']).subscribe(res => {
      this.totalMaterial = res.body.length;
      this.dataSource = new MatTableDataSource(res.body);
      this.materialList = res.body;
      this.dataSource.paginator = this.paginator;
    })
  }

  continue() {
    this.caseData.emit(this.totalCasesList);
  }

  //  show case data
  showCase(index) {
    this.caseIndex = index;
    this.isCaseSelected=true;
    let res = this.totalCasesList[index];
    this.caseList = this.totalCasesList[index];
    if (res.materialList) {
      this.dataSource = new MatTableDataSource(res.materialList);
      this.totalMaterial = res.materialList.length;
      this.dataSource.paginator=this.paginator;
    } else {
      this.dataSource = new MatTableDataSource([]);
      this.totalMaterial = 0;
    }
  }

  /** Created Material */
  createdMaterials(data) {
    this.totalMaterialList = data;
    if (this.totalMaterialList) this.isMaterial = true;
    if (this.receiptInfoData.quantityType === "each") {
      let matCount = this.receiptInfoData.quantity;
      let materialsList = this.createMaterailList(matCount, data);
      if (materialsList.length > 0) this.addItems(materialsList);
    }
    if (this.receiptInfoData.quantityType === "case") {
      let matCount = this.totalCasesList[this.selectCase].count;
      let caseId = this.totalCasesList[this.selectCase].id;
      let materialsList = this.createMaterailList(matCount, data);
      let cases = this.totalCasesList[this.selectCase];
      if (materialsList.length > 0) this.addNewICaseItems(caseId, materialsList,cases);
    }
  }

  /** Update Material */
  updatedMaterial(data) {
    if (this.receiptInfoData.quantityType === "each") {
      for (let index in this.materialList) {
        if (this.materialList[index].id == data.id) {
          this.materialList[index] = data;
        }
      }
      if (this.materialList.length > 0) this.updateEachItems();
    }
    if (this.receiptInfoData.quantityType === "case") {
      this.updateCaseData = data;
      for (let index in this.totalCasesList) {
        for (let innerIndex in this.totalCasesList[index].materialList) {
          if (this.totalCasesList[index].materialList[innerIndex].id === data.id) {
            this.totalCasesList[index].materialList[innerIndex] = data;
          }
        }
      }
      if (this.totalCasesList.length > 0) this.updateICaseItems();
    }
  }

  /** Update Multi Material */
  updatedMultiMaterial(data) {
    if (this.selection.hasValue())
      this.selection['_selected'].forEach(item => {
        data.id = item.id;
        this.receiptService.updateItem(data).subscribe(res => {
          if (res) {
            if (this.receiptInfoData.quantityType === "each") this.getItems();
            if (this.receiptInfoData.quantityType === "case") {
              /** This is for paginated items inside case reload */
              let id = this.caseList.id ? this.caseList.id : this.totalCasesList[0].id;
              this.receiptService.getICaseItems(id).subscribe(res => {
                  this.dataSource = new MatTableDataSource(res.body);
                  this.totalMaterial = res.headers.get('X-Total-Count');
                  this.dataSource.paginator=this.paginator;
              })
              this.getICases(false,this.paginateCases);
            } 
          }
        })
      });
    this.selection['_selected'] = [];
  }

  /** Add Items */
  addItems(materialsList) {
    if (materialsList.length > 0 && (this.totalMaterial != this.receiptInfoData.quantity)) {
      this.receiptService.addNewItems(this.receiptInfoData['id'], materialsList).subscribe(res => {
        this.totalMaterial = res.length;
        this.dataSource = new MatTableDataSource(res);
        this.materialList = res;
        this.dataSource.paginator = this.paginator;
      });
    }else{
      this.helper.showSnackbar('Items are already available',true);
    }
  }

  /** Item Into ICases */
  addNewICaseItems(caseId, items, cases) {
    if(cases.items && cases.items.length < cases.count){
      this.receiptService.addNewICaseItems(caseId, items).subscribe(
        res => {
          if (this.receiptInfoData.quantityType === "case") {
            this.totalCasesList[this.selectCase].materialList = res;
            this.totalMaterial = res.length;
            this.dataSource = new MatTableDataSource(res);
            this.dataSource.paginator = this.paginator;
          }
        }
      )
    }else{
      this.helper.showSnackbar('Items are already available',true);
    }
  }

  /** Update Each Item */
  updateEachItems() {
    this.receiptService.updateItems(this.receiptInfoData['id'], this.materialList).subscribe(res => {
      this.dataSource = new MatTableDataSource(res);
      this.cd.markForCheck();
    })
  }

  /** Update Each Item Into ICase */
  updateICaseItems() {
    let data = [];
    if(this.caseList.materialList) {
      this.caseList.materialList.forEach(ele=>{
        if(ele.id == this.updateCaseData.id) ele = this.updateCaseData;
        data.push(ele);
      })
     let id = this.caseList.id ? this.caseList.id : this.totalCasesList[0].id;
     this.receiptService.updateICaseItems(id,data).subscribe(res=>{
       this.dataSource = new MatTableDataSource(res);
     })
    } 
  }

  /** Create Material List */
  createMaterailList(matCount, data) {
    let listOfMaterial = [];
    let material = {
      labelSize: '', comment: '', orderNo: '', manufacturer: '', lotNo: '',
      batchNo: '', catalogNo: '', manufactureDate: '', expiryDate: '', type: 'client/vendor'
    };
    for (let i = 1; i <= matCount; i++) {
      if (i === 1) listOfMaterial.push(data);
      if (data['replicate'] && i !== 1) {
        listOfMaterial.push(data);
      } else if (i !== 1) {
        listOfMaterial.push(material)
      }
    }
    return listOfMaterial;
  }

  /** Generating Case Boxes */
  setQuantity(quantity) {
    this.listOfItems = Array.from(Array(quantity).keys());
  }

  /** On Change Page **/
  onChangePage(event?: PageEvent) {
    this.paginate.size = event.pageSize;
    this.paginate.page = event.pageIndex;
    this.dataSource.paginator = this.paginator;
    return event;
  }

  /** Whether the number of selected elements matches the total number of rows. */
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return (numSelected > numRows || numSelected === numRows);
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    this.isAllSelected() ?
      this.selection.clear() :
      this.dataSource.data.forEach(row => this.selection.select(row));
  }

  /** The label for the checkbox on the passed row */
  checkboxLabel(row?: Material) {
    if (!row) {
      return `${this.isAllSelected() ? 'select' : 'deselect'} all`;
    }
    return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${row.id + 1}`;
  }

  /** Convert Barcodes. */
  convertBarcodes(barcode) {
    if (barcode) {
      barcode = JSON.parse(barcode);
      this.dimentions = barcode;
      if (this.dimentions == 'N/A') {
        return `Barcode size X N/A`;
      }
      else {
        return `Barcode Size ${barcode.height} X ${barcode.width}`;
      }
    }
  }
}
