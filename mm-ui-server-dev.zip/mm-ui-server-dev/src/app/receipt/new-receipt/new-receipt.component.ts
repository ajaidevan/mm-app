import { Component, OnInit } from '@angular/core';
import { MatStepper } from '@angular/material';
import { AuthService } from 'app/services/auth.service';
import { ReceiptService } from '../receipt.service';

@Component({
  selector: 'app-new-receipt',
  templateUrl: './new-receipt.component.html',
  styleUrls: ['./new-receipt.component.scss']
})
export class NewReceiptComponent implements OnInit {

   public receiptInfoData:any;
   public receiptData:any;
   public editMode:boolean=false;
   public mode:any;
   public damageInfo:any;
   public caseInfo:boolean;
  constructor(private authSrv:AuthService, private receiptService:ReceiptService) { }

  ngOnInit() {
    this.receiptService.sharedReceivable.subscribe((data:any)=>{
         this.receiptInfoData=data; 
         if(data){
           this.editMode=true;
          if(this.receiptInfoData.receiptMode=='qa-approval') this.mode='qa-approval'
          if(this.receiptInfoData.receiptMode=='receiving') this.mode='receiving'
         }
    })
  }

  completeReceiptInfoEvent(data,stepper?: MatStepper) {
    if(data){
      this.receiptInfoData=data;
      if(this.mode=='qa-approval') this.receiptInfoData.receiptMode='qa-approval'
      if(this.mode=='receiving')  this.receiptInfoData.receiptMode='receiving'
      if(data.purchaseOrder) stepper.next();
    }
  }

  completeCasesInfoEvent(data,stepper?: MatStepper){
    this.caseInfo=true;
    this.damageInfo=this.receiptInfoData;
    stepper.next();
  }

  showReceiptSummary(data,stepper?: MatStepper){
    if(data){
      if(data.isDamage) this.receiptInfoData.damageInfo = data;
      this.receiptInfoData.summary=true;
    }
    stepper.next();
  }

  resetStepper(stepper:MatStepper){
    this.authSrv.resetConfirmation(stepper);
  }
}
