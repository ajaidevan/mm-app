import { Routes } from '@angular/router';
// import { ReceivingComponent } from './receiving.component'
import { NewReceiptComponent } from './new-receipt/new-receipt.component';
import { ReceiptListComponent } from './receipt-list.component';
import { ReceptResolver } from './receipt-resolver';
import { QaApprovalListComponent } from './qa-approval-list.component';
export const ReceiptRoute: Routes = [
  {
    path: '',
    redirectTo: 'receipt',
    pathMatch: 'full',
  }, {
    path: '',
    children: [
      {
        path: 'receipt',
        component: ReceiptListComponent,
        resolve:{receipt:ReceptResolver},
        data:{
          params:{
            page:0,
            size:10,
            sort:'createdAt,DESC',
          }
        }
      },
      {
        path: 'new-receipt',
        component: NewReceiptComponent,
      },
      {
        path: 'qa-receipt',
        component: QaApprovalListComponent,
      },
    ]
  }
];
