import { AuditLogModule } from './audit-log.module';

describe('AuditLogModule', () => {
  let auditLogModule: AuditLogModule;

  beforeEach(() => {
    auditLogModule = new AuditLogModule();
  });

  it('should create an instance', () => {
    expect(auditLogModule).toBeTruthy();
  });
});
