import { Routes} from '@angular/router';
import { AuditLogComponent } from './audit-log/audit-log.component';
import { AuditResolver } from './audit.resolver';

export const AuditRoutes: Routes = [
  {
      path:'',
      redirectTo:'audit-log',
      pathMatch:'full'
  },{
      path:'',
      children:[
          {
          path:'audit-log',
          component:AuditLogComponent,
          resolve: {audit: AuditResolver},
          data:{
            params:{
              page:0,
              size:10,
              sort:'createdAt,DESC',
            }
          }
        }, 
      ]
  }
];


