import { Injectable } from '@angular/core';
import{AuditService}from'./audit.service';
import{Observable,of,EMPTY}from"rxjs";
import{catchError,mergeMap}from"rxjs/operators";
import{Resolve,ActivatedRouteSnapshot,RouterStateSnapshot}from"@angular/router";
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { HelperService } from 'app/services/helper.service';
import { CommonApiService } from "app/services/common-api.service";


@Injectable()

export class AuditResolver implements Resolve<any>{
    
    constructor(private auditService:AuditService,private spinnerService:Ng4LoadingSpinnerService,
        private helperService:HelperService,private commonSrv:CommonApiService){}
        
    resolve(route:ActivatedRouteSnapshot,state:RouterStateSnapshot):Observable<any>|Observable<never>{
        if (this.helperService.getRoles() != 'role_client_admin'){
            route.data.params.locations = this.helperService.getLocation();
        }
        if(this.helperService.getRoles() === 'role_client_admin'){
            delete route.data.params.locations
        }
        let reqParams = this.commonSrv.createParam(route.data['params']);
        return this.auditService.getAuditLog(reqParams).pipe(catchError(error=>{
            return EMPTY;
        }),mergeMap(something=>{
            this.spinnerService.hide();
            if(something){
                return of(something);
            }
            else{
                this.spinnerService.hide();
                return EMPTY;
            }
        })
        )
    }
}
 
