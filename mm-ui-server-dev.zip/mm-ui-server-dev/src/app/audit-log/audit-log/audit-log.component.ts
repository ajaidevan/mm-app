import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource, MatPaginator, MatSort, MatDialogConfig, PageEvent, Sort, MatDialog } from '@angular/material';
import { SelectionModel } from '@angular/cdk/collections';
import { AuditService } from '../audit.service';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonApiService } from 'app/services/common-api.service';
import * as jsPDF from 'jspdf';
import 'jspdf-autotable';
import { FormBuilder } from '@angular/forms';
import { trigger, state, style, transition, animate } from '@angular/animations';
import { HelperService } from 'app/services/helper.service';
import{SelectPageComponent} from '../select-page/select-page.component';

@Component({
  selector: 'app-audit-log',
  templateUrl: './audit-log.component.html',
  styleUrls: ['./audit-log.component.scss'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class AuditLogComponent implements OnInit {

  public displayedColumns: string[] = ['activityDateTime', 'activityLog', 'user', 'oldValue', 'newValue', 'action', 'comments'];
  public AuditFilterHeader = ['activityDateTimeFilter', 'activityFilter', 'locationFilter', 'userFilter', 'oldValueFilter', 'newValueFilter', 'actionFilter', 'commentsFilter',];
  public displayedClientColumns: string[] = ['createdAt', 'entityName', 'locations', 'createdBy', 'oldValue', 'newValue', 'action', 'comments']
  public dataSource = new MatTableDataSource<any>();
  public clientDataSource = new MatTableDataSource<any>();
  public enablePrint: boolean = true;
  public managePrintingData: any = [];
  public clientId: any;
  public paginate: any;
  public totalAudits: number;
  public pageEvent: PageEvent;
  public slectedRowsToPrint: any = []
  public role: string;
  public totalClientAudits: number;
  public paginateClient: any;
  public expandedElement:any[];
  public auditForm:any;
  public differentValue:any= {};
  public isDate:boolean = false;
  public actions:any=[
    {viewValue: 'create', value: 'CREATE'},
    {viewValue:'update',value:'UPDATE'},
    {viewValue: 'delete',value: 'DELETE'},
    {viewValue:'login',value:'LOGIN'},
    {viewValue: 'logout', value: 'LOGOUT'},
    {viewValue: 'authorized',value: 'AUTHORIZED'},
  ]
  public entityNames:any=[
    {viewValue: 'User', value: 'User'},
    {viewValue: 'Receivable',value: 'Receivable'},
    {viewValue: 'Location',value: 'Location'},
    {viewValue: 'Item', value: 'Item'},
    {viewValue: 'Freezer', value:'freezer'},
    {viewValue: 'Refrigerator', value:'refrigerator'},
    {viewValue: 'Incubator', value:'incubator'},
    {viewValue: 'Open Storage', value:'open_storage'},
   ];
  public freezers:any=[
     {viewValue: ' Rack', value:'freezer_rack'},
     {viewValue: ' Row', value:'freezer_row'},
     {viewValue: ' Section', value:'freezer_section'},
     {viewValue: ' Shelf', value:'freezer_shelf'},
     {viewValue: ' Slot', value:'freezer_slot'},
   ]; 
  public refrigerators:any=[
    {viewValue: ' Rack', value:'ref_rack'},
    {viewValue: 'Shelf', value:'ref_shelf'},
    {viewValue: 'Section', value:'ref_section'},
    {viewValue: ' Slot', value:'ref_slot'},
  ];
  public incubators:any=[
    {viewValue: ' Rack', value:'inc_rack'},
    {viewValue: ' Row', value:'inc_row'},
    {viewValue: ' Shelf', value:'inc_shelf'},
    {viewValue: 'Section', value:'inc_section'},
  ];
  public openStorages:any=[
    {viewValue: ' Rack', value:'os_rack'},
    {viewValue: 'Shelf', value:'os_shelf'},
    {viewValue: 'Row', value:'os_row'},
    {viewValue: 'Section', value:'os_section'},
  ];
  public locations: [any];
  public selectedStorageType:any=[];
    @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(private auditService: AuditService, private route: ActivatedRoute, private fb: FormBuilder,
    private router: Router, private commonSrv: CommonApiService, private helperSrv: HelperService, private dialog: MatDialog) {
  }

  ngOnInit() {
    /**  default Paginate for audit data  */
   this.defaultPaginateAudit();
    this.auditForm = this.fb.group({
      fromDate : [''],
      toDate : [''],
      action:[''],
      entityName:[''],
      storageTypes:[''],
      locations:[''],
    })
    this.getAllLocationByClient();
    this.auditForm.get('entityName').valueChanges.subscribe(val => {
      this.auditForm.get('storageTypes').patchValue('');
    });
    
  }

  defaultPaginateAudit(){
      this.paginate={
        page:0,
        size:10,
        sort:'createdAt,DESC',
        locations:this.helperSrv.getLocation()
      }
      let reqParams = this.commonSrv.createParam(this.paginate);
      if(this.helperSrv.getRoles() !== 'role_client_admin') {
        this.role = 'Admin' ;
      }
      if(this.helperSrv.getRoles() === 'role_client_admin') {
           this.role = 'role_client_admin';
           delete reqParams['locations'];
       }
      this.router.navigate([],{ queryParams : reqParams});
      this.dataSource.data = this.route.snapshot.data['audit'].body;
      this.totalAudits = this.route.snapshot.data['audit'].headers.get('X-Total-Count');
      
  }

 
  /** Onchange Page **/
  onChangePage(event?: PageEvent) {
    this.paginate.size = event.pageSize;
    this.paginate.page = event.pageIndex;
    this.getAuditByDate(this.auditForm.value,false);
    return event;
  }

  /*Sorting*/
  sortData(event: Sort) {
    this.paginate.sort = event.active + ',' + event.direction;
    this.getAuditByDate(this.auditForm.value,false);
  }

  expand(row) {
    this.expandedElement = row;
  }

  getAuditByDate(data,setPage = true){
    let d = this.dateFormater(data);
    if (setPage) this.paginate.page = 0;
    this.paginate.action  = data.action;
    if(data.storageTypes){      
      this.paginate.entityName=data.storageTypes;
    }else{
      this.paginate.entityName=data.entityName;
    }
    if(d) {
      this.paginate.fromDate = d.dateArr;
      this.paginate.toDate = d.dateArrTo;
    }
    if(this.helperSrv.getRoles() == 'role_client_admin'){
      this.paginate.locations=data.locations;
    }
    if(this.helperSrv.getRoles() != 'role_client_admin'){
      this.paginate.locations=this.helperSrv.getLocation();
    }
    let reqParams = this.commonSrv.createParam(this.paginate);
        this.auditService.getAuditByDate(reqParams).subscribe(res=>{
          this.dataSource.data = res.body;
          this.totalAudits = res.headers.get('X-Total-Count');
          this.router.navigate([], { queryParams: reqParams });
        })
  }

  onPrint(data){
    if(this.isEmptyObject(data)){
      const dialogConfig = new MatDialogConfig();
      dialogConfig.width = "480px";
      let dialogRef = this.dialog.open(SelectPageComponent, dialogConfig);
      dialogRef.afterClosed().subscribe(data => {
        if(data){
        this.paginate.pageSize=data.itemsPerPage;
        this.paginate.pageNo=data.pageNo;
        delete this.paginate.page;
        delete this.paginate.size;
        delete this.paginate.locations;
        this.onRoles(this.paginate);
        }
      }) 
    }
    else{
     delete this.paginate.pageSize;
     delete this.paginate.pageNo;
     let d = this.dateFormater(data);
     this.paginate.action  = data.action;
     if(data.storageTypes){      
       this.paginate.entityName=data.storageTypes;
     }else{
       this.paginate.entityName=data.entityName;
      }
     if(d) {
      this.paginate.fromDate = d.dateArr;
      this.paginate.toDate = d.dateArrTo;
     }
     if(this.helperSrv.getRoles() == 'role_client_admin'){
      this.paginate.locations=data.locations;
     }
     if(this.helperSrv.getRoles() != 'role_client_admin'){
      this.paginate.locations=this.helperSrv.getLocation();
     }
     this.onRoles(this.paginate);
   }
  }

  onRoles(data){
    let reqParams = this.commonSrv.createParam(this.paginate);
    this.router.navigate([], { queryParams: reqParams });
    this.auditService.printAuditByDate(reqParams).subscribe(res=>{
      this.openAuditPDF(res);
    })
  }
 isEmptyObject(data) {
    return Object.keys(data).every(function(x) {
        return data[x]===''||data[x]===null;
    });
 }
  checkExpanded(element){
    this.differentValue = {};
    if(element.newValue && element.oldValue) {
      let diff = Object.keys(element.newValue).reduce((diff, key) => {
        if (element.oldValue[key] === element.newValue[key]) return diff
        return {
          ...diff,
          [key]: element.newValue[key]
        }
      }, {});
      this.differentValue = diff;
    }
    return this.expandedElement = this.expandedElement === element ? null : element;
  }

  checkKey(key){
    return (key in this.differentValue) ? true : false;
  }

  private openAuditPDF(res){
    if(res){
      let file = new Blob([res], { type: 'application/pdf' }); 
      var fileURL = URL.createObjectURL(file);
      window.open(fileURL);
    }
  }

  private dateFormater(data){
    this.isDate = true;
    if(data.fromDate && data.toDate) {
      let month = '' + (data.fromDate.getMonth() + 1);
      let day = '' + data.fromDate.getDate();
      let year = data.fromDate.getFullYear();
      let dateArr = [year,month,day].join('-')
      let monthTo = '' + (data.toDate.getMonth() + 1);
      let dayTo = '' + data.toDate.getDate();
      let yearTo = data.toDate.getFullYear();
      let dateArrTo = [yearTo,monthTo,dayTo].join('-');
      return {
        dateArr:dateArr,
        dateArrTo:dateArrTo
      }
    }
  }
  refresh(){
    this.defaultPaginateAudit();
    this.auditForm.reset();
  }
  
 getAllLocationByClient(){
    this.auditService.getAllLocationsByClient(this.helperSrv.getTenantId()).subscribe(data => {   
      this.locations= data.body.content;
    })
  }
  storageType(data){
    this.selectedStorageType=[];
    if(data.value=='freezer'){
      this.selectedStorageType=this.freezers;
    }
    if(data.value=='refrigerator'){
      this.selectedStorageType=this.refrigerators;
    }
    if(data.value=='incubator'){
      this.selectedStorageType=this.incubators;
    }
    if(data.value=='open_storage'){
      this.selectedStorageType=this.openStorages;
    }
  }
}