import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuditLogComponent } from './audit-log/audit-log.component';
import { RouterModule } from '@angular/router';
import { AuditRoutes } from './audit-log-routing.module'
import { MatFormFieldModule, MatInputModule, MatIconModule, MatCardModule, MatButtonModule, MatListModule, MatProgressBarModule, MatMenuModule, MatSelectModule, MatSortModule, MatTableModule, MatPaginatorModule, MatRadioModule, MatCheckboxModule, MatDialogModule, MatDatepickerModule, MatTooltipModule } from '@angular/material';
import { FlexLayoutModule } from '@angular/flex-layout';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AuditService } from './audit.service';
import { AuditResolver } from './audit.resolver';
import { SharedModule } from 'app/shared/shared.module';
import { SelectPageComponent } from './select-page/select-page.component';

@NgModule({
  declarations: [
    AuditLogComponent,
    SelectPageComponent,
  ],
  imports: [
    CommonModule,
    CommonModule,
    RouterModule.forChild(AuditRoutes),
    MatFormFieldModule,
    MatInputModule,
    MatIconModule,
    MatCardModule,
    MatButtonModule,
    MatListModule,
    MatProgressBarModule,
    MatMenuModule,
    FlexLayoutModule,
    FormsModule,
    ReactiveFormsModule,
    MatSelectModule,
    MatSortModule,
    MatTableModule,
    MatPaginatorModule,
    MatRadioModule,
    MatCheckboxModule,
    MatDatepickerModule,
    MatDialogModule,
    MatCardModule,
    MatTooltipModule,
    SharedModule
  ],
  entryComponents:[SelectPageComponent],
  providers:[AuditService,AuditResolver]
})
export class AuditLogModule { }
