import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';

@Component({
  selector: 'app-select-page',
  templateUrl: './select-page.component.html',
  styleUrls: ['./select-page.component.scss']
})
export class SelectPageComponent implements OnInit {
  
  public itemsPerPage:any=[{value:5},{value:10},{value:15},{value:20}];
  public pageNo:any=[{value:10},{value:20},{value:30},{value:40},{value:50}];
  public pageForm:any;
  
  constructor(@Inject(MAT_DIALOG_DATA) public data: any,private dialogRef: MatDialogRef<any>,private fb:FormBuilder) {}

  ngOnInit() {
  this.pageForm = this.fb.group({
    itemsPerPage:['',Validators.required],
    pageNo:['',Validators.required]
  })
  }
  onSubmit(data){
    this.dialogRef.close( data )
  }
  /** CLOSE mat dialog **/
  close() {
    this.dialogRef.close(null);
  }
}
