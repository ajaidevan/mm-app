import { Injectable } from '@angular/core';
import { HttpClient, HttpParams }   from '@angular/common/http';
import { Observable,throwError}   from 'rxjs';
import { CommonApiService } from 'app/services/common-api.service';
import { HelperService } from 'app/services/helper.service';
import { environment } from '../../environments/environment';
import{Ng4LoadingSpinnerService}from'ng4-loading-spinner';


@Injectable()

export class AuditService {

  private location:string;
  private tenanntId:string;

  constructor( private http: HttpClient ,private httpHelper:CommonApiService,private helperSrv:HelperService,private spinnerService:Ng4LoadingSpinnerService) {
    this.tenanntId=this.helperSrv.getTenantId();
    this.location = this.helperSrv.getLocation()
  }

  /** GET audit-log */
    getAuditUserLocationAdmin(paramObj?:any):Observable<any>{
      return this.httpHelper.getRequestWithToken(environment.BASEURL+'/lg/audit-logs',
      {
        params:new HttpParams().set('locationId',this.helperSrv.getLocation())
      })
    }

    getAuditUserClientAdmin(paramObj?:any):Observable<any>{
      return this.httpHelper.getRequestWithToken(environment.BASEURL+'/lg/audit-logs',paramObj)
    }

    getAuditByDate(paramObj){
      return this.httpHelper.getRequestWithToken(environment.BASEURL+'/lg/audit-logs',paramObj)
    }

    getAuditLog(paramObj){
        return this.httpHelper.getRequestWithToken(environment.BASEURL+'/lg/audit-logs',paramObj)
    }
   
   printAuditByDate(paramObj){
        return this.httpHelper.getImage(environment.BASEURL+'/lg/audit-logs/reports',paramObj)
  }
   printClientAuditByDate(paramObj){
        return this.httpHelper.getImage(environment.BASEURL+'/lg/audit-logs/reports',paramObj)
    }
   /** GET all locations by client */
    getAllLocationsByClient(clientId): any {
      return this.httpHelper.getRequestWithToken(environment.BASEURL + '/auth/locations/tenants/' + clientId,{});
    }
  
  }


