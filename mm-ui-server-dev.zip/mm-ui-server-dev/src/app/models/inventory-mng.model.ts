export interface InventoryMngModel {
  id: string;
  orderNo: string;
  type: string;
  mfg: string;
  mfgLot: string;
  catalog: string;
  qtyRecieved: number;
  qtyRemaining: number;
  expirationDate: string;
  inspectedBy: string;
  date: string;
  status: string; // TODO Limit this to possible statuses
}
