export interface ExploreInventoryModel{
    id:string;
    orderNo:string;
    mfg:string;
    mfglot:string;
    catalog:string;
    qtyReceived:string;
    expirationDate:string;
    gridType:string;
    location:string;
} 
export interface ItemInfoModel{
    id:string;
    type:string;
    location:string;
    labelSize:string;
    orderNo:string;
    manufacturer:string;
    lotNo:string;
    batchNo:string;
    catalogNo:string;
    manufactureDate:string;
    expiryDate:string;
    btext:string;

}