export interface PagableModel {
    page: string;
    size: number;
    sort: string;
    order: string;
}