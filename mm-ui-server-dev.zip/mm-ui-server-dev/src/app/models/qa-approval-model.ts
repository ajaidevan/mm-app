export interface QAApprovalModal{
    id:string; 
    origin:string;
    client:string;
    vendor:string;
    containerType:string;
    itemType:string;
    quantityType:string;
    qaNotifieds:string;
    recipientNotified:string; 
    createdBy:string;
    createdAt:string;
    isDamaged:string; 
    status:string;
    action:string;
}