export interface Company {
  creationAt: string;
  deleted: boolean;
  deletedAt: string;
  id: string;
  modifiedAt: string;
  name: string;
}
