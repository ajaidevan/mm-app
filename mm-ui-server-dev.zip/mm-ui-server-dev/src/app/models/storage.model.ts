export interface StorageModel {
  id: number;
  name: string;
  roomName: string;
  serialNo: string;
  type: string;  //TODO: What are the possible values
  incType: String;
  refType: String;
  freezerType: String;
  opSetPoint: string;
  count: number;
  typeComfig: any;
  shelve: any;
  rack: any;
  row: any;
  grid: any;
  storageType:any;
}
