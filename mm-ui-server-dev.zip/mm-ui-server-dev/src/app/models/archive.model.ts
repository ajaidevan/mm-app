export interface ArchiveModel {
  id:number,
  origin:string,
  vendorName:string,
  containerType:string,
  itemType:string,
  quantityType:string,
  qaNotified:string,
  receipientNotified:string,
  createdBy:string,
  createdAt:any,
  receivableDate:any,
  status:string
 }