/** Super Admin User Model **/
export interface SuperUserModel {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  location: string;
  role: string;
  enabled: boolean;
  locationsRoles: any;
  status: string;

  ///by me ---NIKHIL
  headers:any;
  body: any;
}

/** Client Admin User Model **/
export interface ClientAdminUserModel {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  location: string;
  role: string;
  enabled: boolean;
  locationsRoles: any;
}

export interface SuperClientUserModel {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  role: string;
  status: string;
  enabled: boolean;
}

/** Location Admin User Model **/
export interface LocationUserModel {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  role: string;
  status: string;
  enabled: boolean;
}


