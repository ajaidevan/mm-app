export interface Label {
    labelName: string;
    description: string;
    length: string;
    breadth: string;
}
