/** Location Admin Audit Model **/
export interface LocationAuditModel {
        creationDate: string,
        lastModifiedBy: string,
        lastModifiedDate: string,
        logId: number,
        eventType: string,
        eventDetails: string,
        eventResult: string,
        oldValue: string,
        newValue: string,
        tenant: string,
        location: string,
        role: string,
        userId: string
}

/** Client Admin Audit Model **/
export interface ClientAuditModel {
        creationDate: string,
        lastModifiedBy: string,
        lastModifiedDate: string,
        logId: number,
        eventType: string,
        eventDetails: string,
        eventResult: string,
        oldValue: string,
        newValue: string,
        tenant: string,
        location: string,
        role: string,
        userId: string
}