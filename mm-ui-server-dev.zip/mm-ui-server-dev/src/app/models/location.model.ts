/** Client Admin Location Model **/
export interface ClientLocationModel {
    id: number;
    name: string;
    address: string;
    phone: string;
    email: string;
}

/** Super Admin Location Model **/
export interface SuperLocationModel {
    id: number;
    name: string;
    address: string;
    phone: string;
    email: string;
}
