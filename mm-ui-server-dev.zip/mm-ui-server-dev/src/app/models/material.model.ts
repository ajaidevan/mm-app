export interface Material{
    id?:number;
    labelSize: string;
    comment: string;
    orderNo: string;
    manufacturer: string;
    manufacturerLotNo: string;
    manufacturerBatchNo: string;
    catalogNo: string;
    dateOfManufacture: string;
    expirationDate: string;
    replicate: boolean;
}
