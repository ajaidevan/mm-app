export interface ReceiptModel {
  orderNo: number;
  mfg: string;
  mfgLot: string;
  catalog: string;
  qty: number;
  expDate: any;
  inspectedBy: string;
  date: any;
}