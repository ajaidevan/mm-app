

export interface ReceiptItem {
  createdAt: string;
  modifiedAt: string;
  createdBy: string;
  modifiedBy: string;
  id: number;
  type: string;
  labelSize: string;
  orderNo: string;
  manufacturer: string;
  lotNo: string;
  batchNo: string;
  catalogNo: string;
  manufactureDate: string;
  expiryDate: string;
  damage: any;
  labelSpecs: Array<any>;
  btext: string;
  description:string;
  status:string;
}

export interface ReceiptCase {
  createdAt: string;
  modifiedAt: string;
  createdBy: string;
  modifiedBy: string;
  id: number;
  caseNo: number;
  count: number;
  itemName: string;
  storageType: string;
  comment: string;
  damage: any;
  items: Array<ReceiptItem>;
  btext: string;
  receivedCount: number;
  status:string;
}

export class QAReceipt {
  createdAt: string;
  modifiedAt: string;
  createdBy: string;
  modifiedBy: string;
  id: number;
  purchaseOrder: boolean;
  origin: string;
  itemType: string;
  containerType: string;
  recipientNotified: boolean;
  qaNotified: boolean;
  status: string;
  client: string;
  vendorName: string;
  comment: string;
  iCases: Array<ReceiptCase>;
  items: Array<ReceiptItem>;
  quantityType: string;
  clientType: string;
  isDamage: boolean;
  quantity: number;
  companyId: string;


  // computed props (to be used in Material table)
  itemsCount: number;
  casesCount: number;

  constructor(jsonObj) {
    // set cases and items with type casting
    this.iCases = jsonObj.iCases as Array<ReceiptCase> || [];
    this.items = jsonObj.items as Array<ReceiptItem> || [];
    delete jsonObj.iCases;
    delete jsonObj.items;

    // Deserialize jectrest of obobject
    Object.keys(jsonObj).forEach(k => this[k] = jsonObj[k]);

    this.itemsCount = this.items ? this.items.length : 0;
    this.casesCount = this.iCases ? this.iCases.length : 0;
  }

  toJSON() {

    const obj = Object.assign({}, this);
    delete obj.itemsCount;
    delete obj.casesCount;

    return obj;

  }
}
