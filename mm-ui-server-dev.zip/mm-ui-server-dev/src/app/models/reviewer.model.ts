/** Client Admin Reviewer Model **/
export interface ClientReviewerModel {
  reviewer_name: string;
  reviewer_address: string;
  reviewer_company: string;
  reviewer_phone: string,
  reviewer_email: string;
  reviewer_location: string;
}


/** Super Admin Reviewer Model **/
export interface SuperReviewerModel {
  reviewer_name: string;
  reviewer_address: string;
  reviewer_shippingAddress: string;
  reviewer_phone: string,
  reviewer_email: string;
}