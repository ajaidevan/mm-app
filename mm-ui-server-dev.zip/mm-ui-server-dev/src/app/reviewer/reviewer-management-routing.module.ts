import { Routes} from '@angular/router';
import { ReviewerManagementComponent } from './reviewer-management/reviewer-management.component';
import { ReviewerResolver } from './reviewer.resolver';


export const ReviewerMngRoutes: Routes = [
  {
      path:'',
      redirectTo:'reviewer-management',
      pathMatch:'full'
  },{
      path:'',
      children:[
          {
          path:'reviewer-management',
          component:ReviewerManagementComponent,
          resolve: {reviewers: ReviewerResolver},
          data:{
            params:{
              page:0,
              size:10,
              sort:'creationAt,DESC',
            }
          }
        }, 
      ]
  }
];
