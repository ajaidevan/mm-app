import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { MatFormFieldModule, MatInputModule, MatIconModule, MatCardModule, MatButtonModule, MatListModule, MatProgressBarModule, MatMenuModule, MatSelectModule, MatSortModule, MatTableModule, MatPaginatorModule, MatRadioModule, MatCheckboxModule, MatDialogModule, MatDatepickerModule, MatTooltipModule } from '@angular/material';
import { FlexLayoutModule } from '@angular/flex-layout';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ReviewerManagementComponent } from './reviewer-management/reviewer-management.component';
import { ReviewerMngRoutes } from './reviewer-management-routing.module';
import { CreateReviewerComponent } from './reviewer-management/create-reviewer/create-reviewer.component';
import { ReviewerResolver } from './reviewer.resolver';
import { ReviewerService } from './reviewer.service';
import { LocationService } from 'app/client-admin/services/location.service';

@NgModule({
  declarations: [
    ReviewerManagementComponent,
    CreateReviewerComponent
  ],
  imports: [
    CommonModule,
    // RouterModule.forChild(ReviewerMngRoutes),
    MatFormFieldModule,
    MatInputModule,
    MatIconModule,
    MatCardModule,
    MatButtonModule,
    MatListModule,
    MatProgressBarModule,
    MatMenuModule,
    FlexLayoutModule,
    FormsModule,
    ReactiveFormsModule,
    MatSelectModule,
    MatSortModule,
    MatTableModule,
    MatPaginatorModule,
    MatRadioModule,
    MatCheckboxModule,
    MatDatepickerModule,
    MatDialogModule,
    MatTooltipModule
  ],
  providers: [ReviewerService,LocationService,ReviewerResolver],
  entryComponents:[CreateReviewerComponent]
})
export class ReviewerManagementModule { }
