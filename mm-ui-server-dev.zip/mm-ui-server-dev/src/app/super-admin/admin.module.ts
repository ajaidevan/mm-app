import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { MatIconModule, MatCardModule, MatButtonModule, MatListModule, MatProgressBarModule, MatMenuModule, MatFormFieldModule, MatInputModule, MatRippleModule, MatSelectModule, MatSortModule, MatTableModule, MatPaginatorModule, MatRadioModule, MatCheckboxModule, MatDatepickerModule, MatDialogModule, MatChipsModule, MatAutocompleteModule,MatTooltipModule } from '@angular/material';
import { FlexLayoutModule } from '@angular/flex-layout';

import { ChartsModule } from 'ng2-charts/ng2-charts';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';

import { AdminRoutes } from './admin.routing';
import { LocationComponent } from './location/location.component';
import { ClientComponent } from './client/client.component';
import { UserComponent } from './user/user.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { CreateLocationComponent } from './location/create-location/create-location.component';
import { LocationService } from './services/location.service';
import { ClientService } from './services/client.service';
import { CreateClientComponent } from './client/create-client/create-client.component';
import { UserService } from './services/user.service';
import { CreateUserComponent } from './user/create-user/create-user.component';
import { SuperAdminComponent } from './super-admin/super-admin.component';
import { ReviewerComponent } from './reviewer/reviewer.component';
import { CreateReviewerComponent } from './reviewer/create-reviewer/create-reviewer.component';
import { ReviewerService } from './services/reviewer.service';
import{LocationResolver}from'./services/location.resolver';
import{ClientResolver}from'./services/client.resolver';
import{UserResolver}from'./services/user.resolver';
import{ReviewerResolver}from'./services/reviewer.resolver';


@NgModule({
  declarations: [LocationComponent, ClientComponent,
    UserComponent, CreateLocationComponent, CreateClientComponent, CreateUserComponent
    , SuperAdminComponent, ReviewerComponent, CreateReviewerComponent,
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(AdminRoutes),
    MatFormFieldModule,
    MatInputModule,
    MatIconModule,
    MatCardModule,
    MatButtonModule,
    MatListModule,
    MatProgressBarModule,
    MatMenuModule,
    ChartsModule,
    NgxChartsModule,
    NgxDatatableModule,
    FlexLayoutModule,
    FormsModule,
    ReactiveFormsModule,
    MatSelectModule,
    MatSortModule,
    MatTableModule,
    MatPaginatorModule,
    MatRadioModule,
    MatCheckboxModule,
    MatDatepickerModule,
    MatDialogModule,
    MatRippleModule,
    MatChipsModule,
    MatAutocompleteModule,  
    MatTooltipModule
  ],
  providers: [LocationService,LocationResolver, ClientService,ClientResolver, UserService,UserResolver, ReviewerService,ReviewerResolver],
  entryComponents: [CreateLocationComponent, CreateClientComponent, CreateUserComponent, CreateReviewerComponent,]
})
export class AdminModule { }
