import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { MatDialogRef } from '@angular/material';
import { FormGroup, FormControl, Validators, FormGroupDirective, NgForm } from '@angular/forms';
import { ErrorStateMatcher } from '@angular/material/core';
import { HelperService } from '../../../services/helper.service';
import { ClientService } from 'app/super-admin/services/client.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { FrontValidationService } from 'app/services/front-validation/front-validation.service';
import { DataService } from 'app/services/data.service';
import { PatternValidationService } from 'app/services/front-validation/pattern-validation.service';
import { AuthService } from 'app/services/auth.service';
import { debounceTime } from 'rxjs/operators';
import { ValidatorService } from '../../../services/validator.service';
import Swal from 'sweetalert2';
import { UserRetrievalService } from 'app/services/user.retrieval.service';
import { UserReActivationLinkService } from 'app/services/user-reacivatelink.service';


export class MyErrorStateMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = form && form.submitted;
    return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
  }
}

@Component({
  selector: 'app-create-client',
  templateUrl: './create-client.component.html',
  styleUrls: ['./create-client.component.scss']
})
export class CreateClientComponent implements OnInit {
  @Output() msg = new EventEmitter();
  
  public clientVal: any;
  public errorUser:any;
  public errorEmail:any;
  public addClientForm = new FormGroup({
    id: new FormControl(''),
    password: new FormControl('password', Validators.required),
    email: new FormControl('', [Validators.required, Validators.pattern(this.patternSrv.emailPattern), Validators.maxLength(255)]),
    clientName:new FormControl('', [Validators.required,Validators.pattern(this.patternSrv.namePattern),Validators.maxLength(15)]),
    tenantName: new FormControl(''),
    address: new FormControl('', [Validators.required,Validators.maxLength(255),Validators.pattern(this.patternSrv.addressPattern)]),
    shippingAddress: new FormControl([], [Validators.required,Validators.maxLength(255),Validators.pattern(this.patternSrv.addressPattern)]),
    phoneNumber: new FormControl('', [Validators.required, Validators.maxLength(10), Validators.minLength(10),Validators.pattern(this.patternSrv.numPattern)]),
    enabled: new FormControl(false, Validators.required)
  });

  public matcher = new MyErrorStateMatcher();
  public editMode: boolean = false;
  public oldEmail:string;

  constructor(private dialogRef: MatDialogRef<CreateClientComponent>,
    private helper: HelperService,private data:DataService,
    private clientSrv: ClientService,private patternSrv:PatternValidationService,
    private spinnerService: Ng4LoadingSpinnerService,private authSrv:AuthService,
    private frontValSrv: FrontValidationService, private userRetrievalSrv: UserRetrievalService,
    private validatorService :ValidatorService,private userReacivateLinkSrv:UserReActivationLinkService
  ) {}

  ngOnInit() {
    /** Validation Message **/
    this.clientVal = this.frontValSrv.validationMsg;
    this.clientSrv.sharedClient.distinctUntilChanged().subscribe(data => {
      if (data) {
        console.log(data);
        
        this.addClientForm.patchValue(data);
        this.addClientForm.get('clientName').patchValue(data.username);
        this.oldEmail = data.email;
        this.editMode = true;
      }
    })
  }

  /** CREATE a client **/
  create() {
    this.validatorService.userValidator(this.editMode ?'update':'create').then(res => {
      if(res.val) {
        delete res.val; 
        let client = this.addClientForm.value;
        client.tenant = this.helper.getUserId();
        client.username = this.addClientForm.value.clientName;   
        if (this.editMode) {
          if (this.addClientForm.valid) {       
            this.clientSrv.updateClient(client,res).subscribe(
              data => {
                this.dialogRef.close(this.addClientForm.value);
                this.clientSrv.sendCurrentClient(data);
                this.helper.showSnackbar('Successfully Updated Client !');
              }, err => { if(err.status== '500 '){
                 this.helper.showSnackbar('Something Went Wrong Failed To Update Client',false,true);
              }
              else{
                this.helper.showSnackbar(err.error.message,false,true);
              }
              },()=>{
                this.userReacivateLinkSrv.reactivateUserOnEmailchanges(this.oldEmail,this.addClientForm.get('email').value);
              })
          }
        } else {
          if (this.addClientForm.valid) {
            delete client["id"];
            this.clientSrv.addClient(client,res).subscribe(
              data => {
                this.dialogRef.close(this.addClientForm.value);
                this.clientSrv.sendCurrentClient(data,);
                this.helper.showSnackbar('Successfully Created Client & Sent activation email !');
              })
          }
        }
      }
    }).catch(err => {
      this.helper.showSnackbar("Error Response :", err);
    });
  }

  /** CLOSE mat dialog **/
  close() {
    this.dialogRef.close(null);
  }
 
  isUserExist(clientName){
    this.authSrv.validateUser(clientName).subscribe(res =>{
      if(res.body.exist){
        this.errorUser='User Already Exists'
      }
      if(!res.body.exist && !res.body.deleted){
        this.errorUser=null;
      }
    }
    ) 
  }

  isEmailExist(emailId){
      this.authSrv.validateUser(emailId).subscribe(res =>{
        if(res.body.exist && !res.body.deleted){
          this.errorEmail='Email Already Exists'
        }
        if(!res.body.exist && !res.body.deleted){
          this.errorEmail=null;
        }
        if(res.body.exist && res.body.deleted) {
            this.userRetrievalSrv.userRetrievePopup().then(res=>{
            if(res){
              this.retrieveAndSendReactivationLink(emailId);
            }
            else{
              this.addClientForm.get('email').patchValue('');
            }
          });  
           
        }
      })
  }

  retrieveAndSendReactivationLink(emailId:string){
    this.authSrv.retrieveUser(emailId).subscribe(res=>{
      this.helper.showSnackbar('User Retrieved Successfully');
      this.dialogRef.close(this.addClientForm.value);
      this.clientSrv.sendCurrentClient(res);
    })
  }
}
