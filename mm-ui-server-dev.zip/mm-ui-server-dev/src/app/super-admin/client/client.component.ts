import { Component, OnInit, ViewChild } from '@angular/core';
import { ClientService } from '../services/client.service';
import { MatPaginator, MatSort, MatDialog, MatTableDataSource, MatDialogConfig, PageEvent ,Sort} from '@angular/material';
import { CreateClientComponent } from './create-client/create-client.component';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { ValidatorService } from 'app/services/validator.service';
import { ViewInfoComponent } from 'app/shared/view-info/view-info.component';
import { FrontValidationService } from 'app/services/front-validation/front-validation.service';
import { DataService } from 'app/services/data.service';
import { SuperClientUserModel } from 'app/models/user.model';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonApiService } from 'app/services/common-api.service';
import { HelperService } from 'app/services/helper.service';
import{AuthService} from'app/services/auth.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-client',
  templateUrl: './client.component.html',
  styleUrls: ['./client.component.scss']
})
export class ClientComponent implements OnInit {

  public displayedColumns: string[] = ['id', 'username', 'address', 'shippingAddress', 'phoneNumber', 'email', 'status', 'action'];
  public selectedRow: SuperClientUserModel;
  public editMode: boolean = false;
  public dataSource = new MatTableDataSource();
  public clientval: any;
  public activityLog: string;
  public paginate: any = {}
  public total: any;
  public isLoading: boolean = true;
  public pageEvent: PageEvent;
  public pageSizeOptions: number[] = [10, 20, 30];
  public totalUsers: number;
  public response:any;
  public searchValue:string;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(private dialog: MatDialog,
    private clientService: ClientService, private validatorService: ValidatorService,private helper:HelperService,
    private spinnerService: Ng4LoadingSpinnerService, private data: DataService, private commonSrv: CommonApiService,
    private frontValSrv: FrontValidationService, private route: ActivatedRoute, private router: Router,private authService:AuthService) { }

  ngOnInit() {
    this.data.currentLog.subscribe(activityLog => this.activityLog = activityLog);
    // for every update and create reload page data.
    this.clientService.currentClient.subscribe(data => {
      if (this.editMode) {
        //for edit do not change page
        this.refreshClient(false);
        this.editMode = false;
      } else {
        //for create start with page=0
        this.refreshClient(true);
      }
    })

    /*defaultPaginate for client data*/
    this.defaultPaginateClient();
    this.dataSource.data=this.route.snapshot.data['clients'].body.content;
    
   }

  ngAfterViewInit() {
  //  this.dataSource.sort=this.sort;
    }
  /** open CREATE NEW client **/
  openCreateClient(newData?): void {
    if (newData) {
      this.clientService.setSharedClinet(newData);
    } else {
      this.clientService.setSharedClinet("");
    }
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    let dialogRef = this.dialog.open(CreateClientComponent, dialogConfig);
    
  }

  /** open VIEW INFO **/
  openViewMode(selectedRow: SuperClientUserModel) {
    this.selectedRow = selectedRow;
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.data = {
      'selectedValue': this.selectedRow,
      'tableColumns': this.displayedColumns,
      'columnName': ['Client Id', 'Client Name', 'Address', 'Shipping Address', 'Phone Number', 'Email'],
      "component": "Client",
      "mode": true
    };
    let dialogRef = this.dialog.open(ViewInfoComponent, dialogConfig);
  };

  /** EDIT client **/
  onEditClient(user) {
    this.openCreateClient(user);
    this.editMode = true;
  }

  /** DELETE client **/
  onDeleteClinet(user, index) {
    this.validatorService.userValidator('delete').then(res => {
      if (res.val) {
        delete res.val; 
        this.clientService.deleteClient(user,res).subscribe(data => {
          let client = this.dataSource.data;
          client.splice(Number(index), 1);
          this.refreshClient();
          this.dataSource.data = client;
        });
      }
    }).catch(err => {
      this.helper.showSnackbar("Error Response", err);
    });
  }

  /**Reactivate link to email */
  onReactivateClient(row){
    Swal.fire({
      title: 'Are you sure?',
      text: "You want to send reactivation link to the email !",
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes',
    }).then((result) => {
      if (result.value) {
        this.validatorService.userValidator('reactivate').then(res => {
          if (res.val) {
            delete res.val; 
            this.authService.reactivateUser(row.email,res).subscribe(res=>{
              this.helper.showSnackbar("ReActivation Link has been sent to Email successfully!!!"); 
            })
          }
        }).catch(err => {
          this.helper.showSnackbar("Error Response", err);
        }); 
      }
    })
  }

  /** REFRESH client **/
  refreshClient(changePage?:boolean) {
    this.searchValue='';
    this.spinnerService.show();
    this.clientService.refreshClient().subscribe(res => {
     // this.defaultPaginateClient();
     this.paginateClient(changePage);
     this.helper.showSnackbar('Table Refreshed Successfully',true);
     this.spinnerService.hide();
    }, err => {
       this.helper.showSnackbar('Failed to Refresh the Table !',false,true);
    })
  }

  /** Set Default Param **/
    defaultPaginateClient() {
      this.paginate = this.route.snapshot.data['params'];
      let reqParams = this.commonSrv.createParam(this.paginate);
      this.router.navigate([], { queryParams: reqParams });
      this.dataSource.data=this.route.snapshot.data['clients'].body.content;      
      this.totalUsers = this.route.snapshot.data['clients'].body.totalElements;  
      
  }
 
  /**
   * 
   * @param setPage
   */

  /** Paginate CLient **/
  paginateClient(setPage = true) {
    if (setPage) this.paginate.page = 0;
    let reqParams = this.commonSrv.createParam(this.paginate);
    this.spinnerService.show();
    this.clientService.getAllClients(reqParams).subscribe(res => {
      this.dataSource.data = res.body.content;
      this.totalUsers = res.body.totalElements;
      this.router.navigate([], { queryParams: reqParams });
      this.spinnerService.hide();
         })
   }

  /**
   * 
   * @param event
   */
  /** On CHange Event **/
  onChangePage(event?: PageEvent) {
    this.paginate.size = event.pageSize;
    this.paginate.page = event.pageIndex;
    this.paginateClient(false);
    return event;
  }

  /** SEARCH Client */
  search(filter?: any) {
    this.clientService.searchClient(filter).subscribe(res => {
      this.dataSource.data = res.body;
      
    })
  }

  /** Apply Filter */
  applyFilter(filter?: any) {
    if (filter.length > 2) {
      this.search(filter);
    }
    if (filter.length == 0) {
    this.paginateClient();     
    }
  }
  
  /*Sorting*/
  sortData(event: Sort) {
    this.paginate.sort = event.active + ',' + event.direction;
    this.paginateClient();
      
  }

}
