import { Injectable } from '@angular/core';
import { Observable, BehaviorSubject, throwError } from 'rxjs';
import { CommonApiService } from 'app/services/common-api.service';
import { environment } from '../../../environments/environment';
import { LocationUserModel } from 'app/models/user.model';
import { catchError, map } from 'rxjs/operators';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { HelperService } from '../../services/helper.service';

@Injectable()
export class ReviewerService {

  //created reviewer
  private createdReviewer = new BehaviorSubject("");
  public currentReviewer = this.createdReviewer.asObservable();

  // reviewer data
  private sharableReviewer = new BehaviorSubject<any>("");
  public sharedReviewer = this.sharableReviewer.asObservable();

  constructor(private httpRequest: CommonApiService,private spinnerService:Ng4LoadingSpinnerService,
  private helper : HelperService) { }

  /** SEND current reviewer */
  sendCurrentReviewer(reviewerObj) {
    this.createdReviewer.next(reviewerObj);
  }

  /** SET shared reviewer */
  setSharedReviewer(user) {
    this.sharableReviewer.next(user);
  }

  /** GET all reviewer */
  getAllReviewers(paramObj?:any): Observable<any> {
    this.spinnerService.show();
    return this.httpRequest.getRequestWithToken(environment.BASEURL + '/auth/users',paramObj)
    .pipe(map(res=>{
    return res;
    }),catchError((err:Error) => throwError(err)))
  }

  /** DELETE reviewer */
  deleteReviewer(user: LocationUserModel,header) {
    return this.httpRequest.deleteReqeust(environment.BASEURL + '/auth/users/' + user.id, user,header);
  }

  /** ADD reviewer */
  addReviewer(user: LocationUserModel,header) {
    return this.httpRequest.postRequest(environment.BASEURL + '/auth/users', user,header);
  } 

  /** UPDATE reviewer */
  updateReviewer(user: LocationUserModel,header) {
    return this.httpRequest.putRequest(environment.BASEURL + '/auth/users/' + user.id, user,header);
  } 

  /** REFRESH reviewers */
  refreshReviewer() {
    return this.httpRequest.getRequestWithToken(environment.BASEURL + "/auth/users/refresh",{});
  }

  /** SEARCH reviewers */
  search(filterValue){
    return this.httpRequest.getRequestWithToken(environment.BASEURL+"/auth/users/search?search="+filterValue,{})
  }
 /**GET All companies */
 getAllCompanies(tenantId,paramObj?:any): Observable<any>{
  return this.httpRequest.getRequestWithToken(environment.BASEURL + '/auth/company?tenant='+tenantId,paramObj);
 }
}
