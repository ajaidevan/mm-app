import{Injectable}from"@angular/core";
import{Resolve,ActivatedRouteSnapshot,RouterStateSnapshot,Router,ActivatedRoute}from"@angular/router";
import{Observable, of, EMPTY}from"rxjs";
import{ClientService}from"./client.service";
import { catchError, mergeMap } from "rxjs/operators";
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { CommonApiService } from 'app/services/common-api.service';



@Injectable()
export class ClientResolver implements Resolve<any> {
  
   constructor(private clientService:ClientService,private spinnerService:Ng4LoadingSpinnerService,
    private commonSrv: CommonApiService){}

    resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot):Observable<any>|Observable<never>{

    let reqParams = this.commonSrv.createParam(route.data['params']);
      return this.clientService.getAllClients(reqParams).pipe(catchError(error   => {
      return EMPTY;
        }),
        mergeMap(something => {
              this.spinnerService.hide();
              if (something) {
               return of(something); 

              } 
              else {
                this.spinnerService.hide();
                return EMPTY;
              }
            })
        )

       }       
      }