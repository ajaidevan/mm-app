import{Injectable}from"@angular/core";
import{Resolve,ActivatedRouteSnapshot,RouterStateSnapshot}from"@angular/router";
import{Observable, of, EMPTY}from"rxjs";
import{LocationService}from"./location.service";
import { catchError, mergeMap } from "rxjs/operators";
import{Ng4LoadingSpinnerService}from"ng4-loading-spinner";
import { CommonApiService } from "app/services/common-api.service";

@Injectable()
export class LocationResolver implements Resolve<any> {
    constructor(private locationService:LocationService,
      private spinnerService:Ng4LoadingSpinnerService,private commonSrv:CommonApiService){}
      
    resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<any> | Observable<never> {

      let reqParams = this.commonSrv.createParam(route.data['params']); 
           return this.locationService.getAllLocations(reqParams).pipe(catchError(error   => {
           return EMPTY;
        }), mergeMap(something => {
              if (something) {
                 this.spinnerService.hide();
                 return of(something);
              } else {
                 this.spinnerService.hide();
                 return EMPTY;
              }
            })
          )
        }   
     }

