import{Injectable}from"@angular/core";
import{Resolve,ActivatedRouteSnapshot,RouterStateSnapshot}from"@angular/router";
import{catchError,mergeMap}from"rxjs/operators";
import{Observable,of,EMPTY}from"rxjs";
import{ReviewerService}from"./reviewer.service";
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { CommonApiService } from "app/services/common-api.service";
import { DataService } from "app/services/data.service";

@Injectable()
export class ReviewerResolver implements  Resolve<any>{
    constructor(private reviewerService:ReviewerService,
        private spinnerService:Ng4LoadingSpinnerService,private commonSrv:CommonApiService,
        private data :DataService){}
    resolve(route:ActivatedRouteSnapshot,state:RouterStateSnapshot):Observable<any>|Observable<never>{ 
        this.data.changeCurrentRole("reviewer");    
        let reqParams = this.commonSrv.createParam(route.data['params']);
        return this.reviewerService.getAllReviewers(reqParams).pipe(
        catchError(error=>{
            return EMPTY
        }),
        mergeMap(something=>{
            if(something){
                this.spinnerService.hide();
                return of(something);
            }
            else{
                this.spinnerService.hide();
                return EMPTY;
            }
        })

        )
    }
}

