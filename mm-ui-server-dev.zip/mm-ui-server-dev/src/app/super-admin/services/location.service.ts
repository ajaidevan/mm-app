import { Injectable } from '@angular/core';
import { HttpHeaders, } from '@angular/common/http';
import { BehaviorSubject, throwError } from 'rxjs';
import { HelperService } from 'app/services/helper.service';
import { CommonApiService } from 'app/services/common-api.service';
import { environment } from '../../../environments/environment';
import { SuperLocationModel } from 'app/models/location.model';
import { map, catchError } from 'rxjs/operators';
import{Ng4LoadingSpinnerService}from"ng4-loading-spinner";

@Injectable()

export class LocationService {

  private httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  };

  public clientId: string;
  public location: string;
  private createdLocation = new BehaviorSubject("");
  public currentLocation = this.createdLocation.asObservable();
  private sharableLocation = new BehaviorSubject<any>("");
  public sharedLocation = this.sharableLocation.asObservable();

  constructor(private httpHelper: CommonApiService, private helper: HelperService,private spinnerService:Ng4LoadingSpinnerService) {
    this.clientId = this.helper.getUserId();
    this.location = this.helper.getLocation();
  }

  /** SEND current location */
  sendCurrentLocation(locationObj) {
    this.createdLocation.next(locationObj);
  }

  /** SET shared location */
  setSharedLocation(locationObj) {
    this.sharableLocation.next(locationObj);
  }

  /** GET admin by role */
  getAdminByRole(): any {
    return this.httpHelper.getRequestWithToken(environment.BASEURL + '/auth/users/' + this.clientId + '/locations/' + this.location,{})
  }

  /** GET all locations */
   getAllLocations(paramObj?:any): any {
    this.spinnerService.show();
    return this.httpHelper.getRequestWithToken(environment.BASEURL + '/auth/locations',paramObj).pipe(map(response => {
      return response;
    }), catchError((error: Error) => throwError(error)));
  }

  /** GET all locations by client */
  getAllLocationsByClient(clientId): any {
    return this.httpHelper.getRequestWithToken(environment.BASEURL + '/auth/locations/tenants/' + clientId,{});
  }

  /** DELETE location */
  deleteLocation(location: SuperLocationModel,header) {
    return this.httpHelper.deleteReqeust(environment.BASEURL + '/auth/locations/' + location.id, location,header);
  }

  /** ADD location */
  addLocation(location: SuperLocationModel,header) {
    return this.httpHelper.postRequest(environment.BASEURL + '/auth/locations/', location,header);
  }

  /** UPADTE location */
  updateLocation(location: SuperLocationModel,header) {
    return this.httpHelper.putRequest(environment.BASEURL + '/auth/locations/' + location.id, location,header);
  }

  /** REFRESH location */
  refreshLocation() {
    return this.httpHelper.getRequestWithToken(environment.BASEURL + "/auth/locations/refresh",{});
  }

  /** SEARCH Location */
  searchLocation(searchValue?:any){
    return this.httpHelper.getRequestWithToken(environment.BASEURL + "/auth/locations/search?search="+searchValue,{})
  }
  
}
