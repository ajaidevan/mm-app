import { Injectable } from '@angular/core';
import { HttpHeaders } from '@angular/common/http';
import { Observable, BehaviorSubject, throwError } from 'rxjs';
import { CommonApiService } from 'app/services/common-api.service';
import { environment } from '../../../environments/environment';
import { LocationUserModel } from 'app/models/user.model';
import { map, catchError } from 'rxjs/operators';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import{ActivatedRoute}from'@angular/router';

@Injectable()
export class ClientService {
  private httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  };

    //created client
    private createdClient = new BehaviorSubject("");
    public currentClient = this.createdClient.asObservable();
      // client data
    private sharableClinet = new BehaviorSubject<any>("");
    public sharedClient = this.sharableClinet.asObservable();
  constructor(private httpRequest: CommonApiService,private spinnerService:Ng4LoadingSpinnerService,private route:ActivatedRoute) {}

  /** SEND current client */
  sendCurrentClient(clientObj) {
    this.createdClient.next(clientObj);
  }

  /** SET shared client */
  setSharedClinet(user) {
    this.sharableClinet.next(user);
  }

 /** GET all clients */
  getAllClients(paramObj?:any): Observable<any> {
    return this.httpRequest.getRequestWithToken(environment.BASEURL + '/auth/users/tenants',paramObj ).pipe(map(res=>{
      return res;
      }),catchError((err:Error) => throwError(err)));
  }

  /** DELETE client */
  deleteClient(user: LocationUserModel, header) {
    return this.httpRequest.deleteReqeust(environment.BASEURL + '/auth/users/tenants/'+user.id, user,header);
  }

  
  /** ADD client */
  addClient(user: LocationUserModel, header) {
    return this.httpRequest.postRequest(environment.BASEURL + '/auth/users/tenants', user,header);
  }

  /** UPDATE client */
  updateClient(user:LocationUserModel,header) {
    return this.httpRequest.putRequest(environment.BASEURL + '/auth/users/tenants/'+user.id, user,header);
  }

  /** REFRESH clients */
  refreshClient() {
    return this.httpRequest.getRequestWithToken(environment.BASEURL + "/auth/users/tenants/refresh",{});
  }

  /** SEARCH client */
  searchClient(filterValue?:any){
    return this.httpRequest.getRequestWithToken(environment.BASEURL + "/auth/users/tenants/search?search=" + filterValue,{})
  }
  /** GET all Active  clients */
  getAllActiveClients(paramObj?:any): Observable<any> {
    return this.httpRequest.getRequestWithToken(environment.BASEURL + '/auth/users/tenants?active=true',paramObj ).pipe(map(res=>{
      return res;
      }),catchError((err:Error) => throwError(err)));
  }

}
