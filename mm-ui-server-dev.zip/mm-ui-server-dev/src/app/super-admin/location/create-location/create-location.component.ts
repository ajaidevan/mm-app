import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { MatDialogRef } from '@angular/material';
import { FormGroup, FormControl, Validators, FormGroupDirective, NgForm } from '@angular/forms';
import { ErrorStateMatcher } from '@angular/material/core';
import { HelperService } from '../../../services/helper.service';
import { LocationService } from 'app/super-admin/services/location.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { ClientService } from '../../services/client.service';
import { FrontValidationService } from 'app/services/front-validation/front-validation.service';
import { DataService } from 'app/services/data.service';
import { PatternValidationService } from 'app/services/front-validation/pattern-validation.service';
import { AuthService } from 'app/services/auth.service';
import { debounceTime } from 'rxjs/operators';
import { ValidatorService } from '../../../services/validator.service';


export class MyErrorStateMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = form && form.submitted;
    return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
  }
}

@Component({
  selector: 'app-create-location',
  templateUrl: './create-location.component.html',
  styleUrls: ['./create-location.component.scss']
})
export class CreateLocationComponent implements OnInit, OnDestroy {
  
  public errorEmail:any;
  public errorLocation:any;
  public locationVal: any;
  public addLocnForm = new FormGroup({
    id: new FormControl(''),
    email: new FormControl('', [Validators.required, Validators.pattern(this.patternSrv.emailPattern),Validators.maxLength(60)]),
    phone: new FormControl('', [Validators.required, Validators.pattern(this.patternSrv.numPattern), Validators.maxLength(10), Validators.minLength(10)]),
    address: new FormControl('', [Validators.required,Validators.maxLength(255),Validators.pattern(this.patternSrv.addressPattern)]),
    name: new FormControl('', [Validators.required,Validators.pattern(this.patternSrv.namePattern),Validators.maxLength(15)]),
    tenant: new FormControl(''),
    tenantName: new FormControl('')
  });

  public matcher = new MyErrorStateMatcher();
  public editMode: boolean = false;
  public fetchedClient: [any];
  public paginateClient:any ={};
  public fetchedClientLength:number;
  public oldEmail:string;
  public paginateElements:number;


  @ViewChild('clientSelect') clientSelect:any;

  constructor(private dialogRef: MatDialogRef<CreateLocationComponent>,
    private helper: HelperService,private data:DataService,
    private validatorService : ValidatorService,
    private locationSrv: LocationService,private patternSrv:PatternValidationService,
    private clientSrv: ClientService,private authSrv:AuthService,
    private spinnerService: Ng4LoadingSpinnerService,
    private frontValSrv: FrontValidationService
  ) {}

  ngOnInit() {
    //Create Location form validations
    this.locationVal = this.frontValSrv.validationMsg;
    this.locationSrv.sharedLocation.distinctUntilChanged().subscribe(data => {
      if (data) {
        this.addLocnForm.patchValue(data);
        this.addLocnForm.controls['name'].setValue(data.name.split('-').splice(1));
        this.editMode = true;
        this.oldEmail = data.email;
         //load all client while edit
         this.clientSrv.getAllActiveClients(this.paginateClient).subscribe(
          res=>{ this.fetchedClientLength=res.body.totalElements },
          err=>{
            if(err.status=='500'){
                this.helper.showSnackbar('Something Went Wrong Failed To Fetch Clients !',false, true);
              }
             else{
                this.helper.showSnackbar(err.error.message,false,true);
              }
          },
          ()=>{ this.getAllCleints(); })
      }
      else {
        //load only 10 client while create.
        this.getAllCleints();
      }
    });
  }

  /** DESTROY editmode **/
  ngOnDestroy() {
    this.editMode = false;
  }

  /** GET all clients **/
  getAllCleints(paginateClient?:any) {
    this.spinnerService.show();
    this.paginateClient.page = 0;
    this.paginateClient.size = (this.fetchedClientLength) ? this.fetchedClientLength : 10;
    this.paginateClient.sort='creationAt,DESC';
    this.clientSrv.getAllActiveClients(this.paginateClient).subscribe(
      data => {
        this.fetchedClient = data.body.content;
        this.fetchedClientLength=data.body.totalElements;
        this.paginateElements=data.body.numberOfElements
        this.spinnerService.hide();
      }, err=>{
          if(err.status=='500'){
            this.helper.showSnackbar('Something Went Wrong Failed To Fetch Clients !',false, true);
          }
          else{
           this.helper.showSnackbar(err.error.message,false,true);
           this.spinnerService.hide();
          }
    })
  }
   /**paginate client as load more  */
   loadMoreClients(){
    this.clientSelect.open();
    this.paginateClient.size = this.paginateClient.size + 10;
    this.clientSrv.getAllActiveClients(this.paginateClient).subscribe(
      data => {
        this.fetchedClient = data.body.content;
        this.fetchedClientLength=data.body.totalElements;
        this.paginateElements=data.body.numberOfElements;
      }, err => {
         this.helper.showSnackbar('Failed to Load More Clients',err.error.message)
      }
    )
    return false;
  }

  /** CREATE a location **/
  create() {
    this.validatorService.userValidator(this.editMode ?'update':'create').then(res => {
      if(res.val) {
        delete res.val;
        let locationObj = this.addLocnForm.value;
        locationObj['name'] = this.addLocnForm.get('tenantName').value + "-" + this.addLocnForm.get('name').value;
        res.locations = locationObj.name;
        if (this.editMode) {
          if (this.addLocnForm.valid) {
            this.locationSrv.updateLocation(locationObj,res).subscribe(data => {
              this.helper.showSnackbar('Successfully Updated Location !');
              this.dialogRef.close(this.addLocnForm.value);
              this.locationSrv.sendCurrentLocation(data);
              data['tenantName']=this.addLocnForm.get('tenantName').value;       
              this.spinnerService.hide();
            },err => {
              if(err.status=='500'){
                this.helper.showSnackbar('Something Went Wrong Failed To Update Location',false, true);
              }
              else{
                this.helper.showSnackbar(err.error.message,false,true);
                this.spinnerService.hide();
              }
            })
          }
        } else {
          if (this.addLocnForm.valid) {
            delete locationObj["newName"];
            this.locationSrv.addLocation(locationObj,res).subscribe(data => {
              this.helper.showSnackbar('Successfully Created user & Sent activation email !');
              this.dialogRef.close(this.addLocnForm.value);
              this.locationSrv.sendCurrentLocation(data);          
              this.spinnerService.hide();
            } ,err => {
                this.helper.showSnackbar(err.error.message,false,true);
                this.spinnerService.hide();
              })
          }
        }
      }
      }).catch(err => {
        this.helper.showSnackbar("Error Response :", err);
      });
  }

  /** SET client name **/
  setTenantName(name) {
    this.addLocnForm.get('tenantName').setValue(name);
  }

  /** CLOSE mat dialog **/
  close() {
    this.dialogRef.close(null);
  }

  isLocationExist(locationName){   
    locationName = this.addLocnForm.get('tenantName').value + "-" + locationName;
    this.authSrv.validateLocation(locationName).subscribe(res =>{
      this.errorLocation = null;
    },err=>{
      this.errorLocation = err.error.message;
    }) 
  }

  isEmailExist(emailId){
    this.authSrv.validateLocationEmail(emailId).subscribe(res =>{
      this.errorEmail = null
    },err=>{
      this.addLocnForm.get('email').valueChanges.pipe(debounceTime(1000))
      this.errorEmail = err.error.message;
    })
  } 
}
