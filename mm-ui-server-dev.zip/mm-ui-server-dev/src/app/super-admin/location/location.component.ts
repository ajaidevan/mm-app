import { Component, OnInit, ViewChild } from '@angular/core';
import { LocationService } from '../services/location.service';
import { MatPaginator, MatSort, MatDialog, MatTableDataSource, MatDialogConfig, PageEvent,Sort } from '@angular/material';
import { CreateLocationComponent } from './create-location/create-location.component';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { ValidatorService } from 'app/services/validator.service';
import { ViewInfoComponent } from 'app/shared/view-info/view-info.component';
import { PagableModel } from 'app/models/pagable.model';
import { DataService } from 'app/services/data.service';
import { SuperLocationModel } from 'app/models/location.model';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonApiService } from 'app/services/common-api.service';
import { HelperService } from 'app/services/helper.service';

@Component({
  selector: 'app-location',
  templateUrl: './location.component.html',
  styleUrls: ['./location.component.scss']
})
export class LocationComponent implements OnInit {

  public displayedColumns: string[] = ['id', 'name', 'tenantName', 'address', 'phone', 'email', 'action'];
  public dataSource = new MatTableDataSource();
  public selectedRow: SuperLocationModel;
  public editMode: boolean = false;
  public pagable: PagableModel;
  public activityLog: string;
  public paginate: any = {}
  public total: any;
  public isLoading: boolean = true;
  public pageEvent: PageEvent;
  public pageSizeOptions: number[] = [10, 20, 30];
  public totalLocations: number;
  public searchValue:string;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(private dialog: MatDialog, private locationService: LocationService, private commonSrv: CommonApiService,
    private spinnerService: Ng4LoadingSpinnerService, private data: DataService,private helper:HelperService,
    private validatorService: ValidatorService, private route: ActivatedRoute, private router: Router) { }


  ngOnInit() {
    this.data.currentLog.subscribe(activityLog => this.activityLog = activityLog);
    // for every update and create reload page data.
    this.locationService.currentLocation.subscribe(data => {
      if (this.editMode) {
        //for edit do not change page
        this.refreshLocation(false);
        this.editMode = false;
      } else {
        //for create start with page=0
        this.refreshLocation(true);
      }
    })
    /***defaultPaginate for location data */

    this.defaultPaginateLocation();
    
  }
  ngAfterViewInit() {
 //   this.dataSource.sort=this.sort;
  }


  /** GET admin **/
  getAdmin() {
    this.locationService.getAdminByRole().subscribe(
      data => {
        this.dataSource.data = data;
      },
      err => {
        this.helper.showSnackbar(err.error.message,false, true);
      }
    )
  }
  
  /** open CREATE location **/
  openCreateLocation(newData?): void {
    if (newData) {
      this.data.changeCurrentLog("location-mangement/update");
      this.locationService.setSharedLocation(newData);
    } else {
      this.data.changeCurrentLog("location-mangement/create");
      this.locationService.setSharedLocation("");
    }
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    let dialogRef = this.dialog.open(CreateLocationComponent, dialogConfig);
  }

  /** open VIEW INFO **/
  openViewMode(selectedRow: SuperLocationModel) {
    this.selectedRow = selectedRow;
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.data = {
      'selectedValue': this.selectedRow,
      'tableColumns': this.displayedColumns,
      'columnName': ['Location Id', 'Location Name', 'Client Name', 'Address', 'Phone Number', 'Email'],
      "component": "Location",
      "mode": true
    };
    let dialogRef = this.dialog.open(ViewInfoComponent, dialogConfig);
  };


  /** EDIT a Location **/
  onEditLocation(locationObj) {
    this.editMode = true;
    this.openCreateLocation(locationObj);
  }

  /** DELETE a location **/
  onDeleteLocation(location, index) {
    this.validatorService.userValidator('delete').then(res => {
      if(res.val) {
        delete res.val;
        res.locations = location.name;
            this.spinnerService.show();
            this.locationService.deleteLocation(location,res).subscribe(data => {
              let locationData = this.dataSource.data;
              locationData.splice(Number(index), 1);
              this.refreshLocation();
              this.spinnerService.hide();
              this.dataSource.data = locationData;
            });
          }
    }).catch(err => {
      this.helper.showSnackbar("Error Response :", err);
    });
  }

  

  /** REFRESH Location **/
  refreshLocation(changePage?:boolean) {
    this.searchValue='';
    this.spinnerService.show();
    this.locationService.refreshLocation().subscribe(res => {
      //this.defaultPaginateLocation();
     this.paginateLocation(changePage);
     this.helper.showSnackbar('Table Refreshed Successfully',true);
     this.spinnerService.hide();
    }, err => {
      this.helper.showSnackbar('Failed to Refresh the Table !',false, true);     
    })
  }

  /** Set Default Param **/
  defaultPaginateLocation() {
    this.paginate = this.route.snapshot.data['params'];
    let reqParams = this.commonSrv.createParam(this.paginate);
    this.router.navigate([], { queryParams: reqParams });
    this.dataSource.data=this.route.snapshot.data['locations'].body.content;
    this.totalLocations=this.route.snapshot.data['locations'].body.totalElements
  }

  /** Paginate The Locations**/
  paginateLocation(setPage = true) {
    if (setPage) this.paginate.page = 0;
    let reqParams = this.commonSrv.createParam(this.paginate);
    this.spinnerService.show();
    this.locationService.getAllLocations(reqParams).subscribe(res => {
      this.dataSource.data = res.body.content;
      this.totalLocations = res.body.totalElements;
      this.router.navigate([], { queryParams: reqParams })
      this.spinnerService.hide();
    })
  }


  /** Onchange Page **/
  onChangePage(event?: PageEvent) {
    this.paginate.size = event.pageSize;
    this.paginate.page = event.pageIndex;
    this.paginateLocation(false);
    return event;
  }

  /** Search **/
  search(filterValue?: any) {
    this.locationService.searchLocation(filterValue).subscribe(res => {
      this.dataSource.data = res.body;
    })
  }

  /** Apply Filter **/
  applyFilter(filter: string) {
    if (filter.length >= 3) {
      this.search(filter)
    }
    if(filter.length==0){
      this.paginateLocation();
    }
  }
  /*Sorting*/
  sortData(event: Sort) {
    this.paginate.sort = event.active + ',' + event.direction;
    this.paginateLocation();    
  }

}