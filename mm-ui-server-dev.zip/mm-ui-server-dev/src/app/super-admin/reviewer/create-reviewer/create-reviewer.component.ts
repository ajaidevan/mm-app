import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialogRef } from '@angular/material';
import { FormGroup, FormControl, Validators, FormGroupDirective, NgForm, FormBuilder, FormArray } from '@angular/forms';
import { ErrorStateMatcher } from '@angular/material/core';
import { HelperService } from '../../../services/helper.service';
import { ReviewerService } from '../../services/reviewer.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { ClientService } from 'app/super-admin/services/client.service';
import { LocationService } from 'app/super-admin/services/location.service';
import { FrontValidationService } from 'app/services/front-validation/front-validation.service';
import { DataService } from 'app/services/data.service';
import { PatternValidationService } from 'app/services/front-validation/pattern-validation.service';
import { AuthService } from 'app/services/auth.service';
import { debounceTime } from 'rxjs/operators';
import Swal from 'sweetalert2';
import { ValidatorService } from '../../../services/validator.service';
import { UserRetrievalService } from 'app/services/user.retrieval.service';
import {UserReActivationLinkService} from 'app/services/user-reacivatelink.service';

export class MyErrorStateMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = form && form.submitted;
    return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
  }
}

@Component({
  selector: 'app-create-reviewer',
  templateUrl: './create-reviewer.component.html',
  styleUrls: ['./create-reviewer.component.scss']
})
export class CreateReviewerComponent implements OnInit {

  public errorUser:any;
  public locationsRoles: FormArray;
  public reviewerVal: any;
  public paginateClient:any ={};
  public errorEmail:any;
  public fetchedClientLength:number;
  public oldEmail:string;
  public paginateCompany:any={};
  public fetchedCompanyLength:number;
  public fetchedCompany:[any];
 
 

  public addReviewerForm = this.formBuilder.group({
    id: this.formBuilder.control(''),
    email: this.formBuilder.control('', [Validators.required, Validators.pattern(this.patternSrv.emailPattern),Validators.maxLength(255)]),
    username: this.formBuilder.control('', [Validators.required,Validators.pattern(this.patternSrv.namePattern),Validators.maxLength(15)]),
    address: this.formBuilder.control('', [Validators.required,Validators.pattern(this.patternSrv.addressPattern)]),
    shippingAddress: this.formBuilder.control([]),
    phoneNumber: this.formBuilder.control('', [Validators.required, Validators.pattern(this.patternSrv.numPattern), Validators.maxLength(10), Validators.minLength(10)]),
    tenant: this.formBuilder.control('', Validators.required),
    tenantName: this.formBuilder.control(''),
    locations: this.formBuilder.control('', Validators.required),
    enabled: this.formBuilder.control(false, Validators.required),
    password: this.formBuilder.control('password', Validators.required),
    locationsRoles: this.formBuilder.array([this.createItem()]),
    company: this.formBuilder.array([this.createCompany()],[Validators.required])
  
  });

  createItem(): FormGroup {
    return this.formBuilder.group({
      role: [],
      location: ''
    });
  }
  createCompany(){
    return this.formBuilder.group({
      name:[''],
      tenant: ''
    });
  }
  
  public matcher = new MyErrorStateMatcher();
  public editMode: boolean = false;
  public fetchedClient: [any];
  public dbLoacations: [any];
  public selectedLocations: [any];
  public currentOperation:string;
  public errorMsg:any;
  public addedCompany:boolean=false;
  public paginateClientElements:number;
  public paginateElements:number;
  public totalCompanies:number;
 

  @ViewChild('clientSelect') clientSelect:any;
  @ViewChild('companySelect') companySelect:any;
  
  constructor(private dialogRef: MatDialogRef<CreateReviewerComponent>,
    private helper: HelperService,private data:DataService,
    private reviewerSrv: ReviewerService,private patternSrv:PatternValidationService,
    private clientService: ClientService,private authSrv:AuthService,
    private locationService: LocationService,
    private spinnerService: Ng4LoadingSpinnerService,
    private formBuilder: FormBuilder,private validatorService : ValidatorService,
    private frontValSrv: FrontValidationService,
    private userRetrievalSrv:UserRetrievalService,private userReacivateLinkSrv:UserReActivationLinkService) {}

  ngOnInit() {
    /** Validation Message **/
    this.reviewerVal = this.frontValSrv.validationMsg;
     //Select operation while create either user ,reviewer.
    this.data.currentOperation.subscribe(currentOperation => this.currentOperation = currentOperation);
    this.initForm()
   // this.getAllCleints();
  }

  /** DESTROY editmode **/
  ngOnDestroy() {
    this.editMode = false;
  }

  /** GET all clients **/
  getAllCleints(paginateClient?:any) {
    this.spinnerService.show();
    this.paginateClient.page = 0;
    this.paginateClient.size = (this.fetchedClientLength) ? this.fetchedClientLength : 10;
    this.paginateClient.sort="creationAt,DESC";
    this.clientService.getAllActiveClients(this.paginateClient).subscribe(
      data => {
        this.fetchedClient = data.body.content;
        this.fetchedClientLength=data.body.totalElements;
        this.paginateClientElements=data.body.numberOfElements;
        this.spinnerService.hide();
      }, err => {
        if(err.status=='500'){
          this.helper.showSnackbar('SomeThing Went Wrong Failed To Fetch Clients !',false, true);
        }
        else{
          this.helper.showSnackbar(err.error.message, false, true);
          this.spinnerService.hide();
        }
      })
  }

/**paginate client as load more  */
loadMoreClients(){
  this.clientSelect.open();
  this.paginateClient.size = this.paginateClient.size + 10;
  this.clientService.getAllActiveClients(this.paginateClient).subscribe(
    data => {
      this.fetchedClient = data.body.content;
      this.fetchedClientLength=data.body.totalElements;
      this.paginateClientElements=data.body.numberOfElements;
      this.spinnerService.hide();
    }, err => {
      this.helper.showSnackbar('Failed to LoadMore Clients', false, true);
      this.spinnerService.hide();
    }
  )
  return false;
}

  /** GET all locations by client id **/
  getAllLocationAndCompanyByClient(tenantId) {
    this.spinnerService.show();
    this.locationService.getAllLocationsByClient(tenantId).subscribe(data => {   
      if (data.body.content.length > 0) {
        this.dbLoacations = data.body.content;
      } else {
        data.body.content.push({ "name": "Client has No Location", "disabled":true });
        this.dbLoacations = data.body.content;
      }
      this.spinnerService.hide();
    })
    this.paginateCompany.page = 0;
    this.paginateCompany.size = (this.fetchedCompanyLength) ? this.fetchedCompanyLength : 10;
    this.paginateCompany.sort="creationAt,DESC";
    this.reviewerSrv.getAllCompanies(tenantId,this.paginateCompany).subscribe(data=>{
      this.fetchedCompany = data.body.content;
      this.totalCompanies=data.body.totalElements;
      this.paginateElements=data.body.numberOfElements;
    })
  }

  /**GET All companies  */
  getAllCompanies(tenantId,paginateCompany?:any){
    this.spinnerService.show();
    this.paginateCompany.page = 0;
    this.paginateCompany.size = (this.fetchedCompanyLength) ? this.fetchedCompanyLength : 10;
    this.paginateCompany.sort="creationAt,DESC";
    this.reviewerSrv.getAllCompanies(tenantId,this.paginateCompany).subscribe(
      data => {
        this.fetchedCompany = data.body.content;
        this.spinnerService.hide();
      }, err => {
        if(err.status=='500'){
          this.helper.showSnackbar('Something Went Wrong Failed To Fetch Companies !',false,true);
        }
        else{
          this.helper.showSnackbar(err.error.message,false,true);
          this.spinnerService.hide();
        }
      })
  }
  
/**paginate company as load more  */
loadMoreCompanies(){
  let tenantId=this.addReviewerForm.get('tenant').value;
  this.companySelect.open();
  this.paginateCompany.size = this.paginateCompany.size + 10;
  this.reviewerSrv.getAllCompanies(tenantId,this.paginateCompany).subscribe(
    data => {
      this.fetchedCompany = data.body.content;
      this.totalCompanies=data.body.totalElements;
      this.paginateElements=data.body.numberOfElements;
      this.spinnerService.hide();
    }, err => {
      this.helper.showSnackbar('Failed To Load More Companies',err.error.message);
      this.spinnerService.hide();
    }
  )
  return false;
}

  /** Initialize the FORM */
  initForm() {
    this.reviewerSrv.sharedReviewer.distinctUntilChanged().subscribe(data => {
      if (data) {
        this.addReviewerForm.patchValue(data);
        this.oldEmail = data.email;
        let tenantId = this.addReviewerForm.get("tenant").value;
        this.getAllLocationAndCompanyByClient(tenantId);
         //load all client while edit
        this.clientService.getAllActiveClients(this.paginateClient).subscribe(
          res=>{ this.fetchedClientLength=res.body.totalElements },
          err=>{ console.log(err); },
          ()=>{ this.getAllCleints(); })
        let locations = [];
        for (let locationsRoles of data['locationsRoles']) {
          locations.push(locationsRoles["location"]["name"]);
        }
        this.addReviewerForm.controls["locations"].setValue(locations);
        //load all companies while edit
        this.reviewerSrv.getAllCompanies(tenantId,this.paginateCompany).subscribe(
          data=>{this.fetchedCompanyLength=data.body.totalElements},
          err=>{ console.log(err);},
           ()=>{this.getAllCompanies(tenantId);})
        this.editMode = true;
      } else {
        //load only 10 client while create.
        this.getAllCleints();
      }
    })
  }

  /** CREATE a reviewer **/
  create() {
    this.validatorService.userValidator(this.editMode ?'update':'create').then(res => {
    if(res.val) {
      delete res.val;
      this.data.changeOperation("reviewer");
      if (this.addReviewerForm.valid) {
        let reviewer = this.addReviewerForm.value;
        reviewer['shippingAddress']=null;
        reviewer["locationsRoles"] = [];        
        for (let ln of reviewer["locations"]) {
          let reviewerLocationRoleObj = {
            location: { name: ln },
            role: [{ name: "Reviewer" }]
          }
          reviewer["locationsRoles"].push(reviewerLocationRoleObj);
        }
        res.locations = reviewer["locations"].toString();
        reviewer['company'][0].tenant = reviewer.tenant;
        this.spinnerService.show();
        if (this.editMode) {
          this.data.changeCurrentLog('reviewer-management/update')
          this.reviewerSrv.updateReviewer(reviewer,res).subscribe(
            data => {
              this.dialogRef.close(this.addReviewerForm.value);
              this.reviewerSrv.sendCurrentReviewer(data); 
              if (data) {
                data['locationsRoles']=reviewer["locationsRoles"];           
              }
              this.spinnerService.hide();
              this.helper.showSnackbar('Successfully Updated Reviewer !');
            }, err => {
                if(err.status=='500'){
                  this.helper.showSnackbar('Something Went Wrong Failed To Update Reviewer!',false,true);
                }
                else{
                 this.helper.showSnackbar(err.error.message,false, true);
                 this.spinnerService.hide();
                }
            },()=>{
              this.userReacivateLinkSrv.reactivateUserOnEmailchanges(this.oldEmail,this.addReviewerForm.get('email').value);
            });
        } else {
          this.data.changeCurrentLog('reviewer-management/create')
          delete reviewer["locations"];
          this.reviewerSrv.addReviewer(reviewer,res).subscribe(
            data => {
              this.dialogRef.close(this.addReviewerForm.value);
              this.reviewerSrv.sendCurrentReviewer(data);   
              this.spinnerService.hide();
              this.helper.showSnackbar('Successfully Created Reviewer & Sent activation email !');
            }, err => {
              if(err.status=='500'){
                this.helper.showSnackbar('Something Went Wrong Failed To Create Reviewer!',false,true);
              }
              else{
               this.helper.showSnackbar(err.error.message,false, true);
               this.spinnerService.hide();
              }
            });
        }
    }
  }        
  }).catch(err => {
    this.helper.showSnackbar("Error Response :", err);
  });
  }

  /** CLOSE Mat dialog **/
  close() {
    this.dialogRef.close(null);
  }
    /** SET client name **/
  setTenantName(name) {
    this.addReviewerForm.get('tenantName').patchValue(name);
  }
  isUserExist(username){
    this.authSrv.validateUser(username).subscribe(res =>{
      if(res.body.exist){
        this.errorUser='User Already Exists'
      }
      if(!res.body.exist && !res.body.deleted){
        this.errorUser=null;
      }
    })
  }

  isEmailExist(emailId){
    this.authSrv.validateUser(emailId).subscribe(res =>{
      if(res.body.exist && !res.body.deleted){
        this.errorEmail='Email Already Exists'
      }
      if(!res.body.exist && !res.body.deleted){
        this.errorEmail=null;
      }
      if(res.body.exist && res.body.deleted) {
          this.userRetrievalSrv.userRetrievePopup().then(res=>{
          if(res){
            this.retrieveAndSendReactivationLink(emailId);
          }
          else{
            this.addReviewerForm.get('email').patchValue('');
          }
        });  
      }
    })
  }
  retrieveAndSendReactivationLink(emailId:string){
    this.authSrv.retrieveUser(emailId).subscribe(res=>{
      this.reviewerSrv.sendCurrentReviewer(res); 
      this.helper.showSnackbar('User Retrieved Successfully');
      this.dialogRef.close(this.addReviewerForm.value);
    })
  }

  //addCompany
  addCompany(){
    this.addedCompany=true;
    this.addReviewerForm.get('company').reset();
    
  }
  //removeCompany
  removeCompany(){
    this.addedCompany=false;
  }

  get companiesData() { return <FormArray>this.addReviewerForm.get('company'); }
}
