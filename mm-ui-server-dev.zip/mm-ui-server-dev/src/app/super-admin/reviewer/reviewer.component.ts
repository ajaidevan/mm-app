import { Component, OnInit, ViewChild } from '@angular/core';
import { ReviewerService } from '../services/reviewer.service';
import { MatPaginator, MatSort, MatDialog, MatTableDataSource, MatDialogConfig, PageEvent,Sort } from '@angular/material';
import { CreateReviewerComponent } from './create-reviewer/create-reviewer.component';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { ValidatorService } from 'app/services/validator.service';
import { ViewInfoComponent } from 'app/shared/view-info/view-info.component';
import { DataService } from 'app/services/data.service';
import { SuperUserModel } from 'app/models/user.model';
import { CommonApiService } from 'app/services/common-api.service';
import { ActivatedRoute, Router } from '@angular/router';
import { HelperService } from 'app/services/helper.service';
import{AuthService} from'app/services/auth.service';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-reviewer',
  templateUrl: './reviewer.component.html',
  styleUrls: ['./reviewer.component.scss']
})
export class ReviewerComponent implements OnInit {

  public displayedColumns: string[] = ['id', 'username', 'company', 'tenantName', 'locationsRoles', 'address', 'phoneNumber', 'email', 'status', 'action'];
  public dataSource = new MatTableDataSource();
  public selectedRow: SuperUserModel;
  public editMode: boolean = false;
  public activityLog: string;
  public paginate: any = {}
  public pageEvent: PageEvent;
  public pageSizeOptions: number[] = [10, 20, 30];
  public totalReviewers: number;
  public role: string;
  public searchValue:string;
  public locations:any = [];

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(private dialog: MatDialog, private data: DataService, private commonSrv: CommonApiService,
    private reviewerService: ReviewerService, private route: ActivatedRoute, private router: Router,
    private spinnerService: Ng4LoadingSpinnerService,private helper:HelperService,
    private validatorService: ValidatorService,private authService:AuthService) { }

  ngOnInit() {
    this.data.currentRole.subscribe(currentRole => this.role = currentRole);
    this.data.currentLog.subscribe(activityLog => this.activityLog = activityLog);
    // for every update and create reload page data.
    this.reviewerService.currentReviewer.subscribe(data => {
      if (this.editMode) {
        //for edit do not change page
        this.refreshReviewer(false);
        this.editMode = false;
      } else {
        this.refreshReviewer(true);
      }
    });
    /***default paginate for reviewers data  */
    this.defaultPaginateReviewer();

  }
   ngAfterViewInit() {
    // this.dataSource.sort=this.sort;
  }


  /** Open CREATE reviewer **/
  openCreateReviewer(newData?): void {
    if (newData) {
      this.data.changeCurrentLog("reviewer-mangement/edit");
      this.reviewerService.setSharedReviewer(newData);
    } else {
      this.data.changeCurrentLog("reviewer-mangement/create");
      this.reviewerService.setSharedReviewer("");
    }
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true
    let dialogRef = this.dialog.open(CreateReviewerComponent, dialogConfig);
  }

  // function edit reviwer
  onEditReviewer(user) {
    this.editMode = true;
    this.openCreateReviewer(user);
  }

  /** open VIEW INFO **/
  openViewMode(selectedRow: SuperUserModel) {
    this.selectedRow = selectedRow;
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.data = {
      'selectedValue': this.selectedRow,
      'tableColumns': this.displayedColumns,
      'columnName': ['Reviewer Id', 'Reviewer Name', 'Company', 'Client', 'Location', 'Address', 'Phone Number', 'Email'],
      "component": "Reviewer",
      "mode": true
    };
    let dialogRef = this.dialog.open(ViewInfoComponent, dialogConfig);
  };

  /** DELETE reviewer **/
  onDeleteReviewer(user) {
    this.validatorService.userValidator('delete').then(res => {
      if (res.val) {
       delete res.val;
       res.locations = this.helper.getFormatedLocations(user);
       this.reviewerService.deleteReviewer(user,res).subscribe(data => {
          let reviewer = this.dataSource.data;
          for (const index in reviewer) {
            if (user["id"] == reviewer[index]["id"]) {
              reviewer.splice(Number(index), 1)
              break;
            }
          }
          this.refreshReviewer();
          this.dataSource.data = reviewer;
        })
      }
    }).catch(err => {
      console.log("Error Response ", err);
    });
  }

   /**Reactivate link to email */
   onReactivateReviewer(row){
    Swal.fire({
      title: 'Are you sure?',
      text: "You want to send reactivation link to the email !",
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes',
    }).then((result) => {
      if (result.value) {
        this.validatorService.userValidator('reactivate').then(res => {
          if(res.val) {
            delete res.val;
            res.locations = res.locations = this.helper.getFormatedLocations(row);;
            this.authService.reactivateUser(row.email,res).subscribe(res=>{
                this.helper.showSnackbar("ReActivation Link has been sent to Email successfully!!!"); 
              })
            }
            
        })
      }
    })
  }

  /** REFRESH reviewer **/
  refreshReviewer(changePage?:boolean) {
    this.searchValue='';
    this.spinnerService.show();
    this.reviewerService.refreshReviewer().subscribe(res => {
    //  this.defaultPaginateReviewer();
     this.paginateReviewer(changePage);
     this.helper.showSnackbar('Table Refreshed Successfully',true);
     this.spinnerService.hide();         
    }, err => {
      this.helper.showSnackbar('Failed to Refresh the Table !',false, true);     
    })
  }

  /** Set Default Param **/
  defaultPaginateReviewer() {
    this.paginate = this.route.snapshot.data['params'];
    let reqParams = this.commonSrv.createParam(this.paginate);
    this.router.navigate([], { queryParams: reqParams });
    this.dataSource.data=this.route.snapshot.data['reviewers'].body.content;    
    this.totalReviewers = this.route.snapshot.data['reviewers'].body.totalElements; 
  }

  /**
   * 
   * @param setPage
   */
  /** Paginate The Locations**/

  paginateReviewer(setPage = true) {
    this.data.changeCurrentRole("reviewer");
    if (setPage) this.paginate.page = 0;
    let reqParams = this.commonSrv.createParam(this.paginate);
    this.spinnerService.show();
    this.reviewerService.getAllReviewers(reqParams).subscribe(res => {
      this.router.navigate([], { queryParams: reqParams })
      this.dataSource.data = res.body.content;
      this.totalReviewers = res.body.totalElements;      
      this.spinnerService.hide();
    })
  }

  /**
  * 
  * @param event
  */
  /** Onchange Page **/
  onChangePage(event?: PageEvent) {
    this.paginate.size = event.pageSize;
    this.paginate.page = event.pageIndex;
    this.paginateReviewer(false);
    return event;
  }

  /** Search Reviewers */
  searchReviewer(filterValue) {
    this.reviewerService.search(filterValue).subscribe(data => {
      this.dataSource.data = data.body;
    })
  }

  /** Apply Filter */
  applyFilter(filter) {
    if (filter.length > 2) {
      this.searchReviewer(filter)
    }
    if(filter==0){
      this.paginateReviewer();
    }  
  }

  /*Sorting*/
  sortData(event: Sort) {
    this.paginate.sort = event.active + ',' + event.direction;
    this.paginateReviewer();    
  }
  expand(data,location){
    this.locations = [];
    document.getElementById("overlay").style.display = data;
    if(data == 'block'){
      for(let loc of location){
        this.locations.push(loc.location.name.split("-").length>1 ? loc.location.name.split("-").splice(1): loc.location.name)
      }
    }
  }

}
