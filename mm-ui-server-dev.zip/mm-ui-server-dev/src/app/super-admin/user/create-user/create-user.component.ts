import { Component, OnInit ,ChangeDetectionStrategy,ChangeDetectorRef} from '@angular/core';
import { MatDialogRef, throwMatDuplicatedDrawerError } from '@angular/material';
import { FormGroup, FormControl, Validators, FormGroupDirective, NgForm, FormBuilder, FormArray } from '@angular/forms';
import { ErrorStateMatcher } from '@angular/material/core';
import { LocationService } from 'app/super-admin/services/location.service';
import { UserService } from '../../services/user.service';
import { COMMA, ENTER } from '@angular/cdk/keycodes';
import { ElementRef, ViewChild } from '@angular/core';
import { MatAutocompleteSelectedEvent, MatChipInputEvent, MatAutocomplete } from '@angular/material';
import { Observable } from 'rxjs';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { ClientService } from 'app/super-admin/services/client.service';
import { FrontValidationService } from 'app/services/front-validation/front-validation.service';
import { HelperService } from 'app/services/helper.service';
import { DataService } from 'app/services/data.service';
import { PatternValidationService } from 'app/services/front-validation/pattern-validation.service';
import { AuthService } from 'app/services/auth.service';
import Swal from 'sweetalert2';
import { ValidatorService } from '../../../services/validator.service';
import { UserRetrievalService } from 'app/services/user.retrieval.service';
import {UserReActivationLinkService} from 'app/services/user-reacivatelink.service';


export class MyErrorStateMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = form && form.submitted;
    return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
  }
}

@Component({
  selector: 'app-create-user',
  templateUrl: './create-user.component.html',
  styleUrls: ['./create-user.component.scss'],
  changeDetection:ChangeDetectionStrategy.OnPush,
})
export class CreateUserComponent implements OnInit {

  public errorUser:any;
  public errorEmail:any;
  public locationsRoles: FormArray;
  public roleList: string[] = ["Admin", "QA", "Technician"];
  public editMode: boolean = false;
  public visible: boolean = true;
  public selectable: boolean = true;
  public removable: boolean = true;
  public addOnBlur: boolean = false;
  public separatorKeysCodes: number[] = [ENTER, COMMA];
  public filteredroles: Observable<string[]>;
  public selectedRoles: any[] = [[]];
  public currentSelected: any;
  public fetchedClient: [any];
  public matcher = new MyErrorStateMatcher();
  public dbLoacations: [any];
  public userVal: any;
  public currentOperation :string;
  public noLoc: string;
  public paginateClient:any ={};
  public errorMsg:any;
  public fetchedClientLength:number;
  public oldEmail:string;
  public paginateElements:number;
  public tenantName:string;
  @ViewChild('roleInput') roleInput: ElementRef<HTMLInputElement>;
  @ViewChild('auto') matAutocomplete: MatAutocomplete;
  @ViewChild('clientSelect') clientSelect:any;

  constructor(
    private helper: HelperService,
    private dialogRef: MatDialogRef<CreateUserComponent>,
    private formBuilder: FormBuilder,private data:DataService,
    private locationService: LocationService,private patternSrv:PatternValidationService,
    private clientService: ClientService,private authSrv:AuthService,
    private userService: UserService,
    private spinnerService: Ng4LoadingSpinnerService,
    private validatorService : ValidatorService,
    private frontValSrv: FrontValidationService,private changeDetectorRef: ChangeDetectorRef,
    private userRetrievalSrv:UserRetrievalService,private userReacivateLinkSrv:UserReActivationLinkService) {
    this.locationsRoles = this.userDiagForm.get('locationsRoles') as FormArray;  
  }
  
  ngOnInit() {
    // Creat reviewer form validation
    this.userVal = this.frontValSrv.validationMsg;
    //Select operation while create either user ,reviewer.
    this.data.currentOperation.subscribe(currentOperation => this.currentOperation = currentOperation);
    this.userService.sharedUsers.distinctUntilChanged().subscribe(data => {
      if (data) {
        this.userDiagForm.patchValue(data)
        this.tenantName = data.tenantName
        this.oldEmail = data.email;
        this.addItem(data['locationsRoles']);
        this.getAllLocationByClient(this.userDiagForm.get("tenant").value);
        //load all client while edit
        this.clientService.getAllActiveClients(this.paginateClient).subscribe(
          res=>{ this.fetchedClientLength=res.body.totalElements },
          err=>{ console.log(err); },
          ()=>{ this.getAllCleints(); 
        });
        let formatedLocationsRole = [];
        for (const locationRoles of data['locationsRoles']) {
          formatedLocationsRole.push({ 
            location: locationRoles["location"]["name"],
            role :locationRoles["role"]
          });
        }
        this.userDiagForm.get("locationsRoles").patchValue(formatedLocationsRole);
        this.editMode = true;
      } else {
        //load only 10 client while create.
        this.getAllCleints();
      }
      
    })
  }

  /** USER form **/
  public userDiagForm = this.formBuilder.group({
    id: this.formBuilder.control(''),
    email: this.formBuilder.control('', [Validators.required, Validators.pattern(this.patternSrv.emailPattern),Validators.maxLength(255)]),
    firstName: this.formBuilder.control('', [Validators.required,Validators.pattern(this.patternSrv.namePattern),Validators.maxLength(15)]),
    lastName: this.formBuilder.control('', [Validators.required,Validators.pattern(this.patternSrv.namePattern),Validators.maxLength(15)]),
    enabled: this.formBuilder.control(''),
    tenant: this.formBuilder.control(''),
    tenantName: this.formBuilder.control(''),
    password: this.formBuilder.control('password'),
    locationsRoles: this.formBuilder.array([this.createItem()],[Validators.required])
  });

  /** form array **/
  createItem(): FormGroup {
    return this.formBuilder.group({
      role: [],
      location: ''
    });
  }

  /** ADD chips **/
  addItem(locationRoles?:any): void {
    if (locationRoles) {
      let rolesArray = []
      let count = 0;
      locationRoles.forEach(roles => {
        roles["role"].forEach(r => {
          rolesArray.push(r.name);
        });        
        if (count == 0) {
          this.selectedRoles[0] = rolesArray;
        } else {
          this.selectedRoles.push(rolesArray);          
          this.locationsRoles.push(this.createItem());
        }      
        rolesArray = [];
        count++;
      });     
    } 
    else {
      this.selectedRoles.push([]);
      this.locationsRoles = this.userDiagForm.get('locationsRoles') as FormArray;
      this.locationsRoles.push(this.createItem());
      this.disableSelectedLocation();      
    }
  }

  /** REMOVE chips **/
  removeItem(index): void {
    if (index != 0) {      
      this.locationsRoles = this.userDiagForm.get('locationsRoles') as FormArray;      
      this.locationsRoles.removeAt(index);
      this.selectedRoles.splice(index, 1);
      this.disableSelectedLocation();
    }
  }

  //  function for chips
  add(event: MatChipInputEvent, index: number): void {
    if (!this.matAutocomplete.isOpen) {
      const input = event.input;
      const value = event.value;
      if (input) {
        input.value = '';
      }
    }
  }

  // function for remove the chips
  remove(role, mainIndex): void {
    const index = this.selectedRoles[mainIndex].indexOf(role);
    if (index > 0) {
      this.selectedRoles[mainIndex].splice(index, 1);
    } if (index <= 0) {
      this.selectedRoles[mainIndex].splice(index, 1);
      const locationsRoles = this.userDiagForm.get('locationsRoles') as FormArray;
      locationsRoles.controls[mainIndex].get('role').patchValue(this.selectedRoles[index]);
    }
  }
  
  /** SELECT chips **/
  selected(event: MatAutocompleteSelectedEvent, index: number): void {
    this.currentSelected = event.option.viewValue;
      if ((index || index == 0) && !this.selectedRoles[index].includes(this.currentSelected)) {
        this.selectedRoles[index].push(event.option.viewValue);
      }
    this.roleInput.nativeElement.value = '';
  }

  /** GET all locations by client **/
  getAllLocationByClient(tenant) {
    this.spinnerService.show();
    this.locationService.getAllLocationsByClient(tenant).subscribe(data => {
      if (data.body.content.length > 0) {
        this.dbLoacations = data.body.content;
      } else {
        data.body.content.push({ "name": "Client has No Location" ,"disabled":true});
        this.dbLoacations = data.body.content;
      }
      this.spinnerService.hide();
    })
    this.changeClient();
  }

  /** GET all clients **/
  getAllCleints(paginateClient?:any) {
    this.spinnerService.show();
    this.paginateClient.page = 0;
    this.paginateClient.size = (this.fetchedClientLength) ? this.fetchedClientLength : 10;
    this.paginateClient.sort='creationAt,DESC';
    this.clientService.getAllActiveClients(this.paginateClient).subscribe(
      data => {
        this.fetchedClient = data.body.content;
        this.fetchedClientLength=data.body.totalElements;
        this.paginateElements=data.body.numberOfElements;
        this.changeDetectorRef.markForCheck();
        this.spinnerService.hide();
      }, err => {
          if(err.status=='500'){
            this.helper.showSnackbar('Something Went Wrong Failed To Fetch Clients !',false,true);
          }
          else{
           this.helper.showSnackbar(err.error.message,false, true);
           this.spinnerService.hide();
          }
      }
    )
  }
  /**paginate client as load more  */
  loadMoreClients(){
    this.clientSelect.open();
    this.paginateClient.size = this.paginateClient.size + 10;
    this.clientService.getAllActiveClients(this.paginateClient).subscribe(
      data => {
        this.fetchedClient = data.body.content;
        this.fetchedClientLength=data.body.totalElements;
        this.paginateElements=data.body.numberOfElements;
      }, err => {
        this.helper.showSnackbar(err.error.message,false, true);
      }
    )
    return false;
  }

  /**  CREATE a user **/
  create() {
    this.validatorService.userValidator(this.editMode ?'update':'create').then(res => {
    if(res.val) {
    delete res.val;
    this.data.changeOperation("user");
    this.spinnerService.show();
    if (this.userDiagForm.valid) {
      let userObj = this.userDiagForm.value;
      userObj["roles"] = [];
      userObj["username"] = userObj["firstName"].toLowerCase() + "_" + userObj["lastName"].toLowerCase();
      let locations =[];
      for (let index in this.selectedRoles) {        
        let rolesArray = [];
        for (const role of this.selectedRoles[index]) {
          rolesArray.push({ name: role });
        }
        userObj["locationsRoles"][index]["role"] = rolesArray;
        userObj["locationsRoles"][index]["location"] = {
          name: userObj["locationsRoles"][index]["location"]
        };
        locations.push(userObj["locationsRoles"][index]["location"].name);
      }
      res.locations = locations;
      if (this.editMode) {
        this.data.changeCurrentLog('user-management/edit')
        this.userService.updateUser(userObj,res).subscribe(data => {
            this.userService.sendCreatedUser(userObj);
            this.helper.showSnackbar("Successfully updated A record");
            this.dialogRef.close(this.userDiagForm.value);
            this.spinnerService.hide();            
          },
          err => {
            if(err.status=='500'){
              this.helper.showSnackbar('Something Went Wrong Failed To Update !',false,true);
            }
            else{
             this.helper.showSnackbar(err.error.message,false, true);
             this.spinnerService.hide();
            }
          },()=>{
            this.userReacivateLinkSrv.reactivateUserOnEmailchanges(this.oldEmail,this.userDiagForm.get('email').value);
          });
      }
      else {
        this.data.changeCurrentLog('user-management/create')
        userObj["password"] = "password";
        userObj["enabled"] = false;
        this.userService.addNewUser(userObj,res).subscribe(
          data => {
            this.userService.sendCreatedUser(userObj);
            this.helper.showSnackbar("Activation Email has been sent successfully!!!");
            this.dialogRef.close(this.userDiagForm.value);
            this.spinnerService.hide();
          },
          err => {
            if(err.status=='500'){
              this.helper.showSnackbar('SomethingWent Wrong Failed To Create Record',false,true);
            }
            else{
             this.helper.showSnackbar(err.error.message,false, true);
             this.spinnerService.hide();
            }
          });
        }
      }
    }        
    }).catch(err => {
      this.helper.showSnackbar("Error Response :", err);
    });
  }

  /** disable previous selected location **/
  disableSelectedLocation(){
    this.dbLoacations.forEach(dbLn => {
      dbLn.selected = this.userDiagForm.get('locationsRoles').value.some(ln => ln.location === dbLn.name)
    });
  }

  /** CLOSE mat dialog **/
  close() {
    this.dialogRef.close(null);
  }

  /** DESTROY editmode **/
  ngOnDestroy() {
    this.editMode = false;
    this.changeDetectorRef.detach();
  }
  /** SET client name **/
  setTenantName(name) {
    this.userDiagForm.get('tenantName').setValue(name);
  }

  /** User Exist */
  isUserExist(username){
    this.authSrv.validateUser(username).subscribe(res =>{
      if(res.body.exist){
        this.errorUser='User Already Exists'
      }
      if(!res.body.exist && !res.body.deleted){
        this.errorUser=null;
      }
  }) 
  }

  /** EMail Exist */
  isEmailExist(emailId){
      this.authSrv.validateUser(emailId).subscribe(res =>{
        if(res.body.exist && !res.body.deleted){
          this.errorEmail='Email Already Exists'
        }
        if(!res.body.exist && !res.body.deleted){
          this.errorEmail=null;
        }
        if(res.body.exist && res.body.deleted) {
            this.userRetrievalSrv.userRetrievePopup().then(res=>{
            if(res){
              this.retrieveAndSendReactivationLink(emailId);
            }
            else{
              this.userDiagForm.get('email').patchValue('');
            }
          });  
        }
      })
    }
  
    retrieveAndSendReactivationLink(emailId:string){
      this.authSrv.retrieveUser(emailId).subscribe(res=>{
        this.userService.sendCreatedUser(res);
        this.helper.showSnackbar('User Retrieved Successfully');
        this.dialogRef.close(this.userDiagForm.value);
      })
    }
    
    changeClient(){
      if(this.tenantName !== this.userDiagForm.get('tenantName').value) {
        // To Reset the formArray.
        const control = <FormArray>this.userDiagForm.controls['locationsRoles'];
          for(let i = control.length-1; i >= 0; i--) {
              control.removeAt(i);
              this.selectedRoles = [];
              this.roleInput.nativeElement.value = '';
          }
          // To add one empty location role field.
          this.selectedRoles.push([]);
          this.locationsRoles = this.userDiagForm.get('locationsRoles') as FormArray;
          this.locationsRoles.push(this.createItem())
      }
    }
    
}
