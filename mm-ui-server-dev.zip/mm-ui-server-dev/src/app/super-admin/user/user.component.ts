import { Component, OnInit, ViewChild } from '@angular/core';
import { UserService } from '../services/user.service';
import { MatPaginator, MatSort, MatDialog, MatTableDataSource, MatDialogConfig, PageEvent,Sort } from '@angular/material';
import { CreateUserComponent } from './create-user/create-user.component';
import { FormControl, FormBuilder } from '@angular/forms';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { HelperService } from 'app/services/helper.service';
import { ValidatorService } from 'app/services/validator.service';
import { ViewInfoComponent } from 'app/shared/view-info/view-info.component';
import { DataService } from 'app/services/data.service';
import { SuperUserModel } from 'app/models/user.model';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonApiService } from 'app/services/common-api.service';
import{AuthService} from'app/services/auth.service';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.scss']
})
export class UserComponent implements OnInit {

  public displayedColumns: string[] = ['id', 'firstName', 'lastName', 'email', 'locationsRoles', 'role', 'status', 'action'];
  public selectedRow: SuperUserModel;
  public selectedLocation: any = [{
    location: null,
    role: null
  }];
  public selectedRoles: any = null;
  public locationCellIndex: number;
  public locationList: any[] = [];
  public locationIndexes = new Array();
  public selecteLocation: any;
  public editMode: boolean = false;
  public activityLog: string;
  public dataSource = new MatTableDataSource();
  public userRoleLocationForm = this.formBuilder.group({
    locationsRoles: new FormControl([])
  });
  public rowData: any;
  public roles: any[] = [{ name: "Admin" }, { name: "QA" }, { name: "Technician" }];
  public paginate:any={}
  public total:any;
  public isLoading:boolean=true;
  public userList: any = [];
  public pageEvent:PageEvent;
  public pageSizeOptions: number[] = [10, 20, 30];
  public totalUsers:number ;
  public searchValue:string;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(private dialog: MatDialog, private userService: UserService, private formBuilder: FormBuilder,
    private spinnerService: Ng4LoadingSpinnerService, private helper: HelperService, private data: DataService,
    private authService:AuthService,private validatorService: ValidatorService,private route:ActivatedRoute,
    private router:Router,private commonSrv:CommonApiService) {}

  ngOnInit() {
    this.data.currentLog.subscribe(activityLog => this.activityLog = activityLog);

    // for every update and create reload page data.
    this.userService.createdCurrentUser.subscribe(data => {
      if (this.editMode) {
        //for edit do not change page
        this.refreshUser(false);
        this.editMode = false;
      } else {
        //for create start with page=0
        this.refreshUser(true);
      }
     this.defulatLocationRoleSelect(this.dataSource.data);      
    });
    this.defaultPaginateUser();
  }

  ngAfterViewInit() {
    // this.dataSource.sort=this.sort;
  }

 
  /** default location select role **/
  defulatLocationRoleSelect(data) {
    this.locationList = [];
    let lnIndexes = [];
    for (let outerIndex in data) {
      if (data[outerIndex]['locationsRoles']) {
        this.locationList.push(data[outerIndex]['locationsRoles'][0]);
        lnIndexes.push(parseInt(outerIndex));
      }
    }
    this.locationIndexes = lnIndexes;
  }

  /** open CREATE user **/
  openCreateUser(newData?): void {
    if (newData) {
      this.userService.setSharedUser(newData);
    } else {
      this.userService.setSharedUser("");
    }
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    let dialogRef = this.dialog.open(CreateUserComponent, dialogConfig);
  }

  /** DELETE user **/
  onDeleteUser(user) {
    this.validatorService.userValidator('delete').then(res => {
      if (res.val) {
        delete res.val;
        res.locations = this.helper.getFormatedLocations(user);
        this.userService.deleteUser({ id: user.id },res).subscribe(data => {
          let userData = this.dataSource.data;
          for (const index in userData) {
            if (user.id == userData[index]["id"]) {
              userData.splice(Number(index), 1)
              break;
            }
          }
          this.dataSource.data = userData;
          this.refreshUser();
        });
      }
    }).catch(err => {
      console.log("Delete User Error", err);
    });
  }

   /**Reactivate link to email */
  onReactivateUser(row){
    Swal.fire({
      title: 'Are you sure?',
      text: "You want to send reactivation link to the email !",
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes',
    }).then((result) => {
      if (result.value) {
        this.validatorService.userValidator('reactivate').then(res => {
          if(res.val){
          delete res.val;
            res.locations = this.helper.getFormatedLocations(row);
            this.authService.reactivateUser(row.email,res).subscribe(res=>{
              this.helper.showSnackbar("ReActivation Link has been sent to Email successfully!!!"); 
            })
          }
        }).catch(err => {
          this.helper.showSnackbar("Error Response :", err);
        });
      }
    })
  }


  /** EDIT user **/
  onEditUser(userObj) {
    this.editMode = true;
    this.openCreateUser(userObj);    
  }

  /** open VIEW INFO **/
  openViewMode(selectedRow: SuperUserModel) {
    this.selectedRow = selectedRow
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.data = {
      'selectedValue': this.selectedRow,
      'tableColumns': this.displayedColumns,
      'columnName': ['ID', 'First Name', 'Last Name', 'Email'],
      "component": "User",
      "mode": true
    };
    let dialogRef = this.dialog.open(ViewInfoComponent, dialogConfig);
  };

  // onchange function
  onChange($event: any, index?) {
    this.selectedLocation = $event;
    this.selectedRoles = this.selectedLocation.role;
    this.locationCellIndex = index;
  }

  /** SELECT location **/
  getselecteLocation(index) {
    return this.rowData[index]['locationsRoles'][0];
  }

  /** refresh USER **/
  refreshUser(changePage?:boolean) {
    this.searchValue='';
    this.spinnerService.show();
    this.userService.refreshUser().subscribe(res => {
    //  this.defaultPaginateUser();
      this.onChange(event);
      this.paginateUser(changePage);
      this.helper.showSnackbar('Table Refreshed Successfully',true);
      this.spinnerService.hide();
    }, err => {
      this.helper.showSnackbar('Failed To Refresh Table',false,true);
    })
  }

  /** Set Default Param */
  defaultPaginateUser(){
    this.paginate = this.route.snapshot.data['params'];
    let reqParams = this.commonSrv.createParam(this.paginate);
    this.router.navigate([], { queryParams: reqParams });
    this.dataSource.data = this.route.snapshot.data['users'].body.content;
    this.rowData = this.route.snapshot.data['users'].body.content;
    this.defulatLocationRoleSelect(this.rowData);
    this.totalUsers =this.route.snapshot.data['users'].body.totalElements;   
    
  }  
  /**
   * 
   * @param setPage
   */
  paginateUser(setPage=true){
    if(setPage)
    this.paginate.page=0;    
    let reqParams = this.commonSrv.createParam(this.paginate);
    this.spinnerService.show();
    this.userService.getAllUsers(reqParams).subscribe(response=>{
      this.dataSource.data = response.body.content,
      this.rowData = response.body.content; 
      this.totalUsers=response.body.totalElements;
      this.router.navigate([],{queryParams:reqParams})
      this.defulatLocationRoleSelect(this.rowData);
      this.spinnerService.hide();
      })    
  }

  /**
   * 
   * @param event
   */
  onChangePage(event?:PageEvent) {
    this.paginate.size = event.pageSize;
    this.paginate.page = event.pageIndex;
    this.paginateUser(false);
    return event;
  }

  /** SEARCH User **/
  search(filterValue?:any){
    this.userService.searchUser(filterValue).subscribe(res=>{
      this.dataSource.data = res.body;
      this.rowData = res.body;
      this.defulatLocationRoleSelect(this.rowData)
    })
  }

  /** Apply Filter **/
  applyFilter(filter:string){
    if(filter.length>2){
      this.search(filter)
    }
    if(filter.length==0){
     this.paginateUser();
    }
  }
  /*Sorting*/
  sortData(event: Sort) {
    this.paginate.sort = event.active + ',' + event.direction;
    this.paginateUser();    
  }

}
