import { Routes } from '@angular/router';
import { LocationComponent } from './location/location.component';
import { ClientComponent } from './client/client.component';
import { UserComponent } from './user/user.component';
import { SuperAdminComponent } from './super-admin/super-admin.component';
import { ReviewerComponent } from './reviewer/reviewer.component';
import{LocationResolver}from'./services/location.resolver';
import { ClientResolver } from './services/client.resolver';
import { UserResolver } from './services/user.resolver';
import { ReviewerResolver } from './services/reviewer.resolver';
export const AdminRoutes: Routes = [{
  path: '',
  redirectTo: 'admin',
  pathMatch: 'full',
}, {
  path: '',
  children: [{
    path: 'admin',
    component: SuperAdminComponent
  }, {
    path: 'client',
    component: ClientComponent,
    resolve:{clients:ClientResolver},
    data:{
      params:{
        page: 0,
        size: 10,
        sort:'creationAt,DESC',
      }
    }
     }, {
    path: 'location',
    component: LocationComponent,
    resolve: { locations: LocationResolver },
      data:{
        params:{
          page: 0,
          size: 10,
          sort:'creationAt,DESC',
      }  
    }
  }, {
    path: 'user',
    component: UserComponent,
    resolve:{users:UserResolver},
    data:{
      params:{
        page: 0,
        size: 10,
        sort:'creationAt,DESC',
      }
    }
    
  }, {
    path: 'reviewer',
    component: ReviewerComponent,
    resolve:{reviewers:ReviewerResolver},
    data:{
      params:{
        page: 0,
        size: 10,
        sort:'creationAt,DESC',
      }
    }
  }],  
}];
