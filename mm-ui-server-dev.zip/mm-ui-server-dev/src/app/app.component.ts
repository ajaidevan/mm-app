import { Component, OnInit } from '@angular/core';
import { TranslateService } from 'ng2-translate/ng2-translate';
import { AuthService } from './services/auth.service';
import { HelperService } from './services/helper.service';
import { AutoLogoutService } from './services/auto-logout.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styles: [`
  :host ::ng-deep .custom-spinner-template {
    height: 25% !important;
    width: 25% !important;
    top: 36% !important;
    left: 40% !important;
  }
  `]
})
export class AppComponent implements OnInit {

  public template: string = `<img class="custom-spinner-template" src="./assets/images/ripple.gif">`

  constructor(translate: TranslateService, private authService: AuthService, private helperSrv: HelperService,private autoLogoutSrv: AutoLogoutService) {
    translate.addLangs(['en', 'fr']);
    translate.setDefaultLang('en');
    const browserLang: string = translate.getBrowserLang();
    translate.use(browserLang.match(/en|fr/) ? browserLang : 'en');
  }

  ngOnInit() {
    if (this.authService.isLoggedIn()) {
      this.authService.setScope();
    }
  }

}
