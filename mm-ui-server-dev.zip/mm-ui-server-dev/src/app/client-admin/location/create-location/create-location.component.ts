import { Component, OnInit, OnDestroy } from '@angular/core';
import { MatDialogRef } from '@angular/material';
import { FormGroup, FormControl, Validators, FormGroupDirective, NgForm } from '@angular/forms';
import { ErrorStateMatcher } from '@angular/material/core';
import { HelperService } from '../../../services/helper.service';
import { LocationService } from '../../services/location.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { FrontValidationService } from 'app/services/front-validation/front-validation.service';
import { DataService } from 'app/services/data.service';
import { PatternValidationService } from 'app/services/front-validation/pattern-validation.service';
import { AuthService } from 'app/services/auth.service';
import { debounceTime } from 'rxjs/operators';
import { ValidatorService } from '../../../services/validator.service';

export class MyErrorStateMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = form && form.submitted;
    return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
  }
}

@Component({
  selector: 'app-create-location',
  templateUrl: './create-location.component.html',
  styleUrls: ['./create-location.component.scss']
})

export class CreateLocationComponent implements OnInit, OnDestroy {

  public locationVal: any;
  public errorEmail:any;
  public isLocation:boolean = false;
  public errorLocation:any;
  public oldEmail:string;

  // form for create location
  public addLocnForm = new FormGroup({
    id: new FormControl(''),
    email: new FormControl('', [Validators.required, Validators.pattern(this.patternSrv.emailPattern),Validators.maxLength(60)]),
    phone: new FormControl('', [Validators.required, Validators.pattern(this.patternSrv.numPattern), Validators.maxLength(10),Validators.minLength(10)]),
    address: new FormControl('', [Validators.required,Validators.maxLength(255),Validators.pattern(this.patternSrv.addressPattern)]),
    name: new FormControl('',[ Validators.required,Validators.pattern(this.patternSrv.namePattern),Validators.maxLength(50)]),
    tenantName: new FormControl('')
  });


  public matcher = new MyErrorStateMatcher();
  public editMode: boolean = false;
  public errorMsg:any;

  constructor(private dialogRef: MatDialogRef<CreateLocationComponent>,
    private helper: HelperService,private data:DataService,private authSrv:AuthService,
    private locationSrv: LocationService,private patternSrv:PatternValidationService,
    private spinnerService: Ng4LoadingSpinnerService,private validatorService: ValidatorService,
    private frontValSrv: FrontValidationService
  ) { }

  ngOnInit() {
    // Validation For create new location
    this.locationVal = this.frontValSrv.validationMsg;
    this.locationSrv.sharedLocation.distinctUntilChanged().subscribe(data => {
      if (data) {
        data.name = data.name.replace(`${data.tenantName}-`, "");
        this.addLocnForm.patchValue(data);
        this.editMode = true;
      }
    })
  }

  /** DESTROY editmode **/
  ngOnDestroy() {
    this.editMode = false;
  }

  /** CREATE a location **/
  create() {
    this.validatorService.userValidator(this.editMode ?'update':'create').then(res => {
      if(res.val) {
      delete res.val;
        let locationObj = this.addLocnForm.value;
        locationObj.tenant = this.helper.getTenantId();
        locationObj.tenantName = this.helper.getUserName();
        locationObj['name'] = this.helper.getUserName() + "-" + this.addLocnForm.get('name').value;
        res.locations = locationObj.name;
        if (this.editMode) {
          if (this.addLocnForm.valid) {
            this.locationSrv.updateLocation(locationObj,res).subscribe(data => {
              this.helper.showSnackbar('Successfully Updated Location !');
              this.dialogRef.close(this.addLocnForm.value);
              this.locationSrv.sendCurrentLocation(data);
              this.spinnerService.hide();
            })
          }
        } else {
          if (this.addLocnForm.valid) {
            delete locationObj["id"];
            this.locationSrv.addLocation(locationObj,res).subscribe(data => {
              this.helper.showSnackbar('Successfully Created Location!');
              this.dialogRef.close(this.addLocnForm.value);
              this.locationSrv.sendCurrentLocation(data);
            })
          }
        }
      }
    })
  }

  /** CLOSE mat dialog **/
  close() {
    this.dialogRef.close(null);
  }

  isLocationExist(locationName){
    locationName = this.helper.getUserName() + "-" + locationName;
    this.authSrv.validateLocation(locationName).subscribe(res =>{
      this.errorLocation = null;
    },err=>{
      this.errorLocation = err.error.message;
    }) 
  }

  isEmailExist(emailId){
    this.authSrv.validateLocationEmail(emailId).subscribe(res =>{
      this.errorEmail = null;
    },err=>{
      this.addLocnForm.get('email').valueChanges.pipe(debounceTime(1000))
      this.errorEmail = err.error.message;
    })
  }
}
