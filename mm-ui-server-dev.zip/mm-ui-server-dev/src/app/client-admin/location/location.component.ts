import { Component, OnInit, ViewChild } from '@angular/core';
import { LocationService } from '../services/location.service';
import { MatPaginator, MatSort, MatDialog, MatTableDataSource, MatDialogConfig, PageEvent,Sort } from '@angular/material';
import { CreateLocationComponent } from './create-location/create-location.component';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { ValidatorService } from 'app/services/validator.service';
import { ViewInfoComponent } from 'app/shared/view-info/view-info.component';
import { DataService } from 'app/services/data.service';
import { ClientLocationModel } from 'app/models/location.model';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonApiService } from 'app/services/common-api.service';
import { HelperService } from 'app/services/helper.service';

@Component({
  selector: 'app-location',
  templateUrl: './location.component.html',
  styleUrls: ['./location.component.scss']
})

export class LocationComponent implements OnInit {

  public displayedColumns: string[] = ['location_index', 'name', 'address', 'phone', 'email', 'action'];
  public dataSource = new MatTableDataSource();
  public activityLog: string;
  public selectedRow: ClientLocationModel;
  public editMode: boolean = false;
  public paginate: any;
  public totalLocations: number;
  public pageEvent:PageEvent;
  public searchValue:string;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(private dialog: MatDialog, private locationService: LocationService, private data: DataService,private helper:HelperService,
    private spinnerService: Ng4LoadingSpinnerService, private validatorService: ValidatorService, private route: ActivatedRoute,
    private router: Router, private commonSrv: CommonApiService) { }

  ngOnInit() {
    this.data.currentLog.subscribe(activityLog => this.activityLog = activityLog);
    this.locationService.currentLocation.subscribe(data => {
      if (this.editMode) {
      //for edit do not change page
        this.refreshLocation(false);
        this.editMode = false;
      } else {
        //for create start with page=0
        this.refreshLocation(true);
      }
    });
   //for default paginated location data.
   this.defaultPaginatedLocations();
 }

  ngAfterViewInit() {
    //this.dataSource.sort=this.sort;
  }

  /** open CREATE location **/
  openCreateLocation(newData?): void {
    if (newData) {
      this.locationService.setSharedLocation(newData);
    } else {
      this.locationService.setSharedLocation("");
    }
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true
    let dialogRef = this.dialog.open(CreateLocationComponent, dialogConfig);
  }

  /** EDIT a location **/
  onEditLocation(locationObj) {
    this.editMode = true;
    this.openCreateLocation(locationObj);
  }

  /** DELETE  a location **/
  onDeleteLocation(location, index) {
    this.validatorService.userValidator('delete').then(res => {
      if(res.val) {
      delete res.val;
      res.locations = location.name;
        this.locationService.deleteLocation(location,res).subscribe(data => {
          let locationData = this.dataSource.data;
          locationData.splice(Number(index), 1);
          this.dataSource.data = locationData;
          this.refreshLocation();
        });
      }
    });
  }


  /** open VIEW INFO **/
  openViewMode(selectedRow: ClientLocationModel) {
    this.selectedRow = selectedRow;
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.data = {
      'selectedValue': this.selectedRow,
      'tableColumns': this.displayedColumns,
      'columnName': ['Location Id', 'Location Name', 'Address', 'Phone Number', 'Email'],
      "component": "Location",
      "mode": true
    };
    let dialogRef = this.dialog.open(ViewInfoComponent, dialogConfig);
  };

  /** REFRESH Location **/
  refreshLocation(changePage?:boolean) {
    this.searchValue='';
    this.spinnerService.show();
    this.locationService.refreshLocation().subscribe(res => {
      this.paginateLocation(changePage);
      this.helper.showSnackbar('Table Refreshed Successfully',true);
      this.spinnerService.hide();
      }, err => {
          this.helper.showSnackbar('Failed To Refresh table',false, true);
      })
  }

  /** Set Default Param **/
  defaultPaginatedLocations(){
    this.paginate = this.route.snapshot.data['params'];
    let reqParams = this.commonSrv.createParam(this.paginate);
    this.router.navigate([], { queryParams: reqParams });
    this.dataSource.data=this.route.snapshot.data['locations'].body.content;
    this.totalLocations =this.route.snapshot.data['locations'].body.totalElements;
  }

  /** Paginate The Locations**/
  paginateLocation(setPage = true) {
    if (setPage) this.paginate.page = 0;
    let reqParams = this.commonSrv.createParam(this.paginate);
    this.locationService.getAllLocationsByClient(reqParams).subscribe(data => {
      this.dataSource.data = data.body.content;
      this.totalLocations = data.body.totalElements;
      this.router.navigate([], { queryParams: reqParams });
    });
  }

  /** Search **/
  search(filterValue?:any){
   this.locationService.searchLocation(filterValue).subscribe(res=>{
      this.dataSource.data = res.body;
    })
  }  
  
  /** Apply Filter **/
  applyFilter(filter:string){    
    if(filter.length>=3){      
      this.search(filter)        
    }
    if(filter.length==0){
      this.paginateLocation();
    }
  }
 
  /** Onchange Page **/
  onChangePage(event?: PageEvent) {
    this.paginate.size = event.pageSize;
    this.paginate.page = event.pageIndex;
    this.paginateLocation(false);
    return event;
  }
  
   /*Sorting*/
   sortData(event: Sort) {
    this.paginate.sort = event.active + ',' + event.direction;
    this.paginateLocation();    
  }

}