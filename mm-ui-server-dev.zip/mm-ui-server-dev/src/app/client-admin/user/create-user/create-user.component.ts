import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material';
import { FormGroup, FormControl, Validators, FormGroupDirective, NgForm, FormBuilder, FormArray } from '@angular/forms';
import { ErrorStateMatcher } from '@angular/material/core';
import { HelperService } from '../../../services/helper.service';
import { LocationService } from '../../services/location.service';
import { UserService } from '../../services/user.service';
import { COMMA, ENTER } from '@angular/cdk/keycodes';
import { ElementRef, ViewChild } from '@angular/core';
import { MatAutocompleteSelectedEvent, MatChipInputEvent, MatAutocomplete } from '@angular/material';
import { Observable } from 'rxjs';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { FrontValidationService } from 'app/services/front-validation/front-validation.service';
import { DataService } from 'app/services/data.service';
import { PatternValidationService } from 'app/services/front-validation/pattern-validation.service';
import { AuthService } from 'app/services/auth.service';
import Swal from 'sweetalert2';
import { ValidatorService } from '../../../services/validator.service';
import { UserRetrievalService } from 'app/services/user.retrieval.service';
import {UserReActivationLinkService} from 'app/services/user-reacivatelink.service';

export class MyErrorStateMatcher implements ErrorStateMatcher {

  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = form && form.submitted;
    return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
  }

}

@Component({
  selector: 'app-create-user',
  templateUrl: './create-user.component.html',
  styleUrls: ['./create-user.component.scss']
})
export class CreateUserComponent implements OnInit {

  public errorEmail:any;
  public locationsRoles: FormArray;
  public roleList: string[] = ["Admin", "QA", "Technician"];
  public editMode: boolean = false;
  public visible: boolean = true;
  public selectable: boolean = true;
  public removable: boolean = true;
  public addOnBlur: boolean = false;
  public separatorKeysCodes: number[] = [ENTER, COMMA];
  public filteredroles: Observable<string[]>;
  public selectedRoles: any[] = [[]];
  public currentSelected: String;
  public matcher = new MyErrorStateMatcher();
  public dbLoacations: [any];
  public userVal: any;
  public errorMsg:any;
  public oldEmail:string;

  @ViewChild('roleInput') roleInput: ElementRef<HTMLInputElement>;
  @ViewChild('auto') matAutocomplete: MatAutocomplete;

  constructor(
    private dialogRef: MatDialogRef<CreateUserComponent>,
    private helper: HelperService,private data:DataService,
    private formBuilder: FormBuilder,private patternSrv:PatternValidationService,
    private locationService: LocationService,private authSrv:AuthService, 
    private userService: UserService,private validatorService: ValidatorService,
    private spinnerService: Ng4LoadingSpinnerService,
    private frontValSrv: FrontValidationService,private userRetrievalSrv:UserRetrievalService,
    private userReacivateLinkSrv:UserReActivationLinkService) {
    this.locationsRoles = this.userDiagForm.get('locationsRoles') as FormArray;
  }

  ngOnInit() {
    // Validation for create new user
    this.userVal = this.frontValSrv.validationMsg;
    this.getAllLocations();
    this.userService.sharedUsers.distinctUntilChanged().subscribe(data => {
      if (data) {
        this.userDiagForm.patchValue(data);
        this.oldEmail = data.email;
        this.editMode = true;
      }
      if (data) {
        this.userDiagForm.patchValue(data);
        this.addItem(data['locationsRoles']);
        let locations = [];
        for (const locationRoles of data['locationsRoles']) {
          locations.push({ location: locationRoles["location"]["name"] });
        }
        this.editMode = true;
        this.userDiagForm.get("locationsRoles").patchValue(locations)
      }
    });
  }

  /** USER form **/
  public userDiagForm = this.formBuilder.group({
    id: this.formBuilder.control(''),
    email: this.formBuilder.control('', [Validators.required, Validators.pattern(this.patternSrv.emailPattern),Validators.maxLength(255)]),
    firstName: this.formBuilder.control('', [Validators.required, Validators.pattern(this.patternSrv.namePattern),Validators.maxLength(15)]),
    lastName: this.formBuilder.control('', [Validators.required, Validators.pattern(this.patternSrv.namePattern),Validators.maxLength(15)]),
    enabled: this.formBuilder.control(''),
    tenant: this.formBuilder.control('NA'),
    tenantName: this.formBuilder.control(''),
    password: this.formBuilder.control('password'),
    locationsRoles: this.formBuilder.array([this.createItem()],[Validators.required])
  });

  /** form array for LOCATION and ROLES **/
  createItem(): FormGroup {
    return this.formBuilder.group({
      role: [],
      location: ''
    });
  }

  /** ADD fields **/
  addItem(locationRoles?:any): void {
    if (locationRoles) {
      let rolesArray = []
      let count = 0;
      for (let roles of locationRoles ){
        roles["role"].forEach(r => {
          rolesArray.push(r.name);
        });
        if (count == 0) this.selectedRoles[0] = rolesArray;
        else {
          this.selectedRoles.push(rolesArray);
          this.locationsRoles.push(this.createItem());
        }
        rolesArray = [];
        count++;
      }
      // locationRoles.forEach(roles => {
      //   roles["role"].forEach(r => {
      //     rolesArray.push(r.name);
      //   });
      //   if (count == 0) this.selectedRoles[0] = rolesArray;
      //   else {
      //     this.selectedRoles.push(rolesArray);
      //     this.locationsRoles.push(this.createItem());
      //   }
      //   rolesArray = [];
      //   count++;
      // });
    } else {
      this.selectedRoles.push([]);
      this.locationsRoles = this.userDiagForm.get('locationsRoles') as FormArray;
      this.locationsRoles.push(this.createItem());
      this.disableSelectedLocation(); 
    }
  }

  /** REMOVE fields **/
  removeItem(index): void {
    if (index != 0) {
      this.locationsRoles = this.userDiagForm.get('locationsRoles') as FormArray;
      this.locationsRoles.removeAt(index);
      this.selectedRoles.splice(index, 1);
      this.disableSelectedLocation();
    }
  }

  /** ADD chips **/
  add(event: MatChipInputEvent, index: number): void {
    if (!this.matAutocomplete.isOpen) {
      const input = event.input;
      const value = event.value;
      if (input) {
        input.value = '';
      }
    }
  }

  /** REMOVE chips **/
  remove(role, mainIndex): void {
    const index = this.selectedRoles[mainIndex].indexOf(role);
    if (index > 0) {
      this.selectedRoles[mainIndex].splice(index, 1);
    }
    if (index <=0) {
      this.selectedRoles[mainIndex].splice(index, 1);
      const locationsRoles = this.userDiagForm.get('locationsRoles') as FormArray;
      locationsRoles.controls[mainIndex].get('role').patchValue(null);
    }
  }

  /** SELECT chips **/
  selected(event: MatAutocompleteSelectedEvent, index: number): void {
    this.currentSelected = event.option.viewValue;
    if ((index || index == 0) && !this.selectedRoles[index].includes(this.currentSelected)) {
      this.selectedRoles[index].push(event.option.viewValue);
    }
    this.roleInput.nativeElement.value = '';
  }

  /** GET all locations **/
  getAllLocations() {
    this.locationService.getAllLocationsByClient({}).subscribe(data => {
      if (data.body.content.length > 0) {
        this.dbLoacations = data.body.content;
      } else {
        data.body.content.push({ "name": "Client has No Location" ,"disabled":true});
        this.dbLoacations = data.body.content;
      }
    })
  }

  /** CREATE a user **/
  create() {
    this.validatorService.userValidator(this.editMode ?'update':'create').then(res => {
      if(res.val) {
      delete res.val;
        this.data.changeOperation("user");
        if (this.userDiagForm.valid) {
          let userObj = this.userDiagForm.value;
          userObj.tenant = this.helper.getTenantId();
          userObj.tenantName = this.helper.getTenantName();
          userObj["roles"] = [];
          let locations =[];
          userObj["username"] = userObj["firstName"].toLowerCase() + "_" + userObj["lastName"].toLowerCase();
          for (let index in this.selectedRoles) {
            let rolesArray = [];
            for (const role of this.selectedRoles[index]) {
              rolesArray.push({ name: role });
            }
            userObj["locationsRoles"][index]["role"] = rolesArray;
            userObj["locationsRoles"][index]["location"] = {
              name: userObj["locationsRoles"][index]["location"]
            }
            locations.push(userObj["locationsRoles"][index]["location"].name);
          }
          res.locations = locations;        
          if (this.editMode) {
            this.userService.updateUser(userObj,res).subscribe(data => {
              this.userService.sendCreatedUser(userObj);                   
              this.helper.showSnackbar('Successfully updated A record');
              this.dialogRef.close(this.userDiagForm.value);
            }, err => {
                if(err.status='500'){
                  this.helper.showSnackbar('Something Went Wrong Failed To Update !',false, true);
                }
               else{
                 this.helper.showSnackbar(err.error.message,false, true);
               }
              },()=>{
              this.userReacivateLinkSrv.reactivateUserOnEmailchanges(this.oldEmail,this.userDiagForm.get('email').value);
            });
          } else {
            userObj["password"] = "password";
            userObj["enabled"] = false;
            delete userObj["id"];
            this.userService.addNewUser(userObj,res).subscribe(data => {
              this.userService.sendCreatedUser(userObj);
              this.helper.showSnackbar('Successfully sent activation email!!!');
              this.dialogRef.close(this.userDiagForm.value);
            });
          }
        }
      }
  })
  }
   /** disable previous selected location **/
   disableSelectedLocation(){
    this.dbLoacations.forEach(dbLn => {
      dbLn.selected = this.userDiagForm.get('locationsRoles').value.some(ln => ln.location === dbLn.name)
    });
  }

  /** CLOSE mat dialog **/
  close() {
    this.dialogRef.close(null);
  }

  /** DESTROY editmode **/
  ngOnDestroy() {
    this.editMode = false;
  }

  /** EMail Exist */
  isEmailExist(emailId){
    this.authSrv.validateUser(emailId).subscribe(res =>{
      if(res.body.exist && !res.body.deleted){
        this.errorEmail='Email Already Exists'
      }
      if(!res.body.exist && !res.body.deleted){
        this.errorEmail=null;
      }
      if(res.body.exist && res.body.deleted) {
          this.userRetrievalSrv.userRetrievePopup().then(res=>{
          if(res){
            this.retrieveAndSendReactivationLink(emailId);
          }
          else{
            this.userDiagForm.get('email').patchValue('');
          }
        });  
      }
    })
  }
  retrieveAndSendReactivationLink(emailId:string){
    this.authSrv.retrieveUser(emailId).subscribe(res=>{
      this.userService.sendCreatedUser(res);
      this.helper.showSnackbar('User Retrieved Successfully');
      this.dialogRef.close(this.userDiagForm.value);
    })
  }
}
