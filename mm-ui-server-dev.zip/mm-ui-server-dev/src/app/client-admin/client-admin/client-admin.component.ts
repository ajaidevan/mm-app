import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-client-admin',
  templateUrl: './client-admin.component.html',
  styleUrls: ['./client-admin.component.scss']
})
export class ClientAdminComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
