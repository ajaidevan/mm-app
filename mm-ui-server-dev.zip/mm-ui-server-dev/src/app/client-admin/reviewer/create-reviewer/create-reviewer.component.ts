import { Component, OnInit ,ViewChild} from '@angular/core';
import { MatDialogRef } from '@angular/material';
import { FormGroup, FormControl, Validators, FormGroupDirective, NgForm ,FormBuilder, FormArray} from '@angular/forms';
import { ErrorStateMatcher } from '@angular/material/core';
import { HelperService } from '../../../services/helper.service';
import { ReviewerService } from '../../services/reviewer.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { LocationService } from 'app/client-admin/services/location.service';
import { FrontValidationService } from 'app/services/front-validation/front-validation.service';
import { DataService } from 'app/services/data.service';
import { PatternValidationService } from 'app/services/front-validation/pattern-validation.service';
import { AuthService } from 'app/services/auth.service';
import { debounceTime } from 'rxjs/operators';
import Swal from 'sweetalert2';
import { ValidatorService } from 'app/services/validator.service';
import { UserRetrievalService } from 'app/services/user.retrieval.service';
import {UserReActivationLinkService} from 'app/services/user-reacivatelink.service';

export class MyErrorStateMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = form && form.submitted;
    return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
  }
}

@Component({
  selector: 'app-create-reviewer',
  templateUrl: './create-reviewer.component.html',
  styleUrls: ['./create-reviewer.component.scss']
})
export class CreateReviewerComponent implements OnInit {

  public errorUser:any;
  public errorEmail:any;
  public reviewerVal: any;
  public errorMsg:any;
  public oldEmail:string;

  public addReviewForm = new FormGroup({
    id: new FormControl(''),
    email: new FormControl('', [Validators.required, Validators.pattern(this.patternSrv.emailPattern),Validators.maxLength(255)]),
    username: new FormControl('', [Validators.required,Validators.pattern(this.patternSrv.namePattern),Validators.maxLength(15)]),
    address: new FormControl('', [Validators.required,Validators.maxLength(255),Validators.pattern(this.patternSrv.addressPattern)]),
    shippingAddress: new FormControl([]),
    phoneNumber: new FormControl('', [Validators.required, Validators.pattern(this.patternSrv.numPattern), Validators.maxLength(10),Validators.minLength(10)]),
    locations: new FormControl('', Validators.required),
    password: new FormControl('password', Validators.required),
    enabled: new FormControl(''),
    company: this.formBuilder.array([this.createCompany()],[Validators.required])
    
  });
  createCompany():FormGroup{
    return this.formBuilder.group({
      name:[''],
      tenant:''
    });
  }
  public matcher = new MyErrorStateMatcher();
  public editMode: boolean = false;
  public dbLocations: [any];
  public currentOperation:string;
  public paginateCompany:any={};
  public fetchedCompanyLength:number;
  public fetchedCompany:[any];
  public addedCompany:boolean=false;
  public paginateElements:number;

  @ViewChild('companySelect') companySelect:any;
  
  constructor(private dialogRef: MatDialogRef<CreateReviewerComponent>,
    private helper: HelperService,private data:DataService,
    private reviewerSrv: ReviewerService,private patternSrv:PatternValidationService,
    private spinnerService: Ng4LoadingSpinnerService,private authSrv:AuthService, private formBuilder: FormBuilder,
    private locationService: LocationService,private validatorService: ValidatorService,
    private frontValSrv: FrontValidationService,private userRetrievalSrv:UserRetrievalService,private userReacivateLinkSrv:UserReActivationLinkService) { }
    
  ngOnInit() {
    // Validation for create new reviewer
    this.reviewerVal = this.frontValSrv.validationMsg;
    this.data.currentOperation.subscribe(currentOperation => this.currentOperation = currentOperation);
    this.getAllLocationByClient();
    this.reviewerSrv.sharedReviewer.distinctUntilChanged().subscribe(data => {
      if (data) {
        this.addReviewForm.patchValue(data);
        this.oldEmail = data.email;
        let locations=[];
        for(let locationsRole of data['locationsRoles']){
          locations.push(locationsRole["location"]["name"])
        }
        this.addReviewForm.controls["locations"].setValue(locations);
         //load all companies while edit
         this.reviewerSrv.getAllCompanies(this.paginateCompany).subscribe(
              data=>{this.fetchedCompanyLength=data.body.totalElements},
              err=>{},
               ()=>{this.getAllCompanies();})
         this.editMode = true;
      }else {
        //load only 10 companies while create.
       this.getAllCompanies();
      }
    })
  }

  /** GET all reviewer **/
  getAllLocationByClient() {
    this.spinnerService.show();
    this.locationService.getAllLocationsByClient(this.helper.getTenantId()).subscribe(data => {
      if (data.body.content.length > 0) {
        this.dbLocations = data.body.content;
      } else {
        data.body.content.push({ "name": "Client has No Location" });
        this.dbLocations = data.body.content;
      }
      this.spinnerService.hide();
    })
  }

   /**GET All companies  */
   getAllCompanies(paginateCompany?:any){
    this.spinnerService.show();
    this.paginateCompany.page = 0;
    this.paginateCompany.size = (this.fetchedCompanyLength) ? this.fetchedCompanyLength : 10;
    this.paginateCompany.sort="creationAt,DESC";
    this.reviewerSrv.getAllCompanies(this.paginateCompany).subscribe(
      data => {
        this.fetchedCompany = data.body.content;
        this.fetchedCompanyLength=data.body.totalElements;
        this.paginateElements=data.body.numberOfElements;
        this.spinnerService.hide();
      }
    )
  }
  
/**paginate company as load more  */
loadMoreCompanies(){
  this.companySelect.open();
  this.paginateCompany.size = this.paginateCompany.size + 10;
  this.reviewerSrv.getAllCompanies(this.paginateCompany).subscribe(
    data => {
      this.fetchedCompany = data.body.content;
      this.fetchedCompanyLength=data.body.totalElements;
      this.paginateElements=data.body.numberOfElements;
      this.spinnerService.hide();
    }
  )
  return false;
}


  /** CREATE a reviewer **/
  create() {
    this.validatorService.userValidator(this.editMode ?'update':'create').then(res => {
      if(res.val) {
      delete res.val;
      this.data.changeOperation("reviewer");
      if (this.addReviewForm.valid) {
        let reviewer = this.addReviewForm.value;
        reviewer['shippingAddress']=null;
        reviewer["locationsRoles"] = [];
        for (let ln of reviewer["locations"]) {
          let reviewerLocationRoleObj = {
            location: { name: ln },
            role: [{ name: "Reviewer" }]
          }
          reviewer["locationsRoles"].push(reviewerLocationRoleObj);
        }
        reviewer.tenant = this.helper.getTenantId();
        reviewer.tenantName = this.helper.getUserName();
        res.locations = reviewer["locations"].toString();
        reviewer['company'][0].tenant = this.helper.getTenantId();
        if (this.editMode) {
          this.reviewerSrv.updateReviewer(reviewer,res).subscribe(
            data => {
              this.dialogRef.close(this.addReviewForm.value);
              this.reviewerSrv.sendCurrentReviewer(data);
              if (data) {
                data['locationsRoles']=reviewer["locationsRoles"];              
              }
              this.helper.showSnackbar('Successfully Updated Reviewer !');
            }, err => {
                if(err.status='500'){
                  this.helper.showSnackbar('Something Went Wrong Failed To Update !',false, true);
                 }
                 else{
                   this.helper.showSnackbar(err.error.message,false, true);
                 }
              },()=>{
                this.userReacivateLinkSrv.reactivateUserOnEmailchanges(this.oldEmail,this.addReviewForm.get('email').value);
          });
        } else {
          if (this.addReviewForm.valid) {
            delete reviewer["id"];
            this.reviewerSrv.addReviewer(reviewer,res).subscribe(
              data => {
                this.dialogRef.close(this.addReviewForm.value);
                this.reviewerSrv.sendCurrentReviewer(data);
                this.helper.showSnackbar('Successfully Created Reviewer & Sent activation email !');
              });
          }
        }
      }
    }
   })
  }

  /** CLOSE mat dialog **/
  close() {
    this.dialogRef.close(null);
  }

  /** DESTROY editmode **/
  ngOnDestroy() {
    this.editMode = false;
  }

  /** User Exist */
  isUserExist(username){
    this.authSrv.validateUser(username).subscribe(res =>{
     if(res.body.exist){
        this.errorUser='User Already Exists'
      }
      if(!res.body.exist && !res.body.deleted){
        this.errorUser=null;
      }
    })
  }
  
  /** EMail Exist */
  isEmailExist(emailId){
    this.authSrv.validateUser(emailId).subscribe(res =>{
      if(res.body.exist && !res.body.deleted){
        this.errorEmail='Email Already Exists'
      }
      if(!res.body.exist && !res.body.deleted){
        this.errorEmail=null;
      }
      if(res.body.exist && res.body.deleted) {
          this.userRetrievalSrv.userRetrievePopup().then(res=>{
          if(res){
            this.retrieveAndSendReactivationLink(emailId);
          }
          else{
            this.addReviewForm.get('email').patchValue('');
          }
        });  
      }
    })
  }
  retrieveAndSendReactivationLink(emailId:string){
    this.authSrv.retrieveUser(emailId).subscribe(res=>{
      this.reviewerSrv.sendCurrentReviewer(res);
      this.helper.showSnackbar('User Retrieved Successfully');
      this.dialogRef.close(this.addReviewForm.value);
    })
  }
   //addCompany
   addCompany(){
    this.addedCompany=true;
    this.addReviewForm.get('company').reset();
  }
  //removeCompany
  removeCompany(){
    this.addedCompany=false;
  }

  get companiesData() { return <FormArray>this.addReviewForm.get('company'); }
}
