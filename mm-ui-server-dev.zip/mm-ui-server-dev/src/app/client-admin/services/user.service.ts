import { Injectable } from '@angular/core';
import { HttpHeaders } from '@angular/common/http';
import { Observable, BehaviorSubject,throwError } from 'rxjs';
import { CommonApiService } from 'app/services/common-api.service';
import { environment } from '../../../environments/environment';
import { ClientAdminUserModel } from 'app/models/user.model';
import { HelperService } from 'app/services/helper.service';
import{Ng4LoadingSpinnerService}from'ng4-loading-spinner';
import { catchError, map } from 'rxjs/operators';

@Injectable()
export class UserService {

  private httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  };

  private sharableUser = new BehaviorSubject<any>("");
  public sharedUsers = this.sharableUser.asObservable();
  private createdUser = new BehaviorSubject("");
  public createdCurrentUser = this.createdUser.asObservable();

  constructor(
    private httpRequest: CommonApiService,
    private helperService: HelperService,private  spinnerService:Ng4LoadingSpinnerService) {
  }

  /** SET shared user */
  setSharedUser(userObj) {
    this.sharableUser.next(userObj);
  }

  /** SET created user */
  sendCreatedUser(userObj) {
    this.createdUser.next(userObj);
  }

  // non gmp receipt data
  getAllUsers(roles): Observable<ClientAdminUserModel[]> {
    return this.httpRequest.getRequestWithToken(environment.BASEURL + '/auth/users/tenants/' + roles,{});
}


  // Get users by client id
  getAllUsersByClient(paramObj?:any) {
    this.spinnerService.show();
    return this.httpRequest.getRequestWithToken(environment.BASEURL + '/auth/users/tenants/' +this.helperService.getTenantId() ,paramObj).pipe(map(response => {
      return response;
    }), catchError((error: Error) => throwError(error)));
  }


  /**ACTIVATE user */
  activateUser(token) {
    return this.httpRequest.getRequestWithToken(environment.BASEURL + '/auth/accounts/activate?token=' + token)
  }
  
  /** ADD new user */
  addNewUser(userObj,header) {
    return this.httpRequest.postRequest(environment.BASEURL + '/auth/users' , userObj,header);
  }

  /** UPDATE user */
  updateUser(userObj,header) {
    return this.httpRequest.putRequest(environment.BASEURL + '/auth/users/' + userObj.id, userObj,header);
  }

  /** DELETE user */
  deleteUser(user: any,header) {
    return this.httpRequest.deleteReqeust(environment.BASEURL + '/auth/users/' + user.id, user,header);
  }

  /** REFRESH user */
  refreshUser() {
    return this.httpRequest.getRequestWithToken(environment.BASEURL + "/auth/users/refresh",{});
  }

  /** Search User */
  searchUser(filterValue){
    return this.httpRequest.getRequestWithToken(environment.BASEURL + "/auth/users/tenants/" +this.helperService.getTenantId() + "/search?search=" + filterValue,{})
  }

  /**Reactivate user */
  reactivateUser(email){
    return this.httpRequest.getRequestWithToken(environment.BASEURL + "/auth/accounts/resend-activate-link?email=" + email,{})
  }
}
