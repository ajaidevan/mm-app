import { Injectable } from '@angular/core';
import { Observable ,throwError} from 'rxjs';
import { CommonApiService } from 'app/services/common-api.service';
import { HelperService } from 'app/services/helper.service';
import { environment } from '../../../environments/environment';
import{Ng4LoadingSpinnerService}from"ng4-loading-spinner";
import { catchError, map } from 'rxjs/operators';


@Injectable()

export class AuditService {

  private tenantId: string;

  constructor(private httpHelper: CommonApiService, private helperSrv: HelperService,private spinnerService:Ng4LoadingSpinnerService) {
    this.tenantId = this.helperSrv.getTenantId()
  }

  /** GET audit-log */
  getAuditUser(paramObj?:any): Observable<any> {
    this.spinnerService.show();
    return this.httpHelper.getRequestWithToken(environment.BASEURL + '/auth/audits/tenants/' + this.tenantId,paramObj).pipe(map(response => {
      return response;
    }), catchError((error: Error) => throwError(error)));
  }

  auditSearch(filterValue?:any){
    return this.httpHelper.getRequestWithToken(environment.BASEURL+'/auth/audits/tenants/'+this.helperSrv.getTenantId()+'/search',filterValue)
    .pipe(map(response => {
      return response;
    }), catchError((error: Error) => throwError(error)));
  }
}
