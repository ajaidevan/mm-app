import { Injectable } from '@angular/core';
import { Observable, BehaviorSubject,throwError } from 'rxjs';
import { CommonApiService } from 'app/services/common-api.service';
import { environment } from '../../../environments/environment';
import { LocationUserModel } from 'app/models/user.model';
import { HelperService } from 'app/services/helper.service';
import{Ng4LoadingSpinnerService}from'ng4-loading-spinner';
import { catchError, map } from 'rxjs/operators';
import { DataService } from 'app/services/data.service';

@Injectable()
export class ReviewerService {

  //created reviewer
  private createdReviewer = new BehaviorSubject("");
  public currentReviewer = this.createdReviewer.asObservable();
    // reviewer data
  private sharableReviewer = new BehaviorSubject<any>("");
  public sharedReviewer = this.sharableReviewer.asObservable();

  constructor(private httpRequest: CommonApiService,private helperService:HelperService,private spinnerService:Ng4LoadingSpinnerService,private data:DataService) { }
  /** SEND current reviewer */
  sendCurrentReviewer(reviewerObj) {
    this.createdReviewer.next(reviewerObj);
  }

  /** SET shared reviewer */
  setSharedReviewer(user) {
    this.sharableReviewer.next(user);
  }

  /**GET all reviewers */
  getAllReviewers(paramObj?:any): Observable<any> {
    this.spinnerService.show();
    this.data.changeCurrentRole('reviewer');
    return this.httpRequest.getRequestWithToken(environment.BASEURL + '/auth/users/tenants/' + this.helperService.getTenantId(),paramObj).pipe(map(response => {
      return response;
    }), catchError((error: Error) => throwError(error)));
  }

  /**DELETE reviewer */
  deleteReviewer(user: LocationUserModel,header) {
    return this.httpRequest.deleteReqeust(environment.BASEURL + '/auth/users/' + user.id, user,header);
  }

  /** ADD reviewer */
  addReviewer(user: LocationUserModel,header) {
    return this.httpRequest.postRequest(environment.BASEURL + '/auth/users', user,header);
  }

  /** UPDATE reviewer */
  updateReviewer(user: LocationUserModel,header) {
    return this.httpRequest.putRequest(environment.BASEURL + '/auth/users/' + user.id, user,header);
  }

  /** REFRESH reviewer */
  refreshReviewer() {
    return this.httpRequest.getRequestWithToken(environment.BASEURL + "/auth/users/refresh",{});
  }

  /** SEARCH reviewers */
  search(filterValue?:any){
    return this.httpRequest.getRequestWithToken(environment.BASEURL+"/auth/users/tenants/" +this.helperService.getTenantId() + "/search?search="+filterValue,{})
  }
  
  /**GET All companies */
 getAllCompanies(paramObj?:any): Observable<any>{
  return this.httpRequest.getRequestWithToken(environment.BASEURL + '/auth/company/?tenant='+this.helperService.getTenantId(),paramObj);
 }
   
}
