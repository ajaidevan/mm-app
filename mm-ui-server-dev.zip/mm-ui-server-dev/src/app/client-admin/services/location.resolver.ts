import{Injectable}from"@angular/core";
import{LocationService}from"./location.service";
import{Observable,of,EMPTY}from"rxjs";
import{catchError,mergeMap}from"rxjs/operators";
import{Resolve,ActivatedRouteSnapshot,RouterStateSnapshot}from"@angular/router";
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { HelperService } from 'app/services/helper.service';
import { CommonApiService } from "app/services/common-api.service";


@Injectable()

export class LocationResolver implements Resolve<any>{
    
    constructor(private locationService:LocationService,private spinnerService:Ng4LoadingSpinnerService,
        private helper:HelperService,private commonSrv :CommonApiService ){}
        
    resolve(route:ActivatedRouteSnapshot,state:RouterStateSnapshot):Observable<any>|Observable<never>{

        let reqParams = this.commonSrv.createParam(route.data['params']);
        return this.locationService.getAllLocationsByClient(reqParams).pipe(catchError(error=>{
           return EMPTY;
       }),mergeMap(something=>{
           this.spinnerService.hide();
           if(something){
               return of(something);
           }
           else{
               this.spinnerService.hide();
               return EMPTY;
           }
       })
       )
    }
}