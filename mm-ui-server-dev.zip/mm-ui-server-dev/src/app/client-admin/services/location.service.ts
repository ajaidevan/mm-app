import { Injectable } from '@angular/core';
import { Observable,BehaviorSubject,throwError } from 'rxjs';
import { CommonApiService } from 'app/services/common-api.service';
import { environment } from '../../../environments/environment';
import { ClientLocationModel } from 'app/models/location.model';
import{Ng4LoadingSpinnerService}from'ng4-loading-spinner';
import { catchError, map } from 'rxjs/operators';
import { HelperService } from 'app/services/helper.service';

@Injectable()

export class LocationService {  

  private createdLocation = new BehaviorSubject("");
  public currentLocation = this.createdLocation.asObservable();
  private sharableLocation = new BehaviorSubject<any>("");
  public sharedLocation = this.sharableLocation.asObservable();

  constructor(private httpHelper: CommonApiService,private spinnerService:Ng4LoadingSpinnerService,private helper:HelperService) {}

  /** SET current location */
  sendCurrentLocation(locationObj) {
    this.createdLocation.next(locationObj);
  }

  /** SET shared location */
  setSharedLocation(locationObj) {
    this.sharableLocation.next(locationObj);
  }

/** GET all locations */
getAllLocationsByClient(reqParam):Observable<any> {
  this.spinnerService.show();
  return this.httpHelper.getRequestWithToken(environment.BASEURL + '/auth/locations/tenants/'+this.helper.getTenantId() ,reqParam).pipe(map(res=>{
    return res;
  }),catchError((err:Error)=>throwError(err)));

  }

  /** DELETE location */
  deleteLocation(location: ClientLocationModel, header) {
    return this.httpHelper.deleteReqeust(environment.BASEURL + '/auth/locations/' + location.id, location,header);
  }

  /** ADD location */
  addLocation(location: ClientLocationModel,header) {
    return this.httpHelper.postRequest(environment.BASEURL + '/auth/locations', location,header);
  }

  /** UPDATE location */
  updateLocation(location: ClientLocationModel,header) {
    return this.httpHelper.putRequest(environment.BASEURL + '/auth/locations/' + location.id, location,header);
  }

  /** REFRESH location */
  refreshLocation() {
    return this.httpHelper.getRequestWithToken(environment.BASEURL + "/auth/locations/refresh",{});
  }

    /** SEARCH Location */
    searchLocation(searchValue?:any){
      return this.httpHelper.getRequestWithToken(environment.BASEURL + "/auth/locations/tenants/"+this.helper.getTenantId()+"/search?search="+searchValue,{});
    }
    
}