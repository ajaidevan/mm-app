import { Component, OnInit, ViewChild } from '@angular/core';
import { AuditService } from '../services/audit.service';
import { MatPaginator, MatSort, MatDialogConfig, MatDialog, PageEvent,Sort} from '@angular/material';
import { SelectionModel } from '@angular/cdk/collections';
import { MatTableDataSource } from '@angular/material/table';
import { HelperService } from 'app/services/helper.service';
import { ClientAuditModel } from 'app/models/audit.model';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonApiService } from 'app/services/common-api.service';
import * as jsPDF from 'jspdf';
import 'jspdf-autotable';
import { FormGroup, FormBuilder } from '@angular/forms';
import { trigger, state, style, transition, animate } from '@angular/animations';

export interface LocationAuditModel {
  activityDateTime:string;
  activityLog:string;
  user: string;
  oldValue: string;
  newValue: string;
  action: string;
  comments: string;
}
const ACTIVITYDATETIME: string[] = [
  'Sun 12 2020:11:00', 'Mon 9 2020:1:00', 'Tue 1 2020:09:00'
];

const ACTIVITYLOG: string[] = [
  'Vendor', 'User', 'Client'
];
const USER: string[] = [
  'abl@valogic.com','abs@valogic.com','stablity@valogic.com'
];

const OLDVALUE: string[] = [
  'N/A'
];

const NEWVALUE: string[] = [
  'User Logged In', 'Created', 'Updated'
];

const ACTION: string[] = [
  'User Logged In', 'Created', 'Deleted'
];

const COMMENT: string[] = [
  'User Logged In','Tested','User Created'
];
@Component({
  selector: 'app-audit-log',
  templateUrl: './audit-log.component.html',
  styleUrls: ['./audit-log.component.scss'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0', display: 'none' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class AuditLogComponent implements OnInit {

  public AuditFilterHeader = ['activityDateTimeFilter', 'activityFilter', 'userFilter', 'oldValueFilter', 'newValueFilter',  'actionFilter','commentsFilter',];
  public displayedColumns:string[] = ['activityDateTime','activityLog','user','oldValue','newValue','action','comments']
  public dataSource = new MatTableDataSource<LocationAuditModel>();
  public enablePrint: boolean = true;
  public managePrintingData: any = [];
  public clientId: any;
  public searchParam: any={};
  public paginate: any = {};
  public pageEvent: PageEvent
  public totalAudits: number;
  public slectedRowsToPrint:any =[]
  public auditFormGroup = this.fb.group({
    service : ['']
  })
  expandedElement:any = [] ;
  viewDataSource:any;
  audit:any
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(private auditService: AuditService, private route: ActivatedRoute, private router: Router,private fb:FormBuilder,
    private helperSrv: HelperService, private dialog: MatDialog, private commonSrv: CommonApiService) {
      this.audit = Array.from({length: 3}, (_, k) => createNewAudit(k + 1));

      // Assign the data to the data source for the table to render
      this.dataSource = new MatTableDataSource(this.audit);
     }
  ngOnInit(){
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }


  // TO DO: FOR THE API INTEGRATION USE IT
  // ngOnInit() {
  //   // this.getAuditById();
  //   this.setDefaultParamPaginate()
  // }
  // ngAfterViewInit() {
  //   //this.dataSource.sort=this.sort;
  // }
 

  // isAllSelected() {
  //   const numSelected = this.selection.selected;
  //   const numRows = this.dataSource.data;
  //   return numSelected === numRows;
  // }

  // select(event) {
  //     this.dataSource.data.forEach(row => {
  //       this.selection.select(row);
  //       this.addOrRemoveSelectedRow(event,row);
  //     });
  // }

  // onSelectRow() {
  //   let dataSelection =[];
  //   this.dataSource.data.forEach(row => dataSelection.push(this.selection.isSelected(row)));
  // }

  // selectedRowsExist(row:any):boolean{
  //   if(this.slectedRowsToPrint.some(e => e.logId === row.logId)){
  //     return true;
  //   }else{
  //     return false;
  //   }
  // }

  // addOrRemoveSelectedRow(event,row){
  //   this.selection.toggle(row) ;
  //   if(!event.checked && this.selectedRowsExist(row)){
  //     var removeIndex = this.slectedRowsToPrint.map(function(item) {return item.logId;}).indexOf(row.logId);
  //     this.slectedRowsToPrint.splice(removeIndex,1);
  //   }
  //   if(event.checked && !this.selectedRowsExist(row)){
  //     this.slectedRowsToPrint.push(row); 
  //   }    
  // }

  // formatInputToGenerate(row) {
  //   var input = {
  //     "activity": row.logitem,
  //     "user": row.createdBy,
  //     "role": row.role,
  //     "oldValue": row.oldValue,
  //     "newValue": row.newValue,
  //     "location": row.location,
  //     "datetime": row.datetime,
  //     "details": row.eventDetails,
  //     "comments": row.comments
  //   }
  //   return input
  // }


  // // function print for print the audit log
  // onPrint() {
  //   const dialogConfig = new MatDialogConfig();
  //   dialogConfig.disableClose = true;
  //   dialogConfig.autoFocus = true;
  //   dialogConfig.data = {
  //     'managePrintingData': this.managePrintingData.filter(temp => temp != null)
  //   }
  //   var doc = new jsPDF('l', 'mm', 'a4');
  //   var col = ['Activity Log', 'Created By', 'Role', 'Old Value', 'New Value', 'Location', 'Event Type', 
  //   'Creation Date', 'Event Result', 'Event Details'];
  //   var rows = [];
  //   this.slectedRowsToPrint.forEach(element => {
  //     let row = [element.activityLog,element.createdBy,element.role,element.oldValue,element.newValue,
  //       element.location,element.eventType,element.creationDate,element.eventResult,element.eventDetails];
  //     rows.push(row);
  //   });
    
  //   doc.setFontSize(16);
  //   doc.setTextColor(0, 0, 0);
  //   doc.text(20, 20, "DB Logic Audit Log History for Client Admin.");
  //   doc.setFontSize(8);
  //   doc.autoTable(col,rows, {
  //     theme: "grid",
  //     startY: 25,
  //     styles: {overflow: 'linebreak'},
  //     columnStyles: {
  //       0: {cellWidth: 20},
  //       1: {cellWidth: 20},
  //       2: {cellWidth: 20},
  //       3: {cellWidth: 50},
  //       4: {cellWidth: 50},
  //       5: {cellWidth: 20},
  //       6: {cellWidth: 20},
  //       7: {cellWidth: 20},
  //       8: {cellWidth: 20},
  //       9: {cellWidth: 20},
  //     },
  //     headStyles: {
  //       fontSize: 8,
  //       halign: 'center',
  //       valign:'top'
  //     },
  //     halign: 'center',
  //     valign:'center',
  //     cellPadding:2,
  //     bodyStyles: {
  //     valign:'top',
  //     fontSize: 8,
  //     lineWidth: 0.2,
  //     halign: 'center',
  //     cellPadding:2,
  //     }
  //   })
  //   doc.output('dataurlnewwindow'); 
  // }

  // checkboxLabel(row?: ClientAuditModel): string {
  //   if (!row) {
  //     return `${this.isAllSelected() ? 'select' : 'deselect'} all`;
  //   }
  //   return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${row.logId}`;
  // }

  // /** Set Default Param **/
  // setDefaultParamPaginate(){
  //   this.paginate = this.route.snapshot.data['params'];
  //   let reqParams = this.commonSrv.createParam(this.paginate);
  //   this.router.navigate([],{ queryParams : reqParams});
  //   this.dataSource.data = this.route.snapshot.data['audit'].body.content;
  //   this.totalAudits = this.route.snapshot.data['audit'].body.totalElements;
  // }
  // /**
  //  * 
  //  * @param setPage
  //  */

  // /** Paginate The Locations **/
  // paginateAudit(setPage = true) {
  //   if (setPage) this.paginate.page = 0;
  //   let reqParams = this.commonSrv.createParam(this.paginate);
  //   this.auditService.getAuditUser(reqParams).subscribe(data => {
  //     this.dataSource.data = data.body.content;
  //     this.totalAudits = data.body.totalElements;
  //     this.router.navigate([], { queryParams: reqParams })
  //   })
  // }

  // /**
  //  * 
  //  * @param event
  //  */

  // /** Onchange Page **/
  // onChangePage(event?: PageEvent) {
  //   this.paginate.size = event.pageSize;
  //   this.paginate.page = event.pageIndex;
  //   this.paginateAudit(false);
  //   return event;
  // }

  // /** Search Audit Logs */
  // search() {
  //   let filterValue = this.commonSrv.createParam(this.paginate);
  //   this.auditService.auditSearch(filterValue).subscribe(res => {
  //     this.dataSource.data = res.body.content;
  //     this.router.navigate([],  { queryParams: this.paginate});
  //   })
  // }

  // applyFilter(filter?: any) {
  //   if (filter.length > 2) {        
  //     this.search()
  //   }
  //   if (filter.length == 0) {
  //     this.paginateAudit()
  //   }
  // }
  //   /*Sorting*/
  //   sortData(event: Sort) {
  //     this.paginate.sort = event.active + ',' + event.direction;
  //     this.paginateAudit();    
  //   }
  onPrint(){}
  sortData(event: Sort){}
}

/** Builds and returns a new User. */
function createNewAudit(id: number): LocationAuditModel {
  const user = USER[Math.round(Math.random() * (USER.length - 1))]

  return {
    activityDateTime:ACTIVITYDATETIME[Math.round(Math.random() * (ACTIVITYDATETIME.length - 1))],
    activityLog:ACTIVITYLOG[Math.round(Math.random() * (ACTIVITYLOG.length - 1))],
    user: user,
    action: ACTION[Math.round(Math.random() * (ACTION.length - 1))],
    oldValue: OLDVALUE[Math.round(Math.random() * (OLDVALUE.length - 1))],
    newValue: NEWVALUE[Math.round(Math.random() * (NEWVALUE.length - 1))],
    comments: COMMENT[Math.round(Math.random() * (ACTION.length - 1))],
  };
}