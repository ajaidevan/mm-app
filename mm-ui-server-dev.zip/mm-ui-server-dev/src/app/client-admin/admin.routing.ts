import { Routes } from '@angular/router';
import { LocationComponent } from './location/location.component';
import { UserComponent } from './user/user.component';
import { ClientAdminComponent } from './client-admin/client-admin.component';
import { ReviewerComponent } from './reviewer/reviewer.component';
import { AuditLogComponent } from './audit-log/audit-log.component';
import{LocationResolver}from'./services/location.resolver';
import{UserResolver}from'./services/user.resolver';
import{ReviewerResolver}from'./services/reviewer.resolver';
import { AuditResolver } from './services/audit.resolver';
import { ReviewerManagementComponent } from 'app/reviewer/reviewer-management/reviewer-management.component';

export const AdminRoutes: Routes = [{
  path: '',
  redirectTo: 'admin',
  pathMatch: 'full',
}, {
  path: '',
  children: [{
    path: 'admin',
    component: ClientAdminComponent
  }, {
    path: 'location',
    component: LocationComponent,
    resolve: {locations: LocationResolver},
    data:{
      params:{
        page:0,
        size:10,
        sort:'creationAt,DESC',
      }
    }
  }, {
    path: 'user',
    component: UserComponent,
    resolve:{users:UserResolver},
    data:{
      params:{
        page:0,
        size:10,
        sort:'creationAt,DESC',
      }
    }
  }, {
    path: 'reviewer',
    component: ReviewerComponent,
    // component:ReviewerManagementComponent,
    resolve:{reviewers:ReviewerResolver},
    data:{
      params:{
        page:0,
        size:10,
        sort:'creationAt,DESC',
      }
    }
  
  }, {
    path: 'audit-log',
    component: AuditLogComponent,
    resolve:{audit:AuditResolver},
    data:{
      params:{
        page:0,
        size:10,
        sort:'creationAt,DESC',
      }
    }
  }]
}];
