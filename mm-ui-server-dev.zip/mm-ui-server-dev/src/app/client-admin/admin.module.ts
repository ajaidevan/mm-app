import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { MatIconModule, MatCardModule, MatButtonModule, MatListModule, MatProgressBarModule, MatMenuModule, MatFormFieldModule, MatInputModule, MatRippleModule, MatSelectModule, MatSortModule, MatTableModule, MatPaginatorModule, MatRadioModule, MatCheckboxModule, MatDatepickerModule, MatDialogModule, MatChipsModule, MatAutocompleteModule, MatTooltipModule } from '@angular/material';
import { FlexLayoutModule } from '@angular/flex-layout';
import { ChartsModule } from 'ng2-charts/ng2-charts';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';

import { AdminRoutes } from './admin.routing';
import { LocationComponent } from './location/location.component';
import { UserComponent } from './user/user.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { CreateLocationComponent } from './location/create-location/create-location.component';
import { LocationService } from './services/location.service';
import { UserService } from './services/user.service';
import { CreateUserComponent } from './user/create-user/create-user.component';
import { ClientAdminComponent } from './client-admin/client-admin.component';
import { ReviewerComponent } from './reviewer/reviewer.component';
import { CreateReviewerComponent } from './reviewer/create-reviewer/create-reviewer.component';
import { ReviewerService } from './services/reviewer.service';
import { AuditService } from './services/audit.service';

import { AuditLogComponent } from './audit-log/audit-log.component';

import{LocationResolver}from'./services/location.resolver';
import{UserResolver}from'./services/user.resolver';
import{ReviewerResolver}from'./services/reviewer.resolver';
import{AuditResolver}from'./services/audit.resolver';
import { ReviewerManagementModule } from 'app/reviewer/reviewer-management.module';

@NgModule({
  declarations: [LocationComponent,
    UserComponent, CreateLocationComponent, CreateUserComponent
    , ClientAdminComponent, ReviewerComponent, CreateReviewerComponent, AuditLogComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(AdminRoutes),
    MatFormFieldModule,
    MatInputModule,
    MatIconModule,
    MatCardModule,
    MatButtonModule,
    MatListModule,
    MatProgressBarModule,
    MatMenuModule,
    ChartsModule,
    NgxChartsModule,
    NgxDatatableModule,
    FlexLayoutModule,
    FormsModule,
    ReactiveFormsModule,
    MatSelectModule,
    MatSortModule,
    MatTableModule,
    MatPaginatorModule,
    MatRadioModule,
    MatCheckboxModule,
    MatDatepickerModule,
    MatDialogModule,
    MatRippleModule,
    MatChipsModule,
    MatAutocompleteModule,
    ReviewerManagementModule,
    MatTooltipModule
  ],
  providers: [LocationService, UserService, ReviewerService, AuditService,AuditResolver,LocationResolver,UserResolver,ReviewerResolver],
  entryComponents: [CreateLocationComponent, CreateUserComponent, CreateReviewerComponent]
})
export class AdminModule { }
