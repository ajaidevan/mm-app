import { Component, OnInit, Input, ViewChild, ChangeDetectorRef, Output, EventEmitter } from '@angular/core';
import { MatPaginator, MatSort, MatTableDataSource, PageEvent, Sort } from '@angular/material';
import { DataService } from 'app/services/data.service';
import { AdvSearchService } from '../adv-search.service';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonApiService } from 'app/services/common-api.service';
import { ExportService } from '../export.service';
import { NgSwitchDefault } from '@angular/common';
import { SearchDataService } from '../search.data.service';

@Component({
  selector: 'app-receivables',
  templateUrl: './receivables.component.html',
  styleUrls: ['./receivables.component.scss']
})
export class ReceivablesComponent implements OnInit {
  
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  public displayedColumns: string[] = ['id','origin', 'vendorName','clientName', 'containerType', 'itemType','quantityType', 'qaNotified', 'recipientNotified', 'createdBy', 'createdAt','receivableDate','isDamaged', 'status'];
  public dataSource =  new MatTableDataSource() ;
  public totalReceivable:any;
  public paginate: any = {
    page:0,
    size:10,
    sort:'createdAt,DESC'
  };
  public receivableData:any;
  public pageSizeOptions=[10,20,30];
  public isLoading:boolean = false;
  public pageEvent:PageEvent;
  public isNoData:boolean = false;
  constructor(private dataSrv:DataService,private advSearchSrv:AdvSearchService,private exportSrv:ExportService,
   private router: Router,private commonSrv:CommonApiService,private searchSrv:SearchDataService,) { }
  @Input() set receivable(receivable:any){
    this.receivableData = receivable;
    if(this.receivableData.show == 'search') this.getSearchReceipt(this.receivableData,false);
    if(this.receivableData.show == 'print') this.getExportFile(this.receivableData);
    this.paginate.page = 0;
    this.paginate.size = 10 ;
    this.paginate.sort = 'createdAt,DESC';
  };

  ngOnInit() {
  }

  getExportFile(data){
    switch (data.loadType) {
      case 'excel':
        this.getExcelSheetReceivable(data);
        break;
      case 'pdf':
        this.getPDFReceivable(data);
        break;
      default:
        this.getExcelSheetReceivable(data);
        this.getPDFReceivable(data);
        break;
    }
  }
  getSearchReceipt(data,setPage){
    if (setPage) this.paginate.page = 0;
    let reqParams = this.commonSrv.createParam(this.paginate);
    this.router.navigate([],{queryParams:reqParams});
    switch (data.receipts) {
      case 'status':
        this.getSearchReceiptByStatus(data,reqParams)
        break;
      case 'receipt_no':
        this.getSearchByReceiptNo(data);
        break;
      case 'receipt_creation_date':
        this.getSearchByReceiptCrDt(data,reqParams);
        break;
      case 'damaged':
        this.getSearchByDamage(data,reqParams);
        break;
      case 'qa_approved':
        this.getSearchByQaApp(data,reqParams);
        break;
      default:
        this.getAllReceivable(reqParams);
        break;
    }
  }

   /**  Receipt Status */
   showReceiptStatus(status){
    let statusOb = this.dataSrv.STATUS.RECEIPT.find(o => o.value === status);
    return statusOb.status;
  }

  ngOnDestroy(){
  }

  sortData(event: Sort){  
    this.paginate.sort = event.active + ',' + event.direction;
    this.getSearchReceipt(this.receivableData,false);
  }

    /** On change Page */
  onChangePage(event?: PageEvent) {
    this.paginate.size = event.pageSize;
    this.paginate.page = event.pageIndex;
    this.getSearchReceipt(this.receivableData,false);
    return event;
  }

  getAllReceivable(reqParams){
    this.isLoading = true;
    this.advSearchSrv.getAllReceivable(reqParams).subscribe(data=>{
      this.isNoData = this.advSearchSrv.noData(data.body);
      this.dataSource = new MatTableDataSource(data.body);
      this.totalReceivable = data.headers.get('X-Total-Count');
      this.isLoading = false;
    })
  }
  getSearchReceiptByStatus(data,reqParams){
    this.isLoading = true;
    this.advSearchSrv.getAllReceivableByStatus(data.receiptsStatus,reqParams).subscribe(res=>{
      this.isNoData = this.advSearchSrv.noData(res.body);
      this.dataSource = new MatTableDataSource(res.body);
      this.totalReceivable = res.headers.get('X-Total-Count');
      this.isLoading = false;
    })
  }

  getSearchByReceiptNo(data){
    this.isLoading = true;
    this.advSearchSrv.getAllReceivableByReceiptNo(data.receiptNo).subscribe(res=>{
      this.isNoData = this.advSearchSrv.noData(res.body);
      this.dataSource = new MatTableDataSource(res.body);
      this.totalReceivable = res.headers.get('X-Total-Count');
      this.isLoading = false;
    })
  }

  getSearchByReceiptCrDt(data,reqParams){
    this.isLoading = true;
    let date = this.dateFormater(data.receiptCreationDate);
    this.advSearchSrv.getAllReceivableByCreationDate(date.dateArr,reqParams).subscribe(res=>{
      this.isNoData = this.advSearchSrv.noData(res.body);
      this.dataSource = new MatTableDataSource(res.body);
      this.totalReceivable = res.headers.get('X-Total-Count');
      this.isLoading = false;
    })
  }

  getSearchByDamage(data,reqParams){
    this.isLoading = true;
    this.advSearchSrv.getAllReceivableByDamage(data.damaged,reqParams).subscribe(res=>{
      this.isNoData = this.advSearchSrv.noData(res.body);
      this.dataSource = new MatTableDataSource(res.body);
      this.totalReceivable = res.headers.get('X-Total-Count');
      this.isLoading = false;
    })
  }

  getSearchByQaApp(data,reqParams){
    this.isLoading = true;
    this.advSearchSrv.getAllReceivableByStatus(data.qaApproved,reqParams).subscribe(res=>{
      this.isNoData = this.advSearchSrv.noData(res.body);
      this.dataSource = new MatTableDataSource(res.body);
      this.totalReceivable = res.headers.get('X-Total-Count');
      this.isLoading = false;
    })
  }

  dateFormater(data){
    if(data) {
      let month = '' + (data.getMonth() + 1);
      let day = '' + data.getDate();
      let year = data.getFullYear();
      let dateArr = [year,month,day].join('-')
      return {
        dateArr:dateArr,
      }
    }
  }

  getExcelSheetReceivable(data){
    switch (data.receipts) {
      case 'status':
        this.getXlStReceivableByStatus(data)
        break;
      case 'receipt_no':
        this.getXlStReceivableByRctNo(data);
        break;
      case 'receipt_creation_date':
        this.getXlStReceivableByCreatedAt(data);
        break;
      case 'damaged':
        this.getXlStReceivableByDamage(data);
        break;
      default:
        this.getXlStReceivableByQaApp(data);
        break;
    }
  }

  getXlStReceivableByRctNo(data){
    this.exportSrv.getXlStReceivableByRctNo(data.receiptNo).subscribe(res=> { this.searchSrv.saveAs(res) });
  }

  getXlStReceivableByStatus(data){
    this.exportSrv.getXlStReceivableByStatus(data.receiptsStatus).subscribe(res=> { this.searchSrv.saveAs(res) });
  }

  getXlStReceivableByCreatedAt(data){
    let date = this.dateFormater(data.receiptCreationDate);
    this.exportSrv.getXlStReceivableByCreatedAt(date.dateArr).subscribe(res=> { this.searchSrv.saveAs(res) });
  }

  getXlStReceivableByDamage(data){
    this.exportSrv.getXlStReceivableByDamage(data.damaged).subscribe(res=> { this.searchSrv.saveAs(res) });
  }

  getXlStReceivableByQaApp(data){
    this.exportSrv.getXlStReceivableByQaApp(data.qaApproved).subscribe(res=> { this.searchSrv.saveAs(res) });
  }

  /** Export PDF */
  getPDFReceivable(data){
    switch (data.receipts) {
      case 'status':
        this.getPDFReceivableByStatus(data);
        break;
      case 'receipt_no':
        this.getPDFReceivableByReceiptNo(data);
        break;
      case 'receipt_creation_date':
        this.getPDFReceivableByCreatedAt(data);
        break;
      case 'damaged':
        this.getPDFReceivableByDamage(data);
        break;
      default:
        this.getPDFReceivableByQaApproved(data);
        break;
    }
  }

  getPDFReceivableByStatus(data){
    this.exportSrv.getPDFReceivableByStatus(data.receiptsStatus).subscribe(res=>{ this.searchSrv.openPdf(res) });
  }

  getPDFReceivableByReceiptNo(data){
    this.exportSrv.getPDFReceivableByReceiptNo(data.receiptNo).subscribe(res=>{ this.searchSrv.openPdf(res) });
  }

  getPDFReceivableByCreatedAt(data){
    let date = this.dateFormater(data.receiptCreationDate);
    this.exportSrv.getPDFReceivableByCreatedAt(date.dateArr).subscribe(res=>{ this.searchSrv.openPdf(res) });
  }

  getPDFReceivableByDamage(data){
    this.exportSrv.getPDFReceivableByDamage(data.damaged).subscribe(res=>{ this.searchSrv.openPdf(res) });
  }

  getPDFReceivableByQaApproved(data){
    this.exportSrv.getPDFReceivableByQaApproved(data.qaApproved).subscribe(res=>{ this.searchSrv.openPdf(res) });
  }
}
