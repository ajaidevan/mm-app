import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { AdvanceSearch } from 'app/models/adv-search.model';
import { CommonApiService } from 'app/services/common-api.service';
import { environment } from '../../environments/environment';
import { DataService } from 'app/services/data.service';
import { HelperService } from 'app/services/helper.service';


@Injectable({
  providedIn: 'root'
})
export class AdvSearchService {

  private httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  };

  private advSearchUrl = "../assets/json-files/advance-search.json";

  constructor(private http: HttpClient, private httpHelper: CommonApiService, private data: DataService, private helperSrv: HelperService) { }

  // getSearch(): Observable<AdvanceSearch[]> {
  //   return this.http.get<AdvanceSearch[]>(this.advSearchUrl,this.httpOptions)
  // }
  getAllUsers(paramObj?: any) {
    // this.data.changeCurrentRole('all');
    return this.httpHelper.getRequestWithToken(environment.BASEURL + '/auth/users', paramObj);
  }
  // Get users by location 
  getAllUsersByLocation(paramObj?: any) {
    this.data.changeCurrentRole('all');
    return this.httpHelper.getRequestWithToken(environment.BASEURL +
      '/auth/users/tenants/' + this.helperSrv.getTenantId() + '/locations/' + this.helperSrv.getLocation(), paramObj)
  }

  getAllClients(paramObj) {
    return this.httpHelper.getRequestWithToken(environment.BASEURL + '/auth/users/tenants', paramObj);
  }
  getSearchUsersByTenantName(tenantName, paramObj) {
    return this.httpHelper.getRequestWithToken(environment.BASEURL + '/auth/users/tenants/?tenantName=' + tenantName, paramObj);

  }
  getAllLocations(paramObj) {
    return this.httpHelper.getRequestWithToken(environment.BASEURL + '/auth/locations', paramObj);
  }
  getSearchByLocation(locationName, paramObj) {
    return this.httpHelper.getRequestWithToken(environment.BASEURL + '/auth/users/locations/' + locationName, paramObj);
  }
  /**GeT search by roles under location */
  getSearchByRolesUnderLocation(roleName, paramObj) {
    this.data.changeCurrentRole('all');
    return this.httpHelper.getRequestWithToken(environment.BASEURL +
      '/auth/users/tenants/' + this.helperSrv.getTenantId() + '/locations/' + this.helperSrv.getLocation() + '?roleName=' + roleName, paramObj)
  }

  /**GET All companies */
  getAllCompanies(paramObj?: any) {
    return this.httpHelper.getRequestWithToken(environment.BASEURL + '/auth/company', paramObj);
  }
  getAllCompaniesByLocation(paramObj?: any) {
    return this.httpHelper.getRequestWithToken(environment.BASEURL + '/auth/company/?tenant=' + this.helperSrv.getTenantId(), paramObj);
  }
  getSearchByCompanies(companyName, paramObj) {
    return this.httpHelper.getRequestWithToken(environment.BASEURL + '/auth/users/company/' + companyName, paramObj);
  }
  getSearchByUserType(roleName, paramObj) {
    return this.httpHelper.getRequestWithToken(environment.BASEURL + '/auth/users/roles?roleName=' + roleName, paramObj);
  }
  getSearchByCompaniesUnderLocation(companyName, paramObj) {
    this.data.changeCurrentRole('all');
    return this.httpHelper.getRequestWithToken(environment.BASEURL +
      '/auth/users/tenants/' + this.helperSrv.getTenantId() + '/locations/' + this.helperSrv.getLocation() + '?company=' + companyName, paramObj);
  }

  getAllReceivableByStatus(status, paramObj?: any) {
    return this.httpHelper.getRequestWithToken(environment.BASEURL + '/mm/receivables?status=' + status + '&location=' + this.helperSrv.getLocation(), paramObj);
  }

  getAllReceivableByReceiptNo(receiptNo, paramObj?: any) {
    return this.httpHelper.getRequestWithToken(environment.BASEURL + '/mm/receivables?receiptNo=' + receiptNo + '&location=' + this.helperSrv.getLocation(), paramObj);
  }

  getAllReceivableByCreationDate(date, paramObj?: any) {
    return this.httpHelper.getRequestWithToken(environment.BASEURL + '/mm/receivables?createdAt=' + date + '&location=' + this.helperSrv.getLocation(), paramObj);
  }

  getAllReceivableByDamage(damage, paramObj?: any) {
    return this.httpHelper.getRequestWithToken(environment.BASEURL + '/mm/receivables?damaged=' + damage + '&location=' + this.helperSrv.getLocation(), paramObj);
  }

  getAllReceivable(paramObj?){
    return this.httpHelper.getRequestWithToken(environment.BASEURL + '/mm/receivables?&location=' + this.helperSrv.getLocation(), paramObj);
  }
    /**storages */
  /******* Freezer ********/
  getAllFreezersByLocId(paramObj): any {
    return this.httpHelper.getRequestWithToken(environment.BASEURL + '/st/freezers?locationId=' + this.helperSrv.getLocation(),paramObj);
  }
  getFreezersByType(type,paramObj){
    return this.httpHelper.getRequestWithToken(environment.BASEURL+'/st/freezers?freezerType='+type+'&locationId='+this.helperSrv.getLocation(),paramObj);
  }
  getAllRooms(paramObj?){
    return this.httpHelper.getRequestWithToken(environment.BASEURL + '/st/rooms?locationId='+ this.helperSrv.getLocation(),paramObj);
  }
  getFreezerByRoom(type?,roomName?,paramObj?){
    return this.httpHelper.getRequestWithToken(environment.BASEURL+'/st/freezers?freezerType='+type+'&roomName='+roomName+'&locationId='+this.helperSrv.getLocation(),paramObj);
  }
  getFreezerByStatusType(type?,statusType?,paramObj?){
    return this.httpHelper.getRequestWithToken(environment.BASEURL+'/st/freezers?freezerType='+type+'&statusType='+statusType+'&locationId='+this.helperSrv.getLocation(),paramObj);
  }

    /******* Refrigrators ********/
  getAllRefByLocId(paramObj): any {
      return this.httpHelper.getRequestWithToken(environment.BASEURL + '/st/refrigerators?locationId=' + this.helperSrv.getLocation(),paramObj);
  }
  getRefByType(type,paramObj){
    return this.httpHelper.getRequestWithToken(environment.BASEURL+'/st/refrigerators?refType='+type+'&locationId='+this.helperSrv.getLocation(),paramObj);
  }
  getRefByRoom(type?,roomName?,paramObj?){
    return this.httpHelper.getRequestWithToken(environment.BASEURL+'/st/refrigerators?refType='+type+'&roomName='+roomName+'&locationId='+this.helperSrv.getLocation(),paramObj);
  }
  getRefByStatusType(type?,statusType?,paramObj?){
    return this.httpHelper.getRequestWithToken(environment.BASEURL+'/st/refrigerators?refType='+type+'&statusType='+statusType+'&locationId='+this.helperSrv.getLocation(),paramObj);
  }
 
   /******* Incubator ********/
   getIncByLocId( paramObj?: any) {
    return this.httpHelper.getRequestWithToken(environment.BASEURL + '/st/incubators?locationId=' + this.helperSrv.getLocation(), paramObj);
  }
  getIncByType(type,paramObj){
    return this.httpHelper.getRequestWithToken(environment.BASEURL+'/st/incubators?incType='+type+'&locationId='+this.helperSrv.getLocation(),paramObj);
  }
  getIncByRoom(type?,roomName?,paramObj?){
    return this.httpHelper.getRequestWithToken(environment.BASEURL+'/st/incubators?incType='+type+'&roomName='+roomName+'&locationId='+this.helperSrv.getLocation(),paramObj);
  }
  getIncByStatusType(type?,statusType?,paramObj?){
    return this.httpHelper.getRequestWithToken(environment.BASEURL+'/st/incubators?incType='+type+'&statusType='+statusType+'&locationId='+this.helperSrv.getLocation(),paramObj);
  }
  /**OS */
  getOsByLocationId(paramObj){
    return this.httpHelper.getRequestWithToken(environment.BASEURL + '/st/open-storage/?locationId=' + this.helperSrv.getLocation(),paramObj);
  }
  getOsByRoom(roomName?,paramObj?){
    return this.httpHelper.getRequestWithToken(environment.BASEURL+'/st/open-storage?roomName='+roomName+'&locationId='+this.helperSrv.getLocation(),paramObj);
  }
  getOsByStatusType(statusType?,paramObj?){
    return this.httpHelper.getRequestWithToken(environment.BASEURL+'/st/open-storage?statusType='+statusType+'&locationId='+this.helperSrv.getLocation(),paramObj);
  }
  /** reviewer */

  getReceiptsByCompany(companyId,paramObj){
    return this.httpHelper.getRequestWithToken(environment.BASEURL +'/mm/receivables?location=' + this.helperSrv.getLocation()+'&company='+companyId,paramObj)
  }
  getCompaniesByUserId(paramObj?){
    return this .httpHelper.getRequestWithToken(environment.BASEURL + '/auth/company?userId='+ this.helperSrv.getUserId(),paramObj )
  }
  /** No Data */
  
  noData(data){
    if(data.length == 0) return true;
  }
}
