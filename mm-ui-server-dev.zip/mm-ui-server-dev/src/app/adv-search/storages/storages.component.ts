import { Component, OnInit,Input ,ViewChild} from '@angular/core';
import { AdvSearchService } from '../adv-search.service';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonApiService } from 'app/services/common-api.service';
import { MatTableDataSource, PageEvent, Sort,MatPaginator,MatSort } from '@angular/material';
import { ExportService } from '../export.service';
import { SearchDataService } from '../search.data.service';

@Component({
  selector: 'app-storages',
  templateUrl: './storages.component.html',
  styleUrls: ['./storages.component.scss']
})
export class StoragesComponent implements OnInit {

  constructor( private advSearchSrv:AdvSearchService,private route: ActivatedRoute,private exportSrv:ExportService,
    private router: Router,private commonSrv:CommonApiService,private searchSrv:SearchDataService,) { }

    public displayedColumns: string[] = ['name', 'roomName', 'serialNo', 'type', 'statustype', 'opeSetPoint'];
    public storageData:any;
    public dataSource =  new MatTableDataSource() ;
    public totalStorages:any;
    public paginate: any = {
      page:0,
      size:10,
      sort:'createdAt,DESC'
    };
    public pageSizeOptions=[10,20,30];
    public isLoading:boolean = false;
    public pageEvent: PageEvent;
    public isNoData:boolean = false;
    @ViewChild(MatPaginator) paginator: MatPaginator;
    @ViewChild(MatSort) sort: MatSort;
    @Input() set storage(storage:any){
      this.storageData =storage;
      if(this.storageData.show == 'search') this.getSearchStorage(this.storageData,false);
      if(this.storageData.show == 'print') this.getExportFileStorage(this.storageData);
    };

  ngOnInit() {
  }

  getExportFileStorage(data){
    switch (data.loadType) {
      case 'excel':
        this.getExcelSheet(data);
        break;
      case 'pdf':
        this.getPDFStorages(data);
        break;
      default:
        this.getExcelSheet(data);
        this.getPDFStorages(data);
        break;
    }
  }

  getSearchStorage(data,setPage){
    if (setPage) this.paginate.page = 0;
    let reqParams = this.commonSrv.createParam(this.paginate);
    this.router.navigate([],{queryParams:reqParams});
    if(data.storages)
      switch (data.storages){
        case 'freezers':
          this.getSearchFreezers(data,reqParams);
          break;
        case 'refrigerators':
          this.getSearchRefrigerators(data,reqParams);
          break;
        case 'incubators':
          this.getSearchIncubators(data,reqParams);
          break;
        case 'open shelving':
          this.getSearchOs(data,reqParams);
      }
 
  }
 
 
  getSearchFreezers(data, reqParams){
    switch (data.storageTypes) {
      case 'Ultra-Low Upright':case 'Ultra-Low Chest':case 'LN2':case 'Freezer Upright':case 'Walk In':
          this.getSearchFreezerByType(data,reqParams)
        break;
      default:
         this.searchfreezers(reqParams);
        break;
    }
  } 
  searchfreezers(reqParams){
    this.isLoading = true;
    this.advSearchSrv.getAllFreezersByLocId(reqParams).subscribe(res=>{
      this.isNoData = this.advSearchSrv.noData(res.body);
      this.dataSource.data=res.body;
      this.totalStorages=res.headers.get('X-Total-Count');
      this.isLoading = false;
    })
  }
  getSearchFreezerByType(data,reqParams){
    switch (data.status) {
      case 'room':
        this.getSearchFreezerByRoom(data,reqParams)
        break;
      case 'statusType':
        this.getSearchFreezerByStatusType(data,reqParams);
        break;
      default:
         this.searchFreezersByType(data,reqParams)
      break;
    }
  }
  searchFreezersByType(data,reqParams){
    this.isLoading = true;
        this.advSearchSrv.getFreezersByType(data.storageTypes,reqParams).subscribe(res=>{
         this.isNoData = this.advSearchSrv.noData(res.body);
         this.dataSource.data=res.body;
         this.totalStorages=res.headers.get('X-Total-Count');
         this.isLoading = false;
        }) 
  }
   getSearchFreezerByRoom(data,reqParams){
     this.isLoading = true;
     this.advSearchSrv.getFreezerByRoom(data.storageTypes,data.roomSelect,reqParams).subscribe(res=>{
        this.isNoData = this.advSearchSrv.noData(res.body);
        this.dataSource.data=res.body;
       this.totalStorages=res.headers.get('X-Total-Count');
       this.isLoading = false;
      })  
   }
   getSearchFreezerByStatusType(data,reqParams){
      this.isLoading = true;
      this.advSearchSrv.getFreezerByStatusType(data.storageTypes,data.statusSelect,reqParams).subscribe(res=>{
       this.isNoData = this.advSearchSrv.noData(res.body);
       this.dataSource.data=res.body;
       this.totalStorages=res.headers.get('X-Total-Count');
       this.isLoading = false;
      })  
   }
   
  getSearchRefrigerators(data, reqParams){
    switch (data.storageTypes) {
      case 'Upright':case 'Chest':case 'WalkIn':
          this.getSearchRefByType(data,reqParams)
        break;
      default:
        this.searchRefrigerators(reqParams);
        break;
    }
  }
  searchRefrigerators(reqParams){
    this.isLoading = true;
    this.advSearchSrv.getAllRefByLocId(reqParams).subscribe(res=>{
      this.isNoData = this.advSearchSrv.noData(res.body);
      this.dataSource.data=res.body;
      this.totalStorages=res.headers.get('X-Total-Count');
      this.isLoading = false;
    })
  }
  getSearchRefByType(data,reqParams){
    switch (data.status) {
      case 'room':
        this.getSearchRefByRoom(data,reqParams)
        break;
      case 'statusType':
        this.getSearchRefByStatusType(data,reqParams);
        break;
      default:
        this.searchRefBYType(data,reqParams);
      break;
    }
  }
  searchRefBYType(data,reqParams){
    this.isLoading = true;
    this.advSearchSrv.getRefByType(data.storageTypes,reqParams).subscribe(res=>{
     this.isNoData = this.advSearchSrv.noData(res.body);
     this.dataSource.data=res.body;
     this.totalStorages=res.headers.get('X-Total-Count');
     this.isLoading = false;
    })  
  }
  getSearchRefByRoom(data,reqParams){
    this.isLoading = true;
    this.advSearchSrv.getRefByRoom(data.storageTypes,data.roomSelect,reqParams).subscribe(res=>{
      this.isNoData = this.advSearchSrv.noData(res.body);
      this.dataSource.data=res.body;
      this.totalStorages=res.headers.get('X-Total-Count');
      this.isLoading = false;
     })  
  }
  getSearchRefByStatusType(data,reqParams){
   this.isLoading = true;
   this.advSearchSrv.getRefByStatusType(data.storageTypes,data.statusSelect,reqParams).subscribe(res=>{
     this.isNoData = this.advSearchSrv.noData(res.body);
     this.dataSource.data=res.body;
     this.totalStorages=res.headers.get('X-Total-Count');
     this.isLoading = false;
    })  
  }
  getSearchIncubators(data, reqParams){
    switch (data.storageTypes) {
      case 'Walk In':case 'Counter Top':case 'Upright':case 'Stacked':
          this.getSearchIncByType(data,reqParams)
        break;
      default:
        this.searchIncubators(reqParams);
        break;
    }
  }
  searchIncubators(reqParams){
    this.isLoading = true;
    this.advSearchSrv.getIncByLocId(reqParams).subscribe(res=>{
      this.isNoData = this.advSearchSrv.noData(res.body);
      this.dataSource.data=res.body;
      this.totalStorages=res.headers.get('X-Total-Count');
      this.isLoading = false;
    })
  }
  getSearchIncByType(data,reqParams){
    switch (data.status) {
      case 'room':
        this.getSearchIncByRoom(data,reqParams)
        break;
      case 'statusType':
        this.getSearchIncByStatusType(data,reqParams);
        break;
      default:
        this.searchIncByType(data,reqParams);
      break;
    }
  }
  searchIncByType(data,reqParams){
    this.isLoading = true;
    this.advSearchSrv.getIncByType(data.storageTypes,reqParams).subscribe(res=>{
     this.isNoData = this.advSearchSrv.noData(res.body);
     this.dataSource.data=res.body;
     this.totalStorages=res.headers.get('X-Total-Count');
     this.isLoading = false;
    })
  }
  getSearchIncByRoom(data,reqParams){
    this.isLoading = true;
    this.advSearchSrv.getIncByRoom(data.storageTypes,data.roomSelect,reqParams).subscribe(res=>{
      this.isNoData = this.advSearchSrv.noData(res.body);
      this.dataSource.data=res.body;
      this.totalStorages=res.headers.get('X-Total-Count');
      this.isLoading = false;
     })  
  }
  getSearchIncByStatusType(data,reqParams){
   this.isLoading = true;
   this.advSearchSrv.getIncByStatusType(data.storageTypes,data.statusSelect,reqParams).subscribe(res=>{
     this.isNoData = this.advSearchSrv.noData(res.body);
     this.dataSource.data=res.body;
     this.totalStorages=res.headers.get('X-Total-Count');
     this.isLoading = false;
    })  
  }
  getSearchOs(data, reqParams){
    switch (data.status) {
      case 'room':
        this.getSearchOsByRoom(data,reqParams)
        break;
      case 'statusType':
        this.getSearchOsByStatusType(data,reqParams);
        break;
      default:
         this.searchOpenShelving(reqParams);
      break;
    }
  }
  searchOpenShelving(reqParams){
    this.isLoading = true;
    this.advSearchSrv.getOsByLocationId(reqParams).subscribe(res=>{ 
      this.isNoData = this.advSearchSrv.noData(res.body);
      this.dataSource.data=res.body;
      this.totalStorages=res.headers.get('X-Total-Count');
      this.isLoading = false;
    })
  }
    getSearchOsByRoom(data,reqParams){
      this.isLoading = true;
      this.advSearchSrv.getOsByRoom(data.roomSelect,reqParams).subscribe(res=>{
        this.isNoData = this.advSearchSrv.noData(res.body);
        this.dataSource.data=res.body;
        this.totalStorages=res.headers.get('X-Total-Count');
        this.isLoading = false;
       })  
    }
    getSearchOsByStatusType(data,reqParams){
     this.isLoading = true;
     this.advSearchSrv.getOsByStatusType(data.statusSelect,reqParams).subscribe(res=>{
       this.isNoData = this.advSearchSrv.noData(res.body);
       this.dataSource.data=res.body;
       this.totalStorages=res.headers.get('X-Total-Count');
       this.isLoading = false;
      })  
    }
  
   /** Onchange Page **/
    onChangePage(event: PageEvent) {
       this.paginate.size = event.pageSize;
       this.paginate.page = event.pageIndex;
       this.getSearchStorage(this.storageData,false);
       return event;
    }
   /*Sorting*/
   sortData(event: Sort) {
     this.paginate.sort = event.active + ',' + event.direction;
     this.getSearchStorage(this.storageData,false);
     return event;
   }
 
   /** Excel Sheet Common Function */
   getExcelSheet(data){
    switch (data.storages) {
      case 'freezers':
        this.getExcelSheetFreezer(data);
        break;
      case 'refrigerators':
        this.getExcelSheetRef(data);
        break;
      case 'incubators':
        this.getExcelSheetIncByTyp(data);
        break;
      case 'open shelving':
        this.getExcelSheetOS(data)
    }
   }

   /** Excel Sheet */
   /**Incubators */
   getExcelSheetIncByTyp(data){
    switch (data.status) {
      case 'room':
        this.getExecelSheetIncByRoom(data);
        break;
      case 'statusType':
        this.getExcelSheetIncByStatusType(data);
        break;
      default:
        this.getExcelSheetIncByType(data);
        break;
    }
   }

   getExecelSheetIncByRoom(data){
    this.exportSrv.getExcelSheetIncByTypeRoom(data.storageTypes,data.roomSelect).subscribe(res=>{ this.searchSrv.saveAs(res) });
   }

   getExcelSheetIncByStatusType(data) {
     this.exportSrv.getExcelSheetIncByStatusType(data.storageTypes,data.statusSelect).subscribe(res=> { this.searchSrv.saveAs(res) });
   }

   getExcelSheetIncByType(data) {
     this.exportSrv.getExcelSheetIncByType(data.storageTypes).subscribe(res=> {this.searchSrv.saveAs(res) })
   }

   /** Refrigerators */
   getExcelSheetRef(data) {
      switch ((data.status)) {
        case 'room':
          this.getExcelSheetRefByTypeRoom(data);
          break;
        case 'statusType':
          this.getExcelSheetRefByStatusType(data);
        default:
          this.getExcelSheetRefByType(data);
          break;
      }
  }

   getExcelSheetRefByTypeRoom(data){
     this.exportSrv.getExcelSheetRefByTypeRoom(data.storageTypes,data.roomSelect).subscribe(res=> { this.searchSrv.saveAs(res) });
   }

   getExcelSheetRefByStatusType(data){
     this.exportSrv.getExcelSheetRefByStatusType(data.storageTypes,data.statusSelect).subscribe(res=> { this.searchSrv.saveAs(res) });
   }

   getExcelSheetRefByType(data){
     this.exportSrv.getExcelSheetRefByType(data.storageTypes).subscribe(res=> { this.searchSrv.saveAs(res) });
   }

   /** Open Storage */
   getExcelSheetOS(data){
    switch (data.status) {
      case 'room':
        this.getExcelSheetOSByRoom(data);
        break;
      default:
        this.getExcelSheetOSByStatus(data);
        break;
    }
   }

   getExcelSheetOSByRoom(data){
     this.exportSrv.getExcelSheetOSByRoom(data.roomSelect).subscribe(res=>{ this.searchSrv.saveAs(res) });
   }

   getExcelSheetOSByStatus(data){
     this.exportSrv.getExcelSheetOSByStatus(data.statusSelect).subscribe(res=>{ this.searchSrv.saveAs(res) });
   }

   /** Freezers */
   getExcelSheetFreezer(data){
    switch (data.status) {
      case 'room':
        this.getExcelSheetFreezerByRoom(data);
        break;
      case 'statusType':
        this.getExcelSheetFreezerByStatus(data);
        break;
      default:
        this.getExcelSheetFreezerType(data);
        break;
    }
   }

   getExcelSheetFreezerByRoom(data){
     this.exportSrv.getExcelSheetFreezerByRoom(data.storageTypes,data.roomSelect).subscribe(res=> { this.searchSrv.saveAs(res) });
   }

   getExcelSheetFreezerByStatus(data){
     this.exportSrv.getExcelSheetFreezerByStatus(data.storageTypes,data.statusSelect).subscribe(res=> { this.searchSrv.saveAs(res) });
   }

   getExcelSheetFreezerType(data){
     this.exportSrv.getExcelSheetFreezerType(data.storageTypes).subscribe(res=> { this.searchSrv.saveAs(res) });
   }

  /** PDF Api Integration */
  getPDFStorages(data){
    switch (data.storages) {
      case 'freezers':
        this.getPDFFreezer(data);
        break;
      case 'refrigerators':
        this.getPDFRefrigerator(data);
        break;
      case 'incubators':
        this.getPDFIncubator(data);
        break;
      case 'open shelving':
        this.getPDFOS(data);
        break;
    }
  }

    /** Freezers */
  getPDFFreezer(data){
    switch (data.status) {
      case 'room':
        this.getPDFFreezerByRoom(data);
        break;
      case 'statusType':
        this.getPDFFreezerByStatus(data);
        break;
      default:
        this.getPDFFreezerByType(data);
        break;
    }
  }

  getPDFFreezerByType(data){
    this.exportSrv.getPDFFreezerByType(data.storageTypes).subscribe(res=> { this.searchSrv.openPdf(res) });
  }

  getPDFFreezerByRoom(data){
    this.exportSrv.getPDFFreezerByRoom(data.storageTypes,data.roomSelect).subscribe(res=> { this.searchSrv.openPdf(res) });
  }

  getPDFFreezerByStatus(data){
    this.exportSrv.getPDFFreezerByStatus(data.storageTypes,data.statusSelect).subscribe(res=> { this.searchSrv.openPdf(res) });
  }

  /**Refreigerator */
  getPDFRefrigerator(data){
    switch (data.status) {
      case 'room':
        this.getPDFRefByRoom(data);
        break;
      case 'statusType':
        this.getPDFRefByStatus(data);
        break;
      default:
        this.getPDFRefByType(data);
        break;
    }
  }

  getPDFRefByType(data){
    this.exportSrv.getPDFRefByType(data.storageTypes).subscribe(res=> { this.searchSrv.openPdf(res) });
  }

  getPDFRefByRoom(data){
    this.exportSrv.getPDFRefByRoom(data.storageTypes,data.roomSelect).subscribe(res=> { this.searchSrv.openPdf(res) });
  }

  getPDFRefByStatus(data){
    this.exportSrv.getPDFRefByStatus(data.storageTypes,data.statusSelect).subscribe(res=> { this.searchSrv.openPdf(res) });
  }
   /**Incubator */
   getPDFIncubator(data){
    switch (data.status) {
      case 'room':
        this.getPDFIncByRoom(data);
        break;
      case 'statusType':
        this.getPDFIncByStatus(data);
        break;
      default:
        this.getPDFIncByType(data);
        break;
    }
  }
  getPDFIncByType(data){
    this.exportSrv.getPDFIncByType(data.storageTypes).subscribe(res=> { this.searchSrv.openPdf(res) });
  }

  getPDFIncByRoom(data){
    this.exportSrv.getPDFIncByRoom(data.storageTypes,data.roomSelect).subscribe(res=> { this.searchSrv.openPdf(res) });
  }

  getPDFIncByStatus(data){
    this.exportSrv.getPDFIncByStatus(data.storageTypes,data.statusSelect).subscribe(res=> { this.searchSrv.openPdf(res) });
  }
   /** Open Storage */
   getPDFOS(data){
    switch (data.status) {
      case 'room':
        this.getPDFOSByRoom(data);
        break;
      default:
        this.getPDFOSByStatus(data);
        break;
    }
   }

   getPDFOSByRoom(data){
     this.exportSrv.getPDFOSByRoom(data.roomSelect).subscribe(res=>{ this.searchSrv.openPdf(res) });
   }

   getPDFOSByStatus(data){
     this.exportSrv.getPDFOSByStatus(data.statusSelect).subscribe(res=>{ this.searchSrv.openPdf(res) });
   }
}
