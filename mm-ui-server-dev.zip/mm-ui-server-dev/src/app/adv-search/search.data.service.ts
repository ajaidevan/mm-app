import { Injectable } from "@angular/core";

@Injectable({
  providedIn: 'root'
})

export class SearchDataService {
  public searchType = [
    { value: 'users', viewValue: 'Users' },
    { value: 'receipts', viewValue: 'Receipts' },
    { value: 'storages', viewValue: 'Storages' },
    {value:'reviewer',viewValue:'Reviewer'}
  ];
  public users = [
    { value: 'client', viewValue: 'Client' },
    { value: 'location', viewValue: 'Location' },
    { value: 'userType', viewValue: 'UserType' },
    { value: 'companies', viewValue: 'Companies' },
  ]
  public locationUsers=[
    { value: 'userType', viewValue: 'UserType' },
    { value: 'companies', viewValue: 'Companies' },
  ]

  public userTypes = [
    { value: 'Technician', viewValue: 'Technician' },
    { value: 'QA', viewValue: 'QA' },
    { value: 'Reviewer', viewValue: 'Reviewer' },
  ]

  public storages = [
    { value: 'freezers', viewValue: 'Freezers' },
    { value: 'refrigerators', viewValue: 'Refrigerators' },
    { value: 'incubators', viewValue: 'Incubators' },
    { value: 'open shelving', viewValue: 'Open Shelving/RT' },

  ]
  public freezers = [
    {value: 'Ultra-Low Upright', viewValue: 'Ultra Low Upright'},
    {value: 'Ultra-Low Chest', viewValue: 'Ultra Low Chest'},
    {value: 'LN2', viewValue: 'LN2'},
    {value: 'Freezer Upright ', viewValue: 'Freezer Upright'},
    {value: 'Walk In', viewValue: 'Walk In'},

  ]
  public refrigerators = [
    {value: 'Upright', viewValue: '+5 Upright'},
    {value: 'Chest', viewValue: '+5 Chest'},
    {value: 'WalkIn', viewValue: '+5 Walkin'},

  ]
  public incubators = [
    {value: 'Walk In', viewValue: 'Walk In'},
    {value: 'Counter Top', viewValue: 'Counter Top'},
    {value: 'Upright', viewValue: 'Upright'},
    {value: 'Stacked', viewValue: 'Stacked'},

  ]
  public status = [
    { value: 'room', viewValue: 'Room' },
    { value: 'statusType', viewValue: 'Status Type' },
  ]

  public statusTypes = [
    {value:'N/A', viewValue:'NA'},
    {value:'Quarantine', viewValue:'Quarantine'},
    {value:'Release', viewValue:'Release'},
    {value:'Reject', viewValue:'Reject'},
  ]
  public receipts = [
    { value: 'status', viewValue: 'Status' },
    { value: 'receipt_no', viewValue: 'Receipt No' },
    { value: 'receipt_creation_date', viewValue: 'Receipt Creation Date' },
    { value: 'receipt manufacture no', viewValue: 'Receipt Manufacture No' },
    { value: 'qa_approved', viewValue: 'QA Approved' },
    { value: 'damaged', viewValue: 'Damaged' },
  ]
  public changedStatus = [
    { value: true, viewValue: 'Yes' },
    { value: false, viewValue: 'No' }
  ]

  public receiptStatus: any = [
    { status: 'Save as Draft', value: 'DRAFT' },
    { status: 'Pending for Approval', value: 'QA_PENDING' },
    { status: 'Moved to Material Count', value: 'MATERIAL_COUNT' },
    { status: 'Quarantine storage', value: 'QUARANTINE_STORAGE' },
    { status: 'Release storage', value: 'RELEASE_STORAGE' },
    { status: 'Rejected', value: 'REJECTED' },
    { status: 'Shipped', value: 'SHIPPED' },
    { status: 'Create', value: 'CREATE' },
    { status: 'All', value: 'QA_PENDING,SHIPPED,APPROVED' },
    { status: 'Shipped', value: 'SHIPPED,REJECTED' },
  ]
  public qaApprovedStatus: any = [
    { status: 'Yes', value: 'APPROVED' },
    { status: 'No', value: 'NO' }
  ]
  public reviewerType:any=[
    {value:'receipts',viewValue:'Receipts'},
    {value:'companies',viewValue:'Companies'}
   ]

  /** Exporting PDF */  
  openPdf(res){
    if(res){
      let file = new Blob([res], { type: 'application/pdf' }); 
      var fileURL = URL.createObjectURL(file);
      window.open(fileURL);
    }
  }
  /** Exporting Excel Sheet */  
  public saveAs(res){
    if(res){
      let file = new Blob([res], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }); 
      let link = document.createElement("a");
      if (link.download !== undefined) {
        let url = URL.createObjectURL(file);
        link.setAttribute("href", url);
        link.setAttribute("download", `advance-searcg-download-${new Date()}`);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      }
    }
  }
}

