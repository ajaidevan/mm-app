import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { MatFormFieldModule, MatInputModule, MatIconModule, MatCardModule, MatButtonModule, MatListModule, MatProgressBarModule, MatMenuModule, MatSelectModule, MatSortModule, MatTableModule, MatPaginatorModule, MatRadioModule, MatCheckboxModule, MatDialogModule, MatDatepickerModule, MatProgressSpinnerModule } from '@angular/material';
import { FlexLayoutModule } from '@angular/flex-layout';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import{AdvancedSearchRoutes} from 'app/adv-search/adv-search.routing';
import {AdvSearchComponent} from 'app/adv-search/adv-search.component';
import{ AdvSearchService}from 'app/adv-search/adv-search.service';
import { ReceivablesComponent } from './receivables/receivables.component';
import { UsersComponent } from './users/users.component';
import { SearchDataService } from './search.data.service';
import { StoragesComponent } from './storages/storages.component';
import { ExportService } from './export.service';
import { ReviewerComponent } from './reviewer/reviewer.component';

@NgModule({
    declarations: [
     AdvSearchComponent,
     ReceivablesComponent,
     UsersComponent,
     StoragesComponent,
     ReviewerComponent
    ],
    imports: [
      CommonModule,
      CommonModule,
      RouterModule.forChild(AdvancedSearchRoutes),
      MatFormFieldModule,
      MatInputModule,
      MatIconModule,
      MatCardModule,
      MatButtonModule,
      MatListModule,
      MatProgressBarModule,
      MatMenuModule,
      FlexLayoutModule,
      FormsModule,
      ReactiveFormsModule,
      MatSelectModule,
      MatSortModule,
      MatTableModule,
      MatPaginatorModule,
      MatRadioModule,
      MatCheckboxModule,
      MatDatepickerModule,
      MatDialogModule,
      MatCardModule,
      MatProgressSpinnerModule
    ],
    providers:[AdvSearchService,SearchDataService,ExportService]
  })
  export class AdvSearchModule { }
  