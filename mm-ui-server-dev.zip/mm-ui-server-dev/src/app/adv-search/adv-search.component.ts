import { Component, OnInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import { MatPaginator, MatSort, MatDialogConfig, MatDialog, MatTableDataSource, PageEvent, Sort } from '@angular/material';
import { AdvSearchService } from './adv-search.service';
import { AdvanceSearch } from 'app/models/adv-search.model';
import { FormBuilder } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonApiService } from 'app/services/common-api.service';
import { SearchDataService } from './search.data.service';
import { HelperService } from 'app/services/helper.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-adv-search',
  templateUrl: './adv-search.component.html',
  styleUrls: ['./adv-search.component.scss']
})
export class AdvSearchComponent implements OnInit {

  public selectedRow: AdvanceSearch;
  public dataSource = new MatTableDataSource();
  public step: number = 0;
  public user:any;
  public advSearchForm:any;
  public selectedvalue:String;
  public selectedStorages:any=[];
  public usersSelected:any=[];
  public paginateUser:any={};
  public fetchedUserLength:number;
  public receivable:any;
  public showTable:string;
  public storage:any;
  public fetchedRooms:any=[];
  public reviewer:any;
  public companies:any;
  public role:any;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('clientSelect') clientSelect: any;
  @ViewChild('companySelect') companySelect: any;
  @ViewChild('locationSelect') locationSelect: any;

  constructor(private advSearchSrv: AdvSearchService, private dialog: MatDialog, private advSearch: FormBuilder, private route: ActivatedRoute
    , private router: Router, private commonSrv: CommonApiService, public searchDataSrv: SearchDataService, public helperSrv: HelperService,
    private cd:ChangeDetectorRef) { }

  ngOnInit() {

    this.advSearchForm = this.advSearch.group({
      type: [''],
      users: [''],
      selectedUsers: [''],
      storages: [''],
      storageTypes: [''],
      status: [''],
      roomSelect:[''],
      statusSelect:[''],
      receipts: [''],
      receiptNo: [''],
      receiptCreationDate: [''],
      receiptManufactureNo: [''],
      qaApproved: [''],
      damaged: [''],
      receiptsStatus: [''],
      loadType:[''],
      reviewer:[''],
      companyId:[''],
    })

    if(this.helperSrv.getRoles().includes('Admin')){
      this.searchDataSrv.searchType = this.searchDataSrv.searchType.slice(0,3);
    }
  }

  /**paginate  as load more  */
  loadMore(data) {
    this.paginateUser.size = this.paginateUser.size + 10;
    switch (data.users) {
      case 'client':
        this.getLoadMoreCLients();
        break;
      case 'location':
        this.getLoadMoreLocations();
        break;
      default:
        this.getLoadMoreCompanies();
        break;
    }
  }


  //Load More
  getLoadMoreCLients() {
    this.clientSelect.open();
    this.advSearchSrv.getAllClients(this.paginateUser).subscribe(
      data => {
        this.usersSelected = data.body.content;
      }, err => {
        console.log(err);
      })
  }

  getLoadMoreLocations() {
    this.locationSelect.open();
    this.advSearchSrv.getAllLocations(this.paginateUser).subscribe(
      data => {
        this.usersSelected = data.body.content;
      }, err => {
        console.log(err);
      })
  }

  getLoadMoreCompanies() {
    this.companySelect.open();
    if (this.helperSrv.getRoles() == 'role_super_admin') {
      this.advSearchSrv.getAllCompanies(this.paginateUser).subscribe(
        data => {
          this.usersSelected = data.body.content;
        }, err => {
          console.log(err);
        })
    }

    if (this.helperSrv.getRoles() != 'role_super_admin') {
      this.advSearchSrv.getAllCompaniesByLocation(this.paginateUser).subscribe(
        data => {
          this.usersSelected = data.body.content;
        }, err => {
          console.log(err);
        })
    }
  }

  getSearch(data) {
    this.advSearchForm.get('loadType').patchValue('search');
    switch (data.type) {
      case 'users':
        this.getSearchUser(data);
        break;
      case 'receipts':
        this.getSearchReceipt(data);
        break;
      case 'storages':
        this.getSearchStorage(data);
        break;
      case 'reviewer':
        this.getSearchReviewer(data);
      default:
        break;
    }
  }

  getSearchUser(data) {
    this.user = data;
    this.showTable = 'User';
    this.user.show = 'search';
  }

  getSearchReceipt(data) {
    this.receivable = data;
    this.showTable = 'Receipt';
    this.receivable.show = 'search';
  }

  getSearchStorage(data){
    this.storage=data;
    this.showTable='Storage';
    this.storage.show = 'search';
  }

  getSearchReviewer(data){
    this.reviewer=data;
    this.showTable='Reviewer';
    this.reviewer.show='search'
  }
  storageType(data) {
    this.selectedStorages = [];
    if (data.value == 'freezers') {
      this.selectedStorages = this.searchDataSrv.freezers;
    }
    if (data.value == 'refrigerators') {
      this.selectedStorages = this.searchDataSrv.refrigerators;
    }
    if (data.value == 'incubators') {
      this.selectedStorages = this.searchDataSrv.incubators;
    }
  }

  selectedUsers(data) {
    this.usersSelected = [];
    this.paginateUser.page = 0;
    this.paginateUser.size = (this.fetchedUserLength) ? this.fetchedUserLength : 10;
    this.paginateUser.sort = 'creationAt,DESC';
    switch (data.value) {
      case 'client':
        this.getAllClient();
        break;
      case 'location':
        this.getAllLocations();
        break;
      case 'companies':
        this.getAllCompanies();
        break;
      default:
        this.usersSelected = this.searchDataSrv.userTypes;
        break;
    }
  }
  selectedReviewer(data){
    if(data.value=='receipts'){
      this.advSearchSrv.getCompaniesByUserId(this.paginateUser).subscribe(
       data => {
         this.companies = data.body.content;
       }, err => {
        console.log(err);
      })
    }
  }
  selectedStatus(data){
    if(data.value=='room'){
      this.advSearchSrv.getAllRooms().subscribe(res=>{
        this.fetchedRooms=res.body;
      })
    }
  }

  refresh() {
    this.advSearchForm.reset();
    this.router.navigateByUrl('adv-search');
  }

  //Selected User
  getAllClient() {
    this.advSearchSrv.getAllClients(this.paginateUser).subscribe(
      data => {
        this.usersSelected = data.body.content;
      }, err => {
        console.log(err);
      })
  }

  getAllLocations() {
    this.advSearchSrv.getAllLocations(this.paginateUser).subscribe(
      data => {
        this.usersSelected = data.body.content;
      }, err => {
        console.log(err);
      })
  }

  getAllCompanies() {
    if (this.helperSrv.getRoles() == 'role_super_admin') {
      this.advSearchSrv.getAllCompanies(this.paginateUser).subscribe(
        data => {
          this.usersSelected = data.body.content;
        }, err => {
          console.log(err);
        })
    }

    if (this.helperSrv.getRoles() != 'role_super_admin'){
      this.advSearchSrv.getAllCompaniesByLocation(this.paginateUser).subscribe(
        data => {
          this.usersSelected = data.body.content;
        }, err => {
          console.log(err);
        })
    }
  }

  /**Excel Sheet For Users */
  getExportFile(data){
    // this.advSearchForm.get('loadType').patchValue('excel');
    switch (data.type) {
      case 'users':
        this.getExportFileUser(data);
        break;
      case 'storages':
        this.getExportFileStorage(data);
        break;
      case 'receipts':  
      this.getExportFileReceipt(data);
        break;
      case 'reviewer':
        this.getExportFileReviewer(data);
        break;
      default:
        break;
    }
  }

  getExportFileUser(data){
    this.user = data;
    this.user.show = 'print';
    this.showTable = "User"
  }

  getExportFileStorage(data){
    this.storage = data;
    this.showTable='Storage';
    this.storage.show = 'print';
  }

  getExportFileReceipt(data){
    this.receivable = data;
    this.showTable='Receipt';
    this.receivable.show = 'print';
  }
  getExportFileReviewer(data){
    this.reviewer=data;
    this.showTable='Reviewer';
    this.reviewer.show='print';

  }

  async exportFile(){
    /* inputOptions can be an object or Promise */
      const exportData = await Swal.fire({
        title: 'Select export file option',
        input: 'radio',
        showCancelButton: true,
        confirmButtonText:'Export',
        inputOptions: {
          'excel' : 'Excel',
          'pdf':'PDF',
          'both':'BOTH'
        },
        inputValidator: (value) => {
          if (!value) {
            return 'You need to choose something!'
          }
        }
      })
      if(exportData.value){
        this.advSearchForm.get('loadType').patchValue(exportData.value);
        this.getExportFile(this.advSearchForm.value)
        }else if(exportData.dismiss){
        this.advSearchForm.get('loadType').patchValue('');
      }
  }
}
