import { Component, OnInit, Input } from '@angular/core';
import { DataService } from 'app/services/data.service';
import { AdvSearchService } from '../adv-search.service';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonApiService } from 'app/services/common-api.service';
import { MatTableDataSource, PageEvent, Sort } from '@angular/material';
import { HelperService } from 'app/services/helper.service';
import { ExportService } from '../export.service';
import { SearchDataService } from '../search.data.service';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.scss']
})
export class UsersComponent implements OnInit {

  constructor(private advSearchSrv: AdvSearchService, private helpSrv: HelperService,private searchSrv:SearchDataService,
    private router: Router, private commonSrv: CommonApiService,private exportSrv:ExportService,) { }

  public displayedColumns: string[] = ['id', 'firstName', 'lastName', 'email', 'role', 'status'];
  public userData: any;
  public dataSource = new MatTableDataSource();
  public totalReceivable: any;
  public paginate: any = {
    page: 0,
    size: 10,
    sort: 'creationAt,DESC'
  };
  public totalUsers: number;
  public pageSizeOptions = [10, 20, 30];
  public isLoading: boolean = false;
  public pageEvent:PageEvent;
  public isNoData:boolean = false;
  @Input() set user(user: any) {
    this.userData = user;
    if(this.userData.show == 'search') this.getSearchUser(this.userData, false);
    if(this.userData.show == 'print') this.getExportFileUsers(this.userData);
    this.paginate.page = 0;
    this.paginate.size = 10 ;
    this.paginate.sort = 'creationAt,DESC';
  };
  ngOnInit() {
  }

  getExportFileUsers(data){
    switch (data.loadType) {
      case 'excel':
        this.getExcelSheet(data);
        break;
      case 'pdf':
        this.getPDF(data);
        break;
      default:
        this.getExcelSheet(data);
        this.getPDF(data);
        break;
    }
  }
  getSearchUser(data, setPage) {
    if (setPage) this.paginate.page = 0;
    let reqParams = this.commonSrv.createParam(this.paginate);
    this.router.navigate([], { queryParams: reqParams });

    switch (data.users) {
      case 'client':
        this.getSearchUserByClient(data, reqParams);
        break;
      case 'location':
        this.getSearchUserByLoc(data, reqParams);
        break;
      case 'companies':
        this.getSearchUserByCompany(data, reqParams);
        break;
      case 'userType':
        this.getSearchByUserType(data, reqParams);
        break;
      default:
        this.getSearchAllUser(reqParams);
        break;
    }
  }

  getSearchAllUser(reqParams) {
    if (this.helpSrv.getRoles() == 'role_super_admin') {
      this.isLoading = true;
      this.advSearchSrv.getAllUsers(reqParams).subscribe(res => {
        this.isNoData = this.advSearchSrv.noData(res.body.content);
        this.dataSource.data = res.body.content;
        this.totalUsers = res.body['totalElements'];
        this.isLoading = false;
      })
    }
    if (this.helpSrv.getRoles() != 'role_super_admin') {
      this.isLoading = true;
      this.advSearchSrv.getAllUsersByLocation(reqParams).subscribe(res => {
        this.isNoData = this.advSearchSrv.noData(res.body.content);
        this.dataSource.data = res.body.content;
        this.totalUsers = res.body['totalElements'];
        this.isLoading = false;
      })
    }
  }

  getSearchUserByClient(data, reqParams) {
    this.isLoading = true;
    this.advSearchSrv.getSearchUsersByTenantName(data.selectedUsers.tenantName, reqParams).subscribe(res => {
      this.isNoData = this.advSearchSrv.noData(res.body.content);
      this.dataSource.data = res.body.content;
      this.totalUsers = res.body['totalElements'];
      this.isLoading = false;
    })
  }

  getSearchUserByLoc(data, reqParams) {
    this.isLoading = true;
    this.advSearchSrv.getSearchByLocation(data.selectedUsers, reqParams).subscribe(res => {
      this.isNoData = this.advSearchSrv.noData(res.body.content);
      this.dataSource.data = res.body.content;
      this.totalUsers = res.body['totalElements'];
      this.isLoading = false;
    })
  }

  getSearchUserByCompany(data, reqParams) {
    if (this.helpSrv.getRoles() == 'role_super_admin') {
      this.isLoading = true;
      this.advSearchSrv.getSearchByCompanies(data.selectedUsers, reqParams).subscribe(res => {
        this.isNoData = this.advSearchSrv.noData(res.body.content);
        this.dataSource.data = res.body.content;
        this.totalUsers = res.body['totalElements'];
        this.isLoading = false;
      })
    }
    if (this.helpSrv.getRoles() != 'role_super_admin') {
      this.isLoading = true;
      this.advSearchSrv.getSearchByCompaniesUnderLocation(data.selectedUsers, reqParams).subscribe(res => {
        this.isNoData = this.advSearchSrv.noData(res.body.content);
        this.dataSource.data = res.body.content;
        this.totalUsers = res.body['totalElements'];
        this.isLoading = false;
      })
    }
  }

  getSearchByUserType(data,reqParams) {
    if (this.helpSrv.getRoles() == 'role_super_admin') {
      this.isLoading = true;
      this.advSearchSrv.getSearchByUserType(data.selectedUsers, reqParams).subscribe(res => {
        this.isNoData = this.advSearchSrv.noData(res.body.content);
        this.dataSource.data = res.body.content;
        this.totalUsers = res.body['totalElements'];
        this.isLoading = false;
      })
    }
    if (this.helpSrv.getRoles() != 'role_super_admin') {
      this.isLoading = true;
      this.advSearchSrv.getSearchByRolesUnderLocation(data.selectedUsers, reqParams).subscribe(res => {
        this.isNoData = this.advSearchSrv.noData(res.body.content);
        this.dataSource.data = res.body.content;
        this.totalUsers = res.body['totalElements'];
        this.isLoading = false;
      })
    }
  }

  /** Onchange Page **/
  onChangePage(event?: PageEvent) {
    this.paginate.size = event.pageSize;
    this.paginate.page = event.pageIndex;
    this.getSearchUser(this.userData, false);
    return event;
  }

  /*Sorting*/
  sortData(event: Sort) {
    this.paginate.sort = event.active + ',' + event.direction;
    this.getSearchUser(this.userData, false);
  }

  /** Excel Sheet Api Integration */
  getExcelSheet(data){
    switch (data.users) {
      case 'client':
        this.getExcelSheetUsersByTenant(data);
        break;
      case 'location':
        this.getExcelSheetUsersByLocation(data);
        break;
      case 'companies':
        this.getExcelSheetUsersByCompany(data);
        break;
      default:
        this.getExcelSheetUsersByUsrTyp(data);
        break;
    }
  }

  /** Super Admin */
  getExcelSheetUsersByUsrTyp(data){
    if (this.helpSrv.getRoles() == 'role_super_admin') {
      this.exportSrv.getExcelSheetUsersByRole(data.selectedUsers,{}).subscribe(res=>{ this.searchSrv.saveAs(res); })
    }
    if (this.helpSrv.getRoles() != 'role_super_admin') {
      this.exportSrv.getExcelSheetByRole(data.selectedUsers,{}).subscribe(res=>{ this.searchSrv.saveAs(res); })
    }
    
  }

  getExcelSheetUsersByCompany(data){
    if (this.helpSrv.getRoles() == 'role_super_admin') {
      this.exportSrv.getExcelSheetUsersByCompany(data.selectedUsers,{}).subscribe(res=>{ this.searchSrv.saveAs(res); })
    }
    if (this.helpSrv.getRoles() != 'role_super_admin') {
       this.exportSrv.getExcelSheetByCompany(data.selectedUsers,{}).subscribe(res=>{ this.searchSrv.saveAs(res); })
    }
  }

  getExcelSheetUsersByTenant(data){
      this.exportSrv.getExcelSheetUsersByTenant(data.selectedUsers.tenant,{}).subscribe(res=>{ this.searchSrv.saveAs(res); })
  }

  getExcelSheetUsersByLocation(data){
    this.exportSrv.getExcelSheetUsersByLocation(data.selectedUsers,{}).subscribe(res=>{ this.searchSrv.saveAs(res); })
  }

  /** PDF API Integration */
  getPDF(data){
    switch (data.users) {
      case 'client':
        this.getPDFUsersByTenant(data);
        break;
      case 'location':
        this.getPDFUsersByLocation(data);
        break;
      case 'companies':
        this.getPDFUsersByCompany(data);
        break;
      default:
        this.getPDFUsersByRole(data);
        break;
    }
  }

  getPDFUsersByTenant(data){
    this.exportSrv.getPDFUsersByTenant(data.selectedUsers.tenant).subscribe(res=>{ this.searchSrv.openPdf(res) });
  }

  getPDFUsersByCompany(data){
    if (this.helpSrv.getRoles() == 'role_super_admin') {
      this.exportSrv.getPDFUsersByCompany(data.selectedUsers).subscribe(res=>{ this.searchSrv.openPdf(res) });
    }
    if (this.helpSrv.getRoles() != 'role_super_admin') { 
      this.exportSrv.getPDFUserByCompany(data.selectedUsers).subscribe(res=>{ this.searchSrv.openPdf(res) });
     }
  }

  getPDFUsersByRole(data){
    if (this.helpSrv.getRoles() == 'role_super_admin') {
       this.exportSrv.getPDFUsersByRole(data.selectedUsers).subscribe(res=>{ this.searchSrv.openPdf(res) });
    }
    if (this.helpSrv.getRoles() != 'role_super_admin') {  
      this.exportSrv.getPDFUserByRole(data.selectedUsers).subscribe(res=>{ this.searchSrv.openPdf(res) });}
  }

  getPDFUsersByLocation(data){
    this.exportSrv.getPDFUsersByLocation(data.selectedUsers).subscribe(res=>{ this.searchSrv.openPdf(res) });
  }
}
