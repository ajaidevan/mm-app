import { Routes} from '@angular/router';
import {AdvSearchComponent} from 'app/adv-search/adv-search.component';

export const AdvancedSearchRoutes: Routes = [
  {
      path:'',
      redirectTo:'adv-search',
      pathMatch:'full'
  },{
      path:'',
      children:[
          {
          path:'adv-search',
          component:AdvSearchComponent,
        }, 
      ]
  }
];


