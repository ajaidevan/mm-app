import { Component, OnInit, Input, ViewChild,  } from '@angular/core';
import { DataService } from 'app/services/data.service';
import { AdvSearchService } from '../adv-search.service';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonApiService } from 'app/services/common-api.service';
import { MatPaginator, MatSort, MatTableDataSource, PageEvent, Sort } from '@angular/material';
import { ExportService } from '../export.service';
import { SearchDataService } from '../search.data.service';


@Component({
  selector: 'app-reviewer',
  templateUrl: './reviewer.component.html',
  styleUrls: ['./reviewer.component.scss']
})
export class ReviewerComponent implements OnInit {
   
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  public displayedColumns: string[] = ['id','origin', 'vendorName','clientName', 'containerType', 'itemType','quantityType', 'qaNotified', 'recipientNotified', 'createdBy', 'createdAt','receivableDate','isDamaged', 'status'];
  public companyDisplayedColumns:string[]=['createdBy','createdAt','name','clientName']
  public dataSource =  new MatTableDataSource() ;
  public companyDataSource=  new MatTableDataSource() ;
  public totalReceivable:any;
  public paginate: any = {
    page:0,
    size:10,
    sort:'createdAt,DESC'
  };
  public paginateCompanies:any={
    page:0,
    size:10,
    sort:'creationAt,DESC'
  }
  public reviewerData:any;
  public pageSizeOptions=[10,20,30];
  public isLoading:boolean = false;
  public pageEvent:PageEvent;
  public reviewerType:any;
  public totalCompanies:any;
  public isNoData:boolean = false;
  constructor(private dataSrv:DataService,private advSearchSrv:AdvSearchService,private exportSrv:ExportService,
    private router: Router,private commonSrv:CommonApiService,private searchSrv:SearchDataService,) { }
    @Input() set reviewer(reviewer:any){
      this.reviewerData =reviewer;
      if(this.reviewerData.show == 'search') this.getSearchReviewer(this.reviewerData,false);
      if(this.reviewerData.show == 'print') this.getExportFile(this.reviewerData);
      this.paginate.page = 0;
      this.paginate.size = 10 ;
      this.paginate.sort = 'createdAt,DESC';
    };
  

  ngOnInit() {
  }
  getSearchReviewer(data,setPage){
    if (setPage) this.paginate.page = 0;
    let reqParams = this.commonSrv.createParam(this.paginate);
    this.router.navigate([],{queryParams:reqParams});
    this.reviewerType=data.reviewer

    switch (data.reviewer){
      case 'receipts':
      this.searchReceiptsByCompany(data,reqParams);
      break;
      case 'companies':
        this.searchCompanies();
        break;
      default:
        break;
    }
  }
  searchReceiptsByCompany(data,reqParams){
    this.isLoading = true;
    this.advSearchSrv.getReceiptsByCompany(data.companyId,reqParams).subscribe(res=>{
      this.isNoData = this.advSearchSrv.noData(res.body);
      this.dataSource = new MatTableDataSource(res.body);
      this.totalReceivable = res.headers.get('X-Total-Count');
      this.isLoading = false;
    })

  }
  searchCompanies(){
    let reqParams = this.commonSrv.createParam(this.paginateCompanies);
    this.isLoading=true;
    this.advSearchSrv.getCompaniesByUserId(reqParams).subscribe(data=>{
      this.isNoData = this.advSearchSrv.noData(data.body.content);
      this.companyDataSource = new MatTableDataSource(data.body.content);
      this.totalCompanies =data.body['totalElements'];
      this.isLoading=false;
    })
  }
  sortData(event: Sort){  
    if(this.reviewerType=='receipts'){
    this.paginate.sort = event.active + ',' + event.direction;
    }
    else{
      this.paginateCompanies.sort=event.active+','+event.direction;
    }
    this.getSearchReviewer(this.reviewerData,false);
  }

    /** On change Page */
  onChangePage(event: PageEvent) {
    if(this.reviewerType=='receipts'){
      this.paginate.size = event.pageSize;
      this.paginate.page = event.pageIndex;
    }
    else{
      this.paginateCompanies.size=event.pageSize;
      this.paginateCompanies.page=event.pageIndex;
    }
    this.getSearchReviewer(this.reviewerData,false);
    return event;
  }
 /**  Receipt Status */
 showReceiptStatus(status){
  let statusOb = this.dataSrv.STATUS.RECEIPT.find(o => o.value === status);
  return statusOb.status;
}
getExportFile(data){
  switch (data.loadType) {
    case 'excel':
      this.getExcelSheetReviewer(data);
      break;
    case 'pdf':
      this.getPDFReviewer(data);
      break;
    default:
      this.getExcelSheetReviewer(data);
      this.getPDFReviewer(data);
      break;
  }
}
getExcelSheetReviewer(data){
  switch (data.reviewer) {
    case 'receipts':
      this.getExcelSheetReceiptsByCompany(data);
      break;
    case 'companies':
      this.getExcelSheetByCompanies();
      break;
    default:
        break;
  }
}
getExcelSheetReceiptsByCompany(data){
  this.exportSrv.getExcelSheetReceiptsByCompany(data.companyId).subscribe(res=> { this.searchSrv.saveAs(res) })
} 
getExcelSheetByCompanies(){
  this.exportSrv.getExcelSheetByCompanies().subscribe(res=>{
    this.searchSrv.saveAs(res);
  })
}

getPDFReviewer(data){
  switch (data.reviewer) {
    case 'receipts':
      this.getPDFReceiptsByCompany(data);
      break;
    case 'companies':
      this.getPdfByCompanies();
      break;
    default:
        break;
  }

}   
getPDFReceiptsByCompany(data){
  this.exportSrv.getPDfReceiptsByCompany(data.companyId).subscribe(res=>{{ this.searchSrv.openPdf(res) }})
}
getPdfByCompanies(){
  this.exportSrv.getPDFByCompanies().subscribe(res=>{{ this.searchSrv.openPdf(res) }})
}

}
