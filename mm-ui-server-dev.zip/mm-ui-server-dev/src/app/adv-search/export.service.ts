import { Injectable } from '@angular/core';
import { CommonApiService } from 'app/services/common-api.service';
import { HelperService } from 'app/services/helper.service';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ExportService {

  constructor(private httpHelper: CommonApiService, private helperSrv: HelperService) { }

   /**Excel Sheet Api for the Storages */
  /**Incubators */
  getExcelSheetIncByTypeRoom(incType,roomName){
    return this.httpHelper.getImage(environment.BASEURL + '/st/incubators/download/excel-sheet?locationId='+this.helperSrv.getLocation()+'&incType='+incType+'&roomName='+roomName,{})
  }

  getExcelSheetIncByStatusType(incType,statusType){
    return this.httpHelper.getImage(environment.BASEURL + '/st/incubators/download/excel-sheet?locationId='+this.helperSrv.getLocation()+'&incType='+incType+'&statusType='+statusType,{})
  }

  getExcelSheetIncByType(incType){
    return this.httpHelper.getImage(environment.BASEURL + '/st/incubators/download/excel-sheet?locationId='+this.helperSrv.getLocation()+'&incType='+incType,{})
  }
  /** Refrigerators */
  getExcelSheetRefByTypeRoom(refType,roomName){
    return this.httpHelper.getImage(environment.BASEURL + '/st/refrigerators/download/excel-sheet?locationId='+this.helperSrv.getLocation()+'&refType='+refType+'&roomName='+roomName,{})
  }

  getExcelSheetRefByStatusType(refType,statusType){
    return this.httpHelper.getImage(environment.BASEURL + '/st/refrigerators/download/excel-sheet?locationId='+this.helperSrv.getLocation()+'&refType='+refType+'&statusType='+statusType,{})
  }

  getExcelSheetRefByType(refType){
    return this.httpHelper.getImage(environment.BASEURL + '/st/refrigerators/download/excel-sheet?locationId='+this.helperSrv.getLocation()+'&refType='+refType,{})
  }

  /** Open Storage */
  getExcelSheetOSByRoom(roomName){
    return this.httpHelper.getImage(environment.BASEURL + '/st/open-storage/download/excel-sheet?locationId='+this.helperSrv.getLocation()+'&roomName='+roomName,{})
  }

  getExcelSheetOSByStatus(statusType){
    return this.httpHelper.getImage(environment.BASEURL + '/st/open-storage/download/excel-sheet?locationId='+this.helperSrv.getLocation()+'&statusType='+statusType,{})
  }

  /** Freezers */
  getExcelSheetFreezerByRoom(freezerType,roomName){
    return this.httpHelper.getImage(environment.BASEURL + '/st/freezers/download/excel-sheet?locationId='+this.helperSrv.getLocation()+'&roomName='+roomName+'&freezerType='+freezerType,{})
  }

  getExcelSheetFreezerByStatus(freezerType,statusType){
    return this.httpHelper.getImage(environment.BASEURL + '/st/freezers/download/excel-sheet?locationId='+this.helperSrv.getLocation()+'&statusType='+statusType+'&freezerType='+freezerType,{})
  }

  getExcelSheetFreezerType(freezerType){
    return this.httpHelper.getImage(environment.BASEURL + '/st/freezers/download/excel-sheet?locationId='+this.helperSrv.getLocation()+'&freezerType='+freezerType,{})
  }

  /** Excel Sheet Api For Receipts */
  getXlStReceivableByRctNo(receiptNo){
    return this.httpHelper.getImage(environment.BASEURL + '/mm/receivables/download/excel-sheet?location='+this.helperSrv.getLocation()+'&receiptNo='+receiptNo,{})
  }

  getXlStReceivableByStatus(status){
    return this.httpHelper.getImage(environment.BASEURL + '/mm/receivables/download/excel-sheet?location='+this.helperSrv.getLocation()+'&status='+status,{})
  }

  getXlStReceivableByCreatedAt(createdAt){
    return this.httpHelper.getImage(environment.BASEURL + '/mm/receivables/download/excel-sheet?location='+this.helperSrv.getLocation()+'&createdAt='+createdAt,{})
  }

  getXlStReceivableByDamage(damaged){
    return this.httpHelper.getImage(environment.BASEURL + '/mm/receivables/download/excel-sheet?location='+this.helperSrv.getLocation()+'&damaged='+damaged,{})
  }

  getXlStReceivableByQaApp(status){
    return this.httpHelper.getImage(environment.BASEURL + '/mm/receivables/download/excel-sheet?location='+this.helperSrv.getLocation()+'&status='+status,{})
  }

  
  /** Excel Sheet Api for Users */
  // Super Admin
  getExcelSheetUsersByRole(roleName,paramObj?){
    return this.httpHelper.getImage(environment.BASEURL + '/auth/users/download/excel-sheet?roleName='+ roleName,paramObj)
  }

  getExcelSheetUsersByCompany(companyName,paramObj?){
    return this.httpHelper.getImage(environment.BASEURL + '/auth/users/download/excel-sheet?company='+ companyName,paramObj)
  }

  getExcelSheetUsersByTenant(tenantId,paramObj?){
    return this.httpHelper.getImage(environment.BASEURL + '/auth/users/download/excel-sheet?tenantId='+ tenantId,paramObj)
  }

  getExcelSheetUsersByLocation(location,paramObj?){
    return this.httpHelper.getImage(environment.BASEURL + '/auth/users/download/excel-sheet?locationName='+ location,paramObj)
  }

  // Location Admin
  getExcelSheetByCompany(companyName,paramObj?){
    return this.httpHelper.getImage(environment.BASEURL + '/auth/users/download/excel-sheet?locationName='+ this.helperSrv.getLocation()+'&tenantId='+this.helperSrv.getTenantId()+'&company='+companyName,paramObj)
  }

  getExcelSheetByRole(roleName,paramObj?){
    return this.httpHelper.getImage(environment.BASEURL + '/auth/users/download/excel-sheet?locationName='+ this.helperSrv.getLocation()+'&tenantId='+this.helperSrv.getTenantId()+'&roleName='+roleName,paramObj)
  }

  /** Export PDF API Receipt */
  
  getPDFReceivableByStatus(status){
    return this.httpHelper.getImage(environment.BASEURL + '/mm/receivables/download/pdf?status='+status+'&location='+this.helperSrv.getLocation(),{})
  }

  getPDFReceivableByReceiptNo(receiptNo){
    return this.httpHelper.getImage(environment.BASEURL + '/mm/receivables/download/pdf?receiptNo='+receiptNo+'&location='+this.helperSrv.getLocation(),{})
  }

  getPDFReceivableByCreatedAt(createdAt){
    return this.httpHelper.getImage(environment.BASEURL + '/mm/receivables/download/pdf?createdAt='+createdAt+'&location='+this.helperSrv.getLocation(),{})
  }

  getPDFReceivableByDamage(damaged){
    return this.httpHelper.getImage(environment.BASEURL + '/mm/receivables/download/pdf?damaged='+damaged+'&location='+this.helperSrv.getLocation(),{})
  }

  getPDFReceivableByQaApproved(qaApproved){
    return this.httpHelper.getImage(environment.BASEURL + '/mm/receivables/download/pdf?status='+qaApproved+'&location='+this.helperSrv.getLocation(),{})
  }

  /** Export PDF API Storages */
  /**Freezers */
  getPDFFreezerByType(freezerType){
    return this.httpHelper.getImage(environment.BASEURL + '/st/freezers/download/pdf?locationId='+this.helperSrv.getLocation()+'&freezerType='+freezerType,{})
  }

  getPDFFreezerByRoom(freezerType,roomName){
    return this.httpHelper.getImage(environment.BASEURL + '/st/freezers/download/pdf?locationId='+this.helperSrv.getLocation()+'&freezerType='+freezerType+'&roomName='+roomName,{})
  }

  getPDFFreezerByStatus(freezerType,statusType){
    return this.httpHelper.getImage(environment.BASEURL + '/st/freezers/download/pdf?locationId='+this.helperSrv.getLocation()+'&freezerType='+freezerType+'&statusType='+statusType,{})
  }

  /** Refrigerator */
  getPDFRefByType(refType){
    return this.httpHelper.getImage(environment.BASEURL + '/st/refrigerators/download/pdf?locationId='+this.helperSrv.getLocation()+'&refType='+refType,{})
  }

  getPDFRefByRoom(refType,roomName){
    return this.httpHelper.getImage(environment.BASEURL + '/st/refrigerators/download/pdf?locationId='+this.helperSrv.getLocation()+'&refType='+refType+'&roomName='+roomName,{})
  }

  getPDFRefByStatus(refType,statusType){
    return this.httpHelper.getImage(environment.BASEURL + '/st/refrigerators/download/pdf?locationId='+this.helperSrv.getLocation()+'&refType='+refType+'&statusType='+statusType,{})
  }

  /**Incubator Pdf */
  getPDFIncByType(incType){
    return this.httpHelper.getImage(environment.BASEURL + '/st/incubators/download/pdf?locationId='+this.helperSrv.getLocation()+'&incType='+incType,{})
  }

  getPDFIncByRoom(incType,roomName){
    return this.httpHelper.getImage(environment.BASEURL + '/st/incubators/download/pdf?locationId='+this.helperSrv.getLocation()+'&incType='+incType+'&roomName='+roomName,{})
  }

  getPDFIncByStatus(incType,statusType){
    return this.httpHelper.getImage(environment.BASEURL + '/st/incubators/download/pdf?locationId='+this.helperSrv.getLocation()+'&incType='+incType+'&statusType='+statusType,{})
  }
  /**Opn storages Pdf */

  getPDFOSByRoom(roomName){
    return this.httpHelper.getImage(environment.BASEURL + '/st/open-storage/download/pdf?locationId='+this.helperSrv.getLocation()+'&roomName='+roomName,{})
  }

  getPDFOSByStatus(statusType){
    return this.httpHelper.getImage(environment.BASEURL + '/st/open-storage/download/pdf?locationId='+this.helperSrv.getLocation()+'&statusType='+statusType,{})
  }

    /** Export PDF API Users */
  /** Super Admin */
  getPDFUsersByTenant(tenantId){
    return this.httpHelper.getImage(environment.BASEURL + '/auth/users/download/pdf?tenantId='+ tenantId,{})
  }

  getPDFUsersByRole(roleName){
    return this.httpHelper.getImage(environment.BASEURL + '/auth/users/download/pdf?roleName='+ roleName,{})
  }

  getPDFUsersByCompany(companyName){
    return this.httpHelper.getImage(environment.BASEURL + '/auth/users/download/pdf?company='+ companyName,{})
  }

  getPDFUsersByLocation(locationName){
    return this.httpHelper.getImage(environment.BASEURL + '/auth/users/download/pdf?locationName='+ locationName,{})
  }

  /**Location Admin */
  
  getPDFUserByRole(roleName){
    return this.httpHelper.getImage(environment.BASEURL + '/auth/users/download/pdf?tenantId='+ this.helperSrv.getTenantId()+'&locationName='+this.helperSrv.getLocation()+'&roleName='+roleName,{});
  }
  getPDFUserByCompany(companyName){
    return this.httpHelper.getImage(environment.BASEURL + '/auth/users/download/pdf?tenantId='+ this.helperSrv.getTenantId()+'&locationName='+this.helperSrv.getLocation()+'&company='+companyName,{});
  }
  /**Reviewer Excel */
  getExcelSheetReceiptsByCompany(companyId){
      return this.httpHelper.getImage(environment.BASEURL + '/mm/receivables/download/excel-sheet?location=' + this.helperSrv.getLocation()+'&company='+companyId,{});
  
    }
  getPDfReceiptsByCompany(companyId){
      return this.httpHelper.getImage(environment.BASEURL + '/mm/receivables/download/pdf?location=' + this.helperSrv.getLocation()+'&company='+companyId,{});
  
  }
  getExcelSheetByCompanies(){
    return this.httpHelper.getImage(environment.BASEURL +  '/auth/company/download/excel-sheet?userId='+ this.helperSrv.getUserId(),{})
  }
  getPDFByCompanies(){
    return this.httpHelper.getImage(environment.BASEURL +  '/auth/company/download/pdf?userId='+ this.helperSrv.getUserId(),{})

  }
}
