import { Injectable } from "@angular/core";
import Swal from 'sweetalert2';
import { HelperService } from "./helper.service";
import { Router } from "@angular/router";
import { AuthService } from "./auth.service";
import { BehaviorSubject } from "rxjs";
import * as $ from 'jquery';
import { DataService } from "./data.service";
@Injectable()
export class ValidatorService {

  constructor(private helper: HelperService, private router: Router, private dataSrv: DataService,
    private authService: AuthService) { }

  /** User Re-autherization for confimation of any Create,Update and Delete*/
  public async userValidator(action?: string) {
    let userEmail = this.helper.getEmail();
    let result = await Swal.fire({
      title: 'Are you sure?',
      text: "You won't be able to revert this!",
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#d33',
      cancelButtonColor: '#999',
      allowOutsideClick:  false,
      confirmButtonText: `Yes, ${action} it!`
    }).then(async (result) => {
      if (result.value) {
        var innerResp = Swal.fire({
          title: 'Confirm Your Password',
          html: `
              <input id="email" class="swal2-input" type="text" value=${userEmail} disabled />
              <input id="password" autocomplete="new-password" class="swal2-input" type="password" placeholder="Enter your password" required autofocus />
              <input id="comments" class="swal2-textarea" type="text" placeholder="Enter your Comments" required/>
              `,
          preConfirm: async () => {

            let email = $('#email').val();
            let password = $('#password').val();
            let comments = $('#comments').val();
            this.dataSrv.getCommentMsg(comments);
            var errors = {
              comments: 'Comments cannot be Empty !',
              password: 'Password cannot be Empty !'
            };
            if (password === '' || comments === '' || comments.toString().trim().length === 0) {
              if (password === '')
                if (!$("#invalid-pwd").length)
                  $('#password').addClass('invalid').after('<div id="invalid-pwd" class="invalid-feedback">' + errors.password + '</div>');
              if (comments === '' || comments.toString().trim().length === 0)
                if (!$("#invalid-cmd").length)
                  $('#comments').addClass('invalid').after('<div id="invalid-cmd" class="invalid-feedback">' + errors.comments + '</div>');
              return false;
            } else {
              $('#comments').removeClass('invalid'); $('#invalid-cmd').remove();
              let user = { email: this.helper.getEmail(), password: $('#password').val() };
              let val = await this.authService.userValidator(user)
                .then(res => {
                  this.helper.showSnackbar(`Successfully ${action}d `);
                  return true;
                }).catch(err => {
                  if (!$("#invalid-pwd").length) {
                    $('#password').addClass('invalid').after('<div id="invalid-pwd" class="invalid-feedback">' + err.error.message + '</div>').val('');
                  }
                  if (!$("#invalid-cmd").length) {
                    $('#comments').addClass('invalid').after('<div id="invalid-pwd" class="invalid-feedback">' + '</div>').val('');
                  }
                  $('#password').addClass('invalid');
                  $("#invalid-pwd").replaceWith('<div id="invalid-pwd" class="invalid-feedback">' + err.error.message + '</div>').val('');
                  Swal.showValidationMessage(
                    `${err.error.message}`
                  )
                  return false;
                });
              return { val: val, comment: comments };
            }
          },
          onOpen: function () {
            $('#password').focus();
          },
          showCancelButton: true,
          confirmButtonColor: '#57ABF6',
          cancelButtonColor: '999',
          confirmButtonText: 'Submit',
          allowOutsideClick: false
        })
          .then((res) => {
            if (res.value) {
              return res.value;
            } else if (res.dismiss === Swal.DismissReason.cancel) {
              return false;
            }
          }).catch(error => {
            return false;
          });
        return innerResp;
      } else {
        return false;
      }

    });
    return result;
  }

}
