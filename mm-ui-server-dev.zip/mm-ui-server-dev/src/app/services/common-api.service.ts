import { Injectable } from '@angular/core';
import { Response } from '@angular/http';
import { HttpHeaders, HttpParams, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { HelperService } from './helper.service';
import { HttpClient } from '@angular/common/http';
import { map, catchError } from 'rxjs/operators';
import { environment } from '../../environments/environment';
import { DataService } from './data.service';

@Injectable()
export class CommonApiService {

  private API_ENDPOINT: string = environment.BASEURL;
  public currentMsg: any;
  public currentOperation: any;
  public role: string;

  /** Token Passed From HEADER */
  createTokenisedHeader(headers={}) {
    let httpOptions = {
      headers: new HttpHeaders({
        // 'Content-Type': 'application/json'
      }),
      params: new HttpParams()
    };
    let token = this.helper.getToken();
    if (token) {
      token = 'Bearer ' + token.trim();
      httpOptions.headers = httpOptions.headers.set('Authorization', token);
    }
    //TODO : We have to remove used code for previous audit-header
    let location = (this.helper.getLocation()) ? this.helper.getLocation() : 'N/A';
    let role = (this.helper.getScope()) ? this.helper.getScope() : (this.role) ? this.role : 'N/A';
    httpOptions.headers = httpOptions.headers.set('locations', location);
    httpOptions.headers = httpOptions.headers.set('role', role);
    if (this.currentMsg) {
      httpOptions.headers = httpOptions.headers.set('create', this.currentOperation);
    }
    
    Object.keys(headers).forEach(key => {
      if (headers[key]) httpOptions.headers = httpOptions.headers.set(key, headers[key]);
    });

    return httpOptions;
  }
 
  constructor(private http: HttpClient,
    private helper: HelperService, private data: DataService) {
    this.data.comment.subscribe(message => this.currentMsg = message);
    this.data.currentRole.subscribe(role => this.role = role);
    this.data.currentOperation.subscribe(currentOperation => this.currentOperation = currentOperation);
  }

  //Function to make GET api call
  getRequest(url: any): Observable<any> {
    return this.http.get(this.API_ENDPOINT + url)
      .pipe(map((response: Response) => {
        return response;
      }))
      .pipe(catchError((error: Error) => {
        return [Observable.throw(error)];
      }));
  }

  //Function to make POST api call
  getRequestWithToken(url: any, paramObj: any = {}, headerObj: any={} ): Observable<any> {
    let httpOptions = this.createTokenisedHeader(headerObj);
    Object.keys(paramObj).forEach(key => {
      if (paramObj[key]) httpOptions.params = httpOptions.params.set(key, paramObj[key]);
    });

    return this.http.get<HttpResponse<Object>>(url, { params: httpOptions.params, headers: httpOptions.headers, observe: 'response' });
  }

  getImage(url: any, paramObj?: any, headerObj?: any): Observable<Blob> {
    let httpOptions = this.createTokenisedHeader(headerObj);
    Object.keys(paramObj).forEach(key => {
      if (paramObj[key]) httpOptions.params = httpOptions.params.set(key, paramObj[key]);
    });
    return this.http.get(url, { params: httpOptions.params,responseType: 'blob', headers: httpOptions.headers });
  }


  //Function to make POST api call
  postRequest(url: any, data: any, headerObj?: any): Observable<any> {
    let httpOptions = this.createTokenisedHeader(headerObj);
    httpOptions.headers = httpOptions.headers.set("Content-Type", "application/json");
    return this.http.post(url, data, httpOptions);
  }

  //Function to make PUT api call
  putRequest(url: any, data: any, headerObj?: any): Observable<any> {
    let httpOptions = this.createTokenisedHeader(headerObj);
    httpOptions.headers = httpOptions.headers.set("Content-Type", "application/json");
    return this.http.put(url, data, httpOptions);
  }

  //Function to make PATCH api call
  patchRequest(url: any, data: any, headerObj?: any): Observable<any> {
    return this.http.patch(this.API_ENDPOINT + url, data, this.createTokenisedHeader(headerObj))
      .pipe(map((response: Response) => {
        return response;
      }))
      .pipe(catchError((error: Error) => {
        return [Observable.throw(error)];
      }));
  }

  //Function to make DELETE api call
  deleteReqeust(url: any, body: any, headerObj?: any): Observable<any> {
    let httpOptions = this.createTokenisedHeader(headerObj);
    httpOptions.headers = httpOptions.headers.set("Content-Type", "application/json");
    let options = {
      headers: httpOptions.headers,
      body: body,
    };
    return this.http.delete(url, options);
  }

  //Function to get data locally
  getLocalData(url: any): Observable<any> {
    let token = this.helper.getToken();
    return this.http.get('../assets/' + url)
      .pipe(map(response => {
        return response;
      }));
  }

  //Post Comment
  postComment(url: String, data): Observable<any> {
    return this.http.post(this.API_ENDPOINT + url, data, this.createTokenisedHeader())
      .pipe(map((response: Response) => {
        return response;
      }))
      .pipe(catchError((error: Error) => {
        return [Observable.throw(error)];
      }));
  }

  // Create Param
  createParam = (obj: any) => {
    let queryParams = {};
    if (obj) {
      Object.keys(obj).forEach(function (key) {
        if (key == 'page') queryParams[key] = obj[key];
        else if (!obj[key]) { }
        else {
          queryParams[key] = obj[key];
        }
      });
    }
    return queryParams;
  };

  // Create Request
  createRequest = (req?: any) => {
    let options: any;
    if (req) {
      let params = new HttpParams();
      params = params.append("page", req.page);
      params = params.append("size", req.size);
      params = params.append("sort", req.sort);
      options = params;
    }
    return options;
  };


}
