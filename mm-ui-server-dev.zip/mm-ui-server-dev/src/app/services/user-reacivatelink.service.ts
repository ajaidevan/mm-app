import { Injectable } from "@angular/core";
import Swal from 'sweetalert2';
import { HelperService } from "./helper.service";
import { AuthService } from "./auth.service";
import { ValidatorService } from "./validator.service";

@Injectable()
export class UserReActivationLinkService {

    constructor(private helper: HelperService, private authService: AuthService, private validatorService: ValidatorService) { }

    /**ReactivateUserOnEmail Changes */
    reactivateUserOnEmailchanges(oldEmail: string, newEmail: string) {
        if (oldEmail != newEmail) {
            Swal.fire({
                title: 'Are you sure?',
                text: "You want to send reactivation link to the email !",
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes',
            }).then((result) => {
                if (result.value) {
                    this.validatorService.userValidator('reactivate').then(res => {
                        if (res.val) {
                            delete res.val;
                            this.authService.reactivateUser(newEmail,res).subscribe(res => {
                                this.helper.showSnackbar("ReActivation Link has been sent to Email successfully!!!");
                            }, err => {
                                this.helper.showSnackbar(err)
                            })
                        }
                    })
                }
            });
        }
    }
}
