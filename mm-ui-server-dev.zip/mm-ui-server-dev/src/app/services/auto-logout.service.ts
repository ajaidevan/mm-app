import { Injectable, NgZone } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from './auth.service';
import { MatDialog } from '@angular/material';

const MINUTES_UNITL_AUTO_LOGOUT = 30 // in Minutes
const CHECK_INTERVAL = 100 // in ms
const STORE_KEY = 'lastAction';
@Injectable({
  providedIn: 'root'
})
export class AutoLogoutService {

  constructor(private router: Router, private ngZone: NgZone, private authSrv: AuthService,
    private dialogRef: MatDialog) {
    this.check();
    this.initListner();
    this.initInterval();
  }

  public get lastAction() {
    return parseInt(localStorage.getItem(STORE_KEY))
  }

  public set lastAction(value) {
    localStorage.setItem(STORE_KEY, value.toString());
  }

  initListner() {
    this.ngZone.runOutsideAngular(() => {
      document.body.addEventListener('click', () => this.reset());
      document.body.addEventListener('keypress', () => this.reset());
      document.body.addEventListener('mousemove', () => this.reset());
      document.body.addEventListener('scroll', () => this.reset());
    });
  }

  initInterval() {
    this.ngZone.runOutsideAngular(() => {
      setInterval(() => {
        this.check();
      }, CHECK_INTERVAL);
    })
  }

  reset() {
    this.lastAction = Date.now();
  }

  check() {
    const now = Date.now();
    const timeLeft = this.lastAction + MINUTES_UNITL_AUTO_LOGOUT * 60 * 1000;
    const diff = timeLeft - now;
    const isTimeout = diff < 0;

    this.ngZone.run(() => {
      if (isTimeout && this.authSrv.isLoggedIn()) {
        this.closeSweetAlertPopup();
        this.dialogRef.closeAll();
        this.authSrv.logOutUser();
      }
    });
  }

  closeSweetAlertPopup(){    
    const sweetAlertCancel = document.querySelector('.swal2-cancel') as HTMLElement;
    const sweetAlertConfirm = document.querySelector('.swal2-confirm') as HTMLElement;
    
    if (sweetAlertCancel) {
        sweetAlertCancel.click(); //only if cancel button exists
    }else if (sweetAlertConfirm) {
      sweetAlertConfirm.click(); //if cancel doesn't exist , confirm is the equivalent for Ok button
    }
  }
}
