import { Injectable } from '@angular/core';
import { MatSnackBar, MatSnackBarConfig } from '@angular/material';
import { CookieService } from 'ngx-cookie-service';
import { BehaviorSubject } from 'rxjs';
import * as CryptoJS from 'crypto-js';
import { environment } from '../../environments/environment';

@Injectable()
export class HelperService {

  private messageSource = new BehaviorSubject('default message');
  public currentMessage = this.messageSource.asObservable();

  constructor(private snackbar: MatSnackBar,
    private cookie: CookieService) { }

  /**ENCRYPT the value */
  encryptValue(data: string) {
    if (data)
      return CryptoJS.AES.encrypt(data.trim(), environment.ENC_SECRET_KEY.trim());
  }

  /**DECRYPT the value */
  decryptValue(data: string) {
    if (data)
      return CryptoJS.AES.decrypt(data.trim(), environment.ENC_SECRET_KEY.trim()).toString(CryptoJS.enc.Utf8)
  }

  /**DECRYPT the token */
  getToken() {
    if (sessionStorage.getItem('token')) {
      let token = this.decryptValue(sessionStorage.getItem("token").trim());
      return token;
    } else {
      return null;
    }
  };

  /** DECRYPT the location */
  getLocation() {
    if (sessionStorage.getItem('mm-lotn')) {
      let location = this.decryptValue(sessionStorage.getItem("mm-lotn").trim());
      return location;
    } else {
      return null;
    }
  };

  /** GET Roles **/
  getRoles() {
    if (sessionStorage.getItem('mm-rl')) {
      let roles = this.decryptValue(sessionStorage.getItem("mm-rl").trim());
      return roles;
    } else {
      return null;
    }
  };

  /**DECRYPT the role  */
  getScope() {
    if (sessionStorage.getItem('mm-scope')) {
      let scope = this.decryptValue(sessionStorage.getItem("mm-scope").trim());
      return scope;
    } else {
      return null;
    }
  };

  /** CHANGE message */
  changeMessage(message: string) {
    this.messageSource.next(message)
  }

  /** DECRYPT the email */
  getEmail() {
    if (sessionStorage.getItem('mm-eml')) {
      return this.decryptValue(sessionStorage.getItem('mm-eml').trim());
    } else {
      return null;
    }
  };

  /** DECRYPT the user-id */
  getUserId() {
    if (sessionStorage.getItem('id')) {
      return this.decryptValue(sessionStorage.getItem('id'));
    } else {
      return null;
    }
  };
  
    /** DECRYPT the user_name */
    getUserName() {
      if (sessionStorage.getItem('username')) {
        return this.decryptValue(sessionStorage.getItem('username'));
      } else {
        return null;
      }
    };

    /** DECRYPT the tenant_name */
    getTenantName() {
      if (sessionStorage.getItem('tenant_name')) {
        return this.decryptValue(sessionStorage.getItem('tenant_name'));
      } else {
        return null;
      }
    };

  /** DECRYPT the tenant-id */
  getTenantId() {
    if (sessionStorage.getItem('tenant_id')) {
      return this.decryptValue(sessionStorage.getItem('tenant_id'));
    } else {
      return null;
    }
  };
  /** DECRYPT the address */
  getLocationAddress() {
    if (sessionStorage.getItem('address')) {
      return this.decryptValue(sessionStorage.getItem('address'));
    } else {
      return null;
    }
  };

  /** DECRYPT the companies */
  getCompanies() {
    if (sessionStorage.getItem('companies')) {
      return JSON.parse(this.decryptValue(sessionStorage.getItem('companies')));
    } else {
      return null;
    }
  };

  /** SHOWS the snack bar */
  showSnackbar(msg,isrefresh:boolean=false,iserror:boolean=false) {
    this.snackbar.open(msg, '', {
      duration: 2500,
      verticalPosition: 'bottom',
      horizontalPosition: 'right',
      panelClass:isrefresh ?'refresh-snackbar': iserror? 'error-snackbar':''
    });
  };

  getFormatedLocations(data){
    let locations = [];
    for(let ln of data.locationsRoles) {
      locations.push(ln.location.name)
   }
   return locations.toString();
  }

}
