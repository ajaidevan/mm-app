import { Injectable } from '@angular/core';
import { CommonApiService } from './common-api.service';
import { BehaviorSubject, Observable, of, Subject } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { HelperService } from './helper.service';
import { Router, ActivatedRoute } from '@angular/router';
import { ExplorerItemType, ExplorerItem } from 'app/shared/explorer/explorer.helper';
import { ExplorerLevel } from 'app/shared/explorer/inventory-explorer/inventory-explorer.component';
import { ExplorerService } from 'app/inventory-management/services/explorer.service';

export type ResultType = "ITEM" | "CASE";
export type ResultObject = { type: ResultType, obj: any; parent: any; parentKey: string; };

const KEY_TO_TYPE: { [key: string]: ExplorerItemType; } = {
  "openStorageId": "OPEN-STORAGE",
  "refId": "REFRIGERATOR",
  "freezerId": "FREEZER",
  "incubatorId": "INCUBATOR"
};

const TYPE_TO_CATEGORY: { [key: string]: ExplorerItemType; } = {
  "OPEN-STORAGE": "OS-STORAGE TYPE",
  "REFRIGERATOR": "REFRIGERATOR-STORAGE TYPE",
  "FREEZER": "FREEZER-STORAGE TYPE",
  "INCUBATOR": "INCUBATOR-STORAGE TYPE",
  "ROOMROW": "ROW-STORAGE TYPE"
};

export type BreadcrumbsEvent = {
  breadcrumbs: ExplorerLevel[];
  result: ResultObject;
};

@Injectable()
export class QuickSearchService {

  private searchBreadcrumbs: ExplorerLevel[] = [];
  private breadcrumbs: ExplorerLevel[] = [];

  public newBreadcrumbs = new BehaviorSubject<BreadcrumbsEvent>(null);
  public loading = new BehaviorSubject<boolean>(false);

  constructor(private api: CommonApiService, private httpClient: HttpClient, private explorerService: ExplorerService,
    private helper: HelperService, private router: Router, private route: ActivatedRoute, private httpRequest: CommonApiService) { }


  //quick serach
  quickSearchCaseById(data) {
    return this.httpRequest.getRequestWithToken(environment.BASEURL + "/st/search/" + data + "/i-cases", {});
  }

  quickSearchItemById(data) {
    return this.httpRequest.getRequestWithToken(environment.BASEURL + "/st/search/" + data + "/items", {});
  }

  /**
   * Main function to generate  the breadcrumbs that will be passed to the Explorer Component
   */
  goToResult(result: ResultObject) {
    // Navigate to explorer
    this.router.navigate(['/explore-inventory/explore-inventory']).then(() => {
      this.loading.next(true);
      this.searchBreadcrumbs = [];
      this.breadcrumbs = [];
      const parentIds: string[] = []; // All parent storages Ids
      let topParent: string; // Top parent ID (Refrigerator/OS/Incubator/Freezer)
      let parentType: ExplorerItemType;
      let roomId: string;


      // get all parents IDs
      // set top parent Id
      Object.keys(result.parent).forEach((key) => {
        if (key.toLowerCase().endsWith("id") && !["seqId", "locationId"].includes(key)) {
          if (["openStorageId", "refId", "freezerId", "incubatorId"].includes(key)) {
            topParent = result.parent[key];
            parentType = KEY_TO_TYPE[key];
          } else if (key == "roomId") {
            roomId = result.parent[key];
            parentType = result.parentKey.toUpperCase() as ExplorerItemType;
            topParent = result.parent.id;
            parentIds.push(result.parent[key]);
          }
          parentIds.push(result.parent[key]);
        }
      });


      if (!roomId) {
        // Search for room Id
        this._searchForRoom(parentType, topParent, roomId, parentIds, () => {     // TODO get it from API to eliminate these extra requests
          this.breadcrumbs = this.searchBreadcrumbs.slice(0, 1);
          // Generate  final breadcumbs
          this._generateBreadcrumbs(parentIds, parentType, result);
        });
      } else {
        // Generate  final breadcumbs
        this._pushLevel(this.breadcrumbs, new ExplorerItem('HOME'), this.explorerService.getAllRoomsByLocation(this.helper.getLocation()), () => {
          this._generateBreadcrumbs(parentIds, parentType, result);
        });
      }

    });

  }

  /**
   * Recursive iterator to generate breadcrumbs by exhausting the ids in parentIds list
   *
   * @param parentIds
   * @param parentType
   * @param result
   */
  private _generateBreadcrumbs(parentIds, parentType, result) {
    if (parentIds.length) {
      const currentLevel = this.breadcrumbs[this.breadcrumbs.length - 1];
      currentLevel.children.forEach(child => {
        let index;
        if (currentLevel.current.type == "ROOM" && child.type != TYPE_TO_CATEGORY[parentType]) {
          index = -1;
        } else {
          index = parentIds.indexOf(child.entity.id);
        }

        if (index > -1) {
          this._pushLevel(this.breadcrumbs, child, this.explorerService.getChildren(child, null), () => {
            parentIds.splice(index, 1);
            this._generateBreadcrumbs(parentIds, parentType, result);
          });
        }

      });
    } else {
      //  send generated breadcrumbs to Inventory explorer component
      this.loading.next(false);
      this.newBreadcrumbs.next({
        breadcrumbs: this.breadcrumbs,
        result
      });
      this.searchBreadcrumbs = [];
      this.breadcrumbs = [];
    }
  }

  /**
   * Get all rooms and search inside for the Inventory type
   *
   * @param parentType
   * @param topParent
   * @param roomId
   * @param parentIds
   * @param cb
   */
  private _searchForRoom(parentType: string, topParent: string, roomId: string, parentIds: string[], cb: Function) {
    this._pushLevel(this.searchBreadcrumbs, new ExplorerItem('HOME'), this.explorerService.getAllRoomsByLocation(this.helper.getLocation()), () => {
      // try all rooms for appropriate storage
      for (const room of this.searchBreadcrumbs[0].children) {
        // try a room
        this._pushLevel(this.searchBreadcrumbs, room, this.explorerService.getChildren(room, null), () => {
          // navigate category
          const cat = this.searchBreadcrumbs[1].children.find(e => e.type == TYPE_TO_CATEGORY[parentType]);
          this.searchBreadcrumbs = this.searchBreadcrumbs.slice(0, 2);

          this._pushLevel(this.searchBreadcrumbs, cat, this.explorerService.getChildren(cat, null), () => {
            const children = this.searchBreadcrumbs.reduce((acc, curr) => { acc.push(...curr.children); return acc; }, []);
            children.forEach(c => {
              if (c.entity && c.entity.id == topParent) {
                roomId = c.entity.roomId;
                if (!parentIds.includes(roomId)) {
                  parentIds.push(roomId, roomId);
                  cb();
                }
              }
            });
          });
        });
      }
    });
  }

  private _pushLevel(breadcrumbs, explorerItem: ExplorerItem, childrenRequest?: Observable<ExplorerItem[]>, callback?: Function) {
    childrenRequest.subscribe(children => {
      breadcrumbs.push({
        current: explorerItem,
        children: children.reduce((acc, i) => acc.concat(i), []) || []
      });
      if (callback) callback();
    });
  }
}
