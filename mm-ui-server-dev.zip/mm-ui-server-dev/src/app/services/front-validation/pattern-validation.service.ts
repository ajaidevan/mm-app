import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class PatternValidationService {

  /** PATTERNS for email,phone number,address ,password and name */
  public numPattern: string = '^-?[0-9]\\d*(\\.\\d{1,2})?$';
  public emailPattern = '^[A-Za-z0-9._%-&]+@[A-Za-z0-9._%&-]+\\.[a-z]{1,6}$';
  public pwdPattern: string = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z]).{8,}$";
  public addressPattern=/^(?:\S.{0,}\S)?$/;
  public namePattern=/^(?:\S.{0,}[a-zA-z])?$/;
  public alphabetPattern:string = "^[a-zA-Z'-/]*$";

  constructor() { }

}
