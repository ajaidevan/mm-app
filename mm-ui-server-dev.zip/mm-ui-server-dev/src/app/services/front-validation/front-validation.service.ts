import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class FrontValidationService {

  constructor() { }

  /** VALIDATION MESSAGE **/
  public validationMsg: any = {
    'firstname': [
      { type: 'required', message: 'First Name is required.' },
      { type: 'pattern', message: 'Numbers & Space are not allowed.' },
      { type: 'maxlength', message: 'First Name must be at max 15 characters long.' }
    ],
    'lastname': [
      { type: 'required', message: 'Last Name is required.' },
      { type: 'pattern', message: 'Numbers are not allowed.' },
      { type: 'maxlength', message: 'Last Name must be at max 15 characters long.' }
    ],
    'name': [
      { type: 'required', message: 'Name is required.' },
      { type: 'pattern', message: 'Numbers & Space are not allowed.' },
      { type: 'maxlength', message: 'User Name must be at max 15 characters long.' }
    ],
    'address': [
      { type: 'required', message: 'Address is required.' },
      { type: 'maxlength', message: 'Address must be at max 250 characters long.' },
      { type: 'pattern', message: 'Spaces are not allowed in beginning and ending.'}
    ],
    'shippingAddress': [
      { type: 'required', message: 'Shipping address is required.' },
      { type: 'maxlength', message: 'Shipping Address must be at max 250 characters long.' },
      { type: 'pattern', message: 'Spaces are not allowed in beginning and ending.'}
    ],
    'email': [
      { type: 'required', message: 'Email is required.' },
      { type: 'pattern', message: 'Email is not valid.' },
      { type: 'maxlength', message: 'Email must be at max 250 characters long.' },
      { type: 'email', message: 'Email is not valid.' },
    ],
    'password': [
      { type: 'required', message: 'Password is required.' },
      { type: 'minlength', message: 'Minmum 8 characters are required.' },
      { type: 'pattern', message: 'Password should contains atleast "1 number, 1 lowercase & 1 uppercase".' }
    ],
    'currentPassword': [
      { type: 'required', message: 'Password is required' },
      { type: 'pattern', message: 'Your password must contain at least one uppercase, one lowercase, one number and be 8 characters long.' }
    ],
    'newPassword': [
      { type: 'required', message: 'Password is required.' },
      { type: 'pattern', message: 'Password must contain at least one uppercase, one lowercase, one number and be 8 characters long.' }
    ],
    'retypePassword': [
      { type: 'required', message: 'Password is required.' },
      { type: 'pattern', message: 'Your password must contain at least one uppercase, one lowercase, one number and be 8 characters long.' },      
    ],
    'phoneNumber': [
      { type: 'required', message: 'Phone Number is required.' },
      { type: 'maxlength', message: 'Phone number must be at max 10 characters long.' },
      { type: 'pattern', message: 'Phone number must be a Number value only.' },
      { type: 'minlength', message: 'Phone must be at least 10 characters long.' }
    ],
    'role': [
      { type: 'required', message: 'Role is required.' },
    ],
    'labelSize':[
      { type: 'required', message: 'Label Size is required.' },
    ],
    'orderNo':[
      { type: 'required', message: 'Order Number is required.' },
    ],
    'manufracturer':[
      { type: 'required', message: 'Manufacturer Name is required.' },
      { type: 'maxlength', message: 'Manufacturer Name must be at max 50 characters long.' },
    ],
    'manufracturerLotNo':[
      { type: 'required', message: 'Manufacturer Lot Number is required.' },
    ],
    'manufracturerBatchNo':[
      { type: 'required', message: 'Manufacturer Batch Number is required.' },
    ],
    'catalogNo':[
      { type: 'required', message: 'Catalog Number is required.' },
    ], 
    'manufracturerDate':[
      { type: 'required', message: 'Manufacturer Date is required.' },
    ],
    'expirationDate':[
      { type: 'required', message: 'Expiration Date is required.' },
    ],
  }
}
