import { Injectable } from "@angular/core";
import Swal from 'sweetalert2';
import { HelperService } from "./helper.service";
import { Router } from "@angular/router";
import { AuthService } from "./auth.service";
import { DataService } from "./data.service";
@Injectable()
export class UserRetrievalService {

  constructor( ) { }

  /** User Re-autherization for confimation of any Create,Update and Delete*/
  public async userRetrievePopup() {
   let response = await Swal.fire({
      title: 'User is Archived ',
      text: " Are You sure You want to Retrive It ?",
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes',
    }).then((res) => {
        if (res.value) {
          return res.value;
        } else if (res.dismiss === Swal.DismissReason.cancel) {
          return false;
        }
    });
    return response;
  }
}
