import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable()
export class DataService {

  private activityLog = new BehaviorSubject('');
  private commentMsg = new BehaviorSubject<any>(''); 
  private operation = new BehaviorSubject<any>('');
  private role = new BehaviorSubject<any>('');
  private searchParam = new BehaviorSubject<any>('');
  private quickSearchParam = new BehaviorSubject<any>('');

  public comment = this.commentMsg.asObservable();
  public currentLog = this.activityLog.asObservable();
  public currentOperation = this.operation.asObservable();
  public currentRole = this.role.asObservable();
  public sharedSearchParam = this.searchParam.asObservable();
  public sharedQParam = this.quickSearchParam.asObservable();
  public STATUS ={
    RECEIPT: [
      { status: 'Save as Draft', value: 'DRAFT' },
      { status: 'Pending for Approval', value: 'QA_PENDING' },
      { status: 'Moved to Material Count', value: 'MATERIAL_COUNT' }, 
      { status: 'Approved', value: 'APPROVED' }, 
      { status: 'Quarantine storage', value: 'QUARANTINE_STORAGE' }, 
      { status: 'Release storage', value: 'RELEASE_STORAGE' }, 
      { status: 'Rejected', value: 'REJECTED' },
      { status: 'Shipped', value: 'SHIPPED' },
      { status: 'Create', value: 'CREATE'},
      { status: 'N/A', value: 'NA_STORAGE'}
    ],
     ALL: 'QA_PENDING,SHIPPED,APPROVED,MATERIAL_COUNT',
     APPROVED:'APPROVED',
     SHIPPED:'SHIPPED,REJECTED',
     DRAFT:'DRAFT',
     QA_PENDING:'QA_PENDING',
  };

  receiptData;
  constructor() { }

  /** ACTIVITY Log to detects the activity of user */
  changeCurrentLog(log: string) {
    this.activityLog.next(log)
  }

  /** COMMENT MESSAGE for delete operation */
  getCommentMsg(data: any) {
    this.commentMsg.next(data)
  }

  /** CHANGE OPERATION for create operation */
  changeOperation(operation:string){
    this.operation.next(operation);
  }


  /** SET CURRENT ROLE for getting the data */
  changeCurrentRole(role:string){
    this.role.next(role);
  }

  /** SET searchParam */
  changeSharedSearchParam(searchParam:any){
    this.searchParam.next(searchParam);
  }
  /** SET searchParam */
  changeQuickSearchParam(searchParam:any){
    this.quickSearchParam.next(searchParam);
  }
}