import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { AuthService } from 'app/services/auth.service';
import { HelperService } from '../helper.service';

@Injectable({
  providedIn: 'root'
})
export class RoleGuard implements CanActivate {

  constructor(private authSrv: AuthService, private router: Router,
    private helperSrv: HelperService) { }

    /** CAN ACTIVATE */
  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    let storedRoles: string[] = this.helperSrv.getRoles().split(",");
  
    if (storedRoles.some(r=> next.data.roles.includes(r))) {
      return true;
    }
    // navigate to not found page
    this.router.navigate(['/error/401']);
    return false;
  }

}
