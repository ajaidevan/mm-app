import { Injectable } from '@angular/core';
import { CommonApiService } from './common-api.service';
import { BehaviorSubject } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { HelperService } from './helper.service';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
import { MatStepper } from '@angular/material';

let httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json'
  })
};

@Injectable()
export class AuthService {

  constructor(private api: CommonApiService, private httpClient: HttpClient,
    private helper: HelperService, private router: Router, private httpRequest: CommonApiService) { }

  private user = new BehaviorSubject<any>("");
  public currentUser = this.user.asObservable();

  /** current selected user */
  setCurrentUser(currentUser: any) {
    this.user.next(currentUser);
  }
  /** list of locations  */
  private locations = new BehaviorSubject("");
  currentLocation = this.locations.asObservable();

  setLocations(locations) {
    this.locations.next(locations);
  }
  /** selected location */
  private locationsSelected = new BehaviorSubject("");
  choosenLocation = this.locationsSelected.asObservable();

  /** selected location */
  changeLocations(locations) {
    this.locationsSelected.next(locations);
  }
  /**selected address */
  changeAddress(address) {
    this.addressSelected.next(address);
  }
  /**selected Address */
  private addressSelected = new BehaviorSubject("");
  choosenAddress = this.addressSelected.asObservable();

  /** selecte Roles and setup access scope*/
  setScope() {
    let encryptedScope = sessionStorage.getItem("scope");
    let scope = this.helper.decryptValue(encryptedScope.trim());
    this.setCurrentUser(scope);
    let encryptedLocation = sessionStorage.getItem("mm-lotn");
    if (encryptedLocation) {
      let selectedLocation = this.helper.decryptValue(encryptedLocation);
      this.changeLocations(selectedLocation);
    }
    let encryptedAddress = sessionStorage.getItem("address");
    if (encryptedAddress) {
      let selectedAddress = this.helper.decryptValue(encryptedAddress);
      this.changeAddress(selectedAddress);
    }
  }

  /** clear scope*/
  clearScope() {
    sessionStorage.clear();
    this.setCurrentUser("");
    this.changeLocations("");
  }

  /** Frontend Client Login */
  userLogin(userObj) {
    let body = new URLSearchParams();
    body.set('username', userObj["username"]);
    body.set('grant_type', "password");
    body.set('password', userObj["password"]);

    let header = new HttpHeaders({
      'Authorization': 'Basic ' + btoa(environment.CLIENT_USERNAME + ':' + environment.CLIENT_PASS),
      'Content-Type': 'application/x-www-form-urlencoded'
    });

    return this.httpClient.post<any>(environment.BASEURL + '/auth/oauth/token', body.toString(), { headers: header });
  }

  /** verify is user logged In*/
  isLoggedIn(): boolean {
    return !!sessionStorage.getItem('token');
  }

  /** logout a user*/
  logOutUser() {
    if (this.isLoggedIn()) {
      this.httpRequest.getRequestWithToken(environment.BASEURL + '/auth/accounts/logout', {}).subscribe(
        res => {
          sessionStorage.clear();
          this.clearScope();
          this.router.navigateByUrl("/authentication/login");
        }, err => {
          console.log("Error :User failed to logged out", err);
        }
      );
      sessionStorage.clear();
      this.clearScope();
      this.router.navigateByUrl("/authentication/login");
    }
  }

  /** change password*/
  changePassword(data, headers) {
    if (this.isLoggedIn() && this.helper.getEmail()) {
      data.email = this.helper.getEmail();
      return this.httpRequest.postRequest(environment.BASEURL + '/auth/accounts/change-password', data, headers);
    } else {
      console.log("Error : Change Password Failed !");
    }
  }

  /** user forget password init */
  forgotPassword(email) {
    return this.httpClient.post<any>(environment.BASEURL + '/auth/accounts/forgot-password/init', email, httpOptions);
  }

  /** user forget password finish */
  forgotPasswordFinish(data) {
    return this.httpClient.post<any>(environment.BASEURL + '/auth/accounts/forgot-password/finish', data, httpOptions);
  }

  /** User validator for confirmation */
  userValidator(data) {
    return this.httpClient.post<any>(environment.BASEURL + '/auth/accounts/re-auth', data, httpOptions).toPromise()
      .then(res => res);
  }

  /**Role matcher for two roles */
  roleMatcher(rolesA1, rolesA2) {
    if (rolesA1 != undefined && rolesA2 != undefined) {
      return rolesA1.some(role => rolesA2.includes(role));
    }
  }

  /** Validate User */
  validateUser(user) {
    return this.httpRequest.getRequestWithToken(environment.BASEURL + "/auth/users/exist?name=" + user , {});
  }

  /** Validate Email */
  validateEmail(email) {
    return this.httpRequest.getRequestWithToken(environment.BASEURL + "/auth/users/exist?name=" + email, {});
  }

  /** Validate Locations */
  validateLocation(location) {
    return this.httpRequest.getRequestWithToken(environment.BASEURL + "/auth/locations/name-exist?name=" + location, {});
  }

  /** Validate Location Email */
  validateLocationEmail(email) {
    return this.httpRequest.getRequestWithToken(environment.BASEURL + "/auth/locations/email-exist?email=" + email, {});
  }

  /**Reactivate user */
  reactivateUser(email, header) {
    return this.httpRequest.getRequestWithToken(environment.BASEURL + "/auth/accounts/resend-activate-link?email=" + email, {}, header);
  }

  loginAuditLog() {
    return this.httpRequest.postRequest(environment.BASEURL + '/auth/accounts/audit-login', {}, {});
  }

  /**reset-confirmation */
  resetConfirmation(stepper: MatStepper) {
    Swal.fire({
      title: 'Are you sure?',
      text: "You want to reset!",
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes',
    }).then((result) => {
      if (result.value) {
        stepper.reset();
      }
    });
  }
  getItemOrIcaseUnderBarcode(data) {
    return this.httpRequest.getRequestWithToken(environment.BASEURL + "/mm/barcodes/text?btext=" + data, {});
  }

  //quick serach
  quickSearchCaseById(data) {
    return this.httpRequest.getRequestWithToken(environment.BASEURL + "/st/search/" + data + "/i-cases", {});
  }
  quickSearchItemById(data) {
    return this.httpRequest.getRequestWithToken(environment.BASEURL + "/st/search/" + data + "/items", {});
  }
  quickSearchItemByBarcode(data) {
    return this.httpRequest.getRequestWithToken(environment.BASEURL + "/st/search/" + data.id + "/items", {});
  }
  quickSearchCaseByBarcode(data) {
    return this.httpRequest.getRequestWithToken(environment.BASEURL + "/st/search/" + data.id + "/i-cases", {});
  }

  getUser() {
    return this.httpRequest.getRequestWithToken(environment.BASEURL + "/auth/accounts/login-user", {});
  }
  retrieveUser(emailId){
    return this.httpRequest.putRequest(environment.BASEURL +"/auth/users/retrieve-user?userEmail="+emailId,{})
  }
  /** REFRESH user */
  refreshUser() {
    return this.httpRequest.getRequestWithToken(environment.BASEURL + "/auth/users/refresh",{});
  }
}
